/*
	Program sachdr

	A utility program to display header components of seismic
	signals stored in the SAC (Seismic Analysis Code of
	Lawrence Livermore Lab) format.  SAC header defaults are
	defined in the sac.h file as some variation on the theme,
	-12345, (the value varies upon the type of variable).
	This enables a simple condition to test if the value is
	set.  The value "zero" is valid and will be printed as
	well.

	Written by John Webber, PASSCAL Instrument Center
		November 04, 1993

VERSION  93.308 --

*/

#include <stdio.h>		/* Standard I/O header file	 */
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#include <parse.h>
#include "sac.h"
#ifdef LINUX
#include <byteswap.h>
#endif

/*  Declare global variables  */
float	   sac_float[70];
int	   sac_int[40];
long	   sac_long[5];
char	   sac_string[23][10];

char	   sac_names[152][12] = {                    
  "delta",	"depmin*",	"depmax*",	"scale",	"odelta",    
  "b",		"e",		"o",		"a",		"internal1", 
  "t0",	"t1",	"t2",	"t3",	"t4",        
  "t5",	"t6",	"t7",	"t8",	"t9",        
  "f",	"resp0",	"resp1",	"resp2",	"resp3",     
  "resp4",	"resp5",	"resp6",	"resp7",	"resp8",     
  "resp9",	"stla",	"stlo",	"stel",	"stdp",      
  "evla",	"evlo",	"evel",	"evdp",	"unused1",   
  "user0",	"user1",	"user2",	"user3",	"user4",     
  "user5",	"user6",	"user7",	"user8",	"user9",     
  "dist",	"az",	"baz",	"gcarc",	"internal2", 
  "internal3",	"depmen",	"cmpaz",	"cmpinc",	"unused2",   
  "unused3",	"unused4",	"unused5",	"unused6",	"unused7",   
  "unused8",	"unused9",	"unused10",	"unused11",	"unused12",  
  "nzyear",	"nzjday",	"nzhour",	"nzmin",	"nzsec",     
  "nzmsec",	"internal4",	"internal5",	"internal6",	"npts",      
  "internal7",	"internal8",	"unused13",	"unused14",	"unused15",  
  "iftype",	"idep",	"iztype",	"unused16",	"iinst",     
  "istreg",	"ievreg",	"ievtyp",	"iqual",	"isynth",    
  "unused17",	"unused18",	"unused19",	"unused20",	"unused21",  
  "unused22",	"unused23",	"unused24",	"unused25",	"unused26",  
  "leven",	"lpspol",	"lovrok",	"lcalda",	"unused27",  
  "kstnm[8]*",	"kevnm[16]",           
  "khole[8]",	"ko[8]",	"ka[8]",               
  "kt0[8]",	"kt1[8]",	"kt2[8]",              
  "kt3[8]",	"kt4[8]",	"kt5[8]",              
  "kt6[8]",	"kt7[8]",	"kt8[8]",              
  "kt9[8]",	"kf[8]",	"kuser0[8]",           
  "kuser1[8]",	"kuser2[8]",	"kcmpnm[8]",           
  "knetwk[8]",	"kdatrd[8]",	"kinst[8]*",            
};

/*   *****   from here to main --> definitions for command line parser   ******/

#define my_entry(swit,count,type,store,size) p_entry \
        ("-", (swit), P_CASE_INSENSITIVE, (count), (type), (store), (size))
#define MAX_OTHERS 2000

int             show_help = 0;
int             little_endian = 0;

char           *Files[MAX_OTHERS];

char           *prognam;

arg_info        table[] = {
  my_entry("h", P_NO_ARGS, P_INT, &show_help, 1),
  my_entry("?", P_NO_ARGS, P_INT, &show_help, 1),
  my_entry("l", P_NO_ARGS, P_INT, &little_endian, 1),
};                              /* table */

#define table_size (sizeof (table) / sizeof (arg_info))

#define PROG_VERSION "2002.353"

void
swapFloats (unsigned int *data, int num)
{
  int i;
  typedef union {
    float f;
    char c[4];
  } number ;

  number little_endian;
  number big_endian;

  for (i = 0; i < num; i++) {
#ifdef LINUX
    data[i] = bswap_32 (data[i]);
#else
    little_endian.f = (float) data[i];
    big_endian.c[0] = little_endian.c[3];
    big_endian.c[1] = little_endian.c[2];
    big_endian.c[2] = little_endian.c[1];
    big_endian.c[3] = little_endian.c[0];
    data[i] = (long int) big_endian.f;
#endif
  }
}

main (argc, argv)
     int	argc;
     char   *argv[];
{
  struct sac     *sp;
  
  FILE           *ifp;
  
  int		i, j;
  

  if (argc == 2 && strcmp(argv[1], "-#") == 0) {
    printf("%s\n", PROG_VERSION);
    exit(0);
  }

  prognam = argv[0];
  
  fprintf(stdout, "%s:  Version no. %s\n\n", prognam, PROG_VERSION);
  
  if (!parse_args(argc, argv, table, table_size, Files, MAX_OTHERS)) {
    fprintf(stderr, "%s:  Illegal arguments, quitting\n", prognam);
    exit(1);
  }
  
  if (show_help || argc == 1) {
    do_show_help();
    exit(0);
  }
  
  
  if ((sp = (struct sac *) calloc (1, sizeof(struct sac)) ) == NULL)  {
    fprintf(stderr, "%s: Out of memory allocating SAC header\n", prognam);
	exit(1);
  }

  for (j = 0; Files[j]; j++)  {
    if (!(ifp = fopen(Files[j], "r"))) {
      fprintf(stderr, "%s: Unable to open sac file %s.\n", prognam, Files[j]);
      continue;
    }

    if (!(fread(sp, sizeof(struct sac), 1, ifp))) {
      fprintf(stderr, "%s: Unable to read header from: %s\n", 
	      prognam, Files[j]);
      fclose(ifp);
      continue;
    }
    fclose(ifp);
    
#ifdef LINUX
    if (! little_endian)
      swapFloats ((long int *) sp, 110);
#else
    if (little_endian)
      swapFloats ((long int *)sp, 110);
#endif
    read_sac_values (sp);
    
    fprintf(stdout, "\n\n%s HEADER VALUES\n\n", Files[j]);
    
    /* This loop prints SAC header values that differ from the default  */
    for (i=0; i<132; i++)  {
      if (i < 70 && sac_float[i] != -12345.0)  
	fprintf(stdout, "%10s      = %14.5f\n", sac_names[i], sac_float[i]);
      if (i >= 70 && i < 105 && sac_int[i-70] != -12345)
	fprintf(stdout, "%10s      = %8d\n", sac_names[i], sac_int[i-70]);
      if (i >= 105 && i < 110 && sac_long[i-105] != -12345L)
	fprintf(stdout, "%10s      = %8d\n", sac_names[i], sac_long[i-105]);
      if (i >= 110 &&  memcmp(sac_string[i-110], "-12345  ", 8))
	fprintf(stdout, "%10s      = %8s\n", sac_names[i], sac_string[i-110]);
    }
    
    
  }
}

do_show_help()
{
  
    fprintf(stderr, "Usage: %s\t[-l] sac_files\n", prognam);
    fprintf(stderr, "\t\t -l\tFile is in little endian byte order.\n");
    
}

