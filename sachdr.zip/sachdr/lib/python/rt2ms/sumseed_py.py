
from distutils.core import setup, Extension

setup (name = "mseed_py", version = "2010.084",
       ext_modules = [
    Extension (
    "mseed_py", ["mseedwrapper_py.c"],
    #extra_compile_args = ["-g"],
    #extra_link_args = ["-m32"],
    include_dirs=['../libmseed'],
    library_dirs=['../libmseed'],
    libraries=['mseed']
)])
