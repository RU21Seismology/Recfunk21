#!/bin/bash

rm -v -f 2*.m 2*.log 2*.err 2*.run
rm -v -f *.pyc *.so
rm -v -rf ./build
