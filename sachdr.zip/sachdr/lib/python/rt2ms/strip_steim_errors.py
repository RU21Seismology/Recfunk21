#!/usr/bin/env python

import re

ErrorRE = re.compile (".*Mismatch.*")

fh = open ("ckreftek.log")

while 1 :
    line = fh.readline ()
    if not line : break
    if ErrorRE.match (line) :
        flds = lastline.split ()
        if len (flds) > 3 and flds[3] != '0' :
            print '*', lastline,
            print line,
        else :
            print lastline,
            print line,

    lastline = line
    
