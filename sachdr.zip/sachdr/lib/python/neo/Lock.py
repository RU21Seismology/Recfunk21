#!/usr/bin/env python

from threading import Lock

class lock :
    LOCK = Lock ()