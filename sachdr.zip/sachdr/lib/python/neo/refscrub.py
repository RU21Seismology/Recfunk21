#!/usr/bin/env python
'''
Lloyd Carothers
February 2011
Rewrite of original refscrub
'''
from __future__ import with_statement
USAGE = 'usage: %prog [options] infile1 [ infile2 ... infileN]'
#USAGE = '''Scans (default) or extracts good reftek packets from a REFTEK file or CF card.'''

PROG_VERSION = '2011.046'
VERBOSE = False
EXTRACT = False
SUMMARY_FILE = 'scrubsum.txt'

tabs = "\t\t\t\t"

from os.path import join, basename, getsize
import sys
import struct

class SN():
    def __init__(self, SN):
        self.SN = SN
        self.count = 0
        self.dates = list()
        if EXTRACT:
            self.outfh  = open( PREFIX + '.' + SN +'.scrub.ref', 'ab')
        else:
            self.outfh = None
    def look(self, year, day, hour):
        self.dates.append((year, day, hour))
        self.count += 1
    def close_fh(self):
        if self.outfh is not None:
            self.outfh.close()
    def __str__(self):
        self.dates = list(set(self.dates))
        self.dates.sort()
        start = "%0.2d:%0.3d:%0.2d" % (self.dates[0]) 
        end   = "%0.2d:%0.3d:%0.2d" % (self.dates[-1]) 
        return "%7s: %s -- %s : %12d\n" % (self.SN , start , end, self.count )

class SNseen(dict):
    def look(self, sn, year, day, hour):
        ret = self.setdefault(sn,SN(sn) )
        ret.look(  year, day, hour)
    def close_fhs(self):
        for sn in self.values():
            sn.close_fh()
    def __str__(self):
        s = "     SN: YR:DAY:HR -- YR:DAY:HR : %12s\n" % 'Good Packets'
        for sn in self.values():
            s += str(sn)
        return s
        

##class SNseen(dict):
##    def __init__(self):
##        self.outfiledict = dict()
##    def look(self, SN, year, day, hour):
##        ret = self.setdefault(SN, list())
##        #make a file for a new seen SN
##        if EXTRACT and not self.outfiledict.has_key(SN) :
##            self.outfiledict[SN] = open( PREFIX + '.' + SN +'.scrub.ref', 'ab')
##        if (year, day, hour) not in ret:
##            self[SN].append((year, day, hour))
##    def close_fhs(self):
##        for fh in self.outfiledict.values():
##            fh.close()
##    def __str__(self):
##        s = "     SN: YR:DAY:HR -- YR:DAY:HR\n"
##        for sn in self.keys():
##            dates = self[sn]
##            dates.sort()
##            start = "%0.2d:%0.3d:%0.2d" % (dates[0]) 
##            end   = "%0.2d:%0.3d:%0.2d" % (dates[-1]) 
##            s += "%7s: %s -- %s\n" % (sn , start , end )
##        return s
        
class RTPacket:
    RTstruct = struct.Struct('2c1B1B2B6B2B2B')
    #packetHdrFmt = '2c1B1B2B6B2B2B'
    packet_types = ( 'AD', 'CD', 'DS', 'DT', 'EH', 'ET', 'OM', 'SH', 'SC')
    seen =  SNseen()
    goodpkts = 0
    def __init__(self, data):
        self.data = data
        self.valid = None
    def __str__(self):
        self.settimestring()
        s = "%(sequence)s %(ptype)s %(sn)s %(timestring)s" % self.__dict__
        return s
    def write(self):
        outfh = RTPacket.seen[self.sn].outfh
        #outfh = RTPacket.seen.outfiledict[self.sn]
        try:
            outfh.write(self.data)
        except Exception, e:
            print "Failed to write extracted data to %s" 
            print e
    def settimestring(self):
            self.timestring = "%(year)0.2d:%(day)0.3d:%(hour)0.2d:%(min)0.2d:%(sec)0.2d.%(millisec)0.3d" % self.__dict__
    def isvalid(self):
        '''
        Returns True if a valid reftek packet (headers parse well and are valid)
        Also populates the objects attributes SN, time, etc.
        '''
        try:
            tup = RTPacket.RTstruct.unpack(self.data[:16])
            #tup = unpack( self.packetHdrFmt, self.data[:16])
            self.ptype = tup[0] + tup[1]
            assert self.ptype in self.packet_types, "BAD packet type"
            self.expnum = int("%0.2X" % tup[2])
            self.year = int("%0.2X" %tup[3])
            self.sn = "%0.2X%0.2X" % (tup[4] , tup[5] )
            assert '9001' <= self.sn, "BAD SN"
            assert self.sn <= 'FFFF' , "BAD SN"
            time = "%0.2X%0.2X%0.2X%0.2X%0.2X%0.2X" % tup[6:12]
            self.day, self.hour, self.min, self.sec, self.millisec = \
            int(time[:3]),int(time[3:5]),int(time[5:7]),int(time[7:9]),int(time[9:])
            assert self.day <= 366, "BAD TIME"
            assert self.hour <=24, "BAD TIME"
            assert self.min <= 60, "BAD TIME"
            assert self.sec <=80, "BAD TIME"
            assert self.millisec <=1000, "BAD TIME"
            self.bytecount = int("%0.2X%0.2X" % tup[12:14])
            assert self.bytecount >= 24, "BAD byte count"
            assert self.bytecount <= 1024, "BAD bytecount"
            self.sequence = int("%0.2X%0.2X" % tup[14:16])
        #not a valid packet
        except Exception , e:
            if VERBOSE:
                print tabs +"Not a valid REFTEK packet"
                print tabs + str(e)
            self.valid = False
            return False
        #parsed well :: valid packet
        else:
            self.valid = True
            RTPacket.seen.look(self.sn, self.year, self.day, self.hour)
            RTPacket.goodpkts +=1
            return True
    
def readfile(infile):
    ticker = 1
    #speedup local vars
    tell = infile.tell
    read = infile.read
    seek = infile.seek
    while True:
        ticker += 1
        if VERBOSE is False and ticker == 100000:
            print summary()
            ticker = 1
        if VERBOSE: print "OFFSET: %12d" % tell()
        # often disk wont read
        try:
            buffer = read(1024)
        except IOError:
            print tabs + "IOError on read"
            print "Skipping 1MB.."
            seek(1024*1024, 1)
            continue
        #End of file
        if len(buffer) < 1024:
            if VERBOSE: print "Partial packet"
            break
        p = RTPacket(buffer)
        valid = p.isvalid()
        # Packet is good
        if valid:
            if EXTRACT:
                p.write()
            if VERBOSE:
                print p
                print "<<<<<<<"
        #packet is bad
        else:
            if VERBOSE:
                print tabs + "NOT VALID"
                print tabs + ">>>>>>>>"
            seek(-1023, 1)
            
    print summary()
    RTPacket.seen.close_fhs()
    
def summary():
    OFFSTRING = "%6s: %12d\n"
    s =  OFFSTRING % ( "OFFSET", infile.tell())
    s += OFFSTRING % ( "OF", FILESIZE)
    s += "Good packets: %d = %8.2fMB\n" % (RTPacket.goodpkts, RTPacket.goodpkts / 1024.0)
    s += str(RTPacket.seen) + '\n'
    return s
    

if __name__ == '__main__':
    from optparse import OptionParser
    parser = OptionParser(USAGE, version = "%prog " + PROG_VERSION)
    parser.description = "infile can be a REFTEK file or a raw disk (/dev/disk1) of a CF card."
    parser.add_option('-v', '--verbose', dest="VERBOSE", action = 'store_true', default=False, 
                      help = "Prints info about each packet, good or bad. This will increase runtime.")
    parser.add_option('-e', '--extract', dest='EXTRACT', action = 'store_true', default=False,
                      help = 'Writes good packets to files named infile.SNXX.scrub.ref OR PREFIX.SNXX.scrub.ref, if given, for each Serial Number found. If output file exists it will append. Be careful not to duplicate data by running more than once on the same file in the same dir.' )
    parser.add_option('-p', '--prefix', dest='PREFIX', 
                      help = 'Prefix of output filename. Defaults to inputfilename' )
    parser.add_option('-s', '--savesum', dest = 'SUMMARY', action = 'store_true', default = False,
                      help = 'Appends summary to %s' % SUMMARY_FILE)
    options, args = parser.parse_args()
    VERBOSE = options.VERBOSE
    EXTRACT = options.EXTRACT 
    PREFIX = options.PREFIX
    if options.SUMMARY:
        summaryfh = open (SUMMARY_FILE, 'a')
    for infilename in args:
        print "Processing: %s" % infilename
        if not PREFIX:
            PREFIX = basename(infilename)
        print "Using prefix %s" % PREFIX
        FILESIZE = getsize(infilename)
        with open(infilename) as infile:
            #with open( infile.name + 'scrub.ref')) as outfile:
                #import profile
                #profile.run('readfile(infile)')
            readfile(infile)                
            if options.SUMMARY:
                summaryfh.write(infilename + ', ' + PREFIX + '\n' )
                summaryfh.write(summary())
            
        print "----------------------------------------"