#!/usr/bin/env bash

rm -f *~ *.pyc
