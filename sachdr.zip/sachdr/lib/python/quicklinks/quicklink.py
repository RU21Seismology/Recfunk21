#!/usr/bin/env python

from Tkinter import *
from FileDialog import *
from TkFileDialog import *
from tkSimpleDialog import askinteger
import tkMessageBox
import string
from sys import stderr
from QuickLinks import *
from Event import *

TRUE = (1 == 1)
FALSE = not TRUE

#
#    Over ride some methods in FileDialog so we only select directories
#
class DirectoryDialog (FileDialog) :
    def __init__ (self, root) :
        FileDialog.__init__ (self, root)

    #   Only allow selection of directories (single click)
    def files_select_event (self, e) :
        pass
    #   Double click
    def files_double_event (self, e) :
        pass

    #   Make sure it's a directory and accessable
    def ok_command (self) :
        file = self.get_selection ()
        if not os.path.isdir (file) :
            if not os.access (file, R_OK) :
                self.root.bell ()
                file = None
        
        self.quit (file)

class QLink (Frame) :
    def __init__ (self, root, **kw) :
        apply (Frame.__init__, (self, root), kw)
        self.root = root
        self.haveEvent = FALSE
        self.havePath = FALSE
        self.haveFiles = FALSE
        self.prev = self.path = ''
        self.root.resizable (0, 0)
        self.event = None
        self.tree = None
        self.tol = 30

        #    Set up File menu
        self.menuFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        self.menuFrame.pack (side = TOP, fill = X)
        self.fileMenu = Menubutton (self.menuFrame, text = 'File')
        self.fileMenu.pack (side = LEFT)
        self.fileMenu.menu = Menu (self.fileMenu)
        self.fileMenu.menu.add_command (label = 'Search Path...',
                                        command = self.getPath)
        self.fileMenu.menu.add_command (label = 'Event File...',
                                        command = self.getEvent)
        self.fileMenu.menu.add_command (label = 'Set Tolerance...',
                                        command = self.getTol)
        self.fileMenu.menu.add_separator ()
        self.fileMenu.menu.add_command (label = 'Quit',
                                        command = self.goByeBye)
        self.fileMenu['menu'] = self.fileMenu.menu
        self.menuFrame.tk_menuBar (self.fileMenu)

        #   Frame for things we find
        self.foundFrame = Frame (self, relief = RIDGE, borderwidth = 3)
        self.foundFrame.pack ()
        
        #   List box label
        self.listLabelFrame = Frame (self.foundFrame)
        self.listLabelFrame.pack (side = TOP, fill = X)
        Label (self.listLabelFrame, text = 'Events:').pack ()
        
        #    Set up list box
        self.listFrame = Frame (self.foundFrame)
        self.listFrame.pack (side = TOP)
        self.listBox = Listbox (self.listFrame,
                                width = 19,
                                height = 5,
                                selectmode = MULTIPLE,
                                font = ('MS', 12, 'bold'))
        #self.listBox.bind ('<Double-ButtonRelease-1>', self.getList)
        self.listBox.pack (side = LEFT)
        self.scrollBar = Scrollbar (self.listFrame,
                                    relief = GROOVE,
                                    borderwidth = 2,
                                    command = self.listBox.yview)
        self.scrollBar.pack (side = RIGHT, fill = Y)
        self.listBox.configure (yscrollcommand = self.scrollBar.set)

        #    First trace widget
        self.firstVar = StringVar ()
        self.firstFrame = Frame (self.foundFrame)
        self.firstFrame.pack (side = TOP, fill = X)
        self.entryFirst = Entry (self.firstFrame,
                                textvariable = self.firstVar,
                                width = 21,
                                 font = ('MS', 12, 'bold'))
        
        
        self.firstLabel = Label (self.firstFrame, text = "First Trace:")
        self.firstLabel.pack (side = TOP)
        self.entryFirst.pack ()
        
        #    Last trace widget
        self.lastVar = StringVar ()
        self.lastFrame = Frame (self.foundFrame)
        self.lastFrame.pack (side = TOP, fill = X)
        self.entryLast = Entry (self.lastFrame,
                                textvariable = self.lastVar,
                                width = 21,
                                font = ('MS', 12, 'bold'))
        
        
        self.lastLabel = Label (self.lastFrame, text = "Last Trace:")
        self.lastLabel.pack (side = TOP)
        self.entryLast.pack ()

        #    Starting path entry widget
        self.entryVar = StringVar ()
        self.entryFrame = Frame (self)
        self.entryFrame.pack (side = TOP)
        self.entryPath = Entry (self.entryFrame,
                                textvariable = self.entryVar,
                                width = 21)
        
        self.entryPath.bind ('<Return>', self.setEntry)
        self.entryPath.pack (pady = 4)
        self.entryLabel = Label (self.entryFrame, text = "Search Path")
        self.entryLabel.pack (side = BOTTOM)

        #    Set up Quit and Read buttons
        self.buttonFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        self.buttonFrame.pack (side = TOP,
                               fill = X)
        self.buttonRead = Button (self.buttonFrame,
                                  relief = GROOVE,
                                  state = DISABLED,
                                  borderwidth = 2,
                                  text = "Read",
                                  command = self.walkTree)
        
        self.buttonLink = Button (self.buttonFrame,
                                  relief = GROOVE,
                                  state = DISABLED,
                                  borderwidth = 2,
                                  text = "Link",
                                  command = self.doLinks)
        
        self.buttonQuit = Button (self.buttonFrame,
                                  relief = GROOVE,
                                  borderwidth = 2,
                                  text = "Quit",
                                  command = self.goByeBye)
        self.buttonQuit.pack (side = LEFT)
        self.buttonLink.pack (side = RIGHT)
        self.buttonRead.pack (side = RIGHT)

    def goByeBye (self) :
        self.root.destroy ()

    def canLink (self) :
        if self.haveFiles and self.haveEvent :
            self.buttonLink.configure (state = NORMAL)
        else :
            self.buttonLink.configure (state = DISABLED)

        if self.havePath :
            self.buttonRead.configure (state = NORMAL)
        else :
            self.buttonRead.configure (state = DISABLED)

    def getPath (self) :
        self.havePath = FALSE
        fd = DirectoryDialog (self.root)
        if self.prev != '' :
            self.prev = self.path + ':'

        self.path = fd.go (dir_or_file = '/')
        if self.path != None :
            self.entryFirst.delete (0, END)
            self.entryLast.delete (0, END)
            self.path = self.path[:-1]
            self.path = self.prev + self.path
            self.prev = self.path
            self.entryVar.set (self.path)
            self.havePath = TRUE
        self.canLink ()

    def getEvent (self) :
        self.haveEvent = FALSE
        fd = TkFileDialog ()
        file = fd.askopenfilename ()
        if file == '' :
            return
        try :
            self.event = Event ()
            self.event.read (file)
            self.haveEvent = TRUE
        except :
            mess = "Failed to properly parse %s" % file
            tkMessageBox.showwarning ("Event file read error:", mess)
            stderr.write ("Error: Failed to read event file!\n")
            self.haveEvent = FALSE
            return
        self.listBox.delete (0, END)
        all = self.event.all ()
        for i in all :
            self.listBox.insert (END, i[1])
            
        self.canLink ()
        
    def setEntry (self, e) :
        self.havePath = FALSE
        n = self.entryPath.get ()
        self.path = self.prev = ''
        flds = string.split (n, ':')
        allDir = TRUE
        for i in flds :
            if not os.path.isdir (i) :
                allDir = FALSE

        self.entryPath.delete (0, END)
        if allDir :
            self.path = self.prev = n
            self.entryVar.set (n)
            self.havePath = TRUE
        self.canLink ()

    def getTol (self) :
        sstr = ("Start time tolerance:\n%d seconds" % self.tol)
        tol = askinteger ('Tolerance',
                          sstr,
                          minvalue = 0)
        if tol :
            self.tol = tol
    
    def walkTree (self) :
        self.haveFiles = FALSE
        #print self.path
        self.root.configure (cursor = 'gumby')
        self.root.update_idletasks ()
        self.tree = QuickLink (self.path)
        if self.tree == None or self.tree.length () < 1 :
            mess = "No rsy files found in: %s" % self.path
            tkMessageBox.showwarning ("No files found in path:", mess)
            stderr.write ("Error: Failed to find rsy files!\n")
            self.root.configure (cursor = 'left_ptr')
            return
        self.tree.sort ()
        first = self.tree.first ()
        last = self.tree.last ()
        self.root.configure (cursor = 'left_ptr')
        self.entryFirst.delete (0, END)
        self.entryFirst.insert (END, first)
        self.entryLast.delete (0, END)
        self.entryLast.insert (END, last)
        self.haveFiles = TRUE
        self.canLink ()
            

    def doLinks (self) :
        self.root.configure (cursor = 'gumby')
        self.root.update_idletasks ()
        l = []
        l = self.listBox.curselection ()
        if len (l) == 0 :
            s = self.listBox.size ()
            l = range (s)
        for i in l :
            files = None
            etuple = self.event.get (i)
            if etuple != None :
                files = self.tree.match (etuple[0], self.tol)
                if files != None :
                    self.tree.link (files, etuple[1])
        self.root.configure (cursor = 'left_ptr')



if __name__ == '__main__' :
    r = Tk ()
    r.title ('QuickLinks')
    p = QLink (r)
    p.pack ()
    r.mainloop ()



