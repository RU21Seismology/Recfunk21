#!/usr/bin/env python

from string import split
from time import mktime, tzname
from TimeDoy import *
from os import environ
from sys import stderr

environ['TZ'] = 'GMT'
tzname = ('GMT', 'GMT')

#
#  Parse an event file for the time and get the epoch
#
class Parse :
    def __init__ (self) :
        #self.file = file
        self.vector = []
        self.last = -1
    #   Convert yyyy:jj:hh:mm:ss to epoch
    def getEpoch (self, val) :
        yr, jd, hr, mn, sc = split (val, ':')
        tm = TimeDoy ()
        moda = tm.getMonthDay (int (yr), int (jd))
        
        ep = mktime ((int (yr),
                     int (moda[0] + 1),
                     int (moda[1]),
                     int (hr),
                     int (mn),
                     int (sc),
                     0,
                     int (jd),
                     0))

        return ((ep, val))

    #   Read an event file
    def read (self, file) :
        try :
            fh = open (file)
        except :
            stderr.write ("Error: Failed to read: %s\n" % file)
            return None
        
        self.last = -1
        while 1 :
            line = fh.readline ()

            if not line :
                break

            flds = split (line)
            if len (flds) > 1 :
                yjhms = flds[1]
            elif len (flds) == 1 :
                yjhms = flds[0]
            else :
                continue

            val = self.getEpoch (yjhms)

            if val != None :
                self.last = self.last + 1
                self.vector.append (val)

#
#   Event file handling class
#
class Event (Parse) :
    def __init__ (self) :
        self.current = 0
        Parse.__init__ (self)

    def epCmp (self, x, y) :
        return (int (x[0]) - int (y[0]))

    def sort (self) :
        self.vector.sort (self.epCmp)

    def all (self) :
        self.sort ()
        return (self.vector)

    def next (self) :
        if self.current <= self.last :
            val = self.vector[self.current]
            self.current = self.current + 1
            return val
        else :
            return None

    def get (self, i) :
        try :
            return (self.vector[int (i)])
        except :
            return (None)

    def rewind (self) :
        self.current = 0

###########################
if __name__ == '__main__' :
    p = Event ()
    p.read ('mastereventfile')

    while 1 :
        val = p.next ()
        if val == None :
            break
        print val
    







