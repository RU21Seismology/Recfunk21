#!/usr/bin/env python

#
#   QuickLinks, Search for rsy files and create links to a single directory
#   based on file start time.
#   Steve Azevedo, October 2000
#

from os import popen, symlink, mkdir
from os.path import exists, basename
from string import join, split, replace
from sys import stderr
from time import gmtime

#
#   Class wrapper around qft
#
class Qft :
    def __init__ (self, dir = ".") :
        self.startDir = dir
        #   Don't return raw files
        self.qft = 'qft -r -d ' + str (self.startDir)
        self.vector = []

    #   Read directories
    def read (self, *flags) :
        self.vector = []
        command = self.qft + " " + str (join (flags))
        try :
            fh = popen (command)
        except :
            stderr.write ("Can't execute %s\n" % command)

        while 1 :
            line = fh.readline ()
            if not line :
                break

            line = line[:-1]

            flds = split (line, '\t')

            if line[0] == '1' :
                continue

            self.vector.append ((flds))

#
#   QuickLinks
#
class QuickLink (Qft) :
    def __init__ (self, dir = ".", start = 0, stop = 0) :
        Qft.__init__ (self, dir)
        self.start = start
        self.stop = stop
        self.read ()

    def epochCmp (self, x, y) :
        return (int (x[4]) - int (y[4]))

    #   Sort based on start epoch
    def sort (self) :
        self.vector.sort (self.epochCmp)

    def first (self) :
        ep = self.vector[0][4]
        ttuple = gmtime (int (ep))
        first = ("%d:%03d:%02d:%02d:%02d" % (int (ttuple[0]),
                                             int (ttuple[7]),
                                             int (ttuple[3]),
                                             int (ttuple[4]),
                                             int (ttuple[5])))
        return (first)
    
    def last (self) :
        ep = self.vector[-1][4]
        ttuple = gmtime (int (ep))
        last = ("%d:%03d:%02d:%02d:%02d" % (int (ttuple[0]),
                                            int (ttuple[7]),
                                            int (ttuple[3]),
                                            int (ttuple[4]),
                                            int (ttuple[5])))
        return (last)

    def length (self) :
        return len (self.vector)

    #   Return a list of matching files based on start epoch and tolerance
    def match (self, epoch, tol = 30) :
        path = []
        min = epoch - tol
        max = epoch + tol

        for i in self.vector :
            tstart = int (i[4])
            if tstart > max :
                break
            if tstart >= min and tstart <= max :
                #print min, max, tstart
                path.append (i[2])

        if len (path) == 0 :
            path = None

        return (path)

    #   Create links of files to dir, return number of files linked
    def link (self, files, dir) :
        dir = replace (dir, ":", ".")
        if not exists (dir) and len (files) > 0 :
            mkdir (dir)
        dir = dir + "/Segy"
        if not exists (dir) :
            mkdir (dir)

        i = 0
        for file in files :
            base = basename (file)
            tofile = dir + '/' + base
            
            try :
                if not exists (tofile) :
                    symlink (file, tofile)
                    i = i + 1
            except :
                stderr.write ("Error: Failed to link %s to %s\n" %
                              (file, tofile))

        return i


if __name__ == '__main__' :
    q = QuickLink ('/data')
    q.sort ()
    p = q.match (936048600, 2100)
    i = q.link (p, './junk')
    j = len (p)
    print i, j







