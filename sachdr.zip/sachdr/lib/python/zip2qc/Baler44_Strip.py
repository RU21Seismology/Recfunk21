#!/usr/bin/env picpython

import os, sys, subprocess, re, gc
import Un

PROG_VERSION = '2009.297a'

SDRSPLIT = 'sdrsplit -P -C -r '

#   Low sample rate data
baler44SDataRE = re.compile (".*sdata\/[A-Z]{2}-.*2\d{13}")
baler44DataRE = re.compile (".*data\/[A-Z]{2}-.*2\d{13}")

#Baler44RE = baler44SDataRE

class Baler44_Strip :
    def __init__ (self, verbose = None, outdir = None) :
        #self.big_buffer = Un.readBuffer ()
        self.Baler44RE = baler44SDataRE
        self.here = os.getcwd ()
        if outdir != None :
            if not os.path.exists (outdir) :
                os.mkdir (outdir)
                
        os.chdir (outdir)
        
        self.verbose = verbose
    
    #   Extract all data
    def strip_all (self) :
        global SDRSPLIT
        SDRSPLIT += " -D "
        self.Baler44RE = baler44DataRE
    
    #   Extract only low sample rate data
    def strip_lsr (self) :
        self.Baler44RE = baler44SDataRE
        
    def initialize_striper (self) :
        try :
            #   Each subfile is no greater than 4194304 bytes. Allocate
            #   a buffer to hold about 200 subfiles. (838860800)
            #   Throw away STDOUT unless verbose
            if not self.verbose :
                self.fh = subprocess.Popen (SDRSPLIT + " > /dev/null", shell=True, 
                                            stdin=subprocess.PIPE, close_fds=True, 
                                            bufsize=83886080)
            else :
                self.fh = subprocess.Popen (SDRSPLIT + " 2>&1", shell=True, 
                                            stdin=subprocess.PIPE, close_fds=True, 
                                            bufsize=83886080)
            
        except Exception, e :
            sys.stderr.write ("Failed to open subprocess for sdrsplit!\n")
            sys.stderr.write ("%s\n" % e)
            return False
        
        return True
            
    def initialize_reader (self, filename) :
        '''   Read the output from msview   '''
        archive_type = guess_type (filename)
        if archive_type == None : return
        if archive_type == 'ZIP' :
            self.reader = Un.neoZIP (filename)
        elif archive_type == 'tar' :
            self.reader = Un.neoTAR (filename)
            
        self.reader.open ()            
        
    def clear (self) :
        self.big_buffer.clear ()
        
    def read (self) :
        while 1 :
            if not self.reader.read (self.Baler44RE) :
                os.chdir (self.here)
                #   For some reason self.fh.kill () does not work???
                command = 'kill -9 %d > /dev/null 2>&1' % self.fh.pid
                #print command
                if os.system (command) != 0 :
                    sys.stderr.write ("Warning: Failed to free sub-processes!\n")
                    
                self.fh = None
                gc.collect (2)
                break
            
            if self.reader.buf.length != 0 : break
                        
        #print self.big_buffer.length
        return self.reader.buf.buf
        
    def strip (self, buf, outdir = None) :
        try :
            self.fh.stdin.write (buf)
            #err = self.fh.stderr.readlines ()
            #out = self.fh.stdout.readlines ()
        except Exception, e :
            sys.stderr.write ("Error: exception processing subfile: %s\n" % e)
            return
        
        #if err != None : sys.stderr.write (err)
        #sys.stderr.write (self.fh.stdout.readlines ())

###   Mixins   ###
#   Guess file type based on suffix
def guess_type (filename) :
    #
    if os.path.isdir (filename) :
        return None
    
    suffix = filename[-3:]
    if suffix == 'ZIP' or suffix == 'tar' :
        return suffix
    else :
        return None
    
if __name__ == '__main__' :
    bs = Baler44_Strip ()
    bs.read ('/home/azevedo/Desktop/Neo_Test_Data/2009179.XX-BIGH1.ZIP')
    bs.strip ()