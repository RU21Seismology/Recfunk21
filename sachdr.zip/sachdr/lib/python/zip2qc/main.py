#!/usr/bin/env picpython
#
#   A silly little program to strip low sample rate channels from 
#   a neo zip or tar file of BALER44 data.
#
#   Steve Azevedo, June 2009
#

import sys, os, os.path, re
import Baler44_Strip

PROG_VERSION = '2009.297'

#   Match tar and ZIP files from neo
zipRE = re.compile (".*\d{7}\.[A-Z]{2}-\w{1,5}\.ZIP")
tarRE = re.compile (".*\d{7}\.[A-Z]{2}-\w{1,5}\.tar")

def get_args () :
    global INDIR, OUTDIR, INFILE, ALL, VERBOSE
    
    from optparse import OptionParser
    
    oparser = OptionParser ()
    
    oparser.usage = "zip2qc [--infile=input_file| --indir=input_directory] [--outdir=output_directory]\nVersion: %s" % PROG_VERSION
    
    oparser.description = "Strip out low sample rate channels from a Q330S zip or tar file from neo."
    
    oparser.add_option ("-f", "--infile", dest = "in_file",
                        help = "An input zip or tar file.",
                        metavar = "in_file")
    
    oparser.add_option ("-d", "--indir", dest = "in_dir",
                        help = "The input directory.",
                        metavar = "in_dir")
    
    oparser.add_option ("-o", "--outdir", dest = "out_dir",
                        help = "Output directory.",
                        metavar = "out_dir")
    
    oparser.add_option ("-a", "--all", dest = "all_data",
                        help = "Extract high sample rate data also.",
                        action = "store_true", default = False)
    
    oparser.add_option ("-v", "--verbose", dest = "verbose",
                        help = "Be verbose",
                        action = "store_true", default = False)
    
    options, args = oparser.parse_args ()
    
    if options.out_dir != None :
        OUTDIR = options.out_dir
    else :
        OUTDIR = "./QC"
        
    if options.in_file != None :
        INFILE = []
        INFILE.append (options.in_file)
    else :
        INFILE = None
        
    if options.in_dir != None and INFILE == None :
        INDIR = options.in_dir
    else :
        INDIR = None
        #INDIR = os.getcwd ()
        #print INDIR
        
    ALL = options.all_data
    VERBOSE = options.verbose
        
    if not INFILE and not INDIR :
        sys.stderr.write ("Error: missing option.\nTry --help.\n")
        sys.exit ()
        
def read_dir (in_dir) :
    global INFILE
    INFILE = []
    
    files = os.listdir (in_dir)
    for f in files :
        if zipRE.match (f) or tarRE.match (f) :
            INFILE.append (os.path.join (in_dir, f))
        
if __name__ == "__main__" :
    import gc, time
    global INFILE, OUTDIR, INDIR, ALL, VERBOSE
    
    get_args ()
    if INDIR != None :
        read_dir (INDIR)
        
    for f in INFILE :
        if not os.path.isabs (f) :
            f = os.path.abspath (f)
            
        bs = Baler44_Strip.Baler44_Strip (verbose = VERBOSE, outdir = OUTDIR)
        if ALL == True :
            bs.strip_all ()
        else :
            bs.strip_lsr ()
        
        print f
        bs.initialize_reader (f)
        if not bs.initialize_striper () : continue
        while 1 :
            buf = bs.read ()
            if not buf : break
            bs.strip (buf, OUTDIR)
            
        del bs
        
        gc.collect (2)
        
        #time.sleep (10)
        