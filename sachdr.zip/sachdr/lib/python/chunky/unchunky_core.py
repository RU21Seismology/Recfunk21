#!/usr/bin/env picpython
#
# Read ZIP files produced by neo and convert to ref format. Optionally convert to mseed or PASSCAL SEGY.
#
# Steve Azevedo, September 2006
#
# Modified by Joe Stradling: July 2007
# Modified by Jayson Barr: July 2008
#   -- Added state-saving/continuation functionality, bug fixes
# Modified by Jayson Barr: August 2008
#   -- Added ref file input, bug fixes
# Modified by Jayson Barr: October 22-24, 2008
#   -- Completely removed do_something and added a w/o-state-saving option to use do_something_safely, now only uses do_something_safely
#   -- Changed to using lots and lots of absolute paths and minimized the os.chdir and os.path.basename calls.
#   -- Various changes to make sure that output files are ONLY put into the output directory
#   -- Fix for very specific bug: if input file is ref, output dir is same dir as where the input ref was, and ref checkbox not chcked,
#      it was deleting the input file; now it does not in this case.
#   -- Made it so you could move a ZIP file to the end of zips to work on in the case of a pop-up with a question so we don't get stuck.
#   -- Removed annoying "would you like to continue?" dialog
#   -- Fixed the empty window that gets created when you open the log search function
#   -- Various forgotten bug fixes
#   -- Updated documentation which has been lacking lately
#   -- Deleted large blocks of previously commented out code.  This had been done for testing, but was forgotten about.
#   -- Fixed Continue button not getting disabled while running (ah!)
#   -- Started actually using the resetTimeStamp option I had in core.BackupSelf.  Now every time it backs up it will change the timestamp
#      on the backup file.
# Modified by Jayson Barr: February 16, 2009
#   -- Made Unchunky thread safe with Tk
#   -- Added some documentation
#   -- Fixed a bug dealing with state loading
#   -- Prints status of loaded state before continuing

__version__ = '2009.47'

# Default --UNSAFE option:
RUN_SAFE = False
# This BACKUP_FILENAME for backing up the state of the program if RUN_SAFE = True or ran with --SAFE:
BACKUP_FILENAME = "unchunky_%(timestamp)s.backup"  # The %(timestamp)s is mandatory and filled in later. Configure below.

RT130CUT = "rt130cut"
# unzip zip files
UNZIP = "unzip"
BUNZIP = "bunzip2"
# Convert to mseed
REF2MSEED = "ref2mseed"
# Convert to PASSCAL SEGY
REF2SEGY = "ref2segy"
REF2LOG = "ref2log"
#   LINUX and OS-X
TAR = "tar"
#   Solaris
#TAR = "gtar"

# Added to stop the hardcoding below of the temp directory  --JB, 7/11/08
TEMP_DIR = "tmp_unchunky_%(timestamp)s"     #%(timestamp)s is mandatory, and filled in later. Configure below.

# TIMESTAMP FORMAT
#   NOTE:   This timestamp info is FYI only, do not adjust this without dilligently fixing the sorting
#           algorith in the run_nongui function!
#
#   The different letters represent this:
#   "Y"     Year
#   "j"     julian day of year
#   "h"     hour
#   "m"     min
#   "s"     second
#
#   Fill it in like this: "%(Y):%(j)s:%(h)s:%(m)s:%(s)s" for **Year**:**Julday**:**hour**:**min**:**second**     # this is the default
# Actually, sorting is done based on this, so you really shouldn't change this without updating code!!!
TIME_STAMP = "%(Y)s:%(j)s:%(h)s:%(m)s:%(s)s"
# Now I'm putting this here so you see how TIME_STAMP is used for configuration:
BACKUP_FILENAME = BACKUP_FILENAME % {"timestamp":TIME_STAMP}
TEMP_DIR = TEMP_DIR % {"timestamp":TIME_STAMP}    

# This constant is just to keep track when ref files are unlinkd  --JB, 7/11/08
REFUNLINK = "os.unlink"
# And this one to keep track of when we need to make a new ref file ---JB, 7/11/08
MAKEREF = "make_ref"

import getopt, sys, os, os.path, re, string, time, pexpect, pickle
from Tkinter import *
import tkMessageBox
import Queue

#This was added by Jayson Barr, 7/21/08
import ActionIterator

BLIND_ZIPFILERE = re.compile(".*\.[Zz][Ii][Pp]$")
BLIND_TARFILERE = re.compile(".*\.[Tt][Aa][Rr]$")
BLIND_BZ2FILERE = re.compile(".*\.[Bb][Zz]2$")
BLIND_REFFILERE = re.compile(".*\.[Rr][Ee][Ff]$")
ZIPFILERE = re.compile ("2\d{6}\..{4}\.[Zz][Ii][Pp]$")
TARFILERE = re.compile ("2\d{6}\..{4}\.[Tt][Aa][Rr]$")
BZ2FILERE = re.compile ("2\d{6}\..{4}\.tar\.[Bb][Zz]2$")
NEOFILERE = re.compile("2\d{6}\..{4}\..*")

reg = re.compile("(ENTER data format - \[32, 16, or c0\])|\
(No Sample Rate Specified for Data Stream.*\nENTER Sample Rate in Samples per Second -)|\
(Enter comma separated list of chans for stream.*\n\(i.e., 1,2,3 or 4,5,6 or 1-3 or 4-6\):)|\
(ERROR no gain for channel.*\nENTER gain for channel.*--)|\
(ENTER gain for channel.*--.*)")

#----------------------------------------------------------------------------------------------------------#
def notify_finished():
    for i in range(0,2):
        sys.stdout.write('\a'); sys.stdout.flush()
        time.sleep(0.25)
#----------------------------------------------------------------------------------------------------------#
class QuestionDialog:
    '''
    QuestionDialog
      Just a simple class for displaying questions and
      receiving input from the user using tk windows.
    '''
    def __init__(self,question, title,root=None):
        self.run = True
        self.retval = ''
        childpid = os.fork()
        if childpid == 0:
            count = 0
            while 1:
                count += 1
                sys.stdout.write('\a');   sys.stdout.flush()
                time.sleep(5)
                if count > 12:
                    sys.exit(1)
             
        if not root:
            win= Tk()
        else:
            win = Toplevel(root)
            win.transient(root)
            win.lift(aboveThis=root)
            
        win.title(title)
        self.inpt = StringVar()
        f1 = Frame(win,borderwidth=2)
        f1.pack(fill=BOTH, expand=1, padx=4, pady=4)
        f2 = Frame(win, borderwidth=2)
        f2.pack(fill=BOTH, expand =1, padx=4, pady=4)
        m = Message(f1, text=question, aspect=150, width=450, relief=SUNKEN, bg="lightyellow")
        l = Label(f2, text="Enter your response: ")
        e = Entry(f2, textvar=self.inpt, bg="white")
        b = Button(win, text="OK", command=self.b_press)
        e.bind("<Return>", self.return_bind)
        e.bind("<KP_Enter>", self.return_bind)
        e.focus_set()
        m.pack(side=LEFT)
        l.pack(side=LEFT)
        e.pack()
        b.pack(side=BOTTOM)
        while self.run:
            win.update()
            try: 
                x = win.state()
            except TclError:
                self.retval = '\0'
                break
            
        if self.retval != '\0':  self.retval = self.inpt.get()
        os.kill(childpid, 9)
        win.destroy()
        
    def return_bind(self, event):
        self.run =False
        
    def b_press(self):
        self.run =False


#----------------------------------------------------------------------------------------------------------#
def usage () :
    me = 'unchunky'
    sys.stderr.write ("%s\n" % __version__)
    # DEBUG option added, and -h option added to usage    --JB, 7/11/08
    sys.stderr.write ("Usage: %s -d path_to_zip_or_ref_file_dir | -f path_to_zip_or_ref_file [options]\n" % me)
    sys.stderr.write ("Options:\n")
    sys.stderr.write ("\t[-c] continue where the program leftoff (retry failed/missed options)\n")
    sys.stderr.write ("\t[-m][-s][-l] generate mseed, passcal SEGY, logpeek logs\n")
    sys.stderr.write ("\t[-r] generate ref files\n")
    sys.stderr.write ("\t[-p output_directory] write to output_directory\n")
    sys.stderr.write ("\t[-i instrument_list] comma separated das list to convert\n")
    sys.stderr.write ("\t[-j julian_day_list] comma separated julian day list to convert\n")
    sys.stderr.write ("\t[-v] be verbose\n")
    sys.stderr.write ("\t[-b] blindly add all file archives in directory regardless of name format\n")
    sys.stderr.write ("\t[-L defaults_file] Set ref2segy/ref2mseed -l defaults. Used to reading DS and channel information.\n")
    sys.stderr.write ("\t[--DEBUG] don't delete created temporary files for debugging purposes\n")
    sys.stderr.write ("\t[--SAFE] run saving the state periodically so you can continue without repeating steps later\n")
    sys.stderr.write ("\t[--UNSAFE] this is default unless you changed the configuration in unchunky_core.py, equivalent to not using --SAFE\n")
    sys.stderr.write ("\t[-h] print help\n")
#----------------------------------------------------------------------------------------------------------#
#parse the instrument argument
def instruments (List, INSTRUMENTS) :
    ''' Get a dictionary of requested instruments '''
    flds = string.split (List, ',')
    for d in flds :
        INSTRUMENTS[d] = 1
        
    return INSTRUMENTS

def reverseInstruments (instrDict) :
    ''' Reverse engineer the dictionary given from instruments function to return a list
        of the INSTRUMENT keys.
        This was needed when loading from a previous core save to update the unchunky gui.
        --JB 7/23/08
    '''
    flds = instrDict.keys()
    return ",".join(flds)

#----------------------------------------------------------------------------------------------------------#
def run_command (command, regExp, parentExeThread=None):
    #begin run_command method
    buff = ""
    linebuff = ""
    inp = ""
    quest = ""

    proc = pexpect.spawn (command)
    check = 0
    while proc.isalive ():
        try:
            b = proc.read_nonblocking(1,10)
            if b == '\r':
                continue
            
        except pexpect.EOF:
            break
        except pexpect.TIMEOUT:
            check += 1
            if parentExeThread and len(linebuff) > 0 and linebuff != '\n':
                #mess.log.configure(text_state=NORMAL)
                #mess.log.insert(END, linebuff)
                #mess.log.configure(text_state="disabled")
                parentExeThread.setMess("log",linebuff)
                linebuff = ""
                
            b = ''

        buff = buff + b; linebuff = linebuff + b

        LINEBUFF_NEEDS_TO_BE_LOGGED = False
        if parentExeThread == None:
            sys.stdout.write(b)
            sys.stdout.flush ()
        elif b == '\n':
            #parentExeThread.setMess("log",linebuff)
            #linebuff = ""
            LINEBUFF_NEEDS_TO_BE_LOGGED = True

        if regExp != None and (b == '-' or b==':' or b=='\n' or check):
            m = regExp.search(buff)
            inp = ''
            if m:
                check = 0
                buff = ""
                quest = m.group()
                if parentExeThread:
                    #user in GUI mode use dialog windows
                    #root = mess.frame.master.master
                    yield "COMEBACK"
                    if LINEBUFF_NEEDS_TO_BE_LOGGED:
                        parentExeThread.setMess("log",linebuff)
                        linebuff = ""
                        LINEBUFF_NEEDS_TO_BE_LOGGED = False
                    #d = dialog(quest, "Input Required for: " + command, root)
                    #while d.retval == '':
                    #    d = dialog(quest, "Input Required for: " + command, root)
                    parentExeThread._QAndA[command+":"+quest] = None
                    parentExeThread.setMess("question",command+":"+quest)
                    while parentExeThread._QAndA[command+":"+quest] == None:
                        time.sleep(0.1)
                    inp = parentExeThread._QAndA[command+":"+quest]
                    del(parentExeThread._QAndA[command+":"+quest])
                    #parentExeThread.setMess("log",'\n'+inp+'\n')
                    if inp == '\0' or inp == '':
                        #window closed by user must want me to shutdown
                        proc.terminate()
                        parentExeThread.setMess("status","Dialog Window Closed!  Terminating process!")
                        yield -1
                else:
                    #user in command line mode use stdout/stdin
                    sys.stdout.write('\a')
                    inp = raw_input()
                    while inp == '':
                        sys.stdout.write('\a')
                        inp = raw_input("<"+command+">: "+quest)
                proc.sendline(inp)
        if LINEBUFF_NEEDS_TO_BE_LOGGED:
            parentExeThread.setMess("log",linebuff)
            linebuff = ""
            LINEBUFF_NEEDS_TO_BE_LOGGED = False
        #   Give up after 3 timeouts
        #if check > 3 :
        #    proc.terminate ()
        #    yield -3
        
        #end loop
    if proc.signalstatus == None:
        yield proc.exitstatus
    else:
        proc.terminate()
        yield -2
#----------------------------------------------------------------------------------------------------------#
# walk through target directory and find zip files
#                   Updated by JB, 8/11/08 to find ref files too
def get_zip (files, run_blind) :
    # List of DASs keyed by filename
    zipre = ZIPFILERE
    tarre = TARFILERE
    bz2re = BZ2FILERE
    refre = BLIND_REFFILERE
    if run_blind:
        # get all files ending with .[Zz][Ii][Pp] || .[Tt][Aa][R] || .[Bb][Zz]2
        zipre = BLIND_ZIPFILERE
        tarre = BLIND_TARFILERE
        bz2re = BLIND_BZ2FILERE
        
    List = []
    for f in files :
        # Is this a zip file?
        if re.match (zipre, f) :
            List.append(f)
        # Is this a tar file
        elif re.match (tarre, f) :
            List.append(f)
        # Bzip2 tar file
        elif re.match (bz2re, f) :
            List.append(f)
        elif re.match (refre, f) :
            List.append(f)
    return List
#----------------------------------------------------------------------------------------------------------#
def create_dir (dest_dir, parentExeThread) :
    ''' Create our working directory '''
    cdir = os.path.abspath(os.getcwd())
        
    if dest_dir != '.' :
        # Just create the user requested directory
        if not os.path.isabs (dest_dir) :
            dest_dir = os.path.join (cdir, dest_dir)
        try :
            os.mkdir (dest_dir)
        except OSError, errorString:
            if parentExeThread:
                parentExeThread.setMess("status","Error creating '%s': %s" % (dest_dir, errorString) )
            else:
                sys.stderr.write ("Error creating '%s': %s" % (dest_dir, errorString) )

        Dir = dest_dir
    else :
        # Create a directory WWW-JJJ-HH-MM (Week day, Day of year, hour, minute
        Dir = time.strftime ("%a-%j-%H%M", time.gmtime (time.time ()))
        Dir = os.path.join (cdir, Dir)
        try :
            os.mkdir (Dir)
        except OSError :
            if parentExeThread:
                parentExeThread.setMess("status","%s exists...\n" % Dir)
            else:
                sys.stderr.write ("%s exists...\n" % Dir)
    return Dir
#----------------------------------------------------------------------------------------------------------#
def make_ref (outdir, z, GUI,parentExeThread=None,CleanUp = True):
    ''' Go through the steps to produce a ref file '''
    def clean_up (tmpdir) :
        import shutil
        shutil.rmtree (tmpdir)
    timestampDict = time.localtime()
    timestampDict = {   "Y":timestampDict[0],
                        "M":timestampDict[1],
                        "d":timestampDict[2],
                        "h":timestampDict[3],
                        "m":timestampDict[4],
                        "s":timestampDict[5],
                        "w":timestampDict[6],
                        "j":timestampDict[7],
                    }
    z = os.path.abspath(z)
    outdir = os.path.abspath(outdir)
    tmpdir = os.path.abspath(os.path.join (outdir,TEMP_DIR % timestampDict))
    try :
        os.mkdir (tmpdir)
    except OSError, errorString :
        if parentExeThread:
            parentExeThread.setMess("status","Error creating temporary directory '%s': %s" % (tmpdir,errorString))
        else:
            sys.stderr.write ("Error creating temporary directory '%s': %s\n" % (tmpdir,errorString))
        # Changed to fail here so not to delete users' personal files!  --JB, 7/11/08
        sys.stderr.write("Temporary directory already exists.  Remove directory or change TEMP_DIR var in /opt/passcal/lib/python/chunky/unchunky_core.py\n")
        sys.exit()

    refname = os.path.basename (z) + ".ref"
    if re.match(BLIND_BZ2FILERE, z) :
        prog = TAR + ' -xjf '
    elif re.match(BLIND_TARFILERE, z) :
        prog = TAR + ' -xf '
    elif re.match(BLIND_ZIPFILERE, z) :
        prog = UNZIP
    else:
        if parentExeThread:
            parentExeThread.setMess("status","ERROR: \"" + z + "\" is not a proper archive!")
        else:
            sys.stderr.write("\nERROR: \"" + z + "\" is not a proper archive!\n")
            
        yield None

    cdir = os.path.abspath(os.getcwd())
    
    command = "%s %s" % (prog, z)
    if parentExeThread:
        parentExeThread.setMess("status",command)
    else:
        print command

    rc = run_command (command, None, parentExeThread=parentExeThread)
    os.chdir (tmpdir)
    ret = rc.next()
    os.chdir(cdir)
    while ret == "COMEBACK":
        yield "COMEBACK"
        os.chdir(tmpdir)
        ret = rc.next()
        os.chdir(cdir)
    del(rc)
    if ret :
        if parentExeThread:
            parentExeThread.setMess("status",command + " failed!")
            yield -3
        else:
            print command+" failed!"
            yield -3
        if CleanUp:
            clean_up (tmpdir)
        yield None


    #   Write refname to a single (large) file in verbose mode
    command = "%s -r %s -o %s -v -m" % (RT130CUT, tmpdir, refname)
    if parentExeThread:
        parentExeThread.setMess("status",command)
    else:
        print command
    rc = run_command (command, None, parentExeThread)
    os.chdir (outdir)
    ret = rc.next()
    os.chdir(cdir)
    while ret == "COMEBACK":
        yield "COMEBACK"
        os.chdir (outdir)
        ret = rc.next()
        os.chdir(cdir)
    del(rc)

    if ret :
        if parentExeThread:
            parentExeThread.setMess("status",command + " failed!")
        else:
            sys.stderr.write("\nFAILED: %s\n" %command)
        if CleanUp:
            clean_up (tmpdir)
        yield None
    if CleanUp:
        clean_up (tmpdir)
    yield refname

#-------------------------------------------------------------------------------------#
#       class core:         Heart of unchunky, this is what does stuff ;-)            #
#-------------------------------------------------------------------------------------#
class core:
    ###################
    def __init__(self):
        self.PATH = ""
        self.FILE = ""
        self.ORIGIN = os.path.abspath(os.getcwd())
        self.OUTDIR = os.path.abspath(os.getcwd())
        self.INSTRUMENTS = {}
        self.STRIP = False
        self.MSEED = False
        self.SEGY = False
        self.JDAY = ''
        self.VERBOSE = False
        self.LOG = False
        self.REF = False
        self.BLIND= False
        self.parentExeThread= None
        self.ZIPS = []
        self.GUI = False
        self.CONFIG = None
        # --- Jayson Barr, 7/11/08:
        self.backup_filename = ""
        self.DEBUG = False
        self.COMPLETED_ACTIONS = {}
        # --- Jayson Barr, 8/11/08
        self.RefsInZIPS = []
        # --- Jayson Barr, 10/26/08
        self.ERRORS = {}
    ###################
    def BackupSelf(self,resetTimeStamp=False):
        if resetTimeStamp or (not self.backup_filename):
            timestampDict = time.localtime()
            timestampDict = {"Y":timestampDict[0],
                             "M":timestampDict[1],
                             "d":timestampDict[2],
                             "h":timestampDict[3],
                             "m":timestampDict[4],
                             "s":timestampDict[5],
                             "w":timestampDict[6],
                             "j":timestampDict[7],}
            oldBackupToDelete = self.backup_filename
            self.backup_filename = os.path.join(self.OUTDIR,BACKUP_FILENAME % timestampDict)
        pET = self.parentExeThread
        self.parentExeThread = None
        BACKUP_FILE_OBJECT = open(self.backup_filename,"w")
        pickle.dump(self,BACKUP_FILE_OBJECT)
        BACKUP_FILE_OBJECT.close()
        self.parentExeThread = pET
        if resetTimeStamp and oldBackupToDelete and os.path.exists(oldBackupToDelete):
            try:
                os.remove(oldBackupToDelete)
            except IOError, errorString:
                print "Couldn't delete old backup file '%s': %s" % (oldBackupToDelete,errorString)
    ###################
    def run_nongui(self, version):
        global __version__, RUN_SAFE;
        __version__ = version
        # Added -c, UNSAFE, and DEBUG options    --JB, 7/23/08
        oldCore = False
        activeCore = self
        opts, args = getopt.getopt (sys.argv[1:], "bc:rlvhmsf:d:p:i:j:L:",["DEBUG","UNSAFE","SAFE","FROMREF="])
        
        # ---- This is really weird and needs fixing:
        for COption,BackupFile in [(x,y) for (x,y) in opts if x == "-c"]:
            #if a:
            # -- The next 6 lines used to be under the above "if a"
            if os.path.exists(BackupFile):
                print "Found %s, beginning..." % BackupFile
                oldCore = getPreviousCore(BackupFile)
                activeCore = oldCore
            elif not a:
                print "[-c] option requires a state_save (unchunky_TIMESTAMP.backup) filename for an argument"
                print
                print usage()
                sys.exit()
            else:
                print "State save file: %s does not exist." % BackupFile
                print
                print usage()
                sys.exit()
            break
        # -----
        
        for o, a in opts :
            if o == '-c':
                pass
            elif o == '-d' :
                activeCore.PATH = a
            elif o == '-b':
                activeCore.BLIND = True
            elif o == '-r' :
                activeCore.REF = True
            elif o == '-f' :
                activeCore.FILE = a
            elif o == '-p' :
                activeCore.OUTDIR = a
            elif o == '-h' :
                usage () # Call usage here
                sys.exit ()
            elif o == '-i' :
                activeCore.INSTRUMENTS = instruments (a, activeCore.INSTRUMENTS) # Call get instrument list here
                activeCore.STRIP = True
            elif o == '-m' :
                activeCore.MSEED = True
            elif o == '-s' :
                activeCore.SEGY = True
            elif o == '-j' :
                activeCore.JDAY = a
            elif o == '-v' :
                activeCore.VERBOSE = True
            elif o == '-l' :
                activeCore.LOG = True
            elif o == '-L' :
                activeCore.CONFIG = a
            elif o == "--DEBUG":
                activeCore.DEBUG = True
            elif o == "--UNSAFE":
                RUN_SAFE = False
            elif o == "--SAFE":
                RUN_SAFE = True
            else :
                sys.stderr.write ("\n%s option not supported\n" % o)
                usage ()
                sys.exit()
        print "\nUnchunky version %s\n\n" % __version__
        if activeCore.MSEED or activeCore.SEGY :
            activeCore.LOG = False

        # The only required option ;^)      
        if (activeCore.PATH == "" and activeCore.FILE == "") or (len (activeCore.PATH) > 0 and len (activeCore.FILE) > 0) :
            if oldCore:
                if not oldCore.ZIPS:
                    print "\nLoaded backup of unchunky state had no files to operate on."
                    usage ()
                    sys.exit ()
            else:
                    usage ()
                    sys.exit ()
        if len (activeCore.PATH) > 0 and activeCore.PATH[0] != '/' :
            activeCore.PATH = os.path.abspath (activeCore.PATH)

        if len (activeCore.FILE) > 0 and activeCore.FILE[0] != '/' :
            activeCore.FILE = os.path.abspath (activeCore.FILE)
        ZS = []
        if activeCore.PATH:
            ZS += activeCore.stroll ()
        if activeCore.FILE:
            ZS.append (activeCore.FILE)
        for zipFile in ZS:
            if zipFile and zipFile not in activeCore.ZIPS:
                activeCore.ZIPS.append(zipFile)
            if (re.match(BLIND_REFFILERE,zipFile)) and (os.path.abspath(zipFile) not in activeCore.RefsInZIPS):
                activeCore.RefsInZIPS.append(os.path.abspath(zipFile))
        if oldCore:
            ret = activeCore.do_something_safely(CONTINUE=True,SAFETY=True)
        elif RUN_SAFE:
            ret = activeCore.do_something_safely(CONTINUE=False,SAFETY=True)
        else:
            ret = activeCore.do_something_safely(CONTINUE=False,SAFETY=False)
        if ret:  
            ret = 1
            print "\n\nUnchunky finished with errors"
        else:
            ret = 0
            print "\n\nUnchunky Completed Successfully"
        activeCore.printActionSummary()
        notify_finished()
        sys.exit(ret)
    ######################
    def printActionSummary(self):
        """Print a summary of which actions have been completed and which have failed.  If self.parentExeThread is present then the output will go to its Queue for logging."""
        # Make a run summary string:
        actionSummary = "\n\n-- Run summary --"
        allNeededActions = [MAKEREF]
        if self.SEGY:
            allNeededActions.append(REF2SEGY)
        if self.MSEED:
            allNeededActions.append(REF2MSEED)
        if self.LOG:
            allNeededActions.append(REF2LOG)
        if not self.REF:
            allNeededActions.append(REFUNLINK)
        
        allZs = self.COMPLETED_ACTIONS.keys()
        allZs += [x for x in self.ZIPS if x not in allZs]
        for zf in allZs:
            actionSummary += "\n%s:" % zf
            for act in allNeededActions:
                if zf in self.COMPLETED_ACTIONS.keys() and act in self.COMPLETED_ACTIONS[zf]:
                    actStat = "Completed"
                elif zf in self.ERRORS and act in self.ERRORS[zf]:
                    actStat = "Encountered an error during operation."
                else:
                    actStat = "Skipped because of previous error or cancelled by user"
                actionSummary +="\n\t%s:\t%s" % (act,actStat)
        actionSummary += "\n\n--------\n"
        if self.parentExeThread:   # Put it in the log
            self.parentExeThread.setMess("log",actionSummary)
        else:           # Print it
            print actionSummary
    ######################
    def stroll (self):
        Zs = []
        for Dir, subdirs, files in os.walk(self.PATH):
            zip_list = get_zip(files, self.BLIND)
            for f in zip_list :
                k = string.split(f, '.')
                if re.match(NEOFILERE, f):
                    k = k[1]
                else:
                    k = None
                File = os.path.abspath(os.path.join (Dir, f))
                if self.BLIND or not self.STRIP:
                    Zs.append(File)
                elif self.INSTRUMENTS.has_key (k) :
                    Zs.append (File)
        #All done getting zips
        #return
        return Zs
    ###############
    def do_something_safely (self,CONTINUE=False,SAFETY=True):
        """Basically the same thing as do_something, but doesn't repeat steps that have finished."""

        if CONTINUE == False:
            self.COMPLETED_ACTIONS = {}
            self.ERRORS = {}

        # Every time this function runs, we will initialize a backup file and save a pickled version
        #   of this core() object for backing up:
        if SAFETY:
            self.BackupSelf(resetTimeStamp=True)

        # I have left this function definition inside the above one only because it was like this before, and I am worried someone did this for a reason
        # If anyone knows for sure whether it is necessary to leave it here or not should move it or delete this comment.
        def build (refname, what, outdir):
            ''' Build mseed, SEGY, log, or ref file '''
            cdir = os.path.abspath(os.getcwd())
            refname = os.path.abspath(refname)
            outdir = os.path.abspath(outdir)
            command = "%s -f %s " % (what, refname)
            if self.JDAY != '' :
                command = command + ("-j %s" % self.JDAY)
            if self.CONFIG :
                command = command + ("-l %s" % self.CONFIG)
            if self.parentExeThread:
                self.parentExeThread.setMess("status",command)
            else:
                print command
            rc = run_command (command, reg, self.parentExeThread)
            os.chdir(outdir)
            ret = rc.next()
            os.chdir(cdir)
            while ret == "COMEBACK":
                yield "COMEBACK"
                os.chdir(outdir)
                ret = rc.next()
                os.chdir(cdir)
            del(rc)
            if ret:
                if self.parentExeThread:
                    self.parentExeThread.setMess("status","Failed command: " + command)
                else:
                    print "Failed command: " + command
            yield ret

        ThingsToDoIterator = ActionIterator.ActionIterator(self)
        COME_BACK_TO_THESE = {}		#Add actions pending info from the user here
        for ZIPFile, Action in ThingsToDoIterator:
            newRef = os.path.abspath(   os.path.join(   self.OUTDIR,  os.path.basename(ZIPFile)   )   )  #ONLY use ref files in out output directory
            if os.path.abspath(ZIPFile) in self.RefsInZIPS:
                #The input zip file was actually a ref file:
                oldRef = ZIPFile
            else:
                oldRef = None       # there wasn't one before
                newRef += ".ref"    # We made it from an archive

            if Action == MAKEREF:
                if os.path.abspath(ZIPFile) in self.RefsInZIPS:
                    if oldRef == newRef:    #Means that the copy we would make of the ref file would just overwrite itself, or worse: cp would give a dumb error and it would look like we failed!
                        ret = 0
                    else:
                        command = "cp %s %s" % (oldRef,newRef)
                        if self.parentExeThread:
                            self.parentExeThread.setMess("status",command)
                        else:
                            print command
                        if ZIPFile in COME_BACK_TO_THESE.keys() and Action in COME_BACK_TO_THESE[ZIPFile].keys():
                            rc = COME_BACK_TO_THESE[ZIPFile][Action]
                            del(COME_BACK_TO_THESE[ZIPFile][Action])
                        else:
                            rc = run_command(command,None,self.parentExeThread)
                        ret = rc.next()
                        if ret == "COMEBACK":
                            if ZIPFile not in COME_BACK_TO_THESE.keys():
                                COME_BACK_TO_THESE[ZIPFile] = {}
                            COME_BACK_TO_THESE[ZIPFile][Action] = rc
                            ThingsToDoIterator.comeBackToCurrentZIP()
                            continue
                        del(rc)
                        if ret:
                            if self.parentExeThread:
                                self.parentExeThread.set("Failed command: " + command)
                            else:
                                print "Failed command: " + command
                else:
                    if ZIPFile in COME_BACK_TO_THESE.keys() and Action in COME_BACK_TO_THESE[ZIPFile].keys():
                            rc = COME_BACK_TO_THESE[ZIPFile][Action]
                            del(COME_BACK_TO_THESE[ZIPFile][Action])
                    else:
                        rc = make_ref(self.OUTDIR, ZIPFile, self.GUI, self.parentExeThread, CleanUp=(not self.DEBUG))
                    ret = rc.next()
                    if ret == "COMEBACK":
                        if ZIPFile not in COME_BACK_TO_THESE.keys():
                            COME_BACK_TO_THESE[ZIPFile] = {}
                        COME_BACK_TO_THESE[ZIPFile][Action] = rc
                        ThingsToDoIterator.comeBackToCurrentZIP()
                        continue
                    del(rc)
                    if ret: ret = 0  #means we successfully created the ref file
            elif Action == REFUNLINK:
                if newRef != oldRef:
                    if self.parentExeThread:
                        self.parentExeThread.setMess("status","\n*Unlinking %s\n\n" % newRef)
                    else:
                        print "\n*Unlinking %s\n\n" % newRef
                    ret = os.unlink (newRef)
            else:
                if ZIPFile in COME_BACK_TO_THESE.keys() and Action in COME_BACK_TO_THESE[ZIPFile].keys():
                            rc = COME_BACK_TO_THESE[ZIPFile][Action]
                            del(COME_BACK_TO_THESE[ZIPFile][Action])
                else:
                    rc = build(newRef,Action,self.OUTDIR)
                ret = rc.next()
                if ret == "COMEBACK":
                    if ZIPFile not in COME_BACK_TO_THESE.keys():
                        COME_BACK_TO_THESE[ZIPFile] = {}
                    COME_BACK_TO_THESE[ZIPFile][Action] = rc
                    ThingsToDoIterator.comeBackToCurrentZIP()
                    continue
                del(rc)

            if ret:
                errorMessage = "Failed on %s step with zipfile: %s" % (Action,ZIPFile)
                if ZIPFile not in self.ERRORS.keys():
                    self.ERRORS[ZIPFile] = []
                self.ERRORS[ZIPFile].append(Action)
                ThingsToDoIterator.skipCurrentZIP()
                if self.GUI and self.parentExeThread:
                    self.parentExeThread.setMess("status",errorMessage)
                else:
                    print "\n\n"+errorMessage+" See log file for details. Continuing.\n\n"
            else:
                try:
                    self.COMPLETED_ACTIONS[ZIPFile].append(Action)
                except KeyError:
                    self.COMPLETED_ACTIONS[ZIPFile] = []
                    self.COMPLETED_ACTIONS[ZIPFile].append(Action)
            if SAFETY:
                self.BackupSelf(resetTimeStamp=True)
        return self.ERRORS
    ###############
###############
def getPreviousCore(coreSaveFileName):
    """
    Returns the saved version of a previous core object.
    """
    if (not coreSaveFileName) or (not os.path.exists(coreSaveFileName)):
        return None
    BACKUP_FILE_OBJECT = open(coreSaveFileName,"r")
    try:
        prevCore = pickle.load(BACKUP_FILE_OBJECT)
    except:
        raise Exception, "Either you tried to load a core save that didn't exist or it wasn't unpickleable."
    BACKUP_FILE_OBJECT.close()
    return prevCore
###############
if __name__ == '__main__' :
    baseApp = core()
    baseApp.run_nongui(__version__)
    
    
