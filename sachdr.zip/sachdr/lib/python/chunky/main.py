#!/usr/bin/env python
#
#   chunky
#
#   Routine to optimize space when writing to media such as DVD
#   Chunks data into size to fit on DVD
#
#   Steve Azevedo, July, 2006
#

# MAX in chunk, 4.2 is good for DVD
GB = 1024 * 1024 * 1024
MAXGB = GB * 4.2
PROG_VERSION = "2007.141"
MD5SUM = "md5sum"
ALL = False
import os, os.path, string, sys, getopt, shutil, hashlib

def usage () :
    me = 'chunky'
    sys.stderr.write ("%s\n" % PROG_VERSION)
    sys.stderr.write ("%s -d path_to_data [-w path_to_write_links] [-s service_name][-a][-c][-m max_GB]\n" % me)
    sys.stderr.write ("-d\tpath to input data that gets written to DVD or disk\n")
    sys.stderr.write ("-w\tpath to output\n")
    sys.stderr.write ("-s\tname of service run or backup. As example: \"CAFE01\"\n")
    sys.stderr.write ("-a\tchunky all files not just .ref .tar and .zip files\n")
    sys.stderr.write ("-c\tcopy instead of linking. Good for copying to USB disk.\n")
    sys.stderr.write ("-m\tmaximum size of each chunk in GB.\n")

def md5sum (f) :
    #sum5 = ""
    #command = "%s %s" % (MD5SUM, file)
    #fh = os.popen (command)
    #while 1 :
        #line = fh.readline ()
        #if not line : break
        #line = line[:-1]
        #sum5, dum = string.split (line)

    #fh.close ()
    #return '????????????????????????????????'
    try :
        fh = file (f, 'rb')
        m = hashlib.new("md5")
        while 1 :
            d = fh.read (8096)
            if not d : break
            m.update (d)
            
        fh.close ()
        sum5 = m.hexdigest ()
    except IOError, inst :
        sys.stderr.write ("md5sum failed on: %s\n" % f)
        sum5 = '????????????????????????????????'
    
    return sum5

def chunk (msz = MAXGB) :
    '''   Return list of files totaling MAXGB size   '''
    global DICT, SORTED

    chunked = []
    
    i = 0
    # Start with largest file
    total = DICT[SORTED[0]]
    chunked.append (SORTED[0])
    SORTED.remove (SORTED[0])
    n = len (SORTED)

    # Loop to end of list of files or until MAXGB is reached 
    while i < n :
        #print i, n
        # Size of this file
        sz = DICT[SORTED[i]]
        # We can still add files to our list
        if sz + total <= msz :
            total = total + sz
            # Add file to our list
            chunked.append (SORTED[i])
            # Remove file from SORTED list
            SORTED.remove (SORTED[i])
            #i = 0
            n = len (SORTED)
        # This file won't fit so try the next smallest one
        else :
            i = i + 1

    # Return list and total MB in list
    return chunked, total

def sort_by_size (a, b) :
    '''   Sorts list by file size, largest to smallest   '''
    aa = string.split (a, "\t")
    bb = string.split (b, "\t")

    if int (aa[0]) > int (bb[0]) :
        return -1
    if int (aa[0]) < int (bb[0]) :
        return 1
    else :
        return 0

def check_file (dum, dir, files) :
    '''   Make a list of files under a given directory   '''
    global DICT, FILES, MD, ALL
    add = True
    for f in files :
        if not ALL:
            #only add files with extensions .zip .tar.gzt and .ref
            add = (string.find(f,".zip") + 1) or (string.find(f,".tar.bz2") + 1) or (string.find(f,".ref") + 1)
        if add:
            file = os.path.join (dir, f)
            if os.path.isfile (file) :
                sz = os.stat (file)[6]
                #file = "\"" + file + "\""
                DICT[file] = sz
                MD[file] = md5sum (file)
                FILES.append (str (sz) + '\t' + file)

def newpath (full, xtra) :
    '''   Return new root path  '''
    # =-=-=-=-=- Not currently used -=-=-=-=-=-=-=-
    base = os.path.basename (full)
    dir = os.path.dirname (full)
    ldir = string.split (dir, os.sep)
    lxtra = string.split (xtra, os.sep)
    n = len (lxtra)
    #n = len (ldir) - n
    ldir = ldir[n:]
    relpath = string.join (ldir, os.sep)

    return relpath, base

def disk_size (dir) :
    f = os.statvfs (dir)
    s = f.f_bsize * f.f_bavail
    
    return s


if __name__ == "__main__" :
    PATH = ""
    ROOT = "/data"
    WRITEDIR = "."
    SERVICE = ""
    COPY = False

    try :
        opts, args = getopt.getopt (sys.argv[1:], "d:r:w:s:#hacm:")
    except :
        sys.stderr.write ("Can't read options")

    ROOTSET = False
    for o, a in opts :
        if o == '-#' :
            print PROG_VERSION
            sys.exit ()
        #   Base directory for data 
        elif o == '-d' :
            if os.path.exists(a):
                PATH = a
            else:
                sys.stderr.write("Source path \"" + a + "\" Does Not exist!\n")
                sys.exit(-1)
        #   Root directory written to DVD will not include this
        elif o == "-r" :
            ROOT = a
            ROOTSET = True
        #   Text to prepended to the directory name on DVD
        elif o == "-s" :
            SERVICE = a
        elif o == "-h" :
            usage ()
            sys.exit ()
        #   Directory to write links to
        elif o == "-w" :
            if os.path.exists(a):
                WRITEDIR = a
            else:
                sys.stderr.write("Destination path \"" + a + "\" Does not exist!\n")
                sys.exit(-2)
        # include all files not just .ref, .zip, or .tar.bz2
        elif o == '-a' :
            ALL = True
        # Copy instead of link
        elif o == '-c' :
            COPY = True
        elif o == '-m' :
            try:
                MAXGB = float (a) * GB
            except ValueError:
                sys.stderr.write("\nInvalid argument \"" + a + "\" for option -m\n\n")
                usage()
                sys.exit(-3)
        else :
            print "%s option not supported" % o
            sys.exit (-4)

    if COPY == True :
        os.umask (0003)
        if disk_size (WRITEDIR) < disk_size (PATH) :
            sys.stderr.write ("There is not enough space on: %s\n" % WRITEDIR)
            sys.exit (-5)
            
    if ROOTSET == False :
        ROOT = PATH

    if not os.path.isabs (PATH) :
        PATH = os.path.abspath (PATH)
        
    if PATH == "" :
        sys.stderr.write ("You must provide a path to the zip files with the -d option!\n")
        sys.exit (-6)
        
    #print SERVICE
    # List of files and sizes
    FILES = []
    # File sizes keyed by file name
    DICT = {}
    # md5sum keyed on file name
    MD = {}
    # List of files sorted by size
    SORTED = []
    # Walk down file tree
    print "Examining files...",
    os.path.walk (PATH, check_file, 1)
    print
    # Sort our file list by size, and build a list of files
    FILES.sort (sort_by_size)
    for vk in FILES :
        f = string.split (vk, '\t')[1]
        # Make sure path is quoted to hide illegal chars
        #f = "\"" + f + "\""
        SORTED.append (f)

    i = 0
    while len(SORTED) :
        print "Chunking %sDISK%02d" % (SERVICE, i)
        if COPY == True :
            c, t = chunk (disk_size (WRITEDIR))
        else :
            c, t = chunk ()

        newdir = "%sDISK%02d" % (SERVICE, i)

        fileindex = ''
        fileindex +=  "\tDISK:\t" + str (i)
        fileindex += "\n\tTOTAL: " + str (t) + " MAX: " + str (MAXGB)
        i = 1 + i
        for f in c :
            r, b = newpath (f, ROOT)
            #b = b[:-1]
            #r = r[1:]
            path = os.path.join (WRITEDIR, newdir)
            #print path; sys.exit ()
            # Size, md5sum, filename
            fileindex +=  "\n%d\t%s\t%s" % (DICT[f], MD[f], f)

            try :
                os.makedirs (path)
            except OSError :
                pass
            except :
                sys.stderr.write ("Failed to create directory: %s\n" % path)

            lfile = os.path.join (path, b)
            #print f, file, r
            try :
                # If copy mode copy the data otherwise make a link
                if COPY == True :
                    shutil.copyfile (f, lfile)
                else :
                    os.symlink (f, lfile)

            except :
                sys.stderr.write ("Failed to create symlink: %s\n" % lfile)

        fh = file (os.path.join (WRITEDIR, newdir, "fileindex"), 'w+')
        fh.write (fileindex)
        fh.close ()

    print "Done..."
