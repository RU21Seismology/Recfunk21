'''
File:     unchunky.py
Author: Joe Stradling
Description:
    Graphical interface for unchunky core.
Modified:
    Jayson Barr 7/22/08		-Added state saving support, bug fixes
    Jayson Barr 8/13/08     -Added ref file input support, bug fixes
    Jayson Barr 9/16/09		-Fixed thread safety probs with Tk
'''
__version__ = "2009.47"

import time, tkFileDialog, Pmw, string, os, os.path, re, functools
from tkMessageBox import showerror
from tkMessageBox import showwarning
from traceback import *
from Tkinter import *
from unchunky_core import *
from KThread import *
import Queue


# This is a significant change to unchunky, so I will add a note here:
#
#     In order to make unchunky thread safe, all of the updating of the logs
#     and the "message" class status that is on the bottom of the window is
#     actually a Queue.Queue buffer that is set by the threads created by
#     exe_thread.  When you run exe_thread.start() it creates a thread that
#     runs exe_thread.run and issues a tk event that activates
#     exe_thread.processQueue.  processQueue goes through the whole queue and
#     sets the log and message object status.  At the end of the function it
#     creates a virtual event to be issued 10 milliseconds later that will
#     execute processQueue again.  This is repeated so the log is constantly
#     updated.  The function will stop executing when the exe_thread.thread is
#     killed.
#     exe_thread.Queue is a Queue.Queue object.  It is expected that all objects
#     in the Queue are an iterable of length two with each element a string.
#     The first string should be the name of a "buffer" to change.  The names
#     expected are "status", "log", "question", and "text_state".  The second
#     string is a message to send.  If the buffer is "status", then it will
#     call message.set(msg) and therefore set the message status.  If the buffer
#     was "log" then it calls message.log.appendtext(msg) and adds it to the
#     mess log.  If the buffer was "question", then it splits the secind string
#     on the first ":" and creates a dialogue asking for input from the user.
#     The text before the colon is assumed to be the command that issued the
#     question and the text after is the message that the command is asking of the
#     user.  This is the way input if taken from the user to the thread in case
#     pexpect finds a question for the user from rt130cut or another process it runs.
#      


# Added by Jayson Barr, 7/22/08:
DEFAULT_RUN_SAVING_STATE = False
# --

padding = 8
open_win = 0
LAUNCHED_FROM = os.getcwd()
EXE_COUNT = 0
failed = "The PASSCAL environment variable is not set.  Please set this variable before running unchunky!\n\n"

try:
    if not os.path.isdir(os.environ['PASSCAL']):
        notify(failed, None)
        sys.exit(-1)
except:
        notify(failed, None)
        sys.exit(-1)

UNCHUNKY=os.path.join (os.environ['PASSCAL'], "lib/python/chunky/")
#UNCHUNKY= "/home/azevedo/Svn/passoft/src/chunky"



#----------------------------------------------------------------------------------------------------------#
def kill_child_processes(mypid=os.getpid()):
    fd = os.popen("ps -o user,pid,ppid")
    pidTable = fd.read().split('\n')
    fd.close ()
    pidTable.pop(0)
    for i in pidTable:
        i = i.split()
        if len(i) < 2: continue
        ppid = int(i[len(i)-1])
        pid = int(i[len(i)-2])
        if ppid == mypid:
            #recursively kill child processes of child processes
            kill_child_processes(pid)
            try:
                os.kill(pid, 9)
            except OSError:
                pass
            #ignore already closed processes
    return 0


#----------------------------------------------------------------------------------------------------------#
def show_about():
    about_root = Tk()
    about_root.title("Unchunky " +__version__+ " About")
    frame = Frame(about_root, highlightbackground="orange", highlightthickness=3, highlightcolor="orange")
    frame.pack(expand=1, fill=BOTH)
    text = Text(frame, bg="white", width=26, height=10)
    message = "A wrapper around tar/unzip\nrt130cut\nref2mseed/ref2segy/ref2log\n\n"
    message = message + "Unchunky VERSION: " + __version__ + "\n\nOriginal version by\nSteve Azevedo\nGUI by Joe Stradling\n\n"
    message = message + "Please email bug reports, comments, or question to\n\npasscal@passcal.nmt.edu\n"
    text.insert(END, message)
    text.pack()
    okBtn = Button(frame, text="Exit", command=about_root.destroy)
    okBtn.pack()
    about_root.mainloop()
#----------------------------------------------------------------------------------------------------------#
def show_help():
    help_root = Tk()
    help_root.title("Unchunky " +__version__+  " Help")
    help_root.option_readfile(UNCHUNKY+"/optionsDB")
    frame = Frame(help_root, highlightbackground="orange", highlightthickness=3, highlightcolor="orange")
    frame.pack(expand=1, fill=BOTH)
    notebook = Pmw.NoteBook(frame)
    notebook.pack(fill=BOTH, expand=1, padx=5, pady=5)
    srcPage = notebook.add('Source')
    destPage = notebook.add('Destination')
    fltrPage = notebook.add('Filter')
    outPage = notebook.add('Output')
    notebook.tab('Source').focus_set()
    srcText = Pmw.ScrolledText(srcPage, text_bg='white', text_height=30, text_width=70)
    destText = Pmw.ScrolledText(destPage, text_bg='white', text_height=30, text_width=70)
    fltrText = Pmw.ScrolledText(fltrPage, text_bg='white', text_height=30, text_width=70)
    outText = Pmw.ScrolledText(outPage, text_bg='white', text_height=30, text_width=70)
    L = [[srcText, "src"], [destText, "dest"], [fltrText, "fltr"], [outText, "out"]]
    for i in L:
        contents = open(UNCHUNKY + "/helpFiles/"+i[1]+"Help.txt", "r").read()
        i[0].insert(END, contents)
        i[0].pack()
        i[0].configure(text_state=DISABLED)
    okBtn = Button(frame, text="Exit", command=help_root.destroy)
    okBtn.pack()
    notebook.setnaturalsize()
    help_root.mainloop()

#----------------------------------------------------------------------------------------------------------#
def processTime(exeTime):
    hours = int(exeTime) / (60*60)
    exeTime = exeTime % (60*60)
    minutes = int(exeTime) / 60
    seconds = exeTime % 60
    return "%d hrs %d min %*.*f sec" % (hours,minutes,2,2,seconds)

#----------------------------------------------------------------------------------------------------------#
def notify(message, parent):
    tp = Toplevel(parent)
    tp.transient(tp.master)
    tp.title("Unchunky Message")
    frame = Frame(tp, relief=GROOVE, borderwidth=2)
    frame.pack(fill=BOTH, expand=1)
    mess = Message(frame, text=message, bg="lightyellow", aspect=150, width=450)
    okBtn = Button(frame, text="OK", command=tp.destroy)
    mess.pack(expand=1, fill=BOTH)
    okBtn.pack(side=BOTTOM)

#
#   A simple Signal/Slot mechanism
#   RSA
    
#
#   A dictionary of Tkinter event numbers keyed by event name
#
eventList = { 'KeyPress' : '2', 'KeyRelease' : '3', 'ButtonPress' : '4',
              'ButtonRelease' : '5', 'Motion' : '6', 'Enter' : '7',
              'Leave' : '8', 'FocusIn' : '9', 'FocusOut' : '10',
              'Expose' : '12', 'Visibility' : '15', 'Destroy' : '17',
              'Unmap' : '18', 'Map' : '19', 'Reparent' : '21',
              'Configure' : '22', 'Gravity' : '24', 'Circulate' : '26',
              'Property' : '28',  'Colormap' : '32','Activate' : '36',
              'Deactivate' : '37'}

class Registry :
    ''' Set up a crude signal slot mechanism   '''
    def __init__ (self) :
        self.connections = {}

    def add (self, occasion, function) :
        if eventList.has_key (occasion) :
            occasion = eventList[occasion]
        if self.connections.has_key (occasion) == 0 :
            self.connections[occasion] = [function]
        else :
            self.connections[occasion].append (function)

    def remove (self, occasion, function) :
        if self.connections.has_key (occasion) :
            self.connections[occasion].remove (function)

    def execute (self, occasion) :
        if self.connections.has_key (occasion) :
            for function in self.connections[occasion] :
                apply (function)
                
import Tkinter
class StatusBar(Tkinter.Frame):
    '''   A simple status bar   '''
    def __init__(self, master):
        Tkinter.Frame.__init__(self, master)
        self.tv = Tkinter.StringVar ()
        self.label = Tkinter.Label(self, bd=1,
                                   relief=Tkinter.SUNKEN,
                                   anchor=Tkinter.W,
                                   width = 45, bg = 'white',
                                   textvariable = self.tv)
        self.label.pack(fill=Tkinter.X)

    def set(self, args):
        self.tv.set (args)
        self.label.update_idletasks()

    def clear(self):
        self.tv.set ("")
        self.label.update_idletasks()

class Button (Tkinter.Button) :
    ''' Our button class   '''
    def __init__ (self, root, t=None, **kw) :
        # Sub-class Tkinter.Button
        apply (Tkinter.Button.__init__, (self, root), kw)
        self.configure (text = t)
        self.register = Registry ()
        #print self.configure ()

    #  Add a signal/slot
    def signal_add (self, signal, slot) :
        self.bind ('<' + signal + '>', self.dispatch)
        self.register.add (signal, slot)

    #  Remove a signal/slot
    def signal_remove (self, signal, slot) :
        self.unbind ('<' + signal + '>')
        self.register.remove (signal, slot)

    #  Dispatch callback
    def dispatch (self, what) :       
        self.register.execute (what.type)
#
#   End Signal/Slot
#

#----------------------------------------------------------------------------------------------------------#
class dialog:
    def __init__(self,message, parent):
        self.retVal = -1
        self.tp = Toplevel(parent)
        self.tp.transient(self.tp.master)
        frame = Frame(self.tp, relief=GROOVE, borderwidth=2)
        frame.pack(fill=BOTH, expand=1)
        mess = Message(frame, text=message, bg="lightyellow", aspect=150, width=450)
        okBtn = Button(self.tp, text="OK", command=self.ok_click)
        cncBtn = Button(self.tp, text="Cancel", command=self.cancel_click )
        mess.pack(expand=1, fill=BOTH)
        okBtn.pack(side=LEFT, padx=10, pady=10)
        cncBtn.pack(side=LEFT, padx=10, pady=10)
        while self.retVal != 0 and self.retVal != 1:
            root.update()
    def ok_click(self):
        self.retVal = True
        self.tp.destroy()
    def cancel_click(self):
        self.retVal = False
        self.tp.destroy()
        

#----------------------------------------------------------------------------------------------------------#
class confirm:
    def __init__(self, frame, message):
        self.result = False
        self.dialog = Pmw.Dialog(
            frame.master,
            buttons=('OK', 'Cancel'),
            defaultbutton='OK',
            title='Please Confirm',
            command = self.execute)
        w = Label(self.dialog.interior(), text=message, bg="black", fg="red", pady=20)
        w.pack(expand=1, fill=X, padx=4, pady=4)
        self.dialog.activate()

    def execute(self, result):
        self.dialog.deactivate()
        if result == "OK":
            self.result = True
        else:
            self.result = False
#----------------------------------------------------------------------------------------------------------#
class findWidget:
    def __init__(self, log):
        self.log = log
        self.index = "1.0"
        self.caseSens = False
        self.wholeWord = False
        self.fromCurs = False
        entStr = StringVar()
        self.parent = self.log.component("hull")
        #new window for find 
        self.tp = Toplevel(self.parent)
        #force window ontop of others
        self.tp.transient(self.tp.master)

        entFrame = Frame(self.tp); entFrame.pack(expand=1, fill=X)
        chkFrame = Frame(self.tp); chkFrame.pack(expand=1, fill=X)
        btnFrame = Frame(self.tp); btnFrame.pack(expand=1, fill=X)

        label = Label(entFrame, text="Find: "); label.pack(side=LEFT)

        #entry to hold search argument
        self.ent = Entry(entFrame, textvar=entStr); self.ent.pack(side=LEFT, expand=1, fill=X)

        #option buttons
        self.chkBtns = Pmw.RadioSelect(chkFrame,
                                               buttontype='checkbutton',
                                               command=self.findChk)
        self.chkBtns.add("Case Sensitive"); self.chkBtns.add("Whole Words"); self.chkBtns.add("From Cursor")
        self.chkBtns.pack(expand=1, fill=X)
        #control buttons
        self.btnBox = Pmw.ButtonBox(btnFrame)
        self.btnBox.add("Find", command=self.find)
        self.btnBox.add("Find Next", command=self.findNext)
        self.btnBox.add("Done", command=self.done)
        self.btnBox.pack()

    #verify that the given index contains a whole word instance of the target
    def isWholeWord(self, index, targ):
        spaceBefore = spaceAfter = False
        preWordIndex  =index.split(".")[0] + "." + str(int(index.split(".")[1]) - 1)
        postWordIndex =index.split(".")[0] + "." + str(int(index.split(".")[1]) + len(targ) + 1) 
        testString = self.log.get(preWordIndex, postWordIndex)
        if len(testString) == len(targ):
            #New lines before and after targ
            spaceBefore = spaceAfter = True
        elif len(testString) == (len(targ) + 1):
            #New line either before or after targ
            if int(preWordIndex.split(".")[1]) < 0:
                spaceBefore = True
                spaceAfter = testString[len(testString) - 1].isspace()
            else:
                spaceBefore = testString[0].isspace()
                spaceAfter = True
        else:
            #non newline character before or after targ
            spaceBefore = testString[0].isspace()
            spaceAfter = testString[len(targ) + 1].isspace()
        return spaceBefore and spaceAfter

    #increment the index
    def indexInc(self):
        col = int(self.index.split(".")[1]) + 1
        self.index = self.index.split(".")[0] + "." + str(col)

    #called when find next button pressed, increment index
    #and search again
    def findNext(self):
        targ = self.ent.get()
        #verify entry contains something!
        if not targ:
            notify("\n\n    End of log reached    \n\n", self.parent)
            return
        try:
            #delete any left over tags
            self.log.tag_delete("highlight")
        except:
            pass
        #increment index
        self.indexInc()
        #actually search for the target
        self.index = self.log.search(targ, self.index,stopindex=END,
                                               nocase=(not self.caseSens),
                                               exact=self.wholeWord)
        if self.index: #if index returned it found something
            #should it be a whole word, check if it isn't search again
            if not self.isWholeWord(self.index, targ) and self.wholeWord:
                self.findNext()
            #Found something, highlight it
            self.log.tag_config("highlight", background="orange")
            highlightstop = self.index.split(".")[0]+"."+str(int(self.index.split('.')[1]) + len(self.ent.get()))
            self.log.tag_add("highlight", self.index, highlightstop)
            #scroll to the found word
            self.log.see(self.index)
        elif(self.fromCurs):
            #didn't find anything, if from cursors was checked see if they want to start from
            #the begginning
            d = dialog("\n\nEnd of log reached, would you like to search from the beginning?\n\n", self.parent)
            if d.retVal:
                self.index = "1.0"
                #uncheck the fromCurs checkbox, we're searching from the beginning
                self.chkBtns.invoke(2)
                self.find()
            else:
                #don't search from beginning, just reset index back to current position
                self.index = self.log.index(CURRENT)
        else:
            #target not found, already searched from beginning, report end of log reached
            notify("\n\n    End of log reached    \n\n", self.parent)
            self.index = self.log.index(CURRENT)
            try:
                #delete any residual highlighting left by previouse search
                self.log.tag_delete("highlight")
            except:
                pass

    #method gets called when find button pressed
    def find(self):
        try:
            #delete any residual highlighting left by previouse search
            self.log.tag_delete("highlight")
        except:
            pass

        #default start position is beginning of document
        start = "1.0"

        #get target and verify it actually contains something
        targ = self.ent.get()
        if not targ:
            notify("\n\n    End of log reached    \n\n", self.parent)
            return

        #If user wants to search from current cursor position reset start index
        if self.fromCurs:
            start = self.log.index(CURRENT)
        #actually search for target
        self.index = self.log.search(targ,start,stopindex=END, nocase=(not self.caseSens), exact=self.wholeWord)

        if self.index:
            #should it be a whole word, check if it isn't search again
            if not self.isWholeWord(self.index, targ) and self.wholeWord:
                self.findNext()
            #Found something, highlight it
            self.log.tag_config("highlight", background="orange")
            highlightstop = self.index.split(".")[0]+"."+str(int(self.index.split('.')[1]) + len(self.ent.get()))
            self.log.tag_add("highlight", self.index, highlightstop)
            #scroll to the found word
            self.log.see(self.index)
        elif(self.fromCurs):
            #not found, if from cursors was selected ask to search from beginnig
            d = dialog("\n\nEnd of log reached, would you like to search from the beginning?\n\n", self.parent)
            if d.retVal:
                self.index = "1.0"
                self.chkBtns.invoke("From Cursor")
                self.find()
            else:
                self.index = self.log.index(CURRENT)
        else:
            #not found, confess your failure
            notify("\n\n    End of log reached    \n\n", self.parent)
            self.index = self.log.index(CURRENT)
            try:
                #delete any residual highlighting left by previouse search
                self.log.tag_delete("highlight")
            except:
                pass

    def done(self):
        self.tp.destroy()

    def findChk(self, button, junk):
        if button == "Case Sensitive":
            self.caseSens = not self.caseSens
        elif button == "Whole Words":
            self.wholeWord = not self.wholeWord
        elif button == "From Cursor":
            self.fromCurs = not self.fromCurs

#----------------------------------------------------------------------------------------------------------#
#class for providing menu interface
class menu: 
    def __init__(self, frame, mess, parentUnchunkyApp):
        self.mess = mess
        self.frame = frame
        # --Added by Jayson Barr, 7/22/08-- #
        self.parentUnchunkyApp = parentUnchunkyApp
        self.state_save_filename = StringVar()
        self.run_saving_state = BooleanVar()
        if DEFAULT_RUN_SAVING_STATE:
            self.run_saving_state.set(True)
        else:
            self.run_saving_state.set(False)
        # --------------------------------- #
        self.fileBtn = self.make_fileBtn()
        self.viewBtn = self.make_viewBtn()
        self.cfgBtn = self.make_cfgBtn()
        self.hlpBtn = self.make_hlpBtn()
        self.cfgFile = None

    def getCfg (self) :
        file = tkFileDialog.askopenfilename (title = "Set ref2 defaults file, -l (ell) option.",
                                             parent = self.frame,
                                             initialdir = LAUNCHED_FROM)
        if file :
            self.cfgEntry.delete (0, Tkinter.END)
            self.cfgEntry.insert (0, file)
            
    def set_defaults_file (self) :
        def set_defaults (arg) :
            if arg == 'OK' :
                self.cfgFile = self.cfgEntry.get ()
                if self.cfgFile == "" :
                    self.cfgFile = None
                elif not os.path.exists (self.cfgFile) :
                    showerror ("File Error", "The file: \"%s\" does not exist" % self.cfgEntry.get ())
                    self.cfgFile = None
            else :
                self.cfgFile = None
            mydialog.deactivate (arg)
        
        mydialog = Pmw.Dialog (self.frame,
                               buttons = ('OK', 'Cancel'),
                               defaultbutton = 'OK',
                               title = "Set ref2segy/ref2mseed -l defaults_file",
                               command = set_defaults)      
        mydialog.withdraw ()
        
        f1 = Tkinter.Frame (mydialog.interior (), relief = Tkinter.GROOVE, bd = 2)
        cfgButton = Button (f1, text = "Defaults file")
        cfgButton.grid (row = 0, sticky = 'ew')
        cfgButton.signal_add ('ButtonRelease', self.getCfg)
        
        self.cfgEntry = Tkinter.Entry (f1, bg = 'LightYellow', width = 48)
        self.cfgEntry.grid (row = 0, column = 1, sticky = 'ew')
        f1.grid (sticky = 'ew')
        f1.grid_columnconfigure (0, weight = 1)
        f1.grid_columnconfigure (1, weight = 1)

        f1.pack (expand = 1, fill = Tkinter.X)

        if self.cfgFile != None :
            self.cfgEntry.insert (0, self.cfgFile)
            
        mydialog.activate ()
        
    def make_hlpBtn(self):
        hlpBtn = Menubutton(self.frame, text='Help', underline=0)
        hlpBtn.pack(side=LEFT)
        hlpBtn.menu = Menu(hlpBtn)
        hlpBtn.menu.add_command(label='Help', underline=0, command=show_help)
        hlpBtn.menu.add_command(label='About', 
                                underline=0, 
                                command=show_about)
        
        hlpBtn['menu'] = hlpBtn.menu
        return hlpBtn
    
    def make_cfgBtn(self):
        cfgBtn = Menubutton(self.frame, text='Configure', underline=0)
        cfgBtn.pack(side=LEFT)
        cfgBtn.menu = Menu(cfgBtn)
        cfgBtn.menu.add_command(label='Defaults file...', underline=0, 
                                command=self.set_defaults_file)
        # Added by Jayson Barr on 7/22/08
        cfgBtn.menu.add_radiobutton (label="Run saving state",underline=0,
                                        value=1,variable=self.run_saving_state)
        cfgBtn.menu.add_radiobutton (label="Run without saving state",underline=0,
                                        value=0,variable=self.run_saving_state)

        cfgBtn['menu'] = cfgBtn.menu
        return cfgBtn

    def make_fileBtn(self):
        fileBtn = Menubutton(self.frame, text='File', underline=0)
        fileBtn.pack(side=LEFT)
        fileBtn.menu = Menu(fileBtn)
        fileBtn.menu.add_command(label='Load state',underline=0,command=self.load_state)
        fileBtn.menu.add_command(label='New Window', underline=0, command=self.new_window)
        fileBtn.menu.add_command(label='Close Window', 
                                 underline=0, 
                                 command=self.quit_window)
        
        fileBtn.menu.add_command(label='Exit', underline=0, command=self.exit_app)
        fileBtn['menu'] = fileBtn.menu
        return fileBtn

    def make_viewBtn(self):
        viewBtn = Menubutton(self.frame, text='View', underline=0)
        viewBtn.pack(side=LEFT)
        viewBtn.menu = Menu(viewBtn)
        viewBtn.menu.add_command(label='Open Log', underline =0, command=self.mess.displayLog)
        viewBtn['menu'] = viewBtn.menu
        return viewBtn

    def load_state(self):
        global LAUNCHED_FROM
        origin = LAUNCHED_FROM
        name = "Please choose an Unchunky state save file"
        if os.path.isdir(os.path.dirname(origin)) or os.path.isdir(origin):
            self.state_save_filename.set(tkFileDialog.askopenfilename(  title = name,
                                                            filetypes=[ ('All', '*'),
                                                                        ('Unchunky Save files', 'unchunky_*.backup'),],
                                                            parent = self.frame,
                                                            initialdir = origin)
                                        )
        if self.state_save_filename.get():
            self.parentUnchunkyApp.control.updateFromCore()
    def new_window(self):
        newFrame = Frame(self.frame)
        newFrame.pack()
        unchunky_app(newFrame)

    def quit_window(self):
        global open_win
        if open_win == 1:
            self.exit_app()
            return 0
        
        self.frame.master.destroy()
        open_win = open_win - 1

    def exit_app(self):
        global EXE_COUNT
        if EXE_COUNT > 0:
            conf = confirm(self.frame,
                           "Are you sure you want to exit, all incomplete processes will be terminated!")
            if conf.result:
                kill_child_processes(os.getpid())
                os.kill(os.getpid(), 9)
                
        else:
            sys.exit(0)


#----------------------------------------------------------------------------------------------------------#
# class for getting source type (file archive or directory) and source target
class src_chooser:
    def __init__ (self,root, fltr):
        self.filenames = []
        self.fltr = fltr
        self.mode = "Dir"
        self.name = "Please choose a directory containg zip files"
        self.path = StringVar()
        self.path.set(LAUNCHED_FROM)
        self.frame = Frame(root)
        self.frame.pack(expand=1, fill=BOTH)

        self.mode_opts = ("Dir", "File")
        #combo box for choosing source type
        self.button = Button(self.frame, text="Source", command=self.choseEntry)
        self.combobox = Pmw.ComboBox(self.frame,
                                     entry_width=3,
                                     labelpos='wn',
                                     listbox_width=5,
                                     listbox_height=1,
                                     dropdown=1,
                                     selectioncommand=self.toggle,
                                     scrolledlist_items=self.mode_opts,
                                     entry_fg="black", entry_bg="LightYellow")
        
        self.button.pack(side=LEFT)
        self.combobox.pack(side=LEFT)
        self.combobox.selectitem(self.mode_opts[0])
        #entry field for manually entering target
        self.entry = Entry(self.frame, width=40, textvariable=self.path, bg="LightYellow")
        self.entry.pack(side=LEFT,expand=1,fill=X)

    def disable(self):
        self.button.configure(state=DISABLED)
        self.entry.configure(state=DISABLED)
        self.combobox.component('label').configure(state=DISABLED)
        self.combobox.component('entry').configure(state=DISABLED)
        self.combobox.component('entry').update()
        self.combobox.component('arrowbutton').configure(state=DISABLED)
        
    def enable(self):
        self.button.configure(state=NORMAL)
        self.entry.configure(state=NORMAL)
        self.combobox.component('label').configure(state=NORMAL)
        self.combobox.component('entry').configure(state=NORMAL)
        self.combobox.component('arrowbutton').configure(state=NORMAL)
        
    def toggle(self, entry):
        if entry == "File" or entry == "Dir": self.mode= entry
        
    def choseEntry(self):
        origin = LAUNCHED_FROM
        if self.mode == "Dir":
            self.fltr.enableFilters()
            self.name = "Please choose a directory containg zip files"
            if os.path.isdir(os.path.dirname(self.path.get())) or os.path.isdir(self.path.get()):
                origin = self.path.get()
            choice = tkFileDialog.askdirectory (
                                title = self.name,
                                parent = self.frame,
                                initialdir = origin)
            if choice:  self.path.set(choice)
        else:
            #self.fltr.disableFilters()
            self.name = "Please choose an archive file"
            origin = "/"
            MultFileNames = self.path.get().split(" ")
            reverseIndices = range(1,len(MultFileNames)+1)
            reverseIndices.reverse()
            for i in reverseIndices:
                _tempName = " ".join(MultFileNames[:i])   #Join by spaces with less and less parts of self.path in case of spaces in file name
                if os.path.isdir(os.path.dirname(_tempName)) or os.path.isdir(_tempName):
                    origin = _tempName
                    del(_tempName)
                    break
                elif i == reverseIndices[-1]:
                    try:
                        origin = os.environ["HOME"]
                    except KeyError:
                        pass

            self.filenames = tkFileDialog.askopenfilenames(
                title = self.name,
                filetypes=[
                    ('All', '*'),
                    ('Zip Files', '*.ZIP *.zip'),
                    ('Bzip Files', '*.bz2 *.BZ2'),
                    ('Tar Files', '*.tar *.TAR'),
                    ('Ref Files', '*.ref *.REF')],
                    parent = self.frame,
                    initialdir = origin)
            if len(self.filenames) > 0:
                names = ""
                for i in self.filenames:
                    names += (i + ' ')
                    
                names = names[:-1]
                self.path.set(names)
            else:
                pass

#----------------------------------------------------------------------------------------------------------#
#class for chossing destination path
class dest_chooser:
    def __init__(self, frame, mess):
        self.mess = mess
        self.path = StringVar()
        self.path.set(LAUNCHED_FROM)
        self.frame=Frame(frame)

        self.frame.pack(side=LEFT, expand=1, fill=X)

        #button used for opening a file dialog
        self.button = Button(self.frame,width=10, text="Destination", command=self.openChoser, height=1)
        #entry  for manually typing a path or displaying a path
        self.entry = Entry(self.frame, width=40, textvariable=self.path, bg="LightYellow")
        self.button.pack(side=LEFT)
        self.entry.pack(expand=1, fill=X)
        
    def enable(self):
        self.button.configure(state=NORMAL)
        self.entry.configure(state=NORMAL)
    def disable(self):
        self.button.configure(state=DISABLED)
        self.entry.configure(state=DISABLED)
    def openChoser(self):
        if not os.path.exists(self.path.get()):
            self.path.set(LAUNCHED_FROM)
        origin = LAUNCHED_FROM
        if os.path.isdir(os.path.dirname(self.path.get())) or os.path.isdir(self.path.get()):
            origin = self.path.get()
        x = tkFileDialog.askdirectory (
            parent = self.frame,
            initialdir = origin) 
        if x:   self.path.set(x)

#----------------------------------------------------------------------------------------------------------#
#class for providing a filter combo box and entry
class filter_ctl:
    def __init__ (self,root):
        self.srcIsDir = True
        self.temp = ""
        self.label = Label(root,text="Filters")
        self.label.pack(expand=1, fill=BOTH)
        self.frame1 = Frame(root)
        self.frame2 = Frame(root)
        self.frame1.pack(expand=1, fill=BOTH, side=BOTTOM)
        self.frame2.pack(expand=1, fill=BOTH, side=BOTTOM)
        self.segZip = IntVar()
        self.jul = IntVar()
        self.jul.set(0)
        self.julStr = StringVar()
        self.inst = IntVar()
        self.inst.set(0)
        self.instStr = StringVar()
        self.julEnt = Entry()
        self.instEnt = Entry()
        self.segZipBtn = Checkbutton(root, text="Neo Archives Only", variable=self.segZip, command=self.segZip_click)
        self.segZipBtn.pack(side=LEFT)
        self.segZipBtn.toggle()
        self.julBtn = Checkbutton(self.frame1, text="Julian Day ",variable=self.jul, command=self.jul_click)
        self.julEnt = Entry(self.frame1,
                            width=40,
                            textvariable=self.julStr,
                            bg="LightYellow",
                            state=DISABLED,)
        
        self.instBtn = Checkbutton(self.frame2, text="Instrument", variable=self.inst, command=self.inst_click)
        self.instEnt = Entry(self.frame2,
                             width=40,
                             textvariable=self.instStr,
                             bg="LightYellow",
                             state=DISABLED)

        self.julBtn.pack(side=LEFT)
        self.julEnt.pack(side=LEFT, expand=1, fill=X)
        self.instBtn.pack(side=LEFT)
        self.instEnt.pack(side=LEFT, expand=1, fill=X)
        
    def disable(self):
        self.label.configure(state=DISABLED)
        self.segZipBtn.configure(state=DISABLED)
        self.instEnt.configure(state=DISABLED)
        self.instBtn.configure(state=DISABLED)
        self.julEnt.configure(state=DISABLED)
        self.julBtn.configure(state=DISABLED)
        
    def enable(self):
        self.label.configure(state=NORMAL)
        self.julBtn.configure(state=NORMAL)
        if self.jul.get():
            self.julEnt.configure(state=NORMAL)
            
        if self.srcIsDir:
            self.segZipBtn.configure(state=NORMAL)
            self.instBtn.configure(state=NORMAL)
            if self.inst.get() and not self.segZip.get():
                self.instEnt.configure(state=NORMAL)
                
    def disableFilters(self):
        self.segZipBtn.configure(state=DISABLED)
        self.instEnt.configure(state=DISABLED)
        self.instBtn.configure(state=DISABLED)
        self.srcIsDir = False
        
    def enableFilters(self):
        self.segZipBtn.configure(state=NORMAL)
        self.instBtn.configure(state=NORMAL)
        self.srcIsDir = True
        
    def inst_click(self):
        if self.inst.get():
            self.instEnt.configure(state=NORMAL)
        else:
            self.instEnt.configure(state=DISABLED)
            
    def jul_click(self):
        if self.jul.get():
            self.julEnt.configure(state=NORMAL)
        else:
            self.julEnt.configure(state=DISABLED)
            
    def segZip_click(self):
        if self.segZip.get():
            self.instBtn.configure(state=NORMAL)
        else:
            showerror ("Warning", "Running against archives not created by neo very likely to cause errors.")
            self.instBtn.configure(state=DISABLED)
            self.inst.set(0)
            self.instEnt.configure(state=DISABLED)


#----------------------------------------------------------------------------------------------------------#
# class for providing the radio buttons for choosing file types to extract
class radio_buttons:
    def __init__(self, frame):
        self.log = IntVar()
        self.ref = IntVar()
        self.segy = IntVar()
        self.mseed = IntVar()
        self.log_but = Checkbutton(frame, text="LOG", variable=self.log,)
        self.ref_but = Checkbutton(frame, text="REF", variable=self.ref)
        self.segy_but = Checkbutton(frame, text="SEGY", variable=self.segy)
        self.mseed_but = Checkbutton(frame, text="MSEED", variable=self.mseed)
        L = [self.ref_but, self.segy_but, self.mseed_but, self.log_but]
        self.radLabel = Label(frame, text="Extract files of type:")
        self.radLabel.pack(side=LEFT)
        for i in L:
            i.pack(side=LEFT, padx=10)

    def disable(self):
        self.radLabel.configure(state=DISABLED)
        self.log_but.configure(state=DISABLED)
        self.ref_but.configure(state=DISABLED)
        self.segy_but.configure(state=DISABLED)
        self.mseed_but.configure(state=DISABLED)

    def enable(self):
        self.radLabel.configure(state=DISABLED)
        self.log_but.configure(state=NORMAL)
        self.ref_but.configure(state=NORMAL)
        self.segy_but.configure(state=NORMAL)
        self.mseed_but.configure(state=NORMAL)

#----------------------------------------------------------------------------------------------------------#
# This class provides a method for executing in a seperate thread when the user presses start
class exe_thread:
    def __init__(self, ctl,run_safe,CONTINUE=False,):
        # Killable thread imported from Kthread.py
        self.Queue = Queue.Queue()
        self._QAndA = {}	#This is a dictionary for keeping track of answered questions from popup gui dialogs
        self.thread = KThread(target=self.run)
        self.ctl = ctl
        self.run_safe = run_safe    #Added by JB, 7/22/08
        self.mess = self.ctl.mess
        self.chkBtns = ctl.chkBtns
        self.src = ctl.src
        self.dest = ctl.dest
        self.fltr= ctl.fltr
        self.strtBtn = ctl.startButton
        self.contBtn = ctl.continueButton
        self.stpBtn = ctl.stopButton
        self.cfg = ctl.men
        self.CONTINUE = CONTINUE
        self.base = None
        # -----
        self.BackupFile = None
        self.__actionPartialFunction = None

    def evalJday(self, jday):
        if string.find(jday, ' ') != -1:
            return 1
        
        for i in string.split(jday, ','):
            for j in string.split(i,'-'):
                try:
                    j = int(j)
                    if  (1 > j) or (j > 366):
                        return 1    
                except:
                    return 1
        return 0
    
    def evalInst(self, inst):
        if string.find(inst, " ") != -1:
            return 1
        
        return 0

    def setMess(self,buffer,msg):
        self.Queue.put( (buffer,msg) )
        if buffer == "status":
            self.Queue.put( ("log",msg+"\n") )

    def processQueue(self):
        while self.Queue.qsize():
            try:
                buffer,msg = self.Queue.get(0)
                if buffer == "status":
                    self.mess.set(msg)
                elif buffer == "log":
                    self.mess.log.appendtext(msg)
                elif buffer == "question":
                    command,question = msg[:msg.index(":")],msg[msg.index(":")+1:]
                    self._QAndA[msg] = QuestionDialog("<"+command+"> "+question,"Input Required for: "+command,self.ctl.men.parentUnchunkyApp.root).retval
                elif buffer == "backup_filename":
                    if self.base.backup_filename and (self.CONTINUE or self.run_safe.get()):
                        self.ctl.men.state_save_filename.set(self.BackupFile)
                        if msg: self.mess.log.appendtext(msg)
                    self._QAndA[buffer+":"+msg] = True
                elif buffer == "terminate":
                    self.terminate(msg)
                else:
                    raise Exception, ("Unexpected buffer label for message queue: %s" % buffer)
            except Queue.Empty:
                 pass
        if not self.thread.killed:
            self.ctl.men.parentUnchunkyApp.root.after(100,self.processQueue)

    def start(self):
        self.processQueue()
        self.configure()
        self.thread.start()

    def configure(self):
        global EXE_COUNT; EXE_COUNT += 1
        self.setMess("status","Running")
        self.tStart = time.time()
        startTime = time.strftime("%Y.%j %H:%M: %S") + "\n"
        self.setMess("log",'***************Running****************\n')
        self.setMess("log","            " + startTime)
        self.setMess("log",'***************************************\n\n')
        if not (self.chkBtns.mseed.get() or \
                 self.chkBtns.log.get() or \
                 self.chkBtns.ref.get() or \
                 self.chkBtns.segy.get()):
            self.setMess("terminate","No generation options selected, nothing to do!")
            return
        self.base = None
        if self.CONTINUE:
            self.base = getPreviousCore(self.ctl.men.state_save_filename.get())
            if self.base == None:
                print "Previous core did not exist.  Setting save-state functionality and running from beginning."
                self.setMess("log","Previous core did not exist.  Setting save-state functionality and running from beginning.\n")
                self.run_safe.set(1)
                self.base = core()
                self.ctl.men.state_save_filename.set(self.base.backup_filename)
            elif (self.base.OUTDIR != self.dest.path.get()) or (bool(self.base.STRIP) != bool(self.fltr.inst.get())) or (self.base.JDAY != self.fltr.julStr.get()):
                print "Tried to continue from old core, but filters or output directory has changed.  Starting over with current setup."
                print "If you want to pickup where you left off before, load from this backup/state file: '%s'" % self.ctl.men.state_save_filename.get()
                self.base = core()
                self.ctl.men.state_save_filename.set(self.base.backup_filename)
            else:
            # this else means one of two things if we get here:
            #   -We have the same setup as a previous run
            #   -We have changed the input files, but not the output dir
            #
            #   In both cases, CONTINUE was pressed, not START, and a previous core exists
            #
            #   The result I thought was most appropriate was to just keep the results of getPreviousCore
            #   as our self.base and to overwrite it with any changes.  All file paths are saved as
            #   absolute paths, and even stroll gives us a list of absolute paths to zips.  In the case of getting
            #   new input that includes old partially completed files, it will recognize this and continue on with
            #   them.
            #
            #   However, we must re-evaluate which ZIPS to work on! We don't want to just add things to self.base.ZIPS
            #   that are already there, and we don't want to continue with something not selected THIS time.
            #   The answer is simple: we were about to figure out which ZIPS anyway.  Let's just erase self.base.ZIPS!
            #   Our progress will still be saved in self.COMPLETED_ACTIONS!
                self.base.ZIPS = []
        else:
            self.base = core()
            self.ctl.men.state_save_filename.set(self.base.backup_filename)
        self.base.GUI = True
        self.base.parentExeThread = self
        if self.CONTINUE:
            self.base.printActionSummary()
        #self.base.MESS = self.mess
        self.base.STRIP = False
        if not self.fltr.segZip.get():
            self.base.BLIND = True
        #enable stop button while running
        self.stpBtn.config(state=NORMAL)


        #disable strtBtn/contBtn while running
        self.strtBtn.config(state=DISABLED)
        self.contBtn.config(state=DISABLED)

        #check if a filter is chosen and set appropriate variables
        if self.fltr.inst.get():
            self.base.STRIP = True
            # setup the INSTRUMENTS dictionary
            if self.evalInst(self.fltr.instStr.get()):
                self.setMess("terminate","Invalid instrument entry, see help for usage.")
                return
            
            self.base.INSTRUMENTS = instruments(self.fltr.instStr.get(), self.base.INSTRUMENTS)
        if self.fltr.jul.get():
            #comma delimmeted julian days 122-125 also accepted
            #This will just be passed to refsegy with a -j
            self.base.JDAY = self.fltr.julStr.get()
            if self.evalJday(self.base.JDAY):
                self.setMess("terminate","Invalid julian day entry, see help for usage.")
                return

        #validate the source input
        if self.src.mode == "File":
            if len(self.src.filenames) == 0: 
                self.setMess("terminate","Invalid src, please provide 1 or more file archives")
                return
            
            for i in self.src.filenames:
                self.base.FILE = os.path.abspath(i)
                if not os.path.isfile(self.base.FILE):
                    self.setMess("terminate","Invalid src " + \
                                                    string.lower(self.src.mode) + \
                                                    " \"" + self.base.FILE + "\".")
                    return
                self.base.ZIPS.append(self.base.FILE)
        else:
            self.base.PATH = os.path.abspath(self.src.path.get())
            if not os.path.isdir(self.base.PATH):
                self.setMess("terminate","Invalid src " + string.lower(self.src.mode) +" \"" + self.base.PATH +"\".")
                return
            self.setMess("status","Scanning recursively directory \"" + self.base.PATH + "\" for archives.")
            # walk through directory tree searching for zip files
            self.base.ZIPS = self.base.stroll ()
        for ZIPFILE in self.base.ZIPS:
            if re.match (BLIND_REFFILERE, ZIPFILE) and (os.path.abspath(ZIPFILE) not in self.base.RefsInZIPS):
                self.base.RefsInZIPS.append(os.path.abspath(ZIPFILE))
        #destination directory
        global LAUNCHED_FROM
        #I decided to change this so that if the user throws the process in the background and changes directory it won't mess things up.
        self.base.OUTDIR = os.path.abspath(self.dest.path.get())

        if not os.path.isdir(self.base.OUTDIR):
            self.setMess("terminate","Invalid destination directory \"" + self.base.OUTDIR + "\".")
            return

        #get values of radio button
        self.base.MSEED = bool(self.chkBtns.mseed.get())
        self.base.LOG = bool(self.chkBtns.log.get())
        self.base.REF = bool(self.chkBtns.ref.get())
        self.base.SEGY = bool(self.chkBtns.segy.get())
        if self.ctl.cfgFile:
            self.base.CONFIG = self.ctl.cfgFile

        #don't need to seperately fetch log files
        #since ref2segy and ref2mseed produce them gratis ;-)
        if self.base.MSEED or self.base.SEGY:
            self.base.LOG = False
            self.chkBtns.log.set(1)

        #Got what we need, fullfill the request
        if self.CONTINUE or self.run_safe.get():
            self.base.backup_filename = self.ctl.men.state_save_filename.get()
            self.__actionPartialFunction = functools.partial(self.base.do_something_safely,CONTINUE=self.CONTINUE,SAFETY=True)
            self.ctl.men.state_save_filename.set(self.base.backup_filename)
        else:
            self.__actionPartialFunction = functools.partial(self.base.do_something_safely,CONTINUE=False,SAFETY=False)

    def run(self):
        if self.__actionPartialFunction:
            ret = self.__actionPartialFunction()
            self.base.printActionSummary()
            self.BackupFile = self.base.backup_filename
            buff,msg = "backup_filename","To continue from here, load from state save file: %s\n" % self.BackupFile
            self._QAndA[buff+":"+msg] = None
            self.setMess(buff,msg)
            while self._QAndA[buff+":"+msg] == None:
                time.sleep(0.1)
            #When we escape it means that processQueue got to the request and held on to our state
            #    save filename.  safe to move on now...
            del(self._QAndA[buff+":"+msg])
            self.base = None		# Dereference the base --> garbage collector will get rid of it
            if (ret):
                self.setMess("terminate","Processing Failed, errors with zipfiles: " + str(ret.keys()))
                return
            else:
	            self.setMess("terminate","Finished!")
	            return
        else:
	        raise Exception, "No action to execute!"
    #function for terminating the execution thread and resetting the GUI to the mode it needs
    #to be
    def kill_safely(self):
        if self.CONTINUE or self.run_safe.get():
            self.base.BackupSelf(resetTimeStamp=True)
            self.BackupFile = self.base.backup_filename
            #buff,msg = "backup_filename","Execution stopped.  To continue from last completed action, load from state save file: %s\n" % self.BackupFile
            #self._QAndA[buff+":"+msg] = None
            #self.setMess(buff,msg)
            #while self._QAndA[buff+":"+msg] == None:
            #    time.sleep(0.1)
            #When we escape it means that processQueue got to the request and held on to our state
            #    save filename.  safe to move on now...
            #del(self._QAndA[buff+":"+msg])
            #
            #Note: The above method is what should be used in a thread, as it must wait on the
            #        Tk (main) thread to update itself.  This function is only ever run by the
            #        main thread, so it should not wait, or else it will just get stuck!
            #
            #Instead, do this:
            if self.base.backup_filename and (self.CONTINUE or self.run_safe.get()):
                self.ctl.men.state_save_filename.set(self.BackupFile)
                self.mess.log.appendtext("Execution stopped.  To continue from last completed action, load from state save file: %s\n" % self.BackupFile)
            
        self.thread.kill()

    def terminate(self, message):
        global EXE_COUNT; EXE_COUNT -= 1
        self.stpBtn.config(state=DISABLED)
        self.setMess("status",message)
        #if self.base:
        #    self.base.printActionSummary()
        #if self.base:
        #    self.ctl.men.state_save_filename.set(self.base.backup_filename)
        #self.base = None
        self.mess.frame.master.update()
        notify_finished()
        self.tStop = time.time()
        exeTime = self.tStop - self.tStart
        self.setMess("log","\nTotal running time: " + processTime(exeTime) + "\n")
        self.setMess("log",'\n***************Stopped****************\n\n')
        self.setMess("status","Idle...")
        self.mess.frame.master.update()
        self.strtBtn.config(state=NORMAL)
        self.contBtn.config(state=NORMAL)
        self.src.enable()
        self.fltr.enable()
        self.chkBtns.enable()
        self.dest.enable()
        self.ctl.remove_message()

#----------------------------------------------------------------------------------------------------------#
#provides start and stop buttons and their functions of execution
class startstop:
    def __init__(self, frame, mess, chkBtns, src, dest, fltr, men):
        self.men = men
        self.chkBtns = chkBtns
        self.src = src
        self.dest = dest
        self.fltr = fltr
        self.f1 = Frame(frame);        self.f1.pack()
        self.f2 = Frame(frame);        self.f2.pack()
        self.mess = mess
        self.txt = "Completing Request:  To view progress choose view->log from the menu."
        self.l = Label(self.f2,text='', fg="darkgreen")
        self.l.pack(side=TOP)
        self.startButton=Button(self.f1, 
                                bd=3,
                                text="Start",
                                command=self.start,
                                activeforeground="dark green")
        self.continueButton=Button(self.f1,
                                   bd=3,
                                   text="Continue",
                                   command=self.Continue,
                                   activeforeground="#0000CC")
        self.stopButton=Button(self.f1,
                               bd=3,
                               text="Stop",
                               command=self.stop,
                               activeforeground="red",
                               fg="red")
        
        self.startButton.pack(side=LEFT, fill=X, padx=10)
        self.continueButton.pack(side=LEFT,fill=X,padx=10)
        self.stopButton.pack(side=LEFT, fill=X, padx=50)
        self.stopButton.config(state=DISABLED)
        self.exe = None
        self.cfgFile = None
    def can_write (self) :
        can = True
        try :
            #print self.dest.path.get ()
            file = os.path.join (self.dest.path.get (), ".junk")
            open (file, 'w')
        except IOError, e :
            #   No write permission
            showerror ("Open Error", "Can't write to destination directory: %s" % self.dest.path.get ())
            can = False
        else :
            os.unlink (file)
        
        if can == False :
            return can
        
        try :
            file = os.path.join (self.dest.path.get (), ".xxxx:xxx")
            open (file, 'w')
        except IOError, e :
            #   Brain dead filesystem
            showerror ("Open Error", "Can't process to FAT filesystem: %s" % self.dest.path.get ())
            can = False
        else :
            os.unlink (file)
            
        return can
    
    def config_file (self) :
        return self.men.cfgFile
        
    def start(self):
        if not self.can_write () :
            return
        
        self.fltr.disable()
        self.chkBtns.disable()
        self.src.disable()
        self.dest.disable()
        self.exe = exe_thread(self,self.men.run_saving_state,CONTINUE=False)
        self.show_message()
        self.exe.start()

    def Continue(self):
        if not self.can_write():
            return

        self.fltr.disable()
        self.chkBtns.disable()
        self.src.disable()
        self.dest.disable()
        if not self.men.run_saving_state.get():
            self.men.run_saving_state.set(True)
        self.exe = exe_thread(self,self.men.run_saving_state,CONTINUE=True)
        self.show_message()
        self.exe.start()

    def stop(self):
        #kill the execution thread straight away
        global EXE_COUNT; EXE_COUNT -= 1
        self.exe.kill_safely()
        kill_child_processes(os.getpid())
        self.exe.setMess("terminate","Execution stopped by user!")
        self.startButton.config(state=NORMAL)
        self.continueButton.config(state=NORMAL)
        self.src.enable()
        self.fltr.enable()
        self.chkBtns.enable()
        self.dest.enable()

    def updateFromCore(self):
        savedCoreFilename = self.men.state_save_filename.get()
        newCore = getPreviousCore(savedCoreFilename)
        if newCore.FILE not in newCore.ZIPS and newCore.FILE:
            newCore.ZIPS.append(newCore.FILE)
            if (os.path.abspath(newCore.FILE) not in newCore.RefsInZIPS) and re.match(BLIND_REFFILERE,newCore.FILE):
                newCore.RefsInZIPS.append(os.path.abspath(newCore.FILE))
        self.chkBtns.mseed.set(newCore.MSEED)
        self.chkBtns.log.set(newCore.LOG)
        self.chkBtns.ref.set(newCore.REF)
        self.chkBtns.segy.set(newCore.SEGY)
        self.cfgFile = newCore.CONFIG
        if newCore.BLIND:
            self.fltr.segZip.set(0)
        else:
            self.fltr.segZip.set(1)
        self.fltr.instStr.set(reverseInstruments(newCore.INSTRUMENTS))
        self.fltr.julStr.set(newCore.JDAY)
        if self.fltr.julStr.get():
            self.fltr.jul.set(1)
        else:
            self.fltr.jul.set(0)
        self.src.mode = "File"
        self.src.combobox.selectitem(self.src.mode_opts[1])
        self.src.filenames = newCore.ZIPS
        self.src.path.set(" ".join(newCore.ZIPS))
        self.dest.path.set(newCore.OUTDIR)
        if newCore.MSEED or newCore.SEGY or newCore.LOG:
            self.chkBtns.log.set(1)

    def show_message(self):
        self.l.configure(text=self.txt)

    def remove_message(self):
        self.l.configure(text='')

#----------------------------------------------------------------------------------------------------------#
#This class provides an interface for the messagebar and stdout log
class messages:
    def __init__(self,frame):
        # variable for posting short messages to gui
        self.frame = frame
        self.text = StringVar()
        #create a log for storing I/O messages

        self.log = Pmw.TextDialog(frame.master.master,
                                  scrolledtext_labelpos= 'n',
                                  title='UNCHUNKY LOG',
                                  buttons=["ok", "clear", "find", "save"],
                                  defaultbutton=0,
                                  command=self.btnClick,
                                  text_state='disabled')
        
        self.log.pack(expand=1, fill=BOTH) #side=BOTTOM)
        self.log.configure(text_bg="white")
        self.log.component("hull").configure(borderwidth=1,
                                             highlightbackground="orange",
                                             highlightthickness=3,
                                             highlightcolor="orange")

        self.log.component("text").configure(state=DISABLED)
        # dont display yet!
        self.log.withdraw()
        self.set("Idle...")
        #create a label for message bar
        self.label = Label(frame, text="Messages:")
        #create message bar entry widget for displaying messages
        self.message = Entry(frame,
                             textvariable=self.text,
                             state=DISABLED,
                             disabledforeground="black",
                             disabledbackground="LightYellow")
        
        self.label.pack(side=LEFT)
        self.message.pack(side=LEFT,expand=1, fill=X)
        
    def save (self) :
        logfile = tkFileDialog.asksaveasfilename (title = "Save log file",
                                                  initialdir = LAUNCHED_FROM)
        if logfile :
            self.log.exportfile (logfile)
        
    def btnClick(self, btnName):
        if btnName == "ok" or btnName == None:
            self.log.withdraw()
        elif btnName == "clear":
            self.log.clear()
        elif btnName == "find":
            findMe = findWidget(self.log)
        elif btnName == "save" :
            self.save ()
            
    def set(self, text):
        self.text.set(text)
        if text != "Idle..." and text != "Running":
            #self.log.configure(text_state=NORMAL)
            self.log.insert(END, text + "\n")
            #self.log.configure(text_state="disabled")

    #show the I/O log
    def displayLog(self):
        self.log.configure(text_state="disabled")
        self.log.show()




#----------------------------------------------------------------------------------------------------------#
class unchunky_app:
    def __init__(self, root):
        global open_win
        self.root = root
        window = Frame(relief=RAISED,
                       borderwidth=1,
                       highlightbackground="orange",
                       highlightthickness=3,
                       highlightcolor="orange")

        window.pack(expand=1, fill=X)
        f1 = Frame(window, relief=RAISED, borderwidth=2)
        f2 = Frame(window, relief=GROOVE, borderwidth=2)
        f3 = Frame(window, relief=GROOVE, borderwidth=2)
        f4 = Frame(window, relief=GROOVE, borderwidth=2)
        f5 = Frame(window)
        f6 = Frame(window)

        f1.pack(expand=1, fill=X)
        f2.pack(expand=1, fill=X, pady=padding)
        f3.pack(expand=1, fill=X,  pady=padding)
        f4.pack(expand=1, fill=BOTH, pady=padding)
        f5.pack(expand=1, fill=X, pady=padding)
        f6.pack(expan=1, fill=X)

        mess = messages(f6)
        self.men = menu(f1, mess, self)
        fltr= filter_ctl(f3)
        src = src_chooser(f2, fltr)
        dest = dest_chooser(f2, mess)
        types = radio_buttons(f4)
        self.control = startstop(f5, mess, types, src, dest, fltr, self.men)
        open_win = open_win + 1


#----------------------------------------------------------------------------------------------------------#
#######################     MAIN     ##############################
#----------------------------------------------------------------------------------------------------------#

if __name__ == "__main__" :
    if len(sys.argv) >  1 :
        _base = core()
        sys.exit(_base.run_nongui(__version__))
    global GUI
    GUI = True
    root = Tk()
    # make root.resizable(horizontal false)
    root.resizable(width=True, height=False)
    root.option_readfile(UNCHUNKY+ "/optionsDB")
    root.title("UNCHUNKY " + __version__)
    app = unchunky_app(root)
    #prevent user from killing window with hanging threads
    #exit_app method ensures hanging threads killed aswell!
    root.protocol("WM_DELETE_WINDOW", app.men.exit_app)
    while(1):
        try:
            root.mainloop()
            break
        except Exception, e:
            kill_child_processes()
            raise os.kill(os.getpid(), 9)
        
    app.men.exit_app()
