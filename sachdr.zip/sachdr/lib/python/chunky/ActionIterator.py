"""
ActionIterator Idea:
    by Jayson Barr

Basic idea:

    We want to avoid a massive list of things to do,
    so lets use iterators that are intelligent enough
    to look at what has already been done and continue
    from there.

"How?" you ask:
    We will make an iterable for both reffiles to make
    as well as a generic "BuildActions" iterable which
    will loop through ref2segy, ref2log, ref2mseed, etc.
    for each one of the ZIP files.

    First an iterable is made from the given list of ZIP
    files over which to walk.

    Another iterable is made from the same list of ZIPS,
    but only after removing all of the ZIP filenames that
    we have already made ref-files for.

    First, we crawl through the list of ZIP files that
    need ref-files, and do that first.

    Next, we crawl through all of the ref-files that have
    been successfully made.  For each one, a new iterable
    of build actions is made.  The iterable is a list of
    build actions decided on by the internal options of
    the parent core() object that have not already been
    completed.

Why iterables?
    Because the actions that need to be done is dependent
    on what has already been done, and because iterables
    can be less memory intensive if used correctly.

    Instead of having a massive list of everything to do
    and looking at a list of what has already been done
    EVERY time we want to complete a task, an iterable
    can just return the next job that needs to be done
    (if made correctly).  I think this will make the
    code a lot more elegant, readable, less memory
    intensive, and, most of all, better suited for
    picking up where it had left off before.
"""

__version__ = "2008.207"

from copy import copy
from unchunky_core import REF2LOG,REF2MSEED,REF2SEGY,MAKEREF,REFUNLINK

# These classes are Exceptions that inherit from StopIteration that will tell use when we reach the end
#    of a sequence of things to do, namely the list of Zips, actions to do, and refs to make:
#

class ZIPSStopIter(StopIteration):
    """For listening for when we have finished with everyu ZIP file"""
    pass

class RefsToMakeStopIter(StopIteration):
    """For listening for when we have made all of the ref-files"""
    pass

class BuildsToMakeStopIter(StopIteration):
    """For listening for when we have completed all of the actions (made all of the file conversions)"""
    pass

# This class is a wrapper around an iterator so it will raise a custom StopIteration error when it ends:
class _IteratorWithTracking:
    """
    This class is a wrapper around an iterator so it will raise a custom StopIteration error when it ends.
    It takes two inputs:
        IteratorObject        An iterator object to be a drop-in replacement for
        TrackingError        An error to raise in place of the StopIteration Exception

    NOTE:  I HIGHLY recommend having your new custom StopIteration Exception inherit from
            StopIteration, or work similarly so that doing a for loop with it will
            still work.
    """
    def __init__(self,IteratorObject,TrackingError):
        """
        Initialize our Iterator Wrapper.
        """
        self.IteratorObject = IteratorObject
        self.TrackingError = TrackingError
    def next(self):
        """
        Return the next object that self.IteratorObject returns,
        and raise self.TrackingError if we get a StopIteration error.
        """
        try:
            return self.IteratorObject.next()
        except StopIteration:
            raise self.TrackingError
    def __iter__(self):
        """
        returns itself
        """
        return self

class _GrowingIteratorWithTracking:
    """
    This class is a wrapper around an iterator so it will raise a custom StopIteration error when it ends.
    It takes two inputs:
        ListReference        A list that will be **appended** to (nothing removed or rearranged) while we go through it
        TrackingError        An error to raise in place of the StopIteration Exception

    NOTE:  I HIGHLY recommend having your new custom StopIteration Exception inherit from
            StopIteration, or work similarly so that doing a for loop with it will
            still work.
    """
    def __init__(self,ListReference,TrackingError):
        """
        Initialize our Iterator Wrapper.
        """
        self.ListReference = ListReference
        self.TrackingError = TrackingError
        self._index = 0
    def next(self):
        """
        Return the next object that self.ListReference returns,
        and raise self.TrackingError if we get a StopIteration error.
        """
        try:
            output = self.ListReference[self._index]
            self._index += 1
            return output
        except IndexError:
            raise self.TrackingError
    def __iter__(self):
        """
        returns itself
        """
        return self

# A class that will 
class _BuildActionsIterator:
    """
    An iterator for figuring out the actions that need to be done for a ref file that has already been started,
    but may have had errors, or that simply never got to finish.
    """
    def __init__(self,CompletedActions,AllRequiredActions):
        """
        Initializes a _BuilsActionsIterator
        Takes two arguments:
            CompletedActions    A list of already completed actions
            AllRequiredJobs        A list of all actions that need to be done
        """
        self.AllRequiredActions = AllRequiredActions.__iter__()
        self.CompletedActions = CompletedActions
        if self.CompletedActions:
            self.next = self._nextIfCompletedActions
        else:
            self.next = self._nextIfNotCompletedActions
        #print AllRequiredActions
        #print CompletedActions
    def _nextIfCompletedActions(self):
        nextAction = self.AllRequiredActions.next()
        #print "Had completed actions",nextAction
        if nextAction in self.CompletedActions:
             return self.next()
        else:
            return nextAction
    def _nextIfNotCompletedActions(self):
        #print "didn't have completed actions"
        return self.AllRequiredActions.next()
    def __iter__(self):
        return self

# ----------------------------------------------------------------------------- #

# A class to feed us tasks to complete.  It is safe in that it examines its parent's
#    COMPLETED_ACTIONS attribute to see what is left to complete.
class ActionIterator:
    """An iterator that will return the actions we want our core to do."""
    def __init__(self,parentCore):
        """
        Setup the ActionIterator.
        Takes two arguments:
            ZIPS        A list of ZIP files to operate on
            parentCore  The core object with all of the options that are to
                        be used to generate the actions that should be done,
                        and whose COMPLETED_ACTIONS attribute tells us which
                        actions do not need to be done again.
        """
        # This is a link to the parent core object:
        self.parentCore = parentCore
        # Later we can keep track of ZIP files that were skipped because they produced errors:
        self.SkippedZIPS = []
        # A temporary list of the parent core objects completed actions:
        #completed = parentCore.COMPLETED_ACTIONS
        # A list of zip files that need to be made into ref files:
        self.RefsToMake = list(self.parentCore.ZIPS)
        for x in self.parentCore.COMPLETED_ACTIONS.keys():
            if (MAKEREF in self.parentCore.COMPLETED_ACTIONS[x]) and (x in self.RefsToMake):   # I used to have this, but theoretically it shouldn't ever be needed: and (x in self.RefsToMake):
                self.RefsToMake.remove(x)
        # We want to use them like iterables anyway:
        self.ZIPSList = list(copy(self.parentCore.ZIPS))
        self.ZIPS = _GrowingIteratorWithTracking(self.ZIPSList,ZIPSStopIter)
        #self.ZIPS = _IteratorWithTracking(self.parentCore.ZIPS.__iter__(),ZIPSStopIter)
        self.RefsToMake = _IteratorWithTracking(self.RefsToMake.__iter__(),RefsToMakeStopIter)
        # We will be making a new list of actions to complete for each zip file,
        #    but in order to avoind slowing down, we will here make a master
        #    list of all required build actions regardless of whether they
        #    are already completed or not:
        self._ALL_BUILD_ACTIONS = [MAKEREF]
        if self.parentCore.MSEED:
            self._ALL_BUILD_ACTIONS.append(REF2MSEED)
        if self.parentCore.SEGY:
            self._ALL_BUILD_ACTIONS.append(REF2SEGY)
        if self.parentCore.LOG:
            self._ALL_BUILD_ACTIONS.append(REF2LOG)
        if not self.parentCore.REF:
            self._ALL_BUILD_ACTIONS.append(REFUNLINK)
        # -- REALLY VERY PRIVATE, as they may change with each .next() call:
        try:
            self._CurrentZIP = self.ZIPS.next()
            # We will interface with the build actions as an iterable:
            self._CurrentBuildActionIterator = _IteratorWithTracking(_BuildActionsIterator(self.parentCore.COMPLETED_ACTIONS.get(self._CurrentZIP),self._ALL_BUILD_ACTIONS),BuildsToMakeStopIter)
        except ZIPSStopIter:
            # I later decided that this was okay. If there is nothing to do, then there just is nothing to do:
            #raise ZIPSStopIter, "List of ZIPS was empty, or I was told to skip them all!"
            #self._CurrentZIP = ZIPSStopIter()
            pass

    def next(self):
        """
        First go through all of the previously successfully created Ref files and complete
        all previously uncompleted actions for them, then continue to go through all of the
        ZIP files whose Ref files were not successfully created and do their actions,
        and finally unlink all ref files that we don't want to keep.
        """
        # Look for a StopIteration exception from self._CompletedBuildActionIterator
        # I was continuing the actip ZIP after adding it to self.SkipZIPS, so then I realized the
        #   needs to be done regardless of whether we are moving on to the next ZIP file now or not
        try:
            # Time to do the next build action:
            self._CurrentBuildAction = self._CurrentBuildActionIterator.next()
            # Return the working zipfile and the action to do for it
            return self._CurrentZIP, self._CurrentBuildAction
        except BuildsToMakeStopIter:    # Means that we have finished all the actions for the zip file
            self._skipNoError()
            return self.next()
        except AttributeError:
            raise ZIPSStopIter
        except ZIPSStopIter:
            raise StopIteration
    def skipCurrentZIP(self):
        """
        Means that for some reason we just want to skip to the next ZIP file.
        The only application I know of for this is when we have an error and
        don't want messages for all the likely future errors.

        NOTE: If we reach the end of the ZIPS iterable, StopIteration is raised.
        """
        self.SkippedZIPS.append(self._CurrentZIP)
        # Just calling self._skipNoError pulled StopIteration and actually caused an Exception that
        #       stopped execution, so I am trying this trick instead:
        self._CurrentBuildActionIterator = _IteratorWithTracking([].__iter__(),BuildsToMakeStopIter)
        #self._skipNoError()
    def comeBackToCurrentZIP(self):
        """
        Temporarily move on to the next ZIP file.
        At the end come back to the one skipped.
        """
        # First, set it up so that on the next .next() call we will move on to the next ZIP file:
        self._CurrentBuildActionIterator = _IteratorWithTracking([].__iter__(),BuildsToMakeStopIter)
        # Make sure that we will know to come back to it:
        self.ZIPSList.append(self._CurrentZIP)
        
    def _skipNoError(self):
        """
        Skip to the next ZIP file.

        NOTE: If we reach the end of the ZIPS iterable, StopIteration is raised.
        """
        try:
            self._CurrentZIP = self.ZIPS.next()
            self._CurrentBuildActionIterator = _IteratorWithTracking(_BuildActionsIterator(self.parentCore.COMPLETED_ACTIONS.get(self._CurrentZIP),self._ALL_BUILD_ACTIONS),BuildsToMakeStopIter)
        except ZIPSStopIter:    # Means that we have run out of ZIP files to work on, and we should stop:
            raise ZIPSStopIter
 
    def __iter__(self):
        """
        Return an iterable version of ActionIterator, which is itself.
        """
        return self

if __name__ == "__main__":
    from unchunky_core import core
    CC = core()
    CC.LOG = CC.MSEED = CC.SEGY = True
    CC.REF = False
    l = "a","b","c","d","e"
    l = map(lambda x: x+".zip",l)
    tempActions = [MAKEREF,REF2LOG,REF2MSEED,REF2SEGY,REFUNLINK]
    CC.COMPLETED_ACTIONS = {}
    for x in l:
        CC.COMPLETED_ACTIONS[x] = tempActions
        tempActions = tempActions[:-1]
    l = tuple(list(l)+["f.zip","g.zip","h.zip"])
    #print l
    #print CC.COMPLETED_ACTIONS
    CC.ZIPS = l
    ActIter = ActionIterator(CC)
    #print ActIter._ActionIterator_ALL_BUILD_ACTIONS
    print "This is an example use of ActionIterator for testing purposes."
    print "Running supposing that there are 8 zip files name a.zip, b.zip, c.zip, ..."
    print "Assuming each has a different set of completed actions."
    print
    print "The 'Zip files':"
    for x in l:
        print "\t",x
        print "\t\tCompleted for this zip file:"
        if not CC.COMPLETED_ACTIONS.has_key(x) or not CC.COMPLETED_ACTIONS[x]:
            print "\t\t**None**"
        else:
            for y in CC.COMPLETED_ACTIONS[x]:
                print "\t\t",y
    alreadyCalledComeBack = False
    for z,b_act in ActIter:
        print b_act,z
        if z == "f.zip" and b_act == REF2MSEED and alreadyCalledComeBack == False:
            print "**Pretending to need to skip f.zip temporarily during ref2mseed and return to it later.**"
            ActIter.comeBackToCurrentZIP()
            alreadyCalledComeBack = True
        elif z == "g.zip" and b_act == REF2SEGY:
            print "**Pretending to have an error on g.zip at REF2SEGY step.  It should skip to the next ZIP file.**"
            ActIter.skipCurrentZIP()
        else:
            if z not in CC.COMPLETED_ACTIONS.keys():
                CC.COMPLETED_ACTIONS[z] = []
            CC.COMPLETED_ACTIONS[z].append(b_act)

