#! /usr/bin/env python

from Tkinter import *
import tkMessageBox
import sys
import Pmw

class HCSCmdFrame(Frame):
    def __init__(self, master):
	Frame.__init__(self, master, borderwidth = 1, relief = GROOVE)
	self.createWidgets()
	self.pack(side = LEFT, expand = YES, fill = BOTH)
	self.master = master

    def sepline(self, master):
	Frame(master,
	      height = 4,
	      borderwidth = 1,
	      relief = GROOVE).pack(side = TOP, fill = BOTH)

    def createBootFrm(self):
        winfo = Pmw.Group(self,
                          tag_text='Info',
                          tag_font=Pmw.logicalfont('Helvetica', weight='bold'))
        winfo.pack(fill=Y, padx=2, pady=4)
        frmInfo = winfo.interior()
	btnGenStatus = Button(frmInfo,
			 text = "General Status",
			 command = self.master.getGeneralStatus,
			 state = DISABLED,
			 bg = "grey",
			 fg = "black")
	btnGenStatus.pack(side = TOP, fill = X)
	self.master.actionComponents['btnGeneralStatus'] = btnGenStatus
	btnGPSStatus = Button(frmInfo,
			 text = "GPS Status",
			 command = self.master.getGPSStatus,
			 state = DISABLED,
			 bg = "grey",
			 fg = "black")
	btnGPSStatus.pack(side = TOP, fill = X)
	self.master.actionComponents['btnGPSStatus'] = btnGPSStatus
        btnFirmware = Button(frmInfo,
			     text = 'Firmware Version',
			     command = self.master.enumQ330ForUpdate,
			     state = DISABLED,
			     bg = 'grey',
			     fg = 'black')
	btnFirmware.pack(side = TOP, fill = X)
	self.master.actionComponents['btnFirmwareVer'] = btnFirmware

        wconfig = Pmw.Group(self,
                            tag_text='Config',
                            tag_font=Pmw.logicalfont('Helvetica', weight='bold'))
        wconfig.pack(fill=Y, padx=2, pady=4)
        frmConfig = wconfig.interior()
	btnInterfs = Button(frmConfig,
                            text = "Config Interfaces",
                            command = self.master.cfgInterfaces,
                            state = DISABLED,
                            bg = "grey",
                            fg = "black")
	btnInterfs.pack(side = TOP, fill = X)
	self.master.actionComponents['btnConfigInterfaces'] = btnInterfs

        wclone = Pmw.Group(self,
                           tag_text='XML',
                           tag_font=Pmw.logicalfont('Helvetica', weight='bold'))
        wclone.pack(fill=Y, padx=2, pady=4)
        frmClone = wclone.interior()
        btnLoadXML = Button(frmClone,
                            text = 'Create XML File',
                            command = self.master.loadXMLFile,
                            state = DISABLED,
                            bg = 'grey',
                            fg = 'black')
        btnLoadXML.pack(side = TOP, fill = X)
        self.master.actionComponents['btnLoadXML'] = btnLoadXML
        btnSaveTok = Button(frmClone,
                            text = 'Save Tok to 330',
                            command = self.master.saveXML2Q330,
                            state = DISABLED,
                            bg = 'grey',
                            fg = 'black')
        btnSaveTok.pack(side = TOP, fill = X)
        self.master.actionComponents['btnSaveTok'] = btnSaveTok
        btnSaveCFG = Button(frmClone,
                            text = 'Save CFG to 330',
                            command = self.master.saveXMLCFG2Q330,
                            state = DISABLED,
                            bg = 'grey',
                            fg = 'black')
        btnSaveCFG.pack(side = TOP, fill = X)
        self.master.actionComponents['btnSaveCFG'] = btnSaveCFG
        btnFastSave = Button(frmClone,
                             text = 'Fast Save to 330s',
                             command = self.master.fastSaveXML2Q330s,
                             state = DISABLED,
                             bg = 'grey',
                             fg = 'black')
        btnFastSave.pack(side = TOP, fill = X)
        self.master.actionComponents['btnFastSave'] = btnFastSave
        
        wbinclone = Pmw.Group(self,
                              tag_text='Clone',
                              tag_font=Pmw.logicalfont('Helvetica', weight='bold'))
        wbinclone.pack(fill=Y, padx=2, pady=4)
        frmBinClone = wbinclone.interior()
        btnClone = Button(frmBinClone,
                          text = 'Clone multi Q330s',
                          command = self.master.cloneQ330,
                          state = DISABLED,
                          bg = 'grey',
                          fg = 'black')
        btnClone.pack(side = TOP, expand = 1, fill = X)
        self.master.actionComponents['btnClone'] = btnClone
        btnFastClone = Button(frmBinClone,
                              text = 'Fast Clone',
                              command = self.master.fastCloneQ330,
                              state = DISABLED,
                              bg = 'grey',
                              fg = 'black')
        btnFastClone.pack(side = TOP, fill = X)
        self.master.actionComponents['btnFastClone'] = btnFastClone
        
        wupdate = Pmw.Group(self,
                            tag_text='Modules',
                            tag_font=Pmw.logicalfont('Helvetica', weight='bold'))
        wupdate.pack(fill=Y, padx=2, pady=4)
        frmFirmware = wupdate.interior()
        btnUpdate = Button(frmFirmware,
                           text = 'Update Firmware',
                           command = self.master.updateFirmware,
                           state = DISABLED,
                           bg = 'grey',
                           fg = 'black')
        btnUpdate.pack(side = TOP, fill = X)
        self.master.actionComponents['btnUpdate'] = btnUpdate


    def createParaFrm(self):
	frmPara = Frame(self, borderwidth = 5)
	btnReceive = Button(frmPara,
			    text = "Receive\nParameters",
			    command = "",
			    bg = "white")
	btnReceive.pack(side = TOP, fill = X)
	frmPara.pack(side = TOP, fill = X)

	frmPara = Frame(self, borderwidth = 5)
	btnEdit = Button(frmPara,
			 text = "Edit\nParameters",
			 command = "",
			 bg = "white")
	btnEdit.pack(side = TOP, fill = X)
	btnSummary = Button(frmPara,
			    text = "Summary",
			    command = "",
			    bg = "white")
	btnSummary.pack(side = TOP, fill = X)
	frmPara.pack(side = TOP, fill = X)

	frmPara = Frame(self, borderwidth = 5)
	btnSend = Button(frmPara,
			 text = "Send\nParameters",
			 command = "",
			 bg = "white",
			 fg = "bule")
	
	btnSend.pack(side = TOP, fill = X)
	frmPara.pack(side = TOP, fill = X)
	#self.sepline()

    def createExitFrm(self):
	frmExit = Frame(self, borderwidth = 5)
	btnExit = Button(frmExit,
			 text = "Exit",
			 command = self.sysExit,
			 bg = "grey",
			 fg = "blue")
	btnExit.pack(side = TOP, fill = X)
	frmExit.pack(side = BOTTOM, fill = X)
    
    def createWidgets(self):
	self.createBootFrm()
	self.createExitFrm()

    def sysExit(self):
	if tkMessageBox.askokcancel('Warning', 'You may or may not deregister the Q330(s).\n Are you sure to continue?'):
	    sys.exit(0)
	
