# This is a queue class, intended for use by GUIs, to allow a thread to
# request something be done, and be able to block until a result is available.
#
# The end result will "feel" like the child thread handled the GUI work.

import thread

class Request:

    def __init__(self, func, args):
        self.func = func
        self.args = args
        self.lock = thread.allocate_lock()
        self.lock.acquire()
        
        
    def run(self):
        self.results = self.func(*self.args)
        self.lock.release()
        
    def waitForResult(self):
        """
        Allow another thread to wait for this request to be run

        we then return the results (if any) of the requested action
        """
        self.lock.acquire()
        self.lock.release()
        return self.results
    
class GuiRequestQueue:

    def __init__(self):
        self.requestQueueLock = thread.allocate_lock()
        self.requestQueue = []
        self.failedItemsLock = thread.allocate_lock()
        self.failedItems = {}
        self.purging = False
        
    def enqueueRequest(self, func, args):
        """
        Add a request (made up of a function and arguments) to the queue.  We'll return a locked
        lock, that we'll release when the request is fulfilled.  This will allow the calling
        thread to block without needing to sleep
        """
        newRequest = Request(func, args)

        self.requestQueueLock.acquire()
        self.requestQueue.append(newRequest)
        self.requestQueueLock.release()
        return newRequest

    def purge(self):
        """
        remove everything in the queue, without running
        """
        self.purging = True
        self.requestQueue = []
        self.purging = False
        
    def runQueue(self):
        itemsToRequeue = []

        # run the new items queue
        while len(self.requestQueue):
            if self.purging == True:
                return
            # get the item at the head of the queue
            self.requestQueueLock.acquire()
            thisRequest = self.requestQueue[0]
            del self.requestQueue[0]
            self.requestQueueLock.release()
            try:
                thisRequest.run()
            except:
                itemsToRequeue.append(thisRequest)

        # run the failed items queue
        for item in self.failedItems.keys():
            # nuke it if we've failed this one too many times
            if self.failedItems[item] > 5:
                self.failedItemsLock.acquire()
                del self.failedItems[item]
                self.failedItemsLock.release()
            else:
                try:
                    item.run()
                    self.failedItemsLock.acquire()
                    del self.failedItems[item]
                    self.failedItemsLock.release()
                except:
                    self.failedItemsLock.acquire()
                    self.failedItems[item] += 1
                    self.failedItemsLock.release()

        # toss any freshly failed items into the failed queue
        for item in itemsToRequeue:
            self.failedItemsLock.acquire()
            if not self.failedItems.has_key(item):
                self.failedItems[item] = 0
            self.failedItems[item] += 1
            self.failedItemsLock.release()
            
