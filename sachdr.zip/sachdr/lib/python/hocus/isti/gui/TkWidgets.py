from Tkinter import *
from isti.utils.FunctionProxy import FunctionProxy
from isti.utils.GetSet import GetSet
from isti.utils.Timer import Timer

import Tkinter
import tkSimpleDialog
import tkFont
import time
import sys
import threading
import struct
import threading
import thread

class StopWatch(GetSet, Timer):
    """
    Stopwatch class, with a label as the display
    """
    def __init__(self, Parent, background=None, updateFrequencyInSeconds=1, font=None):
        self.canvas = Tkinter.Canvas(Parent, background=background)
        self.canvas.grid()
        self.displayText = StringVar()
        self.displayLabel = Label(self.canvas, textvar=self.displayText, background=background)
        if font:
            self.displayLabel['font'] = font
        self.displayLabel.grid(row=0, column=0, sticky=E+W)
        self.updateFrequencyInSeconds = updateFrequencyInSeconds
        self.reset()
        self.stopThread = 0
        self.perTickCallback = None
        self.guiRequestQueue = None
        self.timerThread = None
        self.counterThreadDead = True
        
    def __del__(self):
        self.destroy()

    def setGuiRequestQueue(self, rq):
        self.guiRequestQueue = rq
        
    def destroy(self):
        self.stop()
        self.displayLabel.destroy()
        self.canvas.destroy()
        
    def reset(self):
        self.startTime = None
        self.stopThread = 1
        self.displayText.set('0:00')

    def grid(self, **kwargs):
        self.canvas.grid(kwargs)

    def restart(self):
        self.reset()
        self.start()

    def getStartTime(self):
        return self.startTime
    
    def start(self):
        if not self.startTime:
            self.startTime = time.time()

        self.waitForCounterThreadToDie()
        
        self.stopThread = 0
        self.timerThread = threading.Thread(target=self.count, args=())
        self.timerThread.start()

    def stop(self):
        self.stopThread = 1
        if self.timerThread:
            self.timerThread.join()

    def setPerTickCallback(self, func):
        self.perTickCallback = func

    def waitForCounterThreadToDie(self):
        while not self.counterThreadDead:
            time.sleep(.1)
            
    def count(self):
        self.counterThreadDead = False
        
        while self.stopThread == 0:
            delta = time.time() - self.startTime
            if callable(self.perTickCallback):
                self.perTickCallback()
            time.sleep(self.updateFrequencyInSeconds)

            s =  self.getTimeDisplay(delta)

            if self.guiRequestQueue:
                self.guiRequestQueue.enqueueRequest(self.displayText.set, (s, ))
            else:
                self.displayText.set(s)

        self.counterThreadDead = True
        thread.exit()
                
            
    def getTimeDisplay(self, delta):
        minutes = int(delta / 60)
        delta = delta - (minutes * 60)
        seconds = delta
        return '%d:%02d' %(minutes, seconds)

class StopWatchWithTotalTime(StopWatch):

    def __init__(self, Parent, background=None, updateFrequencyInSeconds=1, font=None):
        StopWatch.__init__(self, Parent, background, updateFrequencyInSeconds, font)
        self.totalDisplayText = StringVar()
        self.totalDisplayLabel = Label(self.canvas, textvar=self.totalDisplayText, background=background)
        self.seperatorLabel = Label(self.canvas, text="/", background=background)
        if font:
            self.totalDisplayLabel['font'] = font
            self.seperatorLabel['font'] = font
        self.seperatorLabel.grid(row=0, column=1, sticky=E+W)
        self.totalDisplayLabel.grid(row=0, column=2, sticky=E+W)
        self.totalDisplayText.set('0:00')
        self.totalStartTime = None
        
    def destroy(self):
        self.totalDisplayLabel.destroy()
        self.seperatorLabel.destroy()
        StopWatch.destroy(self)

    def clear(self):
        self.reset()
        self.totalDisplayText.set('0:00')
        self.totalStartTime = None
        
    def start(self):
        if not self.totalStartTime:
            self.totalStartTime = time.time()
        StopWatch.start(self)

    def getTotalStartTime(self):
        return self.totalStartTime
    
    def count(self):
        self.counterThreadDead = False
        
        while self.stopThread == 0:
            delta = time.time() - self.startTime
            totalDelta = time.time() - self.totalStartTime
            if callable(self.perTickCallback):
                self.perTickCallback()
            time.sleep(self.updateFrequencyInSeconds)
            s1 = self.getTimeDisplay(delta)
            s2 = self.getTimeDisplay(totalDelta)
            

            if self.guiRequestQueue:
                self.guiRequestQueue.enqueueRequest(self.displayText.set, (s1, ))
                self.guiRequestQueue.enqueueRequest(self.totalDisplayText.set, (s2, ))
            else:
                self.displayText.set(s1)
                self.totalDisplayText.set(s2)

        self.counterThreadDead = True
        thread.exit()
        


class ProgressBar(GetSet):
    """
    simple progress bar class.  Use setProgress/getProgress to make it work
    """
    def __init__(self, Parent, height=20, width=200, foreground="gray", background=None, initialPercent=0, barcolor="red", donecolor=None, guiRequestQueue=None):
        self.guiRequestQueue=guiRequestQueue
        self.height=height
        self.width=width
        self.doneColor = donecolor
        self.barColor = barcolor
        #if self.guiRequestQueue:
        #    self.bar = self.guiRequestQueue.enqueueRequest(Tkinter.Canvas,
        #                                                   (Parent, ),
        #                                                   {'width':width,'height':height, 'background':background,
        #                                                    'borderwidth':1, 'relief':Tkinter.SUNKEN}).waitForResult()
        #else:
        self.bar = Tkinter.Canvas(Parent, width=width, height=height, background=background,
                                  borderwidth=1, relief=Tkinter.SUNKEN)
            
        self.bar.pack(padx=5,pady=2)
        self.RectangleID=self.bar.create_rectangle(0,0,0,height)
        #if self.guiRequestQueue:
        #    self.guiRequestQueue.enqueueRequest(self.bar.itemconfigure, (self.RectangleID,), {'fill':barcolor})
        #else:
        self.bar.itemconfigure(self.RectangleID, fill=barcolor)
            
        self.setProgress(initialPercent)
        self.colorLocked = 0
        self.currentValue = 0
        
    def __del__(self):
        self.destroy()

    def lockColor(self):
        self.colorLocked = 1

    def setGuiRequestQueue(self, rq):
        self.guiRequestQueue = rq
        
    def unlockColor(self):
        self.colorLocked = 0
        
    def setColor(self, color):
        if not self.colorLocked:
            #if self.guiRequestQueue:
            #    self.guiRequestQueue.enqueueRequest(self.bar.itemconfigure, (self.RectangleID, ), {'fill':color})
            #else:
            self.bar.itemconfigure(self.RectangleID, fill=color)

    def setBackgroundColor(self, color):
        self.bar['background'] = color
        
    def destroy(self):
        ## during shutdown, this may have happened already (in another thread, perhaps)
        try:
            self.bar.destroy()
        except:
            pass

    def update(self, newvalue=None):
        if newvalue == self.currentValue:
            return
        else:
            self.currentValue = newvalue
            
        if newvalue:
            if newvalue > 100:
                newvalue = 100
            self.setProgress(newvalue)
        else:
            return
        
        if newvalue == 100:
            if self.doneColor != None:
                self.setColor(self.doneColor)
        else:
                self.setColor(self.barColor)
                
        ProgressPixel=(self.getProgress()/100.0)*self.width
        self.bar.coords(self.RectangleID,0,0,ProgressPixel,self.height)

    def grid(self, **kwargs):
        self.bar.grid(kwargs)
        
class HorizontalRule:
    def __init__(self, Parent, width=None, rulecolor='black', thickness=1, background=None):
        self.thickness = thickness
        self.width = width
        self.rulecolor = rulecolor
        self.ruleCanvas = Tkinter.Canvas(Parent, height=thickness, width=width, background=background, borderwidth=0, relief=Tkinter.SOLID)
        self.rule = self.ruleCanvas.create_rectangle(width,0, 0, 100)
        self.ruleCanvas.itemconfigure(self.rule, fill=rulecolor)
        self.ruleCanvas.grid(pady=3)
        
    def grid(self, **kwargs):
        self.ruleCanvas.grid(kwargs)

    def destroy(self):
        self.ruleCanvas.destroy()
        

class DialogBox(Toplevel):

    def __init__(self, master=None, text="Empty Dialog", background=None, button1=None, button2=None,
                 title="DialogBox", button1cmd=None, button2cmd=None, buttonbackground="gray",
                 buttonactivebackground="gray2", modal=None):

        Toplevel.__init__(self, master, background=background)

        if modal:
            # make ourselves modal
            self.grab_set()
            
        self.title(title)
        if button1cmd:
            button1Func = button1cmd
        else:
            button1Func = self.destroy

        if button2cmd:
            button2Func = button1cmd
        else:
            button2Func = self.destroy

        self.message = Label(self, text=text, background=background)
        self.message.grid(row=0, column=0, columnspan=3, sticky="nsew")

        if button1 and button2:
            b1Loc = (1, 0)
            b2Loc = (1, 2)
        else:
            b1Loc = (1, 1)
            b2Loc = (1, 1)

        if button1:
            self.button1 = Button(self, text=button1, command=button1Func, background=buttonbackground,
                                  activebackground=buttonactivebackground)
            self.button1.grid(row=b1Loc[0], column=b1Loc[1], sticky="nsew")

        if button2:
            self.button2 = Button(self, text=button2, command=button2Func, background=buttonbackground, 
                                  activebackground=buttonactivebackground)
            self.button2.grid(row=b2Loc[0], column=b2Loc[1], sticky="nsew")
        

    def destroy(self):
        Toplevel.destroy(self)

class StatusBar(Label):
    def __init__(self, *args, **kwargs):
        self.statusBarTxt = StringVar()
        kwargs['textvariable'] = self.statusBarTxt
        kwargs['relief'] = SUNKEN
        Label.__init__(self, *args, **kwargs)
        
    def setStatus(self, txt):
        self.statusBarTxt.set(txt)

    def getStatus(self):
        return self.statusBarTxt.get()
        
class Tab(Frame):
    """
    A Frame that makes up a single tab in a "Tab Panel"
    The TabPanel instance that this Tab should be part of, should
    be used as the TabPanel's root
    """
    def __init__(self, *args, **kwargs):
        if kwargs.has_key('tabname'):
            self.tabname = kwargs['tabname']
            del kwargs['tabname']
        Frame.__init__(self, *args, **kwargs)

    def destroy(self):
        self.deactivated()
        
    def activated(self):
        pass

    def deactivated(self):
        pass
            
class TabPanel(Frame):
    """
    A Tab Panel
    """
    def __init__(self, *args, **kwargs):
        Frame.__init__(self, *args, **kwargs)
        self.tabButtons = []
        self.tabFrames = []

        self.background = None
        if kwargs.has_key('background'):
            self.background = kwargs['background']
            
        self.frameButtons = Frame(self, background='white')

        self.frameButtons.place(x=0, y=0)
        self.activeIndex = 0

        
    def lock(self):
        for button in self.tabButtons:
            button['state'] = DISABLED

    def unlock(self):
        for button in self.tabButtons:
            button['state'] = NORMAL
            
    def addTab(self, newTab):
        self.tabFrames.append(newTab)
        cmd = FunctionProxy(self.changeTab, len(self.tabFrames)-1)
	btn = Button(self.frameButtons, command=cmd, text=newTab.tabname)
        self.tabButtons.append(btn)
	btn.grid(row=0, column=len(self.tabButtons), sticky=N+W)
        btn['relief'] = SUNKEN
        if len(self.tabFrames) == 1:
	    self.changeTab(0)
            
    def changeTab(self, newTabIndex):
        self.tabButtons[self.activeIndex]['relief'] = SUNKEN
	if sys.platform == 'darwin':
	    self.tabButtons[self.activeIndex]['state'] = NORMAL
	    
        self.tabFrames[self.activeIndex].deactivated()
        self.tabFrames[self.activeIndex].place_forget()
        self.activeIndex = newTabIndex
        self.tabFrames[newTabIndex].place(x=0, y=25)
        self.tabButtons[newTabIndex]['relief'] = RAISED
	if sys.platform == 'darwin':
	    self.tabButtons[newTabIndex]['state'] = ACTIVE
	    
        self.tabFrames[self.activeIndex].activated()

class SplashScreen(Toplevel):
     def __init__(self, master, msToDisplay, relief=RAISED, borderwidth=5, width=200, height=200):
         Toplevel.__init__(self, master, relief=relief, borderwidth=borderwidth)

         self.width = width
         self.height = height
         self.master = master
         self.master.withdraw()
         self.overrideredirect(1)
         self.after_idle(self.center)
         self.msToDisplay = msToDisplay
         
         if width:
             self.columnconfigure(0, minsize=width)
         if height:
             self.rowconfigure(0, minsize=height)
         self.update()
         self.after(self.msToDisplay, self.destroy)
         time.sleep(self.msToDisplay/1000)

     def setMSToDisplay(self, newVal):
         self.msToDisplay = newVal
         
     def setupGUI(self):
         """ Override this for drawing """
         Label(self, text="This is a test splashscreen").grid(row=0, column=0)

     def center(self):
         self.update_idletasks()

         xmax = self.winfo_screenwidth()
         ymax = self.winfo_screenheight()
         self.setupGUI()

         x0 = self.x0 = (xmax - self.winfo_reqwidth()) / 2 - self.width/2
         y0 = self.y0 = (ymax - self.winfo_reqheight()) / 2 - self.height/2
         self.geometry("+%d+%d" % (x0, y0))


     def destroy(self):
         self.master.update()
         self.master.deiconify()
         self.withdraw()


class SelectDialog(tkSimpleDialog.Dialog):

    def __init__(self, *args, **kwargs):

        self.displayEntryBox = False
        self.entryLabel = ''
        self.loadLeftList = []
        self.loadRightList = []
        self.leftListContents = []
        self.rightListContents = []
        self.cancelPushed = True
        
        if kwargs.has_key('allowEntry'):
            if kwargs['allowEntry']:
                self.displayEntryBox = True
            del kwargs['allowEntry']

        if kwargs.has_key('entryLabel'):
            self.entryLabel = kwargs['entryLabel']
            del kwargs['entryLabel']

        if kwargs.has_key('leftList'):
            self.loadLeftList = kwargs['leftList']
            if type(self.loadLeftList) not in (tuple, list):
                self.loadLeftList = [ self.loadLeftList ]
            del kwargs['leftList']
            
        if kwargs.has_key('rightList'):
            self.loadRightList = kwargs['rightList']
            if type(self.loadRightList) not in (tuple, list):
                self.loadRightList = [ self.loadRightList ]
            del kwargs['rightList']
            
        tkSimpleDialog.Dialog.__init__(self, *args, **kwargs)

    def apply(self):
        self.cancelPushed = False

    def canceled(self):
        return self.cancelPushed
    
    def body(self, master):

        rowNum = 0

        # The entry box
        self.entryBoxFrame = Frame(master)
        self.entryBoxLabel = Label(self.entryBoxFrame, text='%s:' %self.entryLabel)
        self.entryBoxContents = StringVar()
        self.entryBox = Entry(self.entryBoxFrame, textvariable=self.entryBoxContents)
        self.entryBoxButton = Button(self.entryBoxFrame, text="Add", command=self.addEntryBoxContentsToLeft)
        self.entryBoxLabel.grid(row=0, column=0)
        self.entryBox.grid(row=0, column=1)
        self.entryBoxButton.grid(row=0, column=2)
        if self.displayEntryBox:
            self.entryBoxFrame.grid(row=rowNum, column=0, columnspan=5, sticky="ew")
            rowNum += 1
            
        # the two labels
        Label(master, text="Ignore").grid(row=rowNum, column=0, columnspan=2, sticky="ew")
        Label(master, text="Operate on").grid(row=rowNum, column=3, columnspan=2, sticky="ew")
        rowNum += 1
        
        # the two lists
        self.rightList = Listbox(master, height=10)
        self.leftList = Listbox(master, height=10)

        self.rightList.bind('<Double-Button-1>', self.handleListDoubleclick)
        self.leftList.bind('<Double-Button-1>', self.handleListDoubleclick)
        
        # the two list scrollbars
        self.leftListScroller = Scrollbar(master)
        
        self.rightListScroller = Scrollbar(master)

        # set up the scrollbars
        self.leftListScroller['command'] = self.leftList.yview
        self.leftList['yscrollcommand'] = self.leftListScroller.set
        self.rightListScroller['command'] = self.rightList.yview
        self.rightList['yscrollcommand'] = self.rightListScroller.set
        
        # The two buttons, and the frame they live in
        self.toFromButtonFrame = Frame(master)
        self.moveRightButton = Button(self.toFromButtonFrame, text="---->", command=self.moveToRight)
        self.moveLeftButton = Button(self.toFromButtonFrame, text="<----", command=self.moveToLeft)

        # place the buttons in their frame
        self.moveRightButton.grid(row=0, column=0, pady=5, sticky="ew")
        self.moveLeftButton.grid(row=1, column=0, pady=5, sticky="ew")

        # place the lists and the button frame in the window
        self.leftList.grid(row=rowNum, column=0)
        self.leftListScroller.grid(row=rowNum, column=1, sticky="ns")
        self.toFromButtonFrame.grid(row=rowNum, column=2, padx=10)
        self.rightList.grid(row=rowNum, column=3)
        self.rightListScroller.grid(row=rowNum, column=4, sticky="ns")

        for item in self.loadLeftList:
            self.addItemToList(item, self.leftList)
        for item in self.loadRightList:
            self.addItemToList(item, self.rightList)

        self.sortDisplayList(self.leftList)
        self.sortDisplayList(self.rightList)
        
    def getContentsOfRightList(self):
        """
        Get the contents of the right list
        """
        return self.rightListContents

    def getContentsOfLeftList(self):
        """
        Get the contents of the left list
        """
        return self.leftListContents

    def syncLists(self):
        self.leftListContents = list(self.leftList.get(0, END))
        self.rightListContents = list(self.rightList.get(0, END))
        
    def addItemToList(self, whichItem, whichList):
        """
        Add an item to a list
        """
        whichList.insert(END, whichItem)
        self.sortDisplayList(whichList)
        self.syncLists()
        
    def removeItemFromList(self, itemIndex, whichList):
        """
        remove an item from a list
        """
        whichList.delete(itemIndex)
        self.syncLists()

    def handleListDoubleclick(self, event):
        if event.widget == self.leftList:
            self.moveToRight()
        if event.widget == self.rightList:
            self.moveToLeft()
            
    def moveToRight(self):
        """
        Move selected items from the left to the right
        """
        itemIndices = self.leftList.curselection()
        for item in itemIndices:
            self.addItemToList(self.leftList.get(item), self.rightList)

        for item in itemIndices:
            self.removeItemFromList(item, self.leftList)

    def moveToLeft(self):
        """
        Move selected items from the right to the left
        """
        itemIndices = self.rightList.curselection()
        for item in itemIndices:
            self.addItemToList(self.rightList.get(item), self.leftList)

        for item in itemIndices:
            self.removeItemFromList(item, self.rightList)

        
    def sortDisplayList(self, whichList):
        """
        Sort the display list
        """
        # get and sort
        items = list(whichList.get(0, END))
        items.sort()

        # remove old
        whichList.delete(0, END)

        # insert in new order
        for item in items:
            whichList.insert(END, item)

    def addEntryBoxContentsToLeft(self):
        toAdd = self.entryBoxContents.get()
        if toAdd:
            self.addItemToList(toAdd, self.leftList)
            self.entryBoxContents.set('')
