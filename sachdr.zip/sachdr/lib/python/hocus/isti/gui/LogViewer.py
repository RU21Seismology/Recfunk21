# This is a log viewer dialog
from Tkinter import *
import tkSimpleDialog
import threading

class myDialog(tkSimpleDialog.Dialog):
    def __init__(self, parent, title = None):

        '''Initialize a dialog.

        Arguments:

            parent -- a parent window (the application window)

            title -- the dialog title
        '''
        Toplevel.__init__(self, parent)
        self.transient(parent)

        if title:
            self.title(title)

        self.parent = parent

        self.result = None

        body = Frame(self)
        self.initial_focus = self.body(body)
        body.pack(padx=5, pady=5)

        self.buttonbox()

        self.wait_visibility() # window needs to be visible for the grab
        #self.grab_set()

        if not self.initial_focus:
            self.initial_focus = self

        self.protocol("WM_DELETE_WINDOW", self.cancel)

        if self.parent is not None:
            self.geometry("+%d+%d" % (parent.winfo_rootx()+50,
                                      parent.winfo_rooty()+50))

        self.initial_focus.focus_set()

        self.wait_window(self)

class LogViewer(myDialog):

    def __init__(self, *args, **kwargs):
        if kwargs.has_key('logFileName'):
            self.setLogFileName(kwargs['logFileName'])
            del kwargs['logFileName']
            kwargs['title'] = 'Contents of %s' %self.logFileName
        self.bytesRead = 0
        self.logFile = None
        self.killThread = False
        myDialog.__init__(self, *args, **kwargs)

    #def __del__(self):
    #    self.killThread = True

    def setLogFileName(self, l):
        self.logFileName = l
        
    def getLogFileName(self):
        return self.logFileName
    
    def body(self, master):
        self.widgetMaster = master
        self.logContents = Text(master)
        self.logContentsScroller = Scrollbar(master)

        self.logContentsScroller['command'] = self.logContents.yview
        self.logContents['yscrollcommand'] = self.logContentsScroller.set 
        
        self.logContents.grid(row=0, column=0, sticky=N+S+E+W)
        self.logContentsScroller.grid(row=0, column=1, sticky=N+S)

        self.logContents['state'] = DISABLED
        self.after(250, self.updateText)

    def buttonbox(self):
        self.dismissButton = Button(self.widgetMaster, text="OK", width=10, command=self.ok)
        self.dismissButton.grid(padx=5, pady=5, row=1, column=0, columnspan=2)
        self.bind("<Return>", self.dismissButton)
    
    def updateText(self):
        if not self.logFile:
            self.logFile = open(self.getLogFileName(), 'r')
            
        # go to the end of the file
        self.logFile.seek(0, 2)
        
        # if the end of the file is past where we've read, insert the new text
        if self.logFile.tell() > self.bytesRead:
            self.logFile.seek(self.bytesRead, 0)
            newText = self.logFile.read()
            self.logContents['state'] = NORMAL
            self.logContents.insert(END, newText)
            self.logContents.see(END)
            self.logContents['state'] = DISABLED
            self.bytesRead = self.logFile.tell()

        # do it again after 250ms
        #if not self.killThread:
        self.after(250, self.updateText)
        
if __name__ == '__main__':

    l = open('logTest', 'w')
    l.write("""
this
is
a
test
of
the
logfile
""")
    l.close()
    t = Tk()
    lv = LogViewer(t, logFileName='logTest')
