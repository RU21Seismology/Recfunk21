"""
A class that represents a task to be done
"""

from isti.utils.Logging import *

INCOMPLETE = -1
COMPLETED = 1

class Task(MessageListener):
    def __init__(self, messageListeners=[], timers=[]):
        self.status = INCOMPLETE
        self.silentParent = 0
        self.messageListeners = []
        self.timers = []
        for listener in messageListeners:
            self.addMessageListener(listener)

        for timer in timers:
            self.timers.append(timer)
            
    def addMessageListener(self, listener):
        if isinstance(listener, MessageListener):
            self.messageListeners.append(listener)


    def addTimer(self, newTimer):
        self.timers.append(newTimer)

    def stopTimers(self):
        for timer in self.timers:
            timer.stop()

    def startTimers(self):
        for timer in self.timers:
            timer.start()

    def resetTimers(self):
        for timer in self.timers:
            timer.reset()

    def restartTimers(self):
        for timer in self.timers:
            timer.restart()
            
    def __call__(self, *args):

        self.resetTimers()
        self.startTimers()
        if not self.silentParent:
            self.addMessage("Starting Task: %s" %self.getName())

        self.performTask(args)


        if self.status == INCOMPLETE:
            self.addMessage("%s finished, but incomplete." %self.getName(), ERR)
        elif not self.silentParent:
            self.addMessage("Completed Task: %s" %self.getName())
        self.stopTimers()


    def addMessage(self, msg, msgType=MSG):
        for listener in self.messageListeners:
            thisMessage = LogMessage(msg, msgType)
            listener.addMessage(thisMessage, msgType)

    def performTask(self, args):
        """
        This is a "do-nothing" test that always passes
        """
        self.status = COMPLETE
        
    def throwExceptionIfUnrun(self):
        """
        Check to see if we've been run, and throw an
        exception if we havent been.
        """
        if self.status == INCOMPLETE:
            raise TestingException("Test not run")
        
    def ran(self):
        """
        boolean convenience method for determining
        pass/fail
        """
        return self.status != INCOMPLETE

    def getName(self):
        """
        get the name of this test
        """
        return self.__class__.__name__
