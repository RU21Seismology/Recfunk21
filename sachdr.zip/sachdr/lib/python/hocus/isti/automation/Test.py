"""
a class that represents a basic test
"""
from isti.utils import Logging
from isti.automation.Task import Task, COMPLETED, INCOMPLETE

PASS = COMPLETED + 1
FAIL = PASS + 1
UNRUN = INCOMPLETE

class TestingException(Exception):
    """
    Exception used for the Test class
    """
    pass


class Test(Task):
    
    def __init__(self, listeners=[]):
        Task.__init__(self, listeners)
        self.silentParent = 1
        
    def performTask(self, args):
        self.addMessage("Starting test: %s" %self.getName())
        self.performTest(args)
        #if self.status == UNRUN:
        #    raise TestingException("Test completed, status still unrun")

        if self.status == FAIL:
            self.addMessage("Finished test: %s [Failed]" %self.getName(), Logging.ERR)
        elif self.status == UNRUN:
            self.addMessage("Finished test: %s [Incomplete]" %self.getName(), Logging.ERR)
        else:
            self.addMessage("Finished test: %s [Passed]" %self.getName())
        
    def performTest(self, args):
        """
        This is a "do-nothing" test that always passes
        """
        self.status = PASS
        
    def passed(self):
        """
        boolean convenience method for determining
        pass/fail
        """
        self.throwExceptionIfUnrun()
        return self.status == PASS

    def failed(self):
        """
        boolean convenience method for determining
        pass/fail
        """
        self.throwExceptionIfUnrun()
        return self.status == FAIL
    
