# library replacements for v2.3
