
class FunctionProxy:
    """
    This is a convenient way to pass around a function with predefined args.

    Normally, you can pass around a function pointer, but you can't pass around
    a function pointer with a certian argument set.  This class allows this.

    This is a little dangerous if you aren't careful, since if you use immutable
    types for args, they will be stale, and represent the state of the program
    when the proxy was created, rather than at the time it was called.
    """
    def __init__(self, func, *args):
        self.function = func
        self.functionArgs = args

    def __call__(self, *args):
        """
        call the function we're proxying.  If args is supplied, we'll
        add them to the ones we have already
        """
        callArgs = ()
        if len(self.functionArgs) != 0:
            callArgs += self.functionArgs

        if len(args) != 0:
            callArgs += args

        return apply(self.function, callArgs)


if __name__ == '__main__':

    def testFunc1():
        print 'zero arg test'
    def testFunc2(str):
        print str

    f1 = FunctionProxy(testFunc1)
    f2 = FunctionProxy(testFunc2, "init args")
    print "----------------"
    f1()
    f2()
    f2('call args')
    print "----------------"
