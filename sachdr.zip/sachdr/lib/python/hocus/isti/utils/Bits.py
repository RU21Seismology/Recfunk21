"""
Some items that make dealing with bitmaps easier.

Included are names for the powers of two (BIT0..BIT16)
and a function for decoding a bitfield into a series
of strings
"""

import string

BIT0 = 1
BIT1 = 2
BIT2 = 4
BIT3 = 8
BIT4 = 16
BIT5 = 32
BIT6 = 64
BIT7 = 128
BIT8 = 256
BIT9 = 512
BIT10 = 1024
BIT11 = 2048
BIT12 = 4096
BIT13 = 8192
BIT14 = 16384
BIT15 = 32768
BIT16 = 65536

def bitsToStrings(bitmap, strValues, joinWith='\n      '):
    """
    Go through <bitmap>.  For each bit in <bitmap> there
    should be an element in <strValues>.  This element
    should either be a string, or a 2 element tuple.

    In the case of the string, that string is appended to the
    return value when it's coresponding bit is set, and nothing
    is added if the bit is not set.  In the case of a tuple, the
    first value of the tuple is used for a set bit, and the
    second value for an unset bit.

    Before returning, the various strings are joined together
    by inserting <joinWith> between each one
    """
    
    ret = ['']
    strBothValues = []
    for value in strValues:
        if type(value) in ( type( (1, 2) ), type([1, 2]) ):
            strBothValues.append(value)
        else:
            strBothValues.append( (value, None) )

    bitmap = 1L * bitmap
    for power in range(0, 32):
        bitValue = pow(2L, power)
        if len(strBothValues) > power:
            if bitmap & bitValue:
                if strBothValues[power][0] != None:
                    ret.append( strBothValues[power][0] )
            else:
                if strBothValues[power][1] != None:
                    ret.append(strBothValues[power][1])

    return string.join(ret, joinWith)
                           
