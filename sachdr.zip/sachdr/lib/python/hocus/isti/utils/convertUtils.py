import time
import string
import struct
import sys
import traceback
import calendar

def IllegalByteFormatException(Exception):
    pass

def makeEpochTime(timeStr):
    """
    Take a time in the form of yyyy-mm-dd hh:mm:ss and convert to epoch time
     """
    datePart, timePart = string.split(string.strip(timeStr))
    year, month, day = string.split(datePart, '-')
    hour, minute, second = string.split(timePart, ':')
    
    timeTup = (int(year), int(month), int(day), int(hour), int(minute), int(second), 0, 0, -1)
    return time.mktime(timeTup)

def shiftLeftPreserving32Bits(num, shiftBy):
    val = 0xFFFFFFFF & (num << shiftBy)
    if type(val) == long:
        byteStr = struct.pack("Q", val)
        valAsInt = struct.unpack("l", byteStr[0:4])[0]
        return valAsInt
    return val

def formatExceptionInfo(maxTBlevel=10, infoTuple=None):
    if not infoTuple:
        cla, exc, trbk = sys.exc_info()
    else:
        cla, exc, trbk = infoTuple
        
    try:
        excName = cla.__name__
    except:
        excName = cla
        
    try:
        excArgs = exc.__dict__["args"]
    except KeyError:
        excArgs = "<no args>"
    excTb = traceback.format_tb(trbk, maxTBlevel)
    return (excName, excArgs, excTb)

def formatBytes(numBytes, bias="M"):
    numKilos = 0
    numMegs = 0
    bytesLeft = numBytes
    if bias in ('m', 'M'):
        numMegs = bytesLeft / (1024*1024)
        bytesLeft = bytesLeft - (numMegs * (1024*1024))

    if bias in ('M', 'm', 'k', 'K'):
        numKilos = bytesLeft / 1024
        bytesLeft = bytesLeft - (numKilos * 1024)
        

    if numMegs:
        return '%.02fM' %(numMegs + (numKilos/1000.0))
    if numKilos:
        return '%.2fK' %(numKilos + (bytesLeft/1000.0))
    return '%dB' %bytesLeft

def unformatBytes(byteStr):
    byteStr = byteStr.strip()
    
    label = byteStr[-1].lower()

    bases = {
        'b' : 1,
        'k' : 1024,
        'm' : 1024 * 1024,
        'g' : 1024 * 1024 * 1024
        }

    try:
        num = float(byteStr[:-1])
    except:
        raise IllegalByteFormatException(byteStr)

    if label not in bases.keys():
        raise IllegalByteFormatException(byteStr)

    return int(num * bases[label])
    
def convertYearAndDayOfYearToEpoch(year, dayOfYear):
    year = int(year)
    dayOfYear = int(dayOfYear)

    firstOfYearAsEpoch = calendar.timegm( (year, 1, 1, 0, 0, 0, 0, 0, 0) )
    return firstOfYearAsEpoch + ((dayOfYear-1) * (60*60*24))

def makeDuration(seconds):
    days =0
    hours = 0
    minutes = 0
    ret = ''
    
    while seconds >= (60*60*24):
        days += 1
        seconds -= (60*60*24)
    if days:
        ret += "%dd " %days
    while seconds >= (60*60):
        hours += 1
        seconds -= (60*60)
    if hours:
        ret += "%dh " %hours
    while seconds >= 60:
        minutes += 1
        seconds -= 60
    if minutes:
        ret += "%dm " %minutes
    if seconds:
        ret += "%ds" %seconds

    return ret.strip()

## ignore the << futurewarnings.  If we're not in 2.4 or higher, futurewarnings
## arent in existance, so the try/except will just except to a pass

try:
    import warnings
    warnings.filterwarnings("ignore", r'.*', FutureWarning, 'isti.utils.convertUtils', 0)
except:
    pass
