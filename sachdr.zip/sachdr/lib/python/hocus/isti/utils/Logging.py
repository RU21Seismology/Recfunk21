"""
Items useful for logging
"""

##
# 7-16-2004 - HJS : make the Log class thread-safe
##
import time
import sys
import thread

MSG = 1
ERR = 2

MSGTYPE_TO_PREFIX = {
    MSG : '---',
    ERR : '***'
    }

TIMEFORMAT = "%Y/%m/%d %H:%M:%S"


class MessageListener:
    def __init__(self, *args, **kwargs):
        pass
    
    def addMessage(self, msg, msgType):
        pass
    
class LogMessage:
    """
    a single message in a log
    """
    def __init__(self, msg='', msgType=MSG):
        self.message = msg
        self.timestamp = time.time()
        self.msgType = msgType
        
    def __repr__(self):
        return '[%s] %s %s' %(self.formatTimestamp(), MSGTYPE_TO_PREFIX[self.msgType], self.message)

    def __str__(self):
        return self.__repr__()

    def getMessage(self):
        return self.message
    
    def formatTimestamp(self):
        return time.strftime(TIMEFORMAT, time.localtime(self.timestamp))
    
class Log(MessageListener):
    def __init__(self, logfileName=None, messageListeners=[]):
        self.messages = []
        self.logfileName = logfileName
        self.messageListeners = []
        self.autoFlush = 0

        self.messages_Lock = thread.allocate_lock()
        self.logfile_Lock = thread.allocate_lock()
        
        for listener in messageListeners:
            self.addMessageListener(listener)

    def setAutoFlush(self, newVal):
        self.autoFlush = newVal
        if self.autoFlush:
            self.flush()
        
    def getAutoFlush(self):
        return self.autoFlush
    
    def addMessageListener(self, listener):
        if isinstance(listener, MessageListener):
            self.messageListeners.append(listener)

    def setLogfileName(self, newFileName):
        self.logfileName = newFileName

    def getLogfileName(self):
        return self.logfileName
    
    def silentlyAddMessage(self, msg, msgType=MSG):
        self.addMessage(msg, msgType, skipListeners=True)
        
    def addMessage(self, msg, msgType=MSG, listenersOnly=False, skipListeners=False):
        """
        add a message to the log.  If 'msg' is a string,
        a new LogMessage is created.  If 'msg' is a LogMessage,
        it's added to the log as-is
        """
        if type(msg) == type('adsf'):
            thisMessage = LogMessage(msg, msgType)
        else:
            # this is here to prevent listener-loops
            if msg in self.messages:
                return
            thisMessage = msg

        if not listenersOnly:
            self.messages_Lock.acquire()
            self.messages.append(thisMessage)
            self.messages_Lock.release()
            
        if not skipListeners:
            for listener in self.messageListeners:
                listener.addMessage(thisMessage, msgType)

        if self.getAutoFlush():
            self.flush()        

    def flush(self):
        self.writeToFile(self.logfileName)
        
    def writeToFile(self, file):
        """
        write the log to "file".  If "file" is a string, the file named will be opened, appended and closed.
        if "file" is an opened file, it will be written to and not closed.
        """
        closeFileWhenDone = 0
        self.logfile_Lock.acquire()
        try:
            if type(file) == type('asdf'):
                logOutputFile = open(file, 'a')
                closeFileWhenDone = 1
            elif type(file) == type(sys.stdout):
                logOutputFile = file
            else:
                return
        
            for message in self.messages:
                logOutputFile.write('%s\n' %message)

            if closeFileWhenDone:
                logOutputFile.close()

            self.clearMessages()
            self.logfile_Lock.release()
        except Exception,e:
            # we want to make sure we release the lock
            self.logfile_Lock.release()
            raise e
        
    def clearMessages(self):
        self.messages = []
