class Timer:
    def __init__(self, *args, **kwargs):
        pass

    def start(self):
        pass

    def stop(self):
        pass

    def reset(self):
        pass

    def restart(self):
        pass
