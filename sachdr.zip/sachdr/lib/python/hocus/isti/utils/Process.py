"""
Classes and functions for dealing with processes
"""

import popen2
import os
import string
import signal

STATUS_UNRUN = 0
STATUS_RUNNING = 1
STATUS_COMPLETED = 2
STATUS_KILLED = 3

class ProcessException(Exception):
    pass

    
        
class Process:
    """
    A new process
    """
    def __init__(self, command, args=[]):
        self.command = command
        if type(args) == str:
            self.args = args
        elif type(args) in (list, tuple):
            self.args = string.join(args)
        self.runStatus = STATUS_UNRUN
        self.processOb = None
        self.testOnly = False
        self.returnValue = None
        self.stdout_output = ''
        self.stderr_output = ''
        
    def setTestMode(self, mode):
        self.testOnly = mode
        
    def sendTo(self, strToSend):
        """
        Send a string to the process's stdin
        """
        if self.getRunStatus() != STATUS_RUNNING:
            raise ProcessException('Process is not currently running')
        self.processOb.tochild.write(strToSend)


    def getStandardOut(self):
        """
        Get everything written so stdout so far
        """
        if self.processOb.fromchild:
            # this may be closed, if so, return what we've gotten so far
            try:
                self.stdout_output += self.processOb.fromchild.read()
            except:
                pass
        return self.stdout_output

    def getStandardError(self):
        """
        Get everything written to stderr so far
        """
        if self.processOb.childerr:
            try:
                self.stderr_output += self.processOb.childerr.read()
            except:
                pass
        return self.stderr_output
    
    
    def addArgument(self, newarg):
        """
        Append an argument to the argument list
        """
        self.args.append(newarg)

    def closeStdin(self):
        try:
            self.processOb.tochild.close()
        except:
            pass

    def closeStdout(self):
        try:
            self.processOb.fromchild.close()
        except:
            pass

    def closeStderr(self):
        try:
            self.processOb.childerr.close()
        except:
            pass
        
    def getCommandLine(self):
        """
        Get the command line that will be run.  This can be overridden in subclasses
        to control behavor (automatically wrapping commands etc...)
        """
        return '%s %s' %(self.command, self.args)

    def run(self):
        if self.testOnly:
            print '[TestMode] %s' %self.getCommandLine()
            self.processOb = popen2.Popen3('/bin/false')
        else:
            self.processOb = popen2.Popen3(self.getCommandLine(), 1, 0)
            
        self.runStatus = STATUS_RUNNING

        #fd = self.processOb.fromchild.fileno()
        #fl = fcntl.fcntl(fd, fcntl.F_GETFL)
        #try:
        #    fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NDELAY)
        #except AttributeError:

        #    fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.FNDELAY)

    def getPid(self):
        """
        Get the pid of this process.  If the process isn't currently running, an exception
        is thrown
        """
        currentStatus = self.getRunStatus()
        
        if currentStatus == STATUS_UNRUN:
            raise ProcessException('Process has not yet been run')
        elif currentStatus in (STATUS_COMPLETED, STATUS_KILLED):
            raise ProcessException('Process has already completed')

        return self.processOb.pid
        
    def getRunStatus(self):
        """
        Get the current run status.  This can also cause the internal run status to
        be updated, if the process was running last we checked, and it's not anymore.
        This should always be checked by calling this function, and not by accessing
        the property directly
        """
        try:
            self.closeStdin()
        except:
            pass

        try:
            self.getStandardOut()
        except:
            pass
        
        if self.runStatus == STATUS_RUNNING and self.processOb.poll() != -1:
            self.runStatus = STATUS_COMPLETED

        return self.runStatus

    def getReturnValue(self):
        """
        Get the return value of the process.  This will block until the process has returned
        """
        self.closeStdin()
        self.getStandardOut()
        if self.returnValue != None:
            return self.returnValue
        else:
            self.returnValue = self.processOb.wait()
        return self.returnValue
    
    def kill(self, sig=signal.SIGTERM):
        """
        Kill the process
        """
        os.kill(self.getPid(), sig)

        # if we're here, the getPid() didn't raise an exception (which would apply
        # here if it did) so we'll mark ourselves as killed
        self.runStatus = STATUS_KILLED

class RemoteSSHProcess(Process):
    """
    Execute a process on a remote host
    """
    
    def __init__(self, host, user, passwd, command, args=[]):
        self.remoteHost = host
        self.remoteUser = user
        self.remotePassword = passwd
        Process.__init__(self, command, args)

    def getCommandLine(self):
        return 'ssh %s@%s %s' %(self.remoteUser, self.remoteHost, Process.getCommandLine(self))

if __name__ == '__main__':

    import sys

    if len(sys.argv) == 1:
        proc = Process('uname', '-a')
        proc.run()
        proc.closeStdin()
        print proc.getStandardOut()
    elif sys.argv[1] == 'ssh':
        proc = RemoteSSHProcess('isti.com', 'hal', None, 'uname', '-a')
        proc.run()
        proc.closeStdin()
        print proc.getStandardOut()
