
from isti.utils.FunctionProxy import FunctionProxy
import string

class GetSet:
    """
    An 'ability' type mixin/class that allows for
    'on the fly' creation of get/set functions as
    well as str functions
    """

    def __getattr__(self,attr):
        """
        Handle the cases where the code is looking for getSomething
        or setSomething.  We'll create these functions on the fly.
        """
            
        if len(attr) >= 3:
            if attr[0:3] == 'set':
                return self.getSetFunction(attr[3:])
            elif attr[0:3] == 'get':
                return self.getGetFunction(attr[3:])
            elif attr[0:3] == 'str':
                return self.getStrFunction(attr[3:])
            else:
                raise AttributeError, attr
        raise AttributeError, attr

    def getGetFunction(self, attr):
        """
        Get the 'get' function for a data member
        """
        def innerGetFunc(ob, attr):
            if ob.__dict__.has_key(attr):
                ret = ob.__dict__[attr]
                return ret
            else:
                return None
        funProxy = FunctionProxy(innerGetFunc, self, attr)
        return funProxy

    def getSetFunction(self, attr):
        """ Get the 'set' function for a data member """
        def innerSetFunc(ob, attr, x):
            ob.__dict__[attr] = x

        funProxy = FunctionProxy(innerSetFunc, self, attr)
        return funProxy

    def getStrFunction(self, rawField):
        """
        Get the string output function for the field if one is present.
        If not, return an anonymous function that converts the requested
        field to a string
        """
        ## experimental support for indexing
        indexable = 0
        index = 0
        if '_' in rawField:
            try:
                parts = string.split(rawField, '_')
                index = int(parts[-1])
                field = string.join(parts[:-1], '_')
                indexable = 1
            except ValueError:
                field = rawField
        else:
            field = rawField

        strMethod = 'str%s' %field

        # make a list of all places we can get functions from
        classes = [self.__class__]
        classes += self.__class__.__bases__

        # reverse the class list, so we traverse it so that the root base
        # classes are in the beginning (so inheritance works as intended)
        # we're adding values to a dict, so the last values added with the
        # same name, will be the ones that get called.
        classes.reverse()
        
        ## now a list of all attributes
        methods = {}
        for classOb in classes:
            methods.update(classOb.__dict__)
            
        if strMethod in methods.keys():
            strFunc = getattr(self, strMethod)
            if indexable == 1:
                strFunc = FunctionProxy(strFunc, index)
        else:
            getMethod = self.getGetFunction(rawField)
            def strFunc(func):
                return '%s' %func()
            strFunc = FunctionProxy(strFunc, getMethod)

        return strFunc
