import SocketServer, BaseHTTPServer
import xmlrpclib
import sys, traceback

def getServerOfType(serverType, hostname, port):
    return SocketServer.TCPServer( (hostname, port), serverType)

class RPCMethodDoesNotExistException(Exception):
    pass

class XMLRPCRequestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    """
    This class is based on the example rpcserver that comes with xmlrpclib

    The resolveMethodPath method should be overridden by subclasses if the
    default behavor is not desired
    """

    def __init__(self, *args, **kwargs):
        if kwargs.has_key('methodHandlers'):
            self.methodHandlers = kwargs['methodHandlers'].copy()
            del kwargs['methodHandlers']
        else:
            self.methodHandlers = {}
        BaseHTTPServer.BaseHTTPRequestHandler.__init__(self, *args, **kwargs)
        
    def do_POST(self):
        try:
            # get arguments
            data = self.rfile.read(int(self.headers["content-length"]))
            params, method = xmlrpclib.loads(data)

            # generate response
            try:
                methodToCall = self.resolveMethodPath(method)
                # wrap response in a singleton tuple
                response = (methodToCall(*params), )
            except:
                # print exception to stderr (to aid debugging)
                traceback.print_exc(file=sys.stderr)
                # report exception back to server
                response = xmlrpclib.dumps(
                    xmlrpclib.Fault(1, "%s:%s" % sys.exc_info()[:2])
                    )
            else:
                response = xmlrpclib.dumps(
                    response,
                    methodresponse=1
                    )
        except:
            # internal error, report as HTTP server error
            traceback.print_exc(file=sys.stderr)
            self.send_response(500)
            self.end_headers()
        else:
            # got a valid XML RPC response
            self.send_response(200)
            self.send_header("Content-type", "text/xml")
            self.send_header("Content-length", str(len(response)))
            self.end_headers()
            self.wfile.write(response)

            # shut down the connection (from Skip Montanaro)
            self.wfile.flush()
            self.connection.shutdown(1)

    def addMethodHandler(self, methodPath, handlerMethod):
        self.methodHandlers[methodPath] = handlerMethod
        
    def resolveMethodPath(self, methodPath):
        """
        This method resolves a method name/path to a callable object.
        """
        if self.methodHandlers.has_key(methodPath):
            return self.methodHandlers[methodPath]

        raise RPCMethodDoesNotExistException('Invalid method: %s' %methodPath)
    
