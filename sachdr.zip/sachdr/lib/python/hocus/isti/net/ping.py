"""
Ping related functions
"""
import os
import sys

FAILED_PING_STRINGS = [
    'Request timed out',
    '0 packets received',
    '0 received',
    'Destination Host Unreachable'
    ]

def ping(hostname, numPings, pingTimeoutInSeconds):
    if sys.platform in ('win32', 'cygwin'):
        pingTimeout = int(round(pingTimeoutInSeconds * 1000))
        results = os.popen('ping -n %d -w %d %s' %(numPings, pingTimeout, hostname), 'r').read()
    elif sys.platform in ('darwin'):
        pingTimeout = int(round(pingTimeoutInSeconds))
        #s = os.popen('ping -c %d -i %d %s' %(numPings, pingTimeout, hostname), 'r')
        #results = s.read()
        #s.close()
        print 'ping -c %d -i %d %s' %(numPings, pingTimeout, hostname)
        return "0 packets received"
    else:
        pingTimeout = int(round(pingTimeoutInSeconds))
        s = os.popen('ping -c %d -w %d %s' %(numPings, pingTimeout, hostname), 'r')
        results = s.read()
        s.close()
    return results

def isHostAlive(hostname):
    global FAILED_PING_STRINGS
    pingInfo = ping(hostname, 1, .75)
    for badString in FAILED_PING_STRINGS:
        if badString in pingInfo:
            return 0
    return 1
