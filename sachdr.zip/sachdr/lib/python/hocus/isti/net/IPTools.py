# tools for mucking with IPAddresses

class InvalidIPAddressException(Exception):
    pass

class IPAddress:
    def __init__(self, ip):
        parts = ip.strip().split('.')
        self.octets = []
        for part in parts:
            try:
                self.octets.append( int(part) )
                if self.octets[-1] < 0 or self.octets[-1] > 255:
                    raise InvalidIPAddressException(ip)
            except:
                raise InvalidIPAddressException(ip)

    def internal_compare(self, other):
        """
        return -1 if other is >
        return 1 if other is <
        return 0 if equal
        """
        for i in range(0, 4):
            if self.octets[i] < other.octets[i]:
                return -1
            if self.octets[i] > other.octets[i]:
                return 1
        return 0
        
    def __gt__(self, other):
        return self.internal_compare(other) == 1

    def __ge__(self, other):
        return self.internal_compare(other) in [1, 0]

    def __lt__(self, other):
        return self.internal_compare(other) == -1

    def __le__(self, other):
        return self.internal_compare(other) in [-1, 0]

    def __eq__(self, other):
        return self.internal_compare(other) == 0
    
def isAddressInRange(ip, rangeStart, rangeEnd):
    start = IPAddress(rangeStart)
    end = IPAddress(rangeEnd)
    target = IPAddress(ip)

    if target >= start and target <= end:
        return True
    
    return False


if __name__ == '__main__':

    lowIP = IPAddress('127.0.0.1')
    highIP = IPAddress('127.0.0.2')

    print "Low > High: %s" %(lowIP > highIP)
    print "Low < High: %s" %(lowIP < highIP)
    print "Low >= High: %s" %(lowIP >= highIP)
    print "Low <= High: %s" %(lowIP <= highIP)
    print "Low == High: %s" %(lowIP == highIP)

    print "Low <= Low: %s" %(lowIP <= lowIP)
    print "Low >= Low: %s" %(lowIP >= lowIP)
    print "Low == Low: %s" %(lowIP == lowIP)
