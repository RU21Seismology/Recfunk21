##
# classes for debugging native types
##
import thread
import isti.debug.natives
import sys

def getCallerAsStr():
    try:
        raise Exception("this is fake")
    except Exception, e:
        #get the current execution frame
        f = sys.exc_info()[2].tb_frame

    f = f.f_back
    f = f.f_back
    obj = f.f_locals.get("self", None)
    functionName = f.f_code.co_name
    if obj:
        callStr = obj.__class__.__name__+"::"+f.f_code.co_name+" (line "+str(f.f_lineno)+")"
    else:
        callStr = f.f_code.co_name+" (line "+str(f.f_lineno)+")"
    return callStr

class DebugDict(dict):

    def __init__(self, *args, **kwargs):
        # the native classes implementations for these are atomic,
        # we need to be sure we're thread safe here too.
        self.getLock = thread.allocate_lock()
        self.setLock = thread.allocate_lock()
        self.delLock = thread.allocate_lock()
        dict.__init__(self, *args, **kwargs)
        
    def __getitem__(self, key):
        self.getLock.acquire()
        try:
            ret = dict.__getitem__(self, key)
            print '__GETitem__ -> %s : %s' %(key, ret)
            print ' |--> %s' %getCallerAsStr()
        finally:
            self.getLock.release()
        return ret

    def __setitem__(self, key, value):
        self.setLock.acquire()
        try:
            print '__SETitem__ -> %s : %s' %(key, value)
            print ' |--> %s' %getCallerAsStr()
            ret = dict.__setitem__(self, key, value)
        finally:
            self.setLock.release()
        return ret

    def __delitem__(self, key):
        self.delLock.acquire()
        try:
            print '__DELitem__ -> %s' %key
            print ' |--> %s' %getCallerAsStr()
            ret = dict.__delitem__(self, key)
        finally:
            self.delLock.release()
        return ret


if __name__ == '__main__':
    print 'creating'
    f = isti.debug.natives.DebugDict()
    f['foo'] = 'bar'
    f['l'] = [1, 2, 3]
    del f['l']
    print f['foo']

    print type(f)
    g = dict(f)
    print type(g)
