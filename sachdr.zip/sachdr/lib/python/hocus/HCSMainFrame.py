#! /usr/bin/env python
from Quasar.Q330 import Q330, QDP_C1_CERR
from Tkinter import *
from HCSEnumFrame import *
from HCSSubParmFrame import *
from HCSCmdFrame import *
from HCSMsgFrame import *
from HCSMsgText import *
from HCSMsgTextTab import *
from HCSAboutFrame import *
from HCSStatusFrame import *
from HCSConfigFrame import *
from HCSXMLFrame import *
from HCSFirmwareInfoFrame import *
from HCSMsgDialogFrame import *
from HCSFirmwareFrame import *
from HCSXMLParser import *
from HCSMisc import *
from HCSQ330 import *
from HCSParameters import *
from HCSCloneListFrame import HCSCloneList
from HCSStationIDFrame import *
from HCSSave2PISFrame import *
from HCSFastXML2Q330s import *
from time import sleep
import HCSLoadXML
import Pmw
import tkMessageBox

class HCSMainFrame(Frame):
    def __init__(self, master):
	Frame.__init__(self, master)
	self.master = master
	self.actionComponents = {}
	self.firmwareVers = {}
	self.createWidgets(master)
	self.pack()
        tkMessageBox.showwarning('Warnning',
                                 'USING HOCUS WITH INTERNET CONNECTED MAY HURT THE Q330(S) IN THE FIELD.\nMAKE SURE THE INTERNET IS UNPLUGGED BEFORE USING IT!')
    def sysExit(self):
	if tkMessageBox.askokcancel('Warning', 'You may or may not deregister the Q330(s).\n Are you sure to continue?'):
	    sys.exit(0)
	
    def createWidgets(self, master):
	self.enum = HCSEnumFrame(self)

        #create the massage text field and put it on msgFrm
	self.msgFrm = HCSMsgFrame(self)
	Pmw.initialise()
	self.msgText = HCSMsgText(self.msgFrm)
	self.msgTextTab = HCSMsgTextTab(self.msgFrm)

        self.makeMenu(master)
	self.cmd = HCSCmdFrame(self)
	#subparm = HCSSubParmFrame(self)
	#subcmd  = HCSSubCmdFrame(self)

    def lockComponents(self):
	for c in self.actionComponents.keys():
	    self.actionComponents[c].configure(state = DISABLED)
	self.menuBar.entryconfig(3, state = DISABLED)
	self.menuBar.entryconfig(2, state = DISABLED)
	
    def unlockComponents(self):
	for c in self.actionComponents.keys():
	    self.actionComponents[c].configure(state = NORMAL)
	self.menuBar.entryconfig(3, state = NORMAL)
	self.menuBar.entryconfig(2, state = NORMAL)
	
    def makeMenu(self, master):
        self.msgDialog = HCSMsgDialogFrame(master)
	menuBar = Menu(master)
	master.config(menu = menuBar)
	# File menu
	file = Menu(menuBar, tearoff = 0)
	file.add_command(label = "Save Messages As...",
                         command = self.msgDialog.saveAsMsg,
                         state = NORMAL)
	file.add_command(label = "Load Messages...",
                         command = self.msgDialog.openMsg,
                         state = NORMAL)
	file.add_command(label = "Clear Messages",
                         command = self.msgText.clear,
                         state = NORMAL)
	file.add_separator()
	file.add_command(label = "Quit", command = self.sysExit)
	menuBar.add_cascade(label = "File", menu = file)

	#Status menu
	stat = Menu(menuBar, tearoff = 0)
	stat.add_command(label = "General Status",
			 command = self.getGeneralStatus)
	stat.add_command(label = "GPS Status", command = self.getGPSStatus)
        stat.add_separator()
        stat.add_command(label = "Firmware Version",
                         command = self.enumQ330ForUpdate)
	menuBar.add_cascade(label = "Infomation", menu = stat, state = DISABLED)
	# Config menu
	cfg = Menu(menuBar, tearoff = 0)
	cfg.add_command(label = "Interfaces...", command = self.cfgInterfaces)
        cfg.add_separator()
        cfg.add_command(label = "Create XML File", command = self.loadXMLFile)
        cfg.add_command(label = "Save Tok to Q330", command = self.saveXML2Q330)
        cfg.add_command(label = "Save CFG to Q330", command = self.saveXMLCFG2Q330)
        cfg.add_separator()
        cfg.add_command(label = "Cloning Q330(s)", command = self.cloneQ330)
        cfg.add_command(label = "Fast Cloning", command = self.fastCloneQ330)
        cfg.add_separator()
        cfg.add_command(label = "Updating Firmware", command = self.updateFirmware)
	menuBar.add_cascade(label = "Configuration", menu = cfg, state = DISABLED)
	# Help menu
	help = Menu(menuBar, tearoff = 0)
	help.add_command(label = "Hints", command = '', state = DISABLED)
	help.add_command(label = "About", command = self.about)
	menuBar.add_cascade(label = "Help", menu = help)
	self.menuBar = menuBar
	return
        # END: makeMenu

    def about(self):
	ab = HCSAboutFrame(self)
	ab.about.show()

    def configure(self):
	items = self.enum.getSelectedItems()
	if items:
	    self.master.msgQueue.put("\nStart configuration.\n")
	    self.master.lockQueue.put(0) #not lock yet
	else:
	    tkMessageBox.showerror("Oops!",
				   "can't configure parameters without Q330(s) selected.")
	return items

    def cfgInterfaces(self):
	items = self.configure()
	if items:
	    t = threading.Thread(target = self.cfgInterfacesT,
				 args = (items,))
	    t.start()
	    

    def cfgInterfacesT(self, items):
	self.multiInterfs = {}
	self.multiAdvInterfs = {}
	self.multiAllPhy = {}
        self.master.lockQueue.put(1) # not lock yet
	for item in items:
	    self.master.msgQueue.put("Try to load interfaces for %s ... " % item[0])
	    q330 = HCSQ330(serialNumber = eval('0x' + item[1]))
            try:
                phy,advPhyS1,advPhyS2,advPhyE,dataPortMemorySizes=q330.getAllPhysicalInterfaces()
                interfaces = PhysicalInterfaces(phy)
                interfaces.c1phy2display()
                self.multiInterfs[item[0]] = interfaces
                aQ330advIfs = [advPhyS1, advPhyS2, advPhyE]
                allPhy = (phy, advPhyS1, advPhyS2, advPhyE)#don't change it.
                self.multiAllPhy[item[0]] = allPhy
                for i in range(3):
                    interfaces = AdvPhysicalInterfaces(aQ330advIfs[i], dataPortMemorySizes)
                    interfaces.c2phy2display()
                    aQ330advIfs[i] = interfaces
                self.multiAdvInterfs[item[0]] = aQ330advIfs 
                self.master.msgQueue.put("done\n")
            except:
                self.master.msgQueue.put("failed\n")
	self.master.msgQueue.put("Load interfaces finished.\n")
	self.master.lockQueue.put(0)
	#give a signal to call self.displayInterfaces
	self.master.statQueue.put(3)

    def displayInterfaces(self):
	cfgInt = HCSConfigInterfaces(
	    self, self.multiInterfs, self.multiAdvInterfs, self.multiAllPhy)
	
    def getStatus(self):
	items = self.enum.getSelectedItems()
	if items:
	    self.master.msgQueue.put("\nStart getting status.\n")
	    self.master.lockQueue.put(0) #not lock yet
	else:
	    tkMessageBox.showerror("Oops!",
				   "Can't display status without Q330(s) selected.")
	return items

    def getGPSStatus(self):
	items = self.getStatus()
	if items:
	    t = threading.Thread(target = self.getGPSStatusT,
				 args = (items,))
	    t.start()

    def getGPSStatusT(self, items):
	self.stat = {}
        self.master.lockQueue.put(1) # not lock yet
	for item in items: #tag/sn pair
	    self.master.msgQueue.put("Try %s ... " % item[0])
	    q330 = HCSQ330(serialNumber = eval('0x'+item[1]))
            try:
                s = q330.getGPSStatus()
                self.stat[item[0]] = s
                self.master.msgQueue.put("done\n")
            except:
                self.master.msgQueue.put("failed\n")
	self.master.msgQueue.put("Get GPS status finished.\n")
	self.master.lockQueue.put(0)
        # give a signal to call self.displayStatus
	# since this is a sub-thread, python signal module may have a problem.
	# and gui may have a problem too. So we use safe queue.
	self.master.statQueue.put(2)
	    
    def getGeneralStatus(self):
	items = self.getStatus()
	if items:
	    t = threading.Thread(target = self.getGeneralStatusT,
	    			 args = (items,))
	    t.start()

    def getGeneralStatusT(self, items):
	self.stat = {}
        self.master.lockQueue.put(1) # not lock yet
	for item in items: #tag/sn pair
	    self.master.msgQueue.put("Try %s ... " % item[0])
	    q330 = HCSQ330(serialNumber = eval('0x'+item[1]))
            try:
                s = q330.getGeneralStatus()
                self.stat[item[0]] = s
                self.master.msgQueue.put("done\n")
            except:
                self.master.msgQueue.put("failed\n")
	self.master.msgQueue.put("Get general status finished.\n")
	self.master.lockQueue.put(0)
        # give a signal to call self.displayStatus
	# since this is a sub-thread, python signal module may have a problem.
	# and gui may have a problem too. So we use safe queue.
	self.master.statQueue.put(1)


    def displayGeneralStatus(self):
	frmStatus = Toplevel(self)
	genstat = HCSGeneralStatus(frmStatus, self.stat)

    def displayGPSStatus(self):
	frmStatus = Toplevel(self)
	genstat = HCSGPSStatus(frmStatus, self.stat)

    def enumQ330ForUpdate(self):
        self.master.msgQueue.put("\nPlease wait for loading IPs.\n")
        t = threading.Thread(target = self.enumQ330T,
                             args = ())
        t.start()

    def enumQ330T(self):
        discovered = searchQ330s()
        self.dictOfDASs = discovered.getDeviceMap()
        self.master.msgQueue.put("Loading IPs done.\n")
        self.master.statQueue.put(8)

    def getFirmwareVersion(self, pis = False):
        try:
            items = self.dicOfDASs() # new one here
        except:
            items = self.enum.dictOfDASs  
        if not items:
            return
        if self.isDuplicateIPs(items):
            t = threading.Thread(target = self.getFirmwareVersionT,
                                 args = (items, pis))
            t.start()
        else:
            self.master.msgQueue.put("\nStart getting firmware versions.\n")
            self.master.lockQueue.put(1) #not lock yet
            self.finished = 0
            lck = threading.Lock()
            for tag in items.keys():
                t = threading.Thread(target = self.getFirmwareVersionFastT,
                                     args = (tag,
                                             items[tag]['Serial'],
                                             lck,
                                             len(items),
                                             pis))
                t.start()

    def isDuplicateIPs(self, items):
        IPs = []
        for tag in items.keys():
            thisDevice = items[tag]
            IPs.append(dottedIP2Num(thisDevice['IP']))
        IPs.sort()
        for i in range(len(IPs)-1):
            if IPs[i] == IPs[i+1]:
                return 1
        return 0

    def getFirmwareVersionT(self, items, pis):
	self.master.msgQueue.put("\nStart getting firmware versions.\n")
	self.master.lockQueue.put(1) #not lock yet
	for item in items.keys():
	    self.master.msgQueue.put('Try %s ... ' % item)
	    q330 = HCSQ330(serialNumber = eval('0x' + items[item]['Serial']))
            try:
                ver = q330.getFirmwareVersion()
                self.firmwareVers[item] = ver
                self.master.msgQueue.put('done\n')
            except:
                self.master.msgQueue.put('failed\n')
	self.master.msgQueue.put('Get firmware versions finished.\n')
	self.master.lockQueue.put(0)
        if pis: self.master.statQueue.put(11)
        else: self.master.statQueue.put(4)

    def getFirmwareVersionFastT(self, tag, serial, lck, numoftags, pis):
        q330 = HCSQ330(serialNumber = eval('0x' + serial))
        try:
            q330.realRegister(lck)
            ver = q330.getFirmwareVersion(0) # requireRegister=0
            q330.deregister()
            self.firmwareVers[tag] = ver
            lck.acquire()
            self.finished += 1
            if self.finished == numoftags: # we done
                self.master.msgQueue.put('Get firmware versions finished.\n')
                self.master.lockQueue.put(0)
                if pis: self.master.statQueue.put(11)
                else: self.master.statQueue.put(4)
            lck.release()
        except QDP_C1_CERR, e:
            print e
            self.master.msgQueue.put('%s failed\n' % tag)
	
    def displayFirmwareVersion(self):
	self.msgTextTab.clear()
	self.enum.lstEnum.box.setlist(self.enum.dictOfDASs.keys())
	for tagNum in self.enum.dictOfDASs.keys():
	    thisDevice = self.enum.dictOfDASs[tagNum]
            #changed for fill leading zero(s) for SN accordingly
            snum = '%016x' % eval('0x'+thisDevice['Serial'])
	    dataline = '%-4s' % (tagNum,) + '  ' + \
		'%-15s' % (thisDevice['IP'],) + '  ' + \
		'%-5s' % (str(thisDevice['BasePort']),) + '  ' + \
		'%-9s' % (snum,) + '   '
            #end change on 10/21/2009 
	    try:
		dataline += '%-9s' % (self.firmwareVers[tagNum],)
	    except:
		pass
	    dataline += '\n'
	    self.master.tabQueue.put(dataline)

    def getStationIDs(self):
        items = self.enum.getSelectedItems()
        if not items or len(items)>1:
            tkMessageBox.showerror('Oops!',
                                   "You must select one and only one Q330.")
        else:
            q330 = HCSQ330(serialNumber = eval('0x' + items[0][1]))
            self.stationID = HCSStationIDFrame(self, q330)

    def setStationIDs(self):
        if self.stationID.isSuccessful():
            self.stationID.go()
        else:
            self.master.msgQueue.put("failed.\n")

    def loadXMLFile(self):
        items = self.enum.getSelectedItems()
        if not items or len(items)>1:
            tkMessageBox.showerror('Oops!',
                                   "You must select one and only one Q330.")
        else:
            self.loadxml = HCSXMLFrame(self, items[0][0])
            xmlfile = self.loadxml.saveAsXML()
            if xmlfile:
                t = threading.Thread(target = self.loadXMLFileT,
                                     args = (items, xmlfile))
                t.start()

    def loadXMLFileT(self, items, xmlfile):
        tag = items[0][0]
        sn = items[0][1]
        self.master.msgQueue.put("\nTry to load %s\'s XML file..." % tag)
        self.master.lockQueue.put(1) # not lock yet
        q330 = HCSQ330(serialNumber = eval('0x%s' % sn))
        try:
            HCSLoadXML.printToXMLFile(xmlfile, q330)
            self.master.msgQueue.put("done\n")
            self.master.msgQueue.put("Loading done and saved to %s.\n" % self.loadxml.name)
        finally:
            self.loadxml.closeXML()
            self.master.lockQueue.put(0)

    def saveXML2Q330(self):
        items = self.enum.getSelectedItems()
        if not items:
            tkMessageBox.showerror('Oops!',
                                   "You must select at least one Q330.")
        else:
            self.save2q = HCSXMLFrame(self)
            xmlfile = self.save2q.openXML()
            if xmlfile:
                t = threading.Thread(target = self.saveXML2Q330T,
                                     args = (items, xmlfile))
                t.start()

    def saveXML2Q330T(self, items, xmlfile):
        self.master.msgQueue.put("\nStart to save XML into Q330(s).\n")
        handler = doParser(xmlfile)
        self.save2q.closeXML()

        self.master.lockQueue.put(1) # not lock yet
        for item in items:
            self.master.msgQueue.put("Try to save XML to %s ..." % item[0])
            q330 = HCSQ330(serialNumber = eval('0x' + item[1]))
            #q330.realRegister()
            try:
                q330.realRegister()
                for i in range(1,5): #4 data ports
                    q330.setTokenSet(handler.tokenLists[i-1], i)
                    self.master.msgQueue.put('%d ' % i)

                q330.saveToEEPROM()
                sleep(1)
                q330.reboot()
                sleep(2)
                self.master.msgQueue.put(" done\n")
            except:
                self.master.msgQueue.put(" failed\n")
                q330.deregister()
        self.master.lockQueue.put(0)
        self.master.msgQueue.put("Save XML into Q330(s) finished.\n")

    def saveXMLCFG2Q330(self):
        items = self.enum.getSelectedItems()
        if not items:
            tkMessageBox.showerror('Oops!',
                                   "You must select at least one Q330.")
        else:
            self.save2q = HCSXMLFrame(self)
            xmlfile = self.save2q.openXML()
            if xmlfile:
                t = threading.Thread(target = self.saveXMLCFG2Q330T,
                                     args = (items, xmlfile))
                t.start()


    def saveXMLCFG2Q330T(self, items, xmlfile):
        self.master.msgQueue.put("\nStart to save XML CFG into Q330(s).\n")
        handler = doParser(xmlfile)
        self.save2q.closeXML()

        self.master.lockQueue.put(1) # not lock yet
        for item in items:
            self.master.msgQueue.put("Try to save CFG XML to %s ..." % item[0])
            q330 = HCSQ330(serialNumber = eval('0x' + item[1]))
            
            InterfaceRes = q330.broadcastPhysicalInterfaces()
            #q330.realRegister()
            try:
                q330.realRegister()
                c1fix = q330.sendCommand(c1_rqfix()) #for advanced interfaces
                dataPortMemorySizes = []
                dataPortMemorySizes.append(c1fix.getDataPort1PacketMemorySize())
                dataPortMemorySizes.append(c1fix.getDataPort2PacketMemorySize())
                dataPortMemorySizes.append(c1fix.getDataPort3PacketMemorySize())
                dataPortMemorySizes.append(c1fix.getDataPort4PacketMemorySize())
                for i in range(len(handler.configs)):
                    config = handler.configs[i]
                    if config.getName() == 'Interfaces':
                        #keep MAC,...
                        c1sphy = c1_sphy(InterfaceRes.getPacketBytes())
                        config.setConfigCommand(c1sphy)
                        q330.sendCommand(config.getCommand())
                    elif config.getName() == 'Data':
                        #get the old data
                        c1rqlog = c1_rqlog()
                        c1rqlog.setDataPortNumber(config.getDataPortNumber())
                        c1log = q330.sendCommand(c1rqlog)
                        #set the new data and 'some' old data
                        c1slog = c1_slog(c1log.getPacketBytes())
                        config.setConfigCommand(c1slog)
                        q330.sendCommand(config.getCommand())
                    elif config.getName() == 'Global':
                        c1glob = q330.sendCommand(c1_rqglob())
                        c1sglob = c1_sglob(c1glob.getPacketBytes())
                        config.setConfigCommand(c1sglob)
                        q330.sendCommand(config.getCommand())
                    elif config.getName() == 'Sensor':
                        c1sc = q330.sendCommand(c1_rqsc())
                        c1ssc = c1_ssc(c1sc.getPacketBytes())
                        config.setConfigCommand(c1ssc)
                        q330.sendCommand(config.getCommand())
                    elif config.getName() == 'Slave': #stop here
                        pass
                        #c1spp = q330.sendCommand(c1_rqspp())
                        #c1sspp = c1_sspp(c1spp.getPacketBytes())
                        #config.setConfigCommand(c1sspp)
                        #q330.sendCommand(config.getCommand())
                    elif config.getName() == 'Advanced':
                        c2rqphy = c2_rqphy()
                        serNum = config.getSerial()
                        c2rqphy.setPhysicalInterfaceNumber(serNum)
                        c2phy = q330.sendCommand(c2rqphy)
                        c2sphy = c2_sphy2(c2phy.getPackageBytes())
                        if c2sphy.getDialOutPassword() == 0:
                            c2sphy.setDialOutPassword("")
                        if c2sphy.getDialInPassword() == 0:
                            c2sphy.setDialInPassword("")
                        config.setConfigCommand(c2sphy)
                        new_c2sphy = config.getCommand()
                        mtl = new_c2sphy.getMemoryTriggerLevel() #<trigger>mtl</trigger>
                        lognum = new_c2sphy.getDataPortNumber()

                        #The following is new to fix coupling problem
                        #get the total memory after this boot
                        totalsize = 0
                        for i in range(4):
                            totalsize += dataPortMemorySizes[i]

                        #now we get mem size from XML rather than from querying from q330
                        #adjust 0.2 here,e.g.from 60 to 60.2 to make solution look better
                        memsize = totalsize * (int(handler.percent4dataPorts[lognum])+0.2)/100.0
                        #The following is old
                        #memsize = dataPortMemorySizes[lognum]
                        
                        dpm = int(memsize)
                        mtl_size = int(dpm * mtl/100.0) # like 10M times 80%
                        new_c2sphy.setMemoryTriggerLevel(mtl_size)
                        q330.sendCommand(new_c2sphy)
                    elif config.getName() == 'gps':
                        c2gps = q330.sendCommand(c2_rqgps())
                        c2sgps = c2_sgps(c2gps.getPacketBytes())
                        config.setConfigCommand(c2sgps)
                        q330.sendCommand(config.getCommand())
                    elif config.getName() == 'pll':
                        #The same as 'gps' but not in Willard Config menu
                        pass
                    elif config.getName() == 'AutoMass':
                        c2amass = q330.sendCommand(c2_rqamass())
                        c2samass = c2_samass(c2amass.getPacketBytes())
                        config.setConfigCommand(c2samass)
                        q330.sendCommand(config.getCommand())
                    elif config.getName() == 'Announce':
                        try: # for old firmware without announce yet
                            c3annc = q330.sendCommand(c3_rqannc())
                            c3sannc = c3_sannc(c3annc.getPacketBytes())
                        except:
                            c3sannc = c3_sannc()
                            c3sannc.setC3_rqannc(2) #Why? by comparing with above try
                        config.setConfigCommand(c3sannc)
                        q330.sendCommand(config.getCommand())
                    else:
                        pass

                q330.saveToEEPROM()
                sleep(1)
                q330.reboot()
                sleep(2)                
                self.master.msgQueue.put(" done\n")
            except QDP_C1_CERR, e:
                print e
                self.master.msgQueue.put(" failed\n")
                q330.deregister()
        self.master.lockQueue.put(0)
        self.master.msgQueue.put("Save XML into Q330(s) successfully.\n")

    def fastSaveXML2Q330s(self):
        items = self.enum.getSelectedItems()
        if not items:
            tkMessageBox.showerror('Oops!',
                                   "You must select at least one Q330.")
        else:
            save2q = HCSXMLFrame(self)
            xmlfile = save2q.openXML()
            if xmlfile:
                self.fastXML = HCSFastXML2Q330s(self, items, xmlfile)
                self.fastXML.go()

    def cloneQ330(self):
        items = self.enum.getSelectedItems()
        if not items or len(items)>1:
            tkMessageBox.showerror('Oops!',
                                   "You must select one and only one Q330.")
        else:
            lst = HCSCloneList(self, items[0], self.enum.dictOfDASs.keys())

    def fastCloneQ330(self):
        items = self.enum.getSelectedItems()
        if not items or len(items)>1:
            tkMessageBox.showerror('Oops!',
                                   "You must select one and only one Q330.")
        else:
            self.lst = HCSCloneList(
                self, items[0], self.enum.dictOfDASs.keys(), 1)
    
    def updateFirmware(self):
        items = self.enum.getSelectedItems()
        if not items:
            tkMessageBox.showerror('Oops!',
                                   "You must select at least one Q330.")
        else:
            mod = HCSFirmwareInfoFrame(self)
            if len(mod.modules):
                self.firmware = HCSFirmwareFrame(self,items,mod.modules)

    def loadForPIS(self):
        items = self.enum.getSelectedItems()
        if not items:
            tkMessageBox.showerror('Oops!',
                                   "You must select at least one Q330.")
        else:
            self.items4pis = items
            self.getFirmwareVersion(pis = True)

    def saveToPIS(self):
        info = []
        for item in self.items4pis:
            if self.firmwareVers.has_key(item[0]):
                info.append((item[0],item[1],self.firmwareVers[item[0]]))
            else:
                info.append((item[0],item[1],""))
        self.displayFirmwareVersion()
        self.s2p = HCSSave2PISFrame(self, info)
        self.s2p.go()

    def displayPIS(self):
        successed, failed = self.s2p.getResults()
        self.master.msgQueue.put("%d Successed to PIS and %d Failed to PIS\n"
                                 % (len(successed),len(failed)))
        if len(failed):
            self.master.msgQueue.put("The following stations failed to be sent to PIS\n")
            for tag in failed: self.master.msgQueue.put("%s\n" % tag)
        else:
            tkMessageBox.showinfo("Network","Don't forget to switch back to local network.")


if __name__ == '__main__':
    root = Tk()
    root.title('Hocus' + ' - ' + 'v0.9')
    root.resizable(0, 0)
    mf = HCSMainFrame(root)
    root.mainloop()
