from isti.utils.GetSet import GetSet
from isti.utils.Bits import *
from Quasar.Cmds import *
from HCSMisc import *
from HCSTags import *

class HCSSaveXML(GetSet):
    def __init__(self, values = None): #values from parser
        self.values = values
        
    def setConfigCommand(self, cmd): # cmd like c3_sannc
        if self.values:
            for field in cmd.Fields:
                if self.values.has_key(field):
                    setFunction = cmd.getSetFunction(field)
                    setFunction(self.values[field])
        self.setCommand(cmd)


class HCSSaveInterfaces(HCSSaveXML):
    def __init__(self, values):
        HCSSaveXML.__init__(self, values)
        self.setName('Interfaces')

class HCSSaveDataPort(HCSSaveXML):
    def __init__(self, values):
        HCSSaveXML.__init__(self, values)
        self.setName('Data')
        self.setDataPortNumber(values['DataPortNumber'])

class HCSSaveGlobal(HCSSaveXML):
    def __init__(self, values):
        HCSSaveXML.__init__(self, values)
        self.setName('Global')

class HCSSaveSensor(HCSSaveXML):
    def __init__(self, values):
        HCSSaveXML.__init__(self, values)
        self.setName('Sensor')

class HCSSaveSlave(HCSSaveXML):
    def __init__(self, values):
        HCSSaveXML.__init__(self, values)
        self.setName('Slave')

class HCSSaveAdvanced(HCSSaveXML):
    def __init__(self, serNum,  values):
        HCSSaveXML.__init__(self, values)
        self.setName('Advanced')
        self.setSerial(serNum)

class HCSSaveGPSPLL(HCSSaveXML):
    def __init__(self, name, values):
        HCSSaveXML.__init__(self, values)
        self.setName(name) #GPS, or PLL

class HCSSaveAutoMass(HCSSaveXML):
    def __init__(self, values):
        HCSSaveXML.__init__(self, values)
        self.setName('AutoMass')

class HCSSaveAnnouncement(HCSSaveXML):
    def __init__(self, values):
        HCSSaveXML.__init__(self, values)
        self.setName('Announce')
