
from Quasar.QDPDevice import QDPDevice, QDP_C1_CERR

# get all the commands into the module namespace
from Quasar.Cmds import *
from Quasar import Tokens
from Quasar import Status
from Quasar.Tokens.TokenChunk import TokenChunk
from Quasar.Tokens.TokenSet import TokenSet
class Q330(QDPDevice):
    """
    An interface for talking to a Q330.

    This class extends the QDPDevice class to include methods that
    are specific to dealing with the Q330.
    """
    def __init__(self, serialNumber, IPAddress, basePort):
        QDPDevice.__init__(self)

        if type(serialNumber) == str:
            serialNumber = eval('0x%s' %serialNumber)
        self.setSerialNumber(serialNumber)
        self.setIPAddress(IPAddress)
        self.setBasePort(basePort)
        self.setRegistered(0)
        self.setAuthCode(0)
        self.setDeviceType("Q330")
        
    def register(self):
        """
        Register with a Q330.

        The authentication code must be set via setAuthCode() prior
        to registration, otherwize the default value of 0 (zero) will
        be used

        After a successful registration, a c1_cack command will be returned
        """
        regRequest = c1_rqsrv()
        regRequest.setSerialNumber(self.getSerialNumber())
        challenge = self.sendCommand(regRequest)
        response = c1_srvrsp()
        response.setSerialNumber(self.getSerialNumber())
        response.setChallengeValue(challenge.getChallengeValue())
        response.setServerIPAddress(challenge.getServerIPAddress())
        response.setServerUDPPort(challenge.getServerUDPPort())
        response.setRegistrationNumber(challenge.getRegistrationNumber())
        
        response.createDigest(self.getAuthCode())
        ret = self.sendCommand(response)
        self.setRegistered(1)
        return ret

    def deregister(self):
        """
        Deregister from the Q330

        After a successful deregistration, a c1_cack command will be returned
        """
        dereg = c1_dsrv()
        dereg.setSerialNumber(self.getSerialNumber())
        ret = self.sendCommand(dereg)
        self.setRegistered(0)
        return ret

    def ping(self):
        """
        Send a QDP ping to the Q330.  A successful ping will cause LEDs
        to become solid on the ping'd Q330's front panel

        A c1_ping reply packet will be returned
        """
        ping = c1_ping()
        ping.setType(0)
        pong = self.sendCommand(ping)
        return pong

    def getStatus(self, whichStatuses):
        """
        Get one or more statuses from the Q330

        This method takes a list of strings as an argument.  Each of these
        strings should match one of the elements of Status.StatusTypes.

        If only one status is desired, that status' name may be passed by
        itself, rather than in a list.

        A c1_stat packet is returned.  The data members included depends on
        which statuses were requested.
        """
        bitmap = Status.getBitmap(whichStatuses)
        rqstat = c1_rqstat()
        rqstat.setRequestBitmap(bitmap)
        return self.sendCommand(rqstat)

    def sendControlPacket(self, flags):
        """
        Send a c1_ctrl packet with the supplied flags.  The possible flags
        are listed in the Commands.c1_ctrl module.

        The reboot, saveToEEPROM, resync, turnOnGPS, turnOffGPS and coldStartGPS
        methods are supplied as a convenience so that sendControlPacket only
        needs to be called if several of these options need to be used at once.

        A c1_cack will be returned if successful.
        """
        ctl = c1_ctrl()
        ctl.setFlags(flags)
        return self.sendCommand(ctl)
    
    def reboot(self):
        """
        Reboot the Q330

        calls sendControlPacket with Commands.c1_ctrl.FLAGS_REBOOT

        A c1_cack is returned if successful
        """
        return self.sendControlPacket(FLAGS_REBOOT)

    def saveToEEPROM(self):
        """
        Save the current configuration to EEPROM

        calls sendControlPacket with Commands.c1_ctrl.FLAGS_SAVE_TO_EEPROM

        A c1_cack is returned if successful
        """
        return self.sendControlPacket(FLAGS_SAVE_TO_EEPROM)

    def resync(self):
        """
        Resync

        calls sendControlPacket with Commands.c1_ctrl.FLAGS_RESYNC

        A c1_cack is returned if successful
        """
        return self.sendControlPacket(FLAGS_RESYNC)

    def turnOnGPS(self):
        """
        Turn GPS on

        calls sendControlPacket with Commands.c1_ctrl.FLAGS_TURN_ON_GPS

        A c1_cack is returned if successful
        """
        return self.sendControlPacket(FLAGS_TURN_ON_GPS)

    def turnOffGPS(self):
        """
        Turn GPS off

        calls sendControlPacket with Commands.c1_ctrl.FLAGS_TURN_OFF_GPS

        A c1_cack is returned if successful
        """
        return self.sendControlPacket(FLAGS_TURN_OFF_GPS)

    def coldStartGPS(self):
        """
        Cold start GPS
        
        calls sendControlPacket with Commands.c1_ctrl.FLAGS_COLD_START_GPS

        A c1_cack is returned if successful
        """
        return self.sendControlPacket(FLAGS_COLD_START_GPS)

    ##
    # Get a tokenset for one of the 4 dataports
    ##
    def getTokenSet(self, whichSet):
        """
        Return a Tokens.TokenSet instance representing the dataport number
        supplied
        """
        chunks = []
        chunkSize = 448
        req = c1_rqmem()
        currentStartingAddress = 0
        req.setStartingAddress(currentStartingAddress)
        req.setByteCount(chunkSize)
        req.setMemoryType(whichSet)
        chunks.append( TokenChunk(self.sendCommand(req)) )
        while(chunks[-1].getSegmentNumber() < chunks[-1].getTotalNumberOfSegments()):
            req = c1_rqmem()
            currentStartingAddress += chunks[-1].getMemByteCount() + 6
            req.setStartingAddress(currentStartingAddress)
            req.setByteCount(chunkSize)
            req.setMemoryType(whichSet)

            mem = self.sendCommand(req)
            chunks.append( TokenChunk(mem) )

            
        thisTokenSet = TokenSet(chunks)

        return thisTokenSet

    ##
    # Inject a new tokenset into a dataport
    ##
    def setTokenSet(self, newSet, whichSet):
        newSet.rebuildChunks()
        chunks = newSet.getChunkList()
        for chunk in chunks:
            mem = chunk.c1_mem
            smem = c1_smem(mem.getPacketBytes())
            smem.setMemoryType(whichSet)
            self.sendCommand(smem)

            
            
        
        



