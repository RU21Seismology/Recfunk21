from Tkinter import *


import Tkinter
import tkFont
import time
import sys
import threading
import struct

from isti.utils.FunctionProxy import FunctionProxy
from isti.utils.GetSet import GetSet
from isti.utils.Logging import *
from isti.utils.Timer import Timer

from isti.gui.TkWidgets import *
import isti.utils.convertUtils

class BalerDisplay(MessageListener, Timer):

    def __init__(self, master, background=None, progressBarColor=None, progressBarDoneColor=None, progressBarErrorColor='red', guiRequestQueue=None):
        self.guiRequestQueue = guiRequestQueue
	if sys.platform != 'win32':	
	    self.font = tkFont.Font(family="MS Sans Serif", size=8)
	else:
	    self.font = tkFont.Font(family="MS Sans Serif", size=6)
        self.progressBarErrorColor = 'red'
        if not master['width']:
            master['width'] = 200

        self.canvas = Canvas(master, background=background, width=master['width'])
        self.canvas.grid()

        self.mainFrame = Frame(self.canvas, background=background, width=master['width'])
        self.mainFrame.grid()
        
        self.topFrame = Frame(self.mainFrame, background=background, width=master['width'])
        self.topFrame.grid(row=0, column=0, columnspan=2)

        self.bottomInfoFrame = Frame(self.mainFrame, background=background, width=master['width'])
        self.bottomInfoFrame.grid(row=2, column=0, columnspan=2)

        self.tagID = StringVar()
        self.tagIDLabel = Label(self.topFrame, background=background, textvar=self.tagID,
                                font=self.font, borderwidth=0)
        self.tagIDLabel.grid(row=0, column=0, sticky=W)

        self.macAddress = StringVar()
        self.macAddressLabel = Label(self.topFrame, background=background, textvar=self.macAddress,
                                       font=self.font, borderwidth=0)
        self.macAddressLabel.grid(row=0, column=1, sticky=W)

                               
        self.progressBar = ProgressBar(self.topFrame, background=background, barcolor=progressBarColor,
                                       width=int(master['width'])-50,height=10, donecolor=progressBarDoneColor, initialPercent=1, guiRequestQueue=self.guiRequestQueue)
        self.progressBar.grid(row=0, column=2)
        self.progressBar.update()


        self.stopwatch = StopWatchWithTotalTime(self.topFrame, background=background, font=self.font)
        self.stopwatch.grid(row=0, column=3)
        self.stopwatch.setPerTickCallback(self.updateDisplays)
        
        self.status = StringVar()
        self.statusLabel = Label(self.topFrame, background=background, textvar=self.status, font=self.font,
                                 borderwidth=0)
        self.statusLabel.grid(row=1, column=0, columnspan=4, sticky=E+W)


        self.softwareVersion = StringVar()
        self.softwareVersionLabel = Label(self.bottomInfoFrame, background=background, borderwidth=0,
                                          font=self.font, textvar=self.softwareVersion)
        self.softwareVersionLabel.grid(row=0, column=0, sticky=W)
        
        self.q330SerialNumber = StringVar()
        self.q330SerialNumberLabel = Label(self.bottomInfoFrame, background=background, borderwidth=0,
                                           font=self.font, textvar=self.q330SerialNumber)
        self.q330SerialNumberLabel.grid(row=0, column=1, sticky=E+W)

        self.ipAddress = StringVar()
        self.ipAddressLabel = Label(self.bottomInfoFrame, background=background, textvar=self.ipAddress,
                                    font=self.font, borderwidth=0)
        self.ipAddressLabel.grid(row=0, column=2, sticky=E)

        ##
        # Second row
        ##
        self.TxRx = StringVar()
        self.txRxLabel = Label(self.bottomInfoFrame, background=background, textvar=self.TxRx,
                                    font=self.font, borderwidth=0)
        self.txRxLabel.grid(row=1, column=0, sticky=E)

        self.averageBandwidth = StringVar()
        self.averageBandwidthLabel = Label(self.bottomInfoFrame, background=background, textvar=self.averageBandwidth,
                                           font=self.font, borderwidth=0)
        self.averageBandwidthLabel.grid(row=1, column=1, sticky=E)

        self.thisTransferSize = StringVar()
        self.thisTransferSizeLabel = Label(self.bottomInfoFrame, background=background, textvar=self.thisTransferSize,
                                           font=self.font, borderwidth=0)
        self.thisTransferSizeLabel.grid(row=1, column=2, sticky=E)
        
        self.unused = 1

        self.targetPercentage = None
        self.clearButton = None
        self.logButton = None
        self.stopButton = None
        self.clearButtonPreviousState = -99

        self.clear()

        self.Baler = None
        self.checkpoints = []
        self.numSecondsForAverageSpeed = 5
        self.bytesSentAtLastClockReset = 0
        self.bytesReceivedAtLastClockReset = 0
        self.smoothingAlpha = .1
        
    def setClearButton(self, btn):
        self.clearButton = btn

    def setLogButton(self, btn):
        self.logButton = btn

    def setStopButton(self, btn):
        self.stopButton = btn
        
    def enableLogButton(self):
        if self.logButton:
            self.logButton['state'] = NORMAL

    def disableLogButton(self):
        if self.logButton:
            self.logButton['state'] = DISABLED

    def disableStopButton(self):
        if self.stopButton:
            self.stopButton['state'] = DISABLED

    def enableStopButton(self):
        if self.stopButton:
            self.stopButton['state'] = NORMAL

    def setGuiRequestQueue(self, rq):
        self.guiRequestQueue = rq
        self.progressBar.setGuiRequestQueue(rq)
        self.stopwatch.setGuiRequestQueue(rq)
        
    def clear(self):
        self.bytesSentAtLastClockReset = 0
        self.bytesReceivedAtLastClockReset = 0
        self.setStatus("    ")
        self.setTagID("    ")
        self.setMACAddress("                 ")
        self.setQ330SerialNumber("    ")
        self.setSoftwareVersion("                ")
        self.setIPAddress("               ")
        self.setTxRx("           ")
        self.setThisTransferSize(0)
        self.setAverageBandwidth("                    ")
        self.unlockProgressBarColor()
        self.updateProgressBar(1)
        self.reset()
        self.stopwatch.clear()
        self.unused = 1
        #self.Baler = None
        self.receivedError = 0
        self.checkpoints = []
        self.smoothedAverageRate = None
        if self.clearButton and self.clearButtonPreviousState != -99:
            self.clearButton['state'] = self.clearButtonPreviousState
            self.clearButtonPreviousState = -99
            
    def setProgressBarTarget(self, percentage):
        self.targetPercentage = percentage

    def setProgressBarTargetReached(self):
        self.targetPercentage = None
        
    def isUnused(self):
        return self.unused
    
    def grid(self, **kwargs):
        self.canvas.grid(kwargs)

    def __del__(self):
        self.destroy()
        
    def destroy(self):
        self.canvas.destroy()
        self.topFrame.destroy()
        self.mainFrame.destroy()
        self.progressBar.destroy()
        self.stopwatch.destroy()
        self.statusLabel.destroy()
        self.ipAddressLabel.destroy()
        self.tagIDLabel.destroy()
        self.macAddressLabel.destroy()
        self.softwareVersionLabel.destroy()
        self.q330SerialNumberLabel.destroy()
        self.txRxLabel.destroy()
        self.averageBandwidthLabel.destroy()
        
    def setBalerInfoFromBaler(self, baler, queueRequestIfPossible=True):
        self.Baler = baler
        if self.guiRequestQueue and queueRequestIfPossible:
            self.guiRequestQueue.enqueueRequest(self.internal_setBalerInfoFromBaler, ())
        else:
            self.internal_setBalerInfoFromBaler()

        self.unused = 0

    def updateBalerInfoFromBaler(self, queueRequestIfPossible=True):
        if self.guiRequestQueue and queueRequestIfPossible:
            if self.Baler:
                balerInfo = self.Baler.getGeneralInfo()
                stationInfo = self.Baler.getStationInfo()
            else:
                balerInfo = None
                stationInfo = None
            self.guiRequestQueue.enqueueRequest(self.internal_setBalerInfoFromBaler, (True, balerInfo, stationInfo))
        else:
            self.internal_setBalerInfoFromBaler(True)
        
    def internal_setBalerInfoFromBaler(self, remoteBalerReachable=False, balerInfo=None, stationInfo=None):
        baler = self.Baler

        if self.Baler.getViaStation():
            # this baler may or may not be connected, may or may not have anything other than web access
            thisStation = self.Baler.getStation()
            self.setIPAddress('%s:%s' % (thisStation.getConfigItem('Station.DP4.IPAddress'),
                                         thisStation.getConfigItem('Station.DP4.BasePort')))
            self.updateTxRx()
            self.setTagID(self.Baler.getDisplayName())
            if remoteBalerReachable:
                if not balerInfo:
                    balerInfo = baler.getGeneralInfo()
                if not stationInfo:
                    stationInfo = baler.getStationInfo()
                self.setMACAddress(balerInfo['MAC Address'])
                self.setTagID('%s:%s' %(self.Baler.getDisplayName(), balerInfo['Baler TAGID']))
                self.setSoftwareVersion(balerInfo['SoftwareVersion'])
                self.setQ330SerialNumber(stationInfo['Q330Serial'])
        else:
            self.setIPAddress(baler.getIPAddress())
            self.setSoftwareVersion(baler.getVersionString())
            tagID = baler.getTagID()
            balertype = baler.getBalerType()
            tagID = '%s%s' %(balertype[0], tagID)
            self.setTagID(tagID)
            swappedSN = baler.getBalerSerialNumber() 
            swapped330SN = struct.unpack('>Q', struct.pack('<Q', baler.getQ330SerialNumber()))[0]
            self.setQ330SerialNumber(swapped330SN)
            self.updateTxRx();
            balerInfo = baler.getGeneralInfo()
            self.setMACAddress(balerInfo['MAC Address'])

    def getBaler(self):
        return self.Baler

    def setBaler(self, baler):
        self.Baler = baler
        
    def setIPAddress(self, ip):
        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.ipAddress.set, ('IP: %s' %ip, ))
        else:
            self.ipAddress.set("IP:%s     " %ip)

    def setTxRx(self, str):
        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.TxRx.set, ('Tx/Rx: %s   ' %str, ))
        else:
            self.TxRx.set('Tx/Rx: %s   ' %str)

    def setAverageBandwidth(self, str):
        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.averageBandwidth.set, ('Ave (short | long): %s' %str, ))
        else:
            self.averageBandwidth.set('Ave (short | long): %s' %str)

    def setThisTransferSize(self, numBytes=0):
        self.totalBytesToTransfer = numBytes
        if numBytes == 0:
            str = 'Size:   '
        else:
            str = 'Size: %s' %isti.utils.convertUtils.formatBytes(numBytes)

        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.thisTransferSize.set, (str, ))
        else:
            self.thisTransferSize.set(str)
            
    def getThisTransferSize(self):
        return self.totalBytesToTransfer
    
    def updateDisplays(self):
        self.updateTxRx()
        self.updateAverageBandwidth()
        self.updateProgressBarBasedOnTransfer()

    def updateProgressBarBasedOnTransfer(self):
        if (not self.targetPercentage) or (not self.totalBytesToTransfer) or (not self.Baler.getBytesReceived()) :
            return

        
        # first, lets figure out the percentage done that we are
        totalBytes = self.totalBytesToTransfer
        totalBytesAlready = self.Baler.getBytesReceived()
        percentage = (float(totalBytesAlready) / float(totalBytes)) * 100.0
        
        newPercentage = int((percentage / 100.0) * self.targetPercentage)

        if newPercentage > self.targetPercentage:
            newPercentage = self.targetPercentage
            
        self.updateProgressBar(newPercentage)
        
    def updateTxRx(self):
        
        if not self.Baler:
            return
        
        self.setTxRx("%s/%s" %( isti.utils.convertUtils.formatBytes(self.Baler.getBytesSent()),
                                isti.utils.convertUtils.formatBytes(self.Baler.getBytesReceived()) ) )

    def updateAverageBandwidth(self):
        if not self.Baler:
            return
        #bytesReceived = self.Baler.getBytesReceived()
        #totalTime = time.time() - self.stopwatch.getTotalStartTime()

        #if totalTime < 1:
        #    return
        #bps = bytesReceived / totalTime

        #bpsString = '%s/s' %formatBytes(bps, bias='K')
        #self.setAverageBandwidth(bpsString)

        totalSentBytes = self.Baler.getBytesSent()
        totalReceivedBytes = self.Baler.getBytesReceived()

        totalBytes = max(totalSentBytes, totalReceivedBytes)

        ##
        # Transfer Average
        ##
        transferTime = time.time() - self.stopwatch.getStartTime()
        if self.bytesSentAtLastClockReset == 0 or self.bytesReceivedAtLastClockReset == 0:
            self.bytesSentAtLastClockReset = totalSentBytes
            self.bytesReceivedAtLastClockReset = totalReceivedBytes
            transferBPSString = '%s/s' %(isti.utils.convertUtils.formatBytes(0, bias='K'))
        else:
            if totalBytes == totalSentBytes:
                bps = (totalBytes - self.bytesSentAtLastClockReset) / transferTime
            else:
                bps = (totalBytes - self.bytesReceivedAtLastClockReset) / transferTime
            transferBPSString = '%s/s' %(isti.utils.convertUtils.formatBytes(bps, bias='K'))
                
        ##
        # Rolling average
        ##
            
        # Create this checkpoint
        totalTime = time.time() - self.stopwatch.getTotalStartTime()
        
        thisCheckpoint = (totalTime, totalBytes)
        

        # Some housekeeping on the checkpoints we've saved
        if len(self.checkpoints) == self.numSecondsForAverageSpeed:
            self.checkpoints = self.checkpoints[1:]
        self.checkpoints.append(thisCheckpoint)

        totalBytes = self.checkpoints[-1][1] - self.checkpoints[0][1]
        timeSpent = self.checkpoints[-1][0] - self.checkpoints[0][0]

        if timeSpent < 1:
            return
        
        bps = totalBytes / timeSpent

        if not self.smoothedAverageRate:
            self.smoothedAverageRate = bps
        else:
            self.smoothedAverageRate = ((1 - self.smoothingAlpha) * self.smoothedAverageRate) + (self.smoothingAlpha * bps)

        rollingBPSString = '%s/s' %isti.utils.convertUtils.formatBytes(self.smoothedAverageRate, bias='K')
        
        self.setAverageBandwidth('%s | %s' %(rollingBPSString, transferBPSString))
        
    #def updateCurrentTransferSize(self):
    #    if not self.Baler:
    #        return
    #    self.setThisTransferSize(self.Baler.getCurrentTransferSize())
        
    def addMessage(self, msg, msgClass=MSG):
        if msgClass == ERR:
            if self.clearButton:
                try:
                    self.clearButtonPreviousState = self.clearButton['state']
                    self.clearButton['state'] = NORMAL
                except:
                    pass
            self.setAndLockProgressBarColor(self.progressBarErrorColor)
            self.receivedError = 1
        if type(msg) == type('asdf'):
            self.setStatus(msg)
        if isinstance(msg, LogMessage):
            self.setStatus(msg.getMessage())
            
    def setStatus(self, newstatus):
        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.status.set, (newstatus, ))
        else:
            self.status.set(newstatus)
        
    def setTagID(self, newtag):
        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.tagID.set, ('%s / ' %newtag, ))
        else:
            self.tagID.set('%s / ' %newtag)
        
    def setMACAddress(self, mac):
        if type(mac) == type('asdfadsf'):
            s = '%s ' %mac
        else:
            s ='%x ' %mac

        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.macAddress.set, (s, ))
        else:
            self.macAddress.set(s)
            
    def hadError(self):
        return self.receivedError
    
    def setQ330SerialNumber(self, serial):
        if serial in ('0', None, 0):
            serial = 'None'
            
        if type(serial) == type('asdfadsf'):
            s = 'Q330:%s     ' %serial
        else:
            s = 'Q330:%x     ' %serial

        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.q330SerialNumber.set, (s, ))
        else:
            self.q330SerialNumber.set(s)
            
    def setSoftwareVersion(self, rev):
        s = 'Software:%s     ' %rev
        
        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.softwareVersion.set, (s, ))
        else:
            self.softwareVersion.set(s)
        
    
    def start(self):
        self.bytesSentAtLastClockReset = 0
        self.bytesReceivedAtLastClockReset = 0
        self.stopwatch.start()

    def stop(self):
        self.stopwatch.stop()

    def reset(self):
        self.bytesSentAtLastClockReset = 0
        self.bytesReceivedAtLastClockReset = 0
        self.stopwatch.reset()

    def restart(self):
        self.bytesSentAtLastClockReset = 0
        self.bytesReceivedAtLastClockReset = 0
        self.stopwatch.restart()

    def updateProgressBar(self, newval):
        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.progressBar.update, (newval, ))
        else:
            self.progressBar.update(newval)

    def increaseProgressBar(self, increaseBy):
        #self.progressBar.update(increaseBy + self.progressBar.getProgress())
        self.updateProgressBar(increaseBy + self.progressBar.getProgress())

    def setAndLockProgressBarColor(self, color):
        self.setProgressBarColor(color)
        self.lockProgressBarColor()

    def setProgressBarColor(self, color):
        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.progressBar.setColor, (color, ))
        else:
            self.progressBar.setColor(color)
        
    def setProgressBarBackgroundColor(self, color):
        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.progressBar.setBackgroundColor, (color, ))
        else:
            self.progressBar.setBackgroundColor(color)
        
    def lockProgressBarColor(self):
        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.progressBar.lockColor, ())
        else:
            self.progressBar.lockColor()

    def unlockProgressBarColor(self):
        if self.guiRequestQueue:
            self.guiRequestQueue.enqueueRequest(self.progressBar.unlockColor, ())
        else:
            self.progressBar.unlockColor()

    def getProgressBarValue(self):
        return self.progressBar.getProgress()


