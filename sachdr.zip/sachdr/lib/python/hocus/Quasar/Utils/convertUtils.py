import time
import string

def makeEpochTime(timeStr):
    """
    Take a time in the form of yyyy-mm-dd hh:mm:ss and convert to epoch time
     """
    datePart, timePart = string.split(string.strip(timeStr))
    year, month, day = string.split(datePart, '-')
    hour, minute, second = string.split(timePart, ':')
    
    timeTup = (int(year), int(month), int(day), int(hour), int(minute), int(second), 0, 0, -1)
    return time.mktime(timeTup)