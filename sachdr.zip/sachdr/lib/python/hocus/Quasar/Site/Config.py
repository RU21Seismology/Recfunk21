"""
Utilities and classes related to sitewide configuration
"""

from Quasar.Q330 import Q330, QDP_C1_CERR
from Quasar.Commands.c1_pollsn import c1_pollsn
from Quasar.Commands.c1_rqphy import c1_rqphy
from isti.utils import ConfigFile

from Quasar import CmdID
import time
import copy

def discover(defaultAuthCode=0, authCodeMap={}, receiveTimeout=20):
    """
    discover all Q330s reachable, and build a site configuration

    defaultAuthCode can be passed in to define a default authentication
    code for all registration attempts.  This defaults to zero.

    authCodeMap is a Python dict type, that maps either a Q330's tag or it's
    serial number to an auth code.  This can be used for exceptions to
    the default.
    """

    q330 = Q330(0, '255.255.255.255', 5330)
    q330.setReceiveTimeout(receiveTimeout)
    mysnResponses = q330.sendCommand(c1_pollsn(), receiveMultiple=1)

    c = Config()

    for response in mysnResponses:
        # 10.172.53.1  if on serial1
        # 10.172.53.2  if on serial2
        # 10.172.53.3  if on serial3 (console)
        # 10.172.53.4  if on ethernet
        ip, port = response.getSourceIPAddressInfo()
        tag = response.getKMIPropertyTag()
        serial = response.getSerialNumber()


        if ip in ('10.172.53.1', '10.172.53.2', '10.172.53.3', '10.172.53.4'):
            # this is an "old style" broadcast response, we need to do some work
            # to determine the usable IP
            authcode = defaultAuthCode
            if tag in authCodeMap.keys():
                authcode = authCodeMap[tag]
            elif '%s' %tag in authCodeMap.keys():
                authcode = authCodeMap['%s' %tag]
            elif serial in authCodeMap.keys():
                authcode = authCodeMap[serial]
            elif '%s' %serial in authCodeMap.keys():
                authcode = authCodeMap['%s' %serial]

            q330.setSerialNumber(serial)
            q330.setAuthCode(authcode)
            q330.setBasePort(65535)
            q330.register()

            rqphy = c1_rqphy()
            phyResponses = q330.sendCommand(rqphy, receiveMultiple=1)
            phy = None
            for phyResponse in phyResponses:
                if phyResponse.getQDPCommand() == CmdID.C1_PHY and serial == phyResponse.getSerialNumber():
                    phy = phyResponse

            if phy:
                if ip == '10.172.53.1':
                    ip = phy.strSerialInterface1IPAddress()
                elif ip == '10.172.53.2':
                    ip = phy.strSerialInterface1IPAddress()
                elif ip == '10.172.53.3':
                    ip = phy.strSerialInterface3IPAddress()
                elif ip == '10.172.53.4':
                    ip = phy.strEthernetIPAddress()
                q330.setIPAddress(ip)
                q330.setBasePort(phy.getBasePort())

            try:
                q330.deregister()
            except:
                pass

            q330.setSerialNumber(0)
            q330.setIPAddress('255.255.255.255')
            
        c.addDevice(response.getKMIPropertyTag(), response.getSerialNumber(), ip, port)

    return c

class Config:
    """
    A class representing a sitewide configuration
    """

    def __init__(self, configFileName=None):
        if configFileName != None:
            cfg = ConfigFile.ConfigFile(configFileName)
            self.DeviceMap = cfg._configuration
        else:
            self.DeviceMap = {'Q330' : {}}
        
    def addDevice(self, tagNumber, serialNumber, ipAddress, port):
        self.DeviceMap['Q330']['%s' %tagNumber] = {
            'Serial' : '%x' %serialNumber,
            'IP' : ipAddress,
            'BasePort' : port
            }

    def getDeviceMap(self):
        """
        return a copy of the internal device map
        """
        return copy.deepcopy(self.DeviceMap['Q330'])
    
    def getDeviceInfoByTag(self, tag):
        for key in self.DeviceMap['Q330'].keys():
            if key in (tag, '%s' %tag):
                return self.DeviceMap['Q330'][key]

    def getDeviceInfoByIP(self, ip):
        return self.searchForDevice('IP', ip)

    def getDeviceInfoBySerial(self, rawSerial):
        serial = rawSerial
        if type(serial) == type(1L):
            serial = '%x' %serial
        return self.searchForDevice('Serial', serial)

    def searchForDevice(self, searchBy, searchFor):
        for key in self.DeviceMap['Q330']:
            device = self.DeviceMap['Q330'][key]
            if device[searchBy] in (searchFor, '%s' %searchFor):
                return device

    def writeToFile(self, filename):
        str = ConfigFile.configDictToString(self.DeviceMap)
        outfile = open(filename, 'w')
        outfile.write(str)
        outfile.close()
        
    def __repr__(self):
        return self.DeviceMap.__repr__()
    
