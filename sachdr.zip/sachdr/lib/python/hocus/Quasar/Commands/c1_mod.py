from Quasar.QDPPacket import QDPPacket
from Quasar import CmdID
from Quasar import Structs
from isti.utils import structWrapper



class c1_mod(QDPPacket):
    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_MOD)
        self.Fields = []
        self.FieldDefinition = '>'

        if bytes:
            numModules = (len(bytes) - 12) / structWrapper.calcsize(Structs.mod)
            for i in range(1, numModules+1):
                self.Fields.append('ModuleName_%d' %i)
                self.Fields.append('Revision_%d' %i)
                self.Fields.append('OverlayNumber_%d' %i)
                self.Fields.append('ModuleCRC_%d' %i)
                self.FieldDefinition = self.FieldDefinition + Structs.mod[1:]
        QDPPacket.__init__(self, bytes)
