from Quasar.Commands.c2_poc import c2_poc
from Quasar import CmdID
from Quasar import Structs
import sys

class c2_vack(c2_poc):
    def __init__(self, bytes=None):
        c2_poc.__init__(self, bytes)
        self.setQDPCommand(CmdID.C2_VACK)
	if sys.byteorder == 'little':
	    self.FieldDefinition = Structs.a_ack_le
	else:
	    self.FieldDefinition = Structs.a_ack_be

