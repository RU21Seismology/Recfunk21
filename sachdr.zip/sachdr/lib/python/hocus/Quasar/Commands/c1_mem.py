from Quasar.Commands.c1_smem import c1_smem
from Quasar import CmdID

class c1_mem(c1_smem):
    def __init__(self, bytes=None):
        c1_smem.__init__(self, bytes)
        self.setQDPCommand(CmdID.C1_MEM)
        
        


