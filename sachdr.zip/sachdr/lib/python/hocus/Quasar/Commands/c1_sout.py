from Quasar.QDPPacket import QDPPacket

from Quasar import Structs
from Quasar import CmdID

class c1_sout(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_SOUT)
        self.Fields = [
            'NewBitmap'
            ]
        self.FieldDefinition = Structs.sout
        QDPPacket.__init__(self, bytes)
