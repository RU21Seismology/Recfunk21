from Quasar.QDPPacket import QDPPacket

from Quasar import CmdID
from Quasar import Structs

class c1_mrt(QDPPacket):
    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_MRT)
        self.Fields = [
            'IPAddress',
            'NewPhysicalInterface',
            'NewDataPort'
            ]
        self.FieldDefinition = Structs.mrt
        QDPPacket.__init__(self, bytes)
