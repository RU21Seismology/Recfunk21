from Quasar.QDPPacket import QDPPacket
from Quasar import Structs
from Quasar import CmdID

class c2_sgps(QDPPacket):
    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C2_SGPS)
        self.Fields = [
            'TimingMode',
            'PowerCyclingMode',
            'GPSOffTime',
            'GPSResyncHour',
            'GPSMaximumOnTime',
            'PLLLockUSecs',
            'Spare1',
            'PLLUpdateIntervalInSeconds',
            'PLLFlags',
            'Pfrac',
            'VCOSlope',
            'VCOIntercept',
            'MaxInitialKMRMS',
            'InitialKMWeight',
            'BestVCOWeight',
            'KMDelta',
            'Spare2',
            'Spare3'
            ]
        self.FieldDefinition = Structs.a_gps
        QDPPacket.__init__(self, bytes)
        
            
