from Quasar.QDPPacket import QDPPacket
from Quasar import CmdID
from Quasar import Structs


class c2_samass(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C2_SAMASS)
        self.Fields = [
            'Tolerance1A',
            'Tolerance1B',
            'Tolerance1C',
            'MaximumTries1',
            'NormalInterval1',
            'SquelchInterval1',
            'SensorControlBitmap1',
            'Duration1',
            'Tolerance2A',
            'Tolerance2B',
            'Tolerance2C',
            'MaximumTries2',
            'NormalInterval2',
            'SquelchInterval2',
            'SensorControlBitmap2',
            'Duration2'
            ]
        self.FieldDefinition = Structs.a_amass
        QDPPacket.__init__(self, bytes)
            
