from Quasar.QDPPacket import QDPPacket
from Quasar import Structs
from Quasar import CmdID
from isti.utils.Bits import *

class c1_fix(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_FIX)
        self.Fields = [
            'TimeOfLastReboot',
            'TotalNumberOfReboots',
            'BackupDataStructureBitmap',
            'DefaultDataStructureBitmap',
            'CalibratorType',
            'CalibratorVersion',
            'AuxType',
            'AuxVersion',
            'ClockType',
            'EthernetInstalled',
            'SystemVersion',
            'SlaveProcessorVersion',
            'PLDVersion',
            'MemoryBlockSize',
            'KMIPropertyTag',
            'SystemSerialNumber',
            'AnalogMotherBoardSerialNumber',
            'Seismometer1SerialNumber',
            'Seismometer2SerialNumber',
            'QAPCHP1SerialNumber',
            'InternalDataMemorySize',
            'InternalDataMemoryUsed',
            'ExternalDataMemorySize',
            'FlashMemorySize',
            'ExternalDataMemoryUsed',
            'QAPCHP2SerialNumber',
            'DataPort1PacketMemorySize',
            'DataPort2PacketMemorySize',
            'DataPort3PacketMemorySize',
            'DataPort4PacketMemorySize',
            'Bit7Frequency',
            'Bit6Frequency',
            'Bit5Frequency',
            'Bit4Frequency',
            'Bit3Frequency',
            'Bit2Frequency',
            'Bit1Frequency',
            'Bit0Frequency',
            'Channels1To3Bit7FrequencyDelayInUSec',
            'Channels1To3Bit6FrequencyDelayInUSec',
            'Channels1To3Bit5FrequencyDelayInUSec',
            'Channels1To3Bit4FrequencyDelayInUSec',
            'Channels1To3Bit3FrequencyDelayInUSec',
            'Channels1To3Bit2FrequencyDelayInUSec',
            'Channels1To3Bit1FrequencyDelayInUSec',
            'Channels1To3Bit0FrequencyDelayInUSec',
            'Channels4To6Bit7FrequencyDelayInUSec',
            'Channels4To6Bit6FrequencyDelayInUSec',
            'Channels4To6Bit5FrequencyDelayInUSec',
            'Channels4To6Bit4FrequencyDelayInUSec',
            'Channels4To6Bit3FrequencyDelayInUSec',
            'Channels4To6Bit2FrequencyDelayInUSec',
            'Channels4To6Bit1FrequencyDelayInUSec',
            'Channels4To6Bit0FrequencyDelayInUSec',
            ]
        self.FieldDefinition = Structs.fix
        QDPPacket.__init__(self, bytes)

    def strClockType(self):
        if self.getClockType() == 0:
            return 'No clock'
        if self.getClockType() == 1:
            return 'Motorola M12'
        return 'Unknown clock type'

    def strCalibratorType(self):
        if self.getCalibratorType() == 33:
            return 'QCal330'
        return 'Unknown calibrator type'

    def strCalibratorVersion(self):
        return self.getVersionString(self.getCalibratorVersion())

    def strAuxVersion(self):
        return self.getVersionString(self.getAuxVersion())

    def strSystemVersion(self):
        return self.getVersionString(self.getSystemVersion())

    def strSlaveProcessorVersion(self):
        return self.getVersionString(self.getSlaveProcessorVersion())

    def strPLDVersion(self):
        return self.getVersionString(self.getPLDVersion())
    
    def strBit7Frequency(self):
        return self.getFrequencyString(self.getBit7Frequency())

    def strBit6Frequency(self):
        return self.getFrequencyString(self.getBit6Frequency())

    def strBit5Frequency(self):
        return self.getFrequencyString(self.getBit5Frequency())

    def strBit4Frequency(self):
        return self.getFrequencyString(self.getBit4Frequency())

    def strBit3Frequency(self):
        return self.getFrequencyString(self.getBit3Frequency())

    def strBit2Frequency(self):
        return self.getFrequencyString(self.getBit2Frequency())

    def strBit1Frequency(self):
        return self.getFrequencyString(self.getBit1Frequency())

    def strBit0Frequency(self):
        return self.getFrequencyString(self.getBit0Frequency())

    def getVersionString(self, val):
        return '%d.%d' %(val/256, val%256)
        
    def getFrequencyString(self, val):
        if val == 255:
            return '0.1Hz'
        if val & BIT7:
            # MS bit is set, look at the low order 4 bits
            maskedVal = val & (BIT0 | BIT1 | BIT2 | BIT3)
            freqs = [
                'Unknown',
                'Unknown',
                'Unknown',
                'Unknown',
                '200Hz',
                '250Hz',
                '300Hz',
                '400Hz',
                '500Hz',
                '800Hz',
                '1000Hz'
                ]
            return freqs[maskedVal]
        else:
            return '%sHz' %val
            
