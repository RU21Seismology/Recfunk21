from Quasar.QDPPacket import QDPPacket
from Quasar import Structs
from Quasar import CmdID

class c1_vco(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_VCO)
        self.Fields = [
            'NewCurrentVCOValue',
            'PLLFlag'
            ]
        self.FieldDefinition = Structs.vco
        QDPPacket.__init__(self, bytes)
