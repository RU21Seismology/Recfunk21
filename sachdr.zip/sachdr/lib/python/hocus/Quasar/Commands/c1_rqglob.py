from Quasar.QDPPacket import QDPPacket
from Quasar import CmdID
from Quasar import Structs

class c1_rqglob(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_RQGLOB)
        self.Fields = []
        self.FieldDefinition = ''
        QDPPacket.__init__(self, bytes)
