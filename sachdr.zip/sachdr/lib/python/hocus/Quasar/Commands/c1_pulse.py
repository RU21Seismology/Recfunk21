from Quasar.QDPPacket import QDPPacket
from Quasar import Structs
from Quasar import CmdID


class c1_pulse(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_PULSE)
        self.Fields = [
            'SensorControlBitmap',
            'Duration'
            ]
        self.FieldDefinition = Structs.pulse
        QDPPacket.__init__(self, bytes)
