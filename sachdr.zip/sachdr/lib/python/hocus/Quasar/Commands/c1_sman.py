from Quasar.QDPPacket import QDPPacket
from Quasar import CmdID
from Quasar import Structs
import string

from isti.utils.Bits import *


class c1_sman(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_SMAN)
        self.Fields = [
            'PasswordHigh32',
            'PasswordMidHigh32',
            'PasswordMidLow32',
            'PassowrdLow32',
            'QAPCHP1To3Type',
            'QAPCHP1To3Version',
            'QAPCHP4To6Type',
            'QAPCHP4To6Version',
            'QAPCHP1To3SerialNumber',
            'QAPCHP4To6SerialNumber',
            'QAPCHPChannel1ExpectedCountsWithReferenceApplied',
            'QAPCHPChannel2ExpectedCountsWithReferenceApplied',
            'QAPCHPChannel3ExpectedCountsWithReferenceApplied',
            'QAPCHPChannel4ExpectedCountsWithReferenceApplied',
            'QAPCHPChannel5ExpectedCountsWithReferenceApplied',
            'QAPCHPChannel6ExpectedCountsWithReferenceApplied',
            'BornOnTime',
            'PacketMemoryInstalledInBytes',
            'ClockType',
            'ModelNumber',
            'DefaultCalibratorOffset',
            'Flags',
            'KMIPropertyTag',
            'MaximumPowerOnSeconds'
            ]
        self.FieldDefinition = Structs.man
        QDPPacket.__init__(self, bytes)

    def strClockType(self):
        if self.getClockType() == 0:
            return 'No clock'
        if self.getClockType() == 1:
            return 'Motorola M12'
        return 'Unknown clock type'

    def strFlags(self):
        flags = self.getFlags()
        ret = ['']
        if flags & BIT0:
            ret.append('Clear internal counters')

        val = flags >> 8
        ret.append('Power supply voltage: %f' %(5.45 + (val*.05)))
        return string.join(ret, '\n      ')
                   
