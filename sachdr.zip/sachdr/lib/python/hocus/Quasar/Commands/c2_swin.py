from Quasar.QDPPacket import QDPPacket
from Quasar import Structs
from Quasar import CmdID
from isti.utils import structWrapper
class c2_swin(QDPPacket):
    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C2_SWIN)
        self.Fields = [
            'RecordingFlags',
            'NumberOfWindows',
            ]
        self.FieldDefinition = Structs.a_win
        if bytes:
            numWindows = structWrapper.unpack(">H", bytes[14:16])[0]
            for i in range(1, numWindows+1):
                self.Fields.append('StartRecordingTime_%d' %i)
                self.Fields.append('StopRecordingTime_%d' %i)
                self.FieldDefinition = self.FieldDefinition + Structs.a_window[1:]

        QDPPacket.__init__(self, bytes)
                                                                                            
