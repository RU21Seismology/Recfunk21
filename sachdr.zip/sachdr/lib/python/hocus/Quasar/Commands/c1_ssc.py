from Quasar.QDPPacket import QDPPacket

from Quasar import Structs
from Quasar import CmdID
from isti.utils.Bits import *

class c1_ssc(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_SSC)
        self.Fields = [
            'SensorOutput1Definition',
            'SensorOutput2Definition',
            'SensorOutput3Definition',
            'SensorOutput4Definition',
            'SensorOutput5Definition',
            'SensorOutput6Definition',
            'SensorOutput7Definition',
            'SensorOutput8Definition'
            ]
        self.FieldDefinition = Structs.sc
        QDPPacket.__init__(self, bytes)

    def strSensorOutput1Definition(self):
        return self.getSensorOutputString(self.getSensorOutput1Definition())
    def strSensorOutput2Definition(self):
        return self.getSensorOutputString(self.getSensorOutput2Definition())
    def strSensorOutput3Definition(self):
        return self.getSensorOutputString(self.getSensorOutput3Definition())
    def strSensorOutput4Definition(self):
        return self.getSensorOutputString(self.getSensorOutput4Definition())
    def strSensorOutput5Definition(self):
        return self.getSensorOutputString(self.getSensorOutput5Definition())
    def strSensorOutput6Definition(self):
        return self.getSensorOutputString(self.getSensorOutput6Definition())
    def strSensorOutput7Definition(self):
        return self.getSensorOutputString(self.getSensorOutput7Definition())
    def strSensorOutput8Definition(self):
        return self.getSensorOutputString(self.getSensorOutput8Definition())
    
    def getSensorOutputString(self, outputDef):
        v = outputDef & (BIT0 | BIT1 | BIT2 | BIT3 | BIT4 | BIT5 | BIT6 | BIT7)
        bit8 = outputDef & BIT8
        values = [
            'Not doing calibration or recentering',
            'Sensor A calibration',
            'Sensor A centering',
            'Sensor A capacitive coupling',
            'Sensor B calibration',
            'Sensor B centering',
            'Sensor B capacitive coupling',
            'Sensor A lock',
            'Sensor A unlock',
            'Sensor A aux1',
            'Sensor A aux2',
            'Sensor B lock',
            'Sensor B unlock',
            'Sensor B aux1',
            'Sensor B aux2'
            ]
        if bit8 == 1:
            highLow = 'active high'
        else:
            highLow = 'active low'
        return '%s (%s)' %(values[v], highLow)
