from Quasar.QDPPacket import QDPPacket
from Quasar import Structs
from Quasar import CmdID

class c2_sbpwr(QDPPacket):
    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C2_SBPWR)
        self.Fields = [
            'PhysicalInterface',
            'FlagAndTimeout'
            ]
        self.FieldDefinition = Structs.a_bpwr
        QDPPacket.__init__(self, bytes)
