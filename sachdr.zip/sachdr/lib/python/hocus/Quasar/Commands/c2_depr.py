from Quasar.QDPPacket import QDPPacket
from Quasar import CmdID
from Quasar import Structs


class c2_depr(QDPPacket):
    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C2_DEPR)
        self.Fields = [
            'SubCommand',
            'SubResponse',
            'RemainderOfParameters'
            ]
        self.FieldDefinition = Structs.a_dep
        QDPPacket.__init__(self, bytes)
