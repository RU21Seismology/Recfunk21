from Quasar.Commands.c2_samass import c2_samass
from Quasar import CmdID

class c2_amass(c2_samass):
    def __init__(self, bytes=None):
        c2_samass.__init__(self, bytes)
        self.setQDPCommand(CmdID.C2_AMASS)
        
