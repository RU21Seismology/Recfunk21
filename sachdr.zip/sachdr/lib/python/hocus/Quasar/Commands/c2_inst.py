from Quasar.QDPPacket import QDPPacket
from Quasar import Structs
from Quasar import CmdID

class c2_inst(QDPPacket):
    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C2_INST)
        self.Fields = [
            'DPIPAddress',
            'RouterIPAddress',
            'TimeoutInMinutes',
            'Spare',
            'Flags',
            'DPUDPPort'
            ]
        self.FieldDefinition = Structs.a_inst
        QDPPacket.__init__(self, bytes)
