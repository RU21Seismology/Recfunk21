from Quasar.QDPPacket import *
from Quasar import Structs
from Quasar import CmdID

class c1_mysn(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_MYSN)
        self.Fields = [
            'SerialNumber',
            'KMIPropertyTag',
            'UserTag'
            ]
        self.FieldDefinition = Structs.mysn
        
        QDPPacket.__init__(self, bytes)

    
    def strSerialNumber(self):
        return '%x' %self.getSerialNumber()
