from Quasar.Commands.c2_sgps import c2_sgps
from Quasar import CmdID


class c2_gps(c2_sgps):
    def __init__(self, bytes=None):
        c2_sgps.__init__(self, bytes)
        self.setQDPCommand(CmdID.C2_GPS)
