from Quasar.QDPPacket import QDPPacket

from Quasar import Structs
from Quasar import CmdID

class c1_wstat(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_WSTAT)
        self.Fields = [
            'Spare',
            'NewValue'
            ]
        self.FieldDefinition = Structs.wstat
        QDPPacket.__init__(self, bytes)
