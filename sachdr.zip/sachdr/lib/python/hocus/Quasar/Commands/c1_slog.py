from Quasar.QDPPacket import QDPPacket

from Quasar import CmdID
from Quasar import Structs
import string
from isti.utils.Bits import *

class c1_slog(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_SLOG)
        self.FieldDefinition = Structs.log
        self.Fields = [
            'DataPortNumber',
            'Flags',
            'PercentOfPacketBuffer',
            'MTU',
            'GroupCount',
            'MaximumResendTimeout',
            'GroupTimeout',
            'MinimumResendTimeout',
            'WindowSize',
            'DataSequenceNumber',
            'Channel1Freqs',
            'Channel2Freqs',
            'Channel3Freqs',
            'Channel4Freqs',
            'Channel5Freqs',
            'Channel6Freqs',
            'AcknowledgeCount',
            'AcknowledgeTimeout',
            'OldDataThresholdTime',
            'EthernetThrottle',
            'AlarmPercent',
            'AutomaticFilters',
            'ManualFilters',
            'Spare'
            ]

        QDPPacket.__init__(self, bytes)

    def strDataPortNumber(self):
        portStrings = [
            'Data Port 1',
            'Data Port 2',
            'Data Port 3',
            'Data Port 4'
            ]
        return portStrings[self.getDataPortNumber()]

    def strFlags(self):
        flags = self.getFlags()
        ret = ['']
        
        if flags & BIT0:
            ret.append('Fill mode enabled')
        else:
            ret.append('Fill mode disabled')
            
        if flags & BIT1:
            ret.append('Flush packet buffer based on time')

        if flags & BIT2:
            ret.append('Freeze data port output')

        if flags & BIT3:
            ret.append('Freeze packet buffer input')

        if flags & BIT4:
            ret.append('Keep oldest data in packet buffer')

        if flags & BIT8:
            ret.append('Have DP piggyback status requests with DT_DACK packets')

        if flags & BIT9:
            ret.append('Turn on "Communications Fault" LED if flush did not reduce buffer by 5%%')

        if flags & BIT10:
            ret.append('Allow "Hot Swap" on this data port')

        if flags & BIT11:
            ret.append('Flush sliding window buffer based on time')

        if flags & BIT15:
            ret.append('Save changes in EEPROM')

        return string.join(ret, '\n      ')
        
    def strPercentOfPacketBuffer(self):
        return '%f%%' %(self.getPercentOfPacketBuffer() * (100.0 / 256.0))

    def strMaximumResendTimeout(self):
        return '%d ms' %(self.getMaximumResendTimeout() * 100)

    def strMinimumResendTimeout(self):
        return '%d ms' %(self.getMinimumResendTimeout() * 100)

    def strAcknowledgeTimeout(self):
        return '%d ms' %(self.getAcknowledgeTimeout() * 100)

    def strAlarmPercent(self):
        return '%f%%' %(self.getAlarmPercent() * (100.0 / 256.0))
