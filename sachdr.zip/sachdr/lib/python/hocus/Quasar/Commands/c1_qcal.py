from Quasar.QDPPacket import QDPPacket
from Quasar import Structs
from Quasar import CmdID
from isti.utils.Bits import *

class c1_qcal(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_QCAL)
        self.Fields = [
            'StartingTime',
            'Waveform',
            'Amplitude',
            'DurationInSeconds',
            'SettlingTimeInSeconds',
            'CalibrationBitmap',
            'TrailerTimeInSeconds',
            'SensorControlBitmap',
            'MoitorChannelBitmap',
            'FrequencyDivider',
            'Spare',
            'CouplingBytes0To3',
            'CouplingBytes4To7',
            'CouplingBytes8To11'
            ]
        self.FieldDefinition = Structs.qcal
        QDPPacket.__init__(self, bytes)

    def strWaveform(self):
        v = self.getWaveform()
        ret = ['']
        whichWaveform = v & (BIT0 | BIT1 | BIT2)

        ret.append( [
            'Sine',
            'Red Noise',
            'White Noise',
            'Step',
            'Random Telegraph'
            ][whichWaveform])
        
        bit6 = v & BIT6
        bit7 = v & BIT7
        if bit6 == 1:
            ret.append('Negative step')
        else:
            ret.append('Positive step')

        if bit7 == 1:
            ret.append('Automatic calibration')

        return string.join(ret, '\n      ')

    def strCalibrationBitmap(self):
        values = [
            'Channel 1',
            'Channel 2',
            'Channel 3',
            'Channel 4',
            'Channel 5',
            'Channel 6'
            ]
        return bitsToString(self.getCalibrationBitmap(), values)

    def strSensorControlBitmap(self):
        values = [
            'Channel 1',
            'Channel 2',
            'Channel 3',
            'Channel 4',
            'Channel 5',
            'Channel 6'
            ]
        return bitsToString(self.getCalibrationBitmap(), values)

    def strMonitorChannelBitmap(self):
        values = [
            'Channel 1',
            'Channel 2',
            'Channel 3',
            'Channel 4',
            'Channel 5',
            'Channel 6'
            ]
        return bitsToString(self.getCalibrationBitmap(), values)
            
        

        
        
