from Quasar.QDPPacket import QDPPacket
from Quasar import Structs
from Quasar import CmdID

class c2_sphy(QDPPacket):
    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C2_SPHY)
        self.Fields = [
            'PhysicalInterfaceNumber',
            'DataPortNumber',
            'ModemInitialization',
            'PhoneNumber',
            'UserName',
            'Password',
            'MemoryTriggerLevel',
            'Flags',
            'RetryIntervalOrPowerOffTime',
            'Interval',
            'WebServerBPSLimit',
            'PointOfContactOrBalerIPAddress',
            'BalerSecondaryIPAddress',
            'PointOfContactPortNumber',
            'BalerRetries',
            'BalerRegistrationTimeout',
            'SerialBaudRate',
            'Spare'
            ]
        self.FieldDefinition = Structs.a_phy
        QDPPacket.__init__(self, bytes)
            
