from Quasar.QDPPacket import QDPPacket
from Quasar import CmdID
from Quasar import Structs
import string

FLAGS_SAVE_TO_EEPROM = 1
FLAGS_REBOOT         = 2
FLAGS_RESYNC         = 4
FLAGS_TURN_ON_GPS    = 8
FLAGS_TURN_OFF_GPS   = 16
FLAGS_COLD_START_GPS = 32

class c1_ctrl(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_CTRL)
        self.Fields = [
            'Flags'
            ]
        self.FieldDefinition = Structs.ctrl
        QDPPacket.__init__(self, bytes)

    def strFlags(self):
        flags = self.getFlags()
        ret = ['']
        if flags & FLAGS_SAVE_TO_EEPROM:
            ret.append('Save current programming to EEPROM')
        if flags & FLAGS_REBOOT:
            ret.append('Reboot')
        if flags & FLAGS_RESYNC:
            ret.append('Re-Sync')
        if flags & FLAGS_TURN_ON_GPS:
            ret.append('Turn on GPS')
        if flags & FLAGS_TURN_OFF_GPS:
            ret.append('Turn off GPS')
        if flags & FLAGS_COLD_START_GPS:
            ret.append('Cold-start GPS')

        return string.join(flags, '\n      ')
            
            
