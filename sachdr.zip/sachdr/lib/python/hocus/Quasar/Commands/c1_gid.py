from Quasar.QDPPacket import QDPPacket

from Quasar import Structs
from Quasar import CmdID

class c1_gid(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_GID)
        self.Fields = [
            'ID1',
            'ID2',
            'ID3',
            'ID4',
            'ID5',
            'ID6',
            'ID7',
            'ID8',
            'ID9'
            ]
        self.FieldDefinition = Structs.gid
        QDPPacket.__init__(self, bytes)
            
