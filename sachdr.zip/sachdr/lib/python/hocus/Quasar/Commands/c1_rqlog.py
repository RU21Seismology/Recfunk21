from Quasar.QDPPacket import QDPPacket
from Quasar import Structs
from Quasar import CmdID

class c1_rqlog(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_RQLOG)
        self.Fields = [
            'DataPortNumber'
            ]
        self.FieldDefinition = Structs.rqlog
        QDPPacket.__init__(self, bytes)

    def strDataPortNumber(self):
        portMap = {
            -1 : 'All Ports',
            0  : 'Data Port 1',
            1  : 'Data Port 2',
            2  : 'Data Port 3',
            3  : 'Data Port 4'
            }
        return portMap[self.getDataPortNumber()]
            
        
