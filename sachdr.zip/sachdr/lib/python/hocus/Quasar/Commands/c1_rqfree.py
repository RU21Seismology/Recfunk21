from Quasar.QDPPacket import *
from Quasar import Structs
from Quasar import CmdID

class c1_rqfree(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_RQFREE)
        self.Fields = []
        self.FieldDefinition = ''

        QDPPacket.__init__(self, bytes)
