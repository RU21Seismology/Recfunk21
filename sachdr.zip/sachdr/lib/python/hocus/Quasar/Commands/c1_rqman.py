from Quasar.QDPPacket import QDPPacket

from Quasar import CmdID

class c1_rqman(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_RQMAN)
        self.Fields = []
        self.FieldDefinition = ''
        QDPPacket.__init__(self, bytes)
        
