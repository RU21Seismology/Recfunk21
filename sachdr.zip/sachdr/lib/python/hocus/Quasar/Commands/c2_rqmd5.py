from Quasar.QDPPacket import QDPPacket
from Quasar import CmdID
from Quasar import Structs

class c2_rqmd5(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C2_RQMD5)
        self.Fields = [
            'StationIdentifier'
            ]
        self.FieldDefinition = Structs.a_rqmd5
        QDPPacket.__init__(self, bytes)
