from Quasar.QDPPacket import QDPPacket
from Quasar import CmdID
from Quasar import Structs

class c1_rqflgs(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_RQFLGS)
        self.Fields = [
            'DataPortNumber'
            ]
        self.FieldDefinition = Structs.rqflgs
        QDPPacket.__init__(self, bytes)
