from Quasar.QDPPacket import QDPPacket
from Quasar import CmdID
from Quasar import Structs


class c2_dep(QDPPacket):
    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C2_DEP)
        self.Fields = [
            'SubCommand',
            'Spare',
            'RemainderOfParameters'
            ]
        self.FieldDefinition = Structs.a_dep
        QDPPacket.__init__(self, bytes)
