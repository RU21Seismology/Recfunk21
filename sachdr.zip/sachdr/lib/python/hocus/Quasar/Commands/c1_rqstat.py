from Quasar.QDPPacket import *
from Quasar import Status
from Quasar import Structs
from Quasar import CmdID


class c1_rqstat(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_RQSTAT)
        self.Fields = [
            'RequestBitmap'
            ]
        self.FieldDefinition = Structs.rqstat

        QDPPacket.__init__(self, bytes)


    def strRequestBitmap(self):
        return Status.bitmapToString(self.getRequestBitmap())
            
