from Quasar.QDPPacket import QDPPacket
from Quasar import Structs
from Quasar import CmdID
from isti.utils import structWrapper

class c1_thn(QDPPacket):

    def __init__(self, bytes=None):
        self.setQDPCommand(CmdID.C1_THN)
        self.Fields = []
        self.FieldDefinition = ''
        if bytes:
            numThreads = (len(bytes)-12) / structWrapper.calcsize(Structs.thread)
            for i in range(0, numThreads):
                self.Fields.append('Thread_%d' %(i+1))
                self.FieldDefinition = self.FieldDefinition + Structs.thread[1:]
        QDPPacket.__init__(self, bytes)
