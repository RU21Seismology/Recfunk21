
import Cloning.Profile
from Cmds import *
from QDPDevice import QDPDevice
from Q330 import Q330
import sys

global device
global q330

def pollsnTest():
    print 'Getting serial number'
    device.setBasePort(65535)
    device.setIPAddress('255.255.255.255')

    f = c1_pollsn()
    response = device.sendCommand(f)
    return response.getSerialNumber()

def statusTest():
    rqstat = c1_rqstat()
    rqstat.setRequestBitmap(2)
    return q330.sendCommand(rqstat)

def getPhy():
    global q330
    rq = c1_rqphy()
    phy = q330.sendCommand(rq)
    print phy.__dict__

def getTokenSet():
    global q330
    q330.getTokenSet(1)
    
if __name__ == '__main__':
    
    device = QDPDevice()
    serial = pollsnTest()

    try:
        print "Heard from %x" %serial
        q330 = Q330(serial, '192.168.1.165', 5330)
        print 'Registering'
        q330.register()
        print 'Creating profile'
        prof = Cloning.Profile.Profile(sys.argv[1])
        print 'Reading from Q330'
        prof.readFromQ330(q330)
        #print prof
        print 'Writing to file'
        Cloning.Profile.writeProfileToFile(prof)
    finally:
        print 'Deregistering'
        q330.deregister()


