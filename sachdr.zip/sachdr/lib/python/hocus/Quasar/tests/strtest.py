
from Commands.c1_log import *

s = c1_log()
print s
