
from Cmds import *
from QDPDevice import QDPDevice
from Q330 import Q330

global device
global q330

def pollsnTest():
    print 'Getting serial number'
    device.setBasePort(65535)
    device.setIPAddress('255.255.255.255')

    f = c1_pollsn()
    response = device.sendCommand(f)
    return response.getSerialNumber()

def statusTest():
    rqstat = c1_rqstat()
    rqstat.setRequestBitmap(2)
    return q330.sendCommand(rqstat)

def getPhy():
    global q330
    rq = c1_rqphy()
    phy = q330.sendCommand(rq)
    print phy.__dict__

def getTokenSet():
    global q330
    q330.getTokenSet(1)
    
if __name__ == '__main__':
    
    device = QDPDevice()
    serial = pollsnTest()

    try:
        print "Heard from %x" %serial
        q330 = Q330(serial, '192.168.2.50', 5330)
        print 'Registering'
        q330.register()
        #print 'Getting global status'
        #print statusTest().__dict__
        #print getPhy()

        #msg = c1_umsg()
        #msg.setUserMessage('This is a test')

        #print q330.sendCommand(c1_rqsc())
        #getTokenSet()
        import time
        print q330.sendCommand(c1_rqglob())
    finally:
        print 'Deregistering'
        q330.deregister()
