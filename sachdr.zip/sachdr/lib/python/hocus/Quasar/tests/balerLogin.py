import Baler
import sys

thisBaler = Baler.Baler()
thisBaler.setIPAddress(sys.argv[1])
thisBaler.setBasePort(int(sys.argv[2]))
print thisBaler.login()
