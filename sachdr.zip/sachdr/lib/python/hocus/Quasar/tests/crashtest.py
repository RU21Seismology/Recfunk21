
import Cloning.Profile
from Cmds import *
from QDPDevice import QDPDevice
from Q330 import Q330
import sys

global q330


if __name__ == '__main__':
    
    q330 = Q330(0x10000069a37e501, '192.168.1.165', 5330)
    print 'Registering'
    q330.register()
    
    print 'Reading from file'
    prof = Cloning.Profile.getProfileFromFile(sys.argv[1])
    print 'profile read'
    print 'writing to Q330'
    prof.writeToQ330(q330)
    prof.writeToQ330(q330)
