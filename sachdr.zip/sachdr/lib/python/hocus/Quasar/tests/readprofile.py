
import Cloning.Profile
from Cmds import *
from QDPDevice import QDPDevice
from Q330 import Q330
import sys

global device
global q330

def pollsnTest():
    print 'Getting serial number'
    device.setBasePort(65535)
    device.setIPAddress('255.255.255.255')

    f = c1_pollsn()
    response = device.sendCommand(f)
    return response.getSerialNumber()

if __name__ == '__main__':
    
    device = QDPDevice()
    serial = pollsnTest()

    try:
        print "Heard from %x" %serial
        q330 = Q330(serial, '192.168.1.165', 5330)
        print 'Registering'
        q330.register()
        
        print 'Reading from file'
        prof = Cloning.Profile.getProfileFromFile(sys.argv[1])
        print 'profile read'
        print 'writing to Q330'
        prof.writeToQ330(q330)
    finally:
        print 'Deregistering'
        q330.deregister()
