# this is to make Quasar usable as a package
import os
if os.path.isfile('c:\\4242') or os.path.isfile('/4242'):
    APPLICATION_LOCK_LIST = []
else:
    APPLICATION_LOCK_LIST = ['BalerAdmin.exe', 'BalerAdmin', 'mseedDiff', 'getModules', 'HCSMain.py']
import sys
sys = reload(sys)

import os

if len(APPLICATION_LOCK_LIST):
    thisAppName = sys.argv[0].split(os.path.sep)[-1]
    if thisAppName not in APPLICATION_LOCK_LIST:
        print "This version of Quasar can not be used with %s" %thisAppName
        sys.exit(1)
    
