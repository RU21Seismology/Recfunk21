import Quasar.Baler
import isti.utils.ConfigFile
import isti.utils
from isti.librep.v2_3 import urllib
from isti.librep.v2_3 import urllib2
import httplib
import time
import os
import socket

class BalerWaitTimeoutException(Exception):
    pass

class UnableToTurnBalerOnException(Exception):
    pass

class Station:
    """
    A Station is a view of a station from the outside.  Both the Q330 and the Baler can
    be accessed through this common interface.  Eventually other items located at the station
    should be accesable as well.
    """
    def __init__(self, stationName, stationConfig):
        self.stationConfig = isti.utils.ConfigFile.XMLConfig(stationConfig)

        self.baler = None
        self.q330 = None
        self.stationName = stationName

    def __eq__(self, other):
        if type(other) != type(self):
            return False
        
        if self.stationName != other.stationName:
            return False

        return True
    
    def getConfigItem(self, configItem):
        """
        Get a config item from the config file used to create this station
        """
            
        if configItem in ('Station.Baler.IPAddress', 'Station.Q330.IPAddress') and not self.stationConfig[configItem]:
            return self.stationConfig['Station.IPAddress']

        return self.stationConfig[configItem]

    #def whichConfigItemsAreMissing(self, requiredConfigList):
    #    missingItems = []
    #    for configItem in requiredConfigList:
    #        if self.getConfigItem(configItem) == None:
    #            missingItems.append(configItem)
    #    return missingItems
    
    def getName(self):
        return self.stationName

    def getBalerConfig(self):
        for dp in ['DP1', 'DP2', 'DP3', 'DP4']:
            thisSection = self.getConfigItem('Station.%s.Type' %dp)
            if thisSection in ('baler14', 'BALER14', 'Baler14'):
                return self.getConfigItem('Station.%s' %dp)

    def getQ330Config(self):
        return self.getConfigItem('Station.Q330')
    
    def waitForBaler(self, timeoutInSeconds=1):
        """
        Wait for at most timeoutInSeconds seconds for a baler to be available.  of the baler
        isn't available by then, raise a BalerWaitTimeoutException
        """
#        try:
#            oldTimeout = socket.getdefaulttimeout()
#            socket.setdefaulttimeout(1)
#        except:
#            pass
        
        startTime = time.time()
        while (time.time() - startTime) < timeoutInSeconds:
            if self.isBalerAlive():
                return 

#        try:
#            socket.setdefaulttimeout(oldTimeout)
#        except:
#            pass
        
        raise BalerWaitTimeoutException()

    def isBalerAlive(self):
        balerConfig = self.getBalerConfig()
        tmpUrl = None
        
        try:
            #opener = Baler.AccountingURLOpener
            #opener.retrieve('http://%s:%d/index.htm' %(balerConfig['IPAddress'], balerConfig['WebPort']))
            retryPattern = [1, 5, 10]
            tmpUrl = urllib.urlopen('http://%s:%d/index.htm' %(balerConfig['IPAddress'], balerConfig['WebPort']),
                                    retryPattern=retryPattern, connectedSocketTimeout=20)
            txt = tmpUrl.read(128)
            tmpUrl.close()
            if 'TITLE' in txt.upper():
                return True
            else:
                return False
        except:
            if tmpUrl:
                try:
                    tmpUrl.close()
                except:
                    pass
            return False
        
    def turnBalerOn(self, username='', authCode='', retry=0):
        if retry >= 3:
            raise UnableToTurnBalerOnException

        retryPattern = [1, 5, 10]
        connectedSocketTimeout = 60
        
        turnOnUrl = 'http://%s:%d/BALEPWR.HTM' %(self.getConfigItem('Station.Q330.Ethernet.IPAddress'),
                                             self.getConfigItem('Station.Q330.Ethernet.WebPort'))
        turnOnArgs = urllib.urlencode({'PWR' : 'Turn on Baler Power', 'POSTDONE' : 'YES'})

        url = None
        
        try:
            if not username:
                url = urllib.urlopen('%s' %turnOnUrl, turnOnArgs, retryPattern=retryPattern, connectedSocketTimeout=connectedSocketTimeout)
            else:
                authinfo = urllib2.HTTPDigestAuthHandler()
                authinfo.setRetryPattern(retryPattern)
                authinfo.setConnectedSocketTimeout(connectedSocketTimeout)
                authinfo.add_password('BPWR', turnOnUrl, username, authCode)
                opener = urllib2.build_opener(authinfo)
                url = opener.open(turnOnUrl, turnOnArgs)
                
        except IOError,e:
            if isinstance(e, urllib2.HTTPError):
                retCode = e.code
            else:
                retCode = e[1]
            if retCode == 401:
                # unauthorized
                homepage = urllib.urlopen('http://%s:%d/INDEX.HTM' %(self.getConfigItem('Station.Q330.Ethernet.IPAddress'),
                                                                     self.getConfigItem('Station.Q330.Ethernet.WebPort')
                                                                     ),
                                          retryPattern=retryPattern,
                                          connectedSocketTimeout=connectedSocketTimeout).read()
                if 'When prompted, use ' in homepage and 'When prompted, use Q330 S/N' not in homepage:
                    username = homepage.split('When prompted, use ')[1].split()[0]
                    try:
                        hexval = eval('0x%s' %username.strip())
                    except:
                        username = self.getConfigItem('Station.Q330.SerialNumber')
                else:
                    username = self.getConfigItem('Station.Q330.SerialNumber')
                if self.getConfigItem('Station.Q330.DP4.AuthCode'):
                    passwd = self.getConfigItem('Station.Q330.DP4.AuthCode')
                else:
                    passwd = 0
                return self.turnBalerOn(username, passwd, retry+1)
        except UnableToTurnBalerOnException, e:
            raise e
        except Exception, e:
            print e
            self.turnBalerOn(username, authCode, retry+1)

        if url:
            url.read()
            url.close()

    def getBaler(self):
        """
        get a Baler instance representing the baler at this station.  If
        the baler hasn't been created yet, it's done here
        """
        if self.baler:
            return self.baler
        balerConfig = self.getBalerConfig()
        self.baler = Quasar.Baler.Baler()
        self.baler.setWebPort(balerConfig['WebPort'])
        self.baler.setStation(self)
        self.baler.setViaStation(True)
        self.baler.setIPAddress(balerConfig['IPAddress'])
        if balerConfig.has_key('ConfigPort'):
            self.baler.setBasePort(balerConfig['ConfigPort'])
        elif balerConfig.has_key('BasePort'):
            self.baler.setBasePort(balerConfig['BasePort'])
        else:
            self.baler.setBasePort(0)
        return self.baler

    def getQ330(self):
        """
        Get a Q330 instance representing the Q330 at this station
        """
        if self.q330:
            return self.q330

        q330Config = self.getQ330Config()
        if q330Config.has_key('AuthCode'):
            authCode = q330Config['AuthCode']
        else:
            authCode = 0

        self.q330 = Quasar.Q330.Q330(q330Config['SerialNumber'], q330Config['Ethernet']['IPAddress'], q330Config['BasePort'])

        self.q330.setAuthCode(authCode)
        return self.q330
