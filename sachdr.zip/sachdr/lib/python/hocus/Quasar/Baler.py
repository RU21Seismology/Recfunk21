from Quasar.QDPDevice import QDPDevice, QDP_C1_CERR

import socket
import struct
import sys
import time
import calendar
import re
import string
import thread
import threading
import os
import warnings
import hashlib
from isti.net import ping

# get all the commands into the module namespace
from Quasar import Cmds
from Quasar import CmdID
from Quasar.Utils import seedUtils
from Quasar.Utils import mseed

from isti.librep.v2_3 import urllib
import isti.utils.convertUtils
import Quasar.QDPDevice

def openBroadcastSocket():
    """
    Open a socket prepared to send broadcast UDP packets
    """
    if sys.platform in ('cygwin', 'win32', 'darwin'):
        host = ''
    else:
        host = '255.255.255.255'
    port = 65535
    info = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_DGRAM)
    af, socktype, proto, canonname, sa = info[0]
    connection = socket.socket(af, socktype, proto)
    if sys.platform in ('cygwin', 'win32', 'darwin'):
        connection.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    connection.bind((host, port))
    return connection

#class TransferAbortedException(Exception):
#    def __init__(self, remainingTransfers):
#        Exception.__init__(self)
#        self.remainingTransfers = remainingTransfers

#    def getRemainingTransfers(self):
#        return self.remainingTransfers

class TransferNeedsToBeRestartedException(Exception):
    def __init__(self, remainingTransfers):
        Exception.__init__(self)
        self.remainingTransfers = remainingTransfers

    def getRemainingTransfers(self):
        return self.remainingTransfers

class TransferAbortedException(TransferNeedsToBeRestartedException):
    pass

class TransferDiedDueToAnErrorException(TransferNeedsToBeRestartedException):
    
    def setRootExceptionInfoTuple(self, infoTuple):
        self.rootExceptionInfoTuple = infoTuple

    def getRootExceptionInfoTuple(self):
        return infoTuple

class TransferTimedOutException(TransferNeedsToBeRestartedException):
    pass

class TransferConnectionResetException(TransferNeedsToBeRestartedException):
    pass

class TransferProceedingTooSlowException(TransferNeedsToBeRestartedException):
    pass

class BalerDetector:

    """
    A class encapsulating a multi-threaded approach to baler detection.

    This should be used instead of the older getBalers approach.  This class
    always uses the balerHandleFunction-like functionality.  The old "return a list"
    functionality may be simulated using this.
    """

    def __init__(self):
        self.ipAddressPool = []
        self.assignedIPAddresses = []
        self.usableIPAddresses = []
        self.assignedIPAddresses_LOCK = thread.allocate_lock()
        self.usableIPAddresses_LOCK = thread.allocate_lock()
        self.balerHandlerFunction = self.defaultBalerHandlerFunction
        self.balerHandlerFunctionArgs = ()
        self.timeoutInSeconds = None
        self.broadcastIP = '255.255.255.255'
        self.netmask = '255.255.255.0'
        self.bpsThrottle = 0
        self.currentlyDetecting = False
        self.seenButUnregisteredBalers = {}
        self.seenButUnregisteredBalers_LOCK = thread.allocate_lock()
        self.balersToOperateOn = None

    def continueAckingBaler(self, brdy):
        sn = brdy.getBalerSerialNumber()
        if self.seenButUnregisteredBalers.has_key(sn):
            self.seenButUnregisteredBalers_LOCK.acquire()
            self.seenButUnregisteredBalers[sn] += 1
            self.seenButUnregisteredBalers_LOCK.release()
            return True
        else:
            self.seenButUnregisteredBalers_LOCK.acquire()
            self.seenButUnregisteredBalers[sn] = 0
            self.seenButUnregisteredBalers_LOCK.release()
            return True

    def setBalersToOperateOn(self, balerList):
        if type(balerList) != list:
            raise TypeError, "Argument must be a list"
        self.balersToOperateOn = balerList
        
    def balerSuccessfullyRegistered(self, whichBaler):
        sn = struct.unpack('<Q', struct.pack('>Q', whichBaler.getBalerSerialNumber()))[0]
        self.seenButUnregisteredBalers_LOCK.acquire()
        del self.seenButUnregisteredBalers[sn]
        self.seenButUnregisteredBalers_LOCK.release()

    def getNumBRDYsForBaler(self, brdy):
        sn = brdy.getBalerSerialNumber()
        return self.seenButUnregisteredBalers[sn]
    
    def defaultBalerHandlerFunction(self, thisBaler):
        print 'Baler Detected: %s' %thisBaler
        
    def recycleIPAddress(self, ip, prepend=False):
        """
        instruct the detector that an IP in the pool may be
        re-used.  This is an alias for markIPAsUnused, but
        makes code using the BalerDetector more readable
        """
        self.markIPAsUnused(ip, prepend)

    def clearIPAddressPool(self):
        self.ipAddressPool = []
        self.usableIPAddresses_LOCK.acquire()
        self.usableIPAddresses = []
        self.usableIPAddresses_LOCK.release()
        
    def addIPAddressToPool(self, ip):
        """ Add an IP to the pool that doesn't already exist """
        if ip not in self.ipAddressPool:
            self.ipAddressPool.append(ip)
            self.usableIPAddresses.append(ip)

    def markIPAsUsed(self, ip):
        """ Mark an IP as already used """
        if ip not in self.ipAddressPool:
            return
        
        if ip not in self.assignedIPAddresses:
            self.assignedIPAddresses_LOCK.acquire()
            self.assignedIPAddresses.append(ip)
            self.assignedIPAddresses_LOCK.release()

        if ip in self.usableIPAddresses:
            self.usableIPAddresses_LOCK.acquire()
            del self.usableIPAddresses[self.usableIPAddresses.index(ip)]
            self.usableIPAddresses_LOCK.release()

    def markIPAsUnused(self, ip, prepend=False):
        """ Mark an IP as unused """
        if ip not in self.ipAddressPool:
            return

        if ip in self.assignedIPAddresses:
            self.assignedIPAddresses_LOCK.acquire()
            del self.assignedIPAddresses[self.assignedIPAddresses.index(ip)]
            self.assignedIPAddresses_LOCK.release()

        if ip not in self.usableIPAddresses:
            self.usableIPAddresses_LOCK.acquire()
            if prepend:
                self.usableIPAddresses = [ip] + self.usableIPAddresses
            else:
                self.usableIPAddresses.append(ip)
            self.usableIPAddresses_LOCK.release()
        
    def isCurrentlyDetecting(self):
        """ Are we currently detecting? """
        return currentlyDetecting

    def stopDetecting(self):
        """ Stop detecting balers """
        self.currentlyDetecting = False
        
    def setBPSThrottle(self, throttle):
        """ set the throttle to give to the balers """
        self.BPSThrottle = throttle
        
    def setBroadcastIP(self, newBroadcast):
        """ set the broadcast IP to give to the balers """
        self.broadcastIP = newBroadcast

    def setNetmask(self, netmask):
        """ set the netmask to give to teh balers """
        self.netmask = netmask
        
    def setBalerHandlerFunctionAndArgs(self, func, args):
        """
        set the baler handler function and arguments.
        This function will be called, with the baler as the first argument,
        when a baler is detected
        """
        self.balerHandlerFunction = func
        self.balerHandlerFunctionArgs = args

    def setTimeoutInSeconds(self, timeout):
        self.timeoutInSeconds = timeout

    def startDetecting(self):
        """ Start detecting balers """
        self.currentlyDetecting = True
        self.detectionThread = threading.Thread(target=self._detectBalers)
        self.detectionThread.setDaemon(True)
        self.detectionThread.start()

    def _detectBalers(self):
        """
        This function should not be run from the outside.  It is intended
        to be run in its own thread
        """
        con = openBroadcastSocket()
        if con.__class__.__dict__.has_key('settimeout') and self.timeoutInSeconds:
            con.settimeout(self.timeoutInSeconds)

        
        while self.currentlyDetecting:
            if not len(self.usableIPAddresses):
                time.sleep(.5)
                continue

            ipToAssign = self.usableIPAddresses[0]
            self.markIPAsUsed(ipToAssign)
                        

            try:
                packetBytes, addr = con.recvfrom(44)
            except Exception, e:
                #print e
                self.recycleIPAddress(ipToAssign, prepend=True)
                continue
            

            commandID = struct.unpack('B', packetBytes[4])[0]
            brdy = Cmds.cmdToClass[commandID](packetBytes)

            if self.continueAckingBaler(brdy):
                handleThread = threading.Thread(target=self._setupAndHandleBaler,
                                                args=(ipToAssign, brdy, addr))
                handleThread.start()
                

        con.close()
        
    def _setupAndHandleBaler(self, ip, brdy, addrInfo):

        # remove this IP from the ARP table before we re-assign it
        if sys.platform in ('win32', 'cygwin'):
            os.popen("arp -d %s" %ip)
        else:
            ## fill in some code to do this one line at a time
            ## This hasn't been done yet, since unix-ish OSs require
            ## root access to muck with the arp table
            pass

        brdy.setSourceIPAddressInfo(addrInfo)
        balerTag = '%05d' %brdy.getBalerTag()

        # see if this is one of the balers we're looking for
        balerTag2 = '%d' %brdy.getBalerTag()
        if self.balersToOperateOn not in (None, []):
            if balerTag not in self.balersToOperateOn and balerTag2 not in self.balersToOperateOn:
                self.recycleIPAddress(ip)
                return
            
        thisBaler = Baler()
        thisBaler.tagID = balerTag
        thisBaler.setIPAddress('255.255.255.255')
        thisBaler.setBroadcastIPAddress(self.broadcastIP)
        thisBaler.setInternalPort(addrInfo[1])
        thisBaler.setVacPref(brdy.getVPREF())
        thisBaler.setAvailable(brdy.getAVAIL())
        
        vack = Cmds.c2_vack()
        if thisBaler.getVacPref() or thisBaler.getAvailable():
            vack.setQ330SerialNumber(0)
        else:
            vack.setQ330SerialNumber(brdy.getQ330SerialNumber())
        vack.setQ330IPAddress(0)
        vack.setPointOfContactIPBalerIPAddress(struct.unpack("L", socket.inet_aton(ip))[0])
        vack.setBalerSecondaryIPAddressOrNetMask(struct.unpack("L", socket.inet_aton(self.netmask))[0])
        vack.setQ330BasePortNumber(0)
        vack.setQ330DataPortNumber(0)
        vack.setWebServerBPSLimit(self.bpsThrottle)
        vack.setFlags(0)
        vack.setAccessTimeout(0)
        vack.setSerialBaudRate(0)
	if sys.byteorder == 'big':
	    swappedSN = struct.unpack('>Q', struct.pack('<Q', brdy.getBalerSerialNumber()))[0]
	    vack.setBalerSerialNumber(swappedSN)
	else:
	    vack.setBalerSerialNumber(brdy.getBalerSerialNumber())
        vack.setQDPAcknowledgeNumber(brdy.getQDPSequenceNumber())
        #print 'Acking %d' %brdy.getQDPSequenceNumber()
        # account for the BRDYs sent by this baler
        for i in range(0, self.getNumBRDYsForBaler(brdy)):
            thisBaler.getNextSequenceNumber()

        #print 'Sending vack:\n%s' %vack
        thisBaler.sendCommand(vack, preservePortForBroadcast=1, skipReceive=1)
        thisBaler.setIPAddress(ip)
        thisBaler.setQ330SerialNumber(brdy.getQ330SerialNumber())
        thisBaler.setNetwork(brdy.getNetwork())
        thisBaler.setStationName(brdy.getStationName())
        thisBaler.setModelNumber(brdy.getModelNumber())
        thisBaler.setDiskSizeInBytes(brdy.getDiskSizeInBytes())
        thisBaler.setSwappedBalerSerialNumber(brdy.getBalerSerialNumber())
        try:
            origTimeout = thisBaler.getReceiveTimeout()
            thisBaler.setReceiveTimeout(2)
            thisBaler.setBalerTime()
            thisBaler.setReceiveTimeout(origTimeout)
        except Exception,e:
            # put this IP back into the list
            self.recycleIPAddress(ip)

        self.balerSuccessfullyRegistered(thisBaler)
        
        tmpArgs = (thisBaler, ) + self.balerHandlerFunctionArgs[:]
        
        self.balerHandlerFunction(*tmpArgs)
        
def getBalers(IPAddressPool, netmask="255.255.255.0", balerHandleFunction=None, broadcastIP='255.255.255.255', balerHandleFunctionArgs=None, timeoutInSeconds=None, bpsThrottle=0):
    """
    Using IP addresses from IPAddressPool, assign IPs to balers as they become alive.
    netmask is the netmask that is given to each baler.
    if balerHandleFunction is not None, a new thread is started with each detected baler
    as an argument, and detection continues.  If timeoutInSeconds is supplied, we
    give up if that number of seconds goes by without any responses.

    returns a list of baler objects
        
    Baler detection continues until:
      1) all IP addresses are given out
      2) the socket that is waiting for c2_brdy packets times out (the default timeout
      can be overridden by the timeoutInSeconds argument)
    """

    warnings.warn("""
    Please use the Baler.BalerDetector class for detecting balers rather than the
    Baler.getBalers() function.  Baler.getBalers() will be removed in a future
    release
    """, DeprecationWarning)
    
    balerList = []
    IPAddressPoolPtr = 0

    # clear the arp cache before we start looking for balers
    for IPAddress in IPAddressPool:
        # Skip IP addresses that are in use

        if sys.platform in ('win32', 'cygwin'):
            if ping.isHostAlive(IPAddress):
                continue


        # just remove this baler's IP
        if sys.platform in ('win32', 'cygwin'):
            os.popen("arp -d %s" %IPAddress)
        else:
            ## fill in some code to do this one line at a time
            ## This hasn't been done yet, since unix-ish OSs require
            ## root access to muck with the arp table
            pass
    

        con = openBroadcastSocket()
        if con.__class__.__dict__.has_key('settimeout') and timeoutInSeconds != None:
            con.settimeout(timeoutInSeconds)
        
        try:
            result, addr = con.recvfrom(44)
            con.close()
        except socket.error, e:
            con.close()
            return balerList

        cid = struct.unpack('B', result[4])[0]
        brdy = Cmds.cmdToClass[cid](result)
        brdy.setSourceIPAddressInfo(addr)
        thisBaler = Baler()
        thisBaler.setIPAddress('255.255.255.255')
        thisBaler.setBroadcastIP(broadcastIP)
        thisBaler.setInternalPort(addr[1])
        thisBaler.setVacPref(brdy.getVPREF())
        thisBaler.setAvailable(brdy.getAVAIL())
        vack = Cmds.c2_vack()
        if thisBaler.getVacPref() or thisBaler.getAvailable():
            vack.setQ330SerialNumber(0)
        else:    
            vack.setQ330SerialNumber(brdy.getQ330SerialNumber())
        vack.setQ330IPAddress(0)
        vack.setPointOfContactIPBalerIPAddress(struct.unpack("L", socket.inet_aton(IPAddress))[0])
        vack.setBalerSecondaryIPAddressOrNetMask(struct.unpack("L", socket.inet_aton(netmask))[0])
        vack.setQ330BasePortNumber(0)
        vack.setQ330DataPortNumber(0)
        vack.setWebServerBPSLimit(bpsThrottle)
        vack.setFlags(0)
        vack.setAccessTimeout(0)
        vack.setSerialBaudRate(0)
	if sys.byteorder == 'big':
	    swappedSN = struct.unpack('>Q', struct.pack('<Q', brdy.getBalerSerialNumber()))[0]
	    vack.setBalerSerialNumber(swappedSN)
	else:
	    vack.setBalerSerialNumber(brdy.getBalerSerialNumber())
        vack.setQDPAcknowledgeNumber(brdy.getQDPSequenceNumber())
        #print 'Acking %d' %brdy.getQDPSequenceNumber()
        thisBaler.sendCommand(vack, preservePortForBroadcast=1, skipReceive=1)
        thisBaler.setIPAddress(IPAddress)
        thisBaler.setQ330SerialNumber(brdy.getQ330SerialNumber())
        thisBaler.setNetwork(brdy.getNetwork())
        thisBaler.setStationName(brdy.getStationName())
        thisBaler.setModelNumber(brdy.getModelNumber())
        thisBaler.setDiskSizeInBytes(brdy.getDiskSizeInBytes())
        thisBaler.setSwappedBalerSerialNumber(brdy.getBalerSerialNumber())
        try:
            origTimeout = thisBaler.getReceiveTimeout()
            thisBaler.setReceiveTimeout(2)
            thisBaler.setBalerTime()
            thisBaler.setReceiveTimeout(origTimeout)
        except Exception,e:
            # put this IP back into the list
            IPAddressPool.append(IPAddress)
            print 'getBalers: %s' %e
            ## We ack'd this baler, but it didn't take.  Maybe a Q330 ack'd first? Maybe
            ## it just didn't get it, we'll skip from here on in.
            continue
       
        ##
        # We can't rely on this version, since 1.40 is split between
        # "needs byteswapped portno" and not.  We need to check the
        # baler via web to determine RC version
        #rawVersion = brdy.getVersion()
        #thisBaler.setVersion(rawVersion / 256, rawVersion % 256, '')
        ##
        balerList.append(thisBaler)
        if balerHandleFunction:
            args = (thisBaler, )
            if balerHandleFunctionArgs:
                args = args + balerHandleFunctionArgs
            thread.start_new_thread(balerHandleFunction, args)

    return balerList

def addTimeToDuration(startTime, duration):
    """
    Take in a time in a baler's retrieve.htm format, and a duration in '1d 1h 1m 1s' format, and
    add the duration to the time
    """
    days = 0
    hours = 0
    minutes = 0
    seconds = 0
    buffer = ''
    for ch in duration:
        if ch in 'dhms':
            num = int(buffer)
            if ch == 'd':
                days = num
            elif ch == 'h':
                hours = num
            elif ch == 'm':
                minutes = num
            elif ch == 's':
                seconds = num
            buffer = ''
        else:
            buffer += ch

    return addTime(startTime, days=days, hours=hours, minutes=minutes, seconds=seconds)

def convertBalerTimeToEpochTime(balerTime):
    """
    convert baler time (2004/07/11 12:00:00 or 2004-7-11 ...) to unix epoch time
    """
    timeParts = [2000, 1, 1, 0, 0, 0, 0, 0, -1] # the beginning of time, in baler land
    collector = ''
    timePartIndex = 0

    # go through the string, and replace the "initial starting times" with the
    # supplies data.  Anything not replaced will default to it's current "beginning
    # of time period"
    for char in balerTime:
        if char in (' ', '/', ':', '-'):
            num = int(collector)
            collector = ''
            timeParts[timePartIndex] = num
            timePartIndex += 1
        elif char in '0123456789':
            collector += char
        else:
            raise "Invalid character in time string", char

    if collector != '':
        try:
            timeParts[timePartIndex] = int(collector)
        except:
            raise "Invalid character in time string"
        
    # as per the baler's retrieve.htm page
    if timeParts[0] < 2000:
        timeParts[0] = timeParts[0] + 2000

    return calendar.timegm(tuple(timeParts))

def addTime(startTime, days=0, hours=0, minutes=0, seconds=0):
    """
    Take in a time in a baler's retrieve.htm format, and add time to it.
    """
    timeToAdd = seconds
    timeToAdd += (minutes * 60)
    timeToAdd += (hours * 60 * 60)
    timeToAdd += (days * 24 * 60 * 60)

    newTimeParts = time.gmtime(convertBalerTimeToEpochTime(startTime) + timeToAdd)
    return '%d/%02d/%02d %d:%02d:%02d' %newTimeParts[0:6]

from isti.librep.v2_3.urllib import *

###
# Much of this code is taken from urllib.py.  Some is prevented from being imported,
# but is needed none the less, and some is code from retrieve() that was needed to
# make a hacked retrieve
##
try:
    unicode
except NameError:
    def _is_unicode(x):
        return 0
else:
    def _is_unicode(x):
        return isinstance(x, unicode)

def toBytes(url):
    """toBytes(u"URL") --> 'URL'."""
    # Most URL schemes require ASCII. If that changes, the conversion
    # can be relaxed
    if _is_unicode(url):
        try:
            url = url.encode("ASCII")
        except UnicodeError:
            raise UnicodeError("URL " + repr(url) +
                               " contains non-ASCII characters")
    return url

class AccountingURLopener(FancyURLopener):
    def __init__(self, *args, **kwargs):
        FancyURLopener.__init__(self, *args, **kwargs)
        self.stopRequestCallback = None
        self.filesizeCallback = None
        self.mseedMode = False
        self.mseedByChannel = False
        self.readSock = None
        self.socketTimeout = 0
        self.checkpointReportingFunction = None
        self.forcedDatafileName = None
        self.transferBelowThresholdCount = 0
        self.maxFileSize = None
        self.ignoreDataStartingBefore = None

    def setIgnoreDataStartingBefore(self, v):
        self.ignoreDataStartingBefore = v
        
    def setForcedDatafileName(self, n):
        self.forcedDatafileName = n
        
    def setStopRequestCallback(self, func):
        self.stopRequestCallback = func

    def setFilesizeCallback(self, func):
        self.filesizeCallback = func

    def setMaxFileSize(self, v):
        self.maxFileSize = v
        
    def setTimeout(self, timeoutVal):
        self.socketTimeout = timeoutVal
        
    def open(self, url, data=None):
        newurl = url.replace(' ', '%20')
        return FancyURLopener.open(self, newurl, data)
        
    def setMSEEDMode(self, val):
        self.mseedMode = val

    def setByChannelForMSEED(self, val):
        self.mseedByChannel = val

    def setCheckpointReportingFunction(self, func):
        self.checkpointReportingFunction = func
        
    def retrieve(self, url, filename=None, reporthook=None, data=None, dirName=None, remoteFileName=False, auxInfoMap=None, filenameTemplate=None, minimumBPSThreshold=0, belowThresholdMinutesBeforeRetry=3):
        """retrieve(url) returns (filename, headers) for a local object
        or (tempfilename, headers) for a remote object."""
        url = unwrap(toBytes(url))
        if self.tempcache and url in self.tempcache:
            return self.tempcache[url]
        type, url1 = splittype(url)
        if filename is None and (not type or type == 'file'):
            try:
                fp = self.open_local_file(url1)
                hdrs = fp.info()
                del fp
                return url2pathname(splithost(url1)[1]), hdrs
            except IOError, msg:
                pass
        fp = self.open(url, data)
        realFP = fp.fp
        realFPSock = realFP._sock
        if self.socketTimeout:
            realFPSock.settimeout(1)
        
        headers = fp.info()

        if headers['Content-type'] == 'text/html':
            fp.close()
            return None, headers
        if callable(self.filesizeCallback):
            self.filesizeCallback( int(headers['Content-length']) )
            
        if remoteFileName:
            filename = string.split(fp.geturl(), '/')[-1]

        if dirName:
            filename = os.path.join(dirName, filename)
            
        if filename:
            if self.mseedMode:
                tfp = mseed.mseedFileWriter(filename, splitChannels=self.mseedByChannel)
                if self.checkpointReportingFunction:
                    tfp.setStatusLoggingFunction(self.checkpointReportingFunction)
                if self.ignoreDataStartingBefore:
                    tfp.setIgnoreDataStartingBefore(self.ignoreDataStartingBefore)
                filename = os.path.join(dirName, filenameTemplate)
                tfp.setFilenameTemplate(filename)
                if self.forcedDatafileName and ',' in self.forcedDatafileName:
                    allowedDatafiles = ','.split(self.forcedDatafileName)
                    tfp.setAllowedDatafileNames(allowedDatafiles)
                else:
                    tfp.setForcedDatafileName(self.forcedDatafileName)
                tfp.setMaxFileSizeInBytes(self.maxFileSize)
                if auxInfoMap:
                    tfp.setAuxFilenameReplacements(auxInfoMap)
            else:
                tfp = open(filename, 'wb')
        else:
            raise "No filename specified for download"
        result = filename, headers
        if self.tempcache is not None:
            self.tempcache[url] = result
        bs = 1024 * 4
        size = -1
        if reporthook:
            if "content-length" in headers:
                size = int(headers["Content-Length"])
            reporthook(0, bs, size)

        #block = realFPSock.recv(bs)
        #if reporthook:
        #    reporthook(1, bs, size)
        block = ''
        blocknum = 0
        numTimesZeroBytesReceived = 0
        completed = False

        ##
        # This while loop loops until all blocks are retrieved
        ##
        lastCheckpointTime = time.time()
        bytesSinceLastCheckpoint = 0
        while not completed: 
            
            block = ''
            numTries = 0

            ##
            # This while loop gets _1_ block
            ##
            while not block:
                # abort if the user requested it
                if callable(self.stopRequestCallback):
                    if self.stopRequestCallback():
                        retryInfo = tfp.getChannelsFilesSamplerateAndLastRecordEndTime()
                        if callable(self.checkpointReportingFunction):
                            self.checkpointReportingFunction("Transfer aborted, cleaning up...")
                        tfp.close()
                        if callable(self.checkpointReportingFunction):
                            self.checkpointReportingFunction("Done")
                        raise TransferAbortedException(retryInfo)
                try:

                    # read data
                    block = realFPSock.recv(bs)
                    if not len(block):
                        numTimesZeroBytesReceived += 1
                    if numTimesZeroBytesReceived == 10:
                        completed = True
                        break
                except socket.timeout, sto:
                    if block:
                        tfp.write(block)
                    numTries += 1
                    if blocknum == 0 and numTries > (self.socketTimeout * 2):
                        retryInfo = tfp.getChannelsFilesSamplerateAndLastRecordEndTime()
                        if callable(self.checkpointReportingFunction):
                            self.checkpointReportingFunction("Connection to station dropped, cleaning up...(1)")
                        tfp.close()
                        try:
                            realFPSock.close()
                            fp.close()
                        except:
                            pass
                        raise TransferTimedOutException(retryInfo)
                    elif numTries > self.socketTimeout:
                        retryInfo = tfp.getChannelsFilesSamplerateAndLastRecordEndTime()
                        if callable(self.checkpointReportingFunction):
                            self.checkpointReportingFunction("Connection to station dropped, cleaning up...(2)")
                        tfp.close()
                        try:
                            realFPSock.close()
                            fp.close()
                        except:
                            pass
                        raise TransferTimedOutException(retryInfo)
                except socket.error, se:
                    if block:
                        tfp.write(block)
                    retryInfo = tfp.getChannelsFilesSamplerateAndLastRecordEndTime()
                    if callable(self.checkpointReportingFunction):
                        self.checkpointReportingFunction("Connection to station dropped, cleaning up...(3)")
                    tfp.close()
                    try:
                        realFPSock.close()
                        fp.close()
                    except:
                        pass
                    raise TransferConnectionResetException(retryInfo)
                except IOError, ioe:
                    if block:
                        tfp.write(block)
                    retryInfo = tfp.getChannelsFilesSamplerateAndLastRecordEndTime()
                    if callable(self.checkpointReportingFunction):
                        self.checkpointReportingFunction("Connection to station dropped, cleaning up...(4)")
                    tfp.close()
                    try:
                        realFPSock.close()
                        fp.close()
                    except:
                        pass
                    raise TransferConnectionResetException(retryInfo)
                except Exception, e:
                    if block:
                        tfp.write(block)
                    retryInfo = tfp.getChannelsFilesSamplerateAndLastRecordEndTime()
                    if callable(self.checkpointReportingFunction):
                        self.checkpointReportingFunction("Connection to station dropped, cleaning up...(5)")
                    tfp.close()
                    try:
                        realFPSock.close()
                        fp.close()
                    except:
                        pass
                    ex = TransferDiedDueToAnErrorException(retryInfo)
                    ex.setRootExceptionInfoTuple(sys.exc_info())
                    raise ex
                    
            tfp.write(block)
            blocknum = blocknum + 1
            if reporthook:
                reporthook(blocknum, len(block), size)

            # some bookkeeping for checkpoints and transfer thresholds
            bytesSinceLastCheckpoint += len(block)
            rightNow = time.time()
            if (completed and (rightNow != lastCheckpointTime)) or (rightNow - lastCheckpointTime) > 60:
                if completed:
                    tfp.processBuffer()
                bps = bytesSinceLastCheckpoint / (rightNow-lastCheckpointTime)

                ##
                # See if we're proceeding too slow, and should trigger a restart as a
                # result
                ##
                if minimumBPSThreshold and belowThresholdMinutesBeforeRetry:
                    if bps < minimumBPSThreshold:
                        self.transferBelowThresholdCount += 1
                        if self.transferBelowThresholdCount > belowThresholdMinutesBeforeRetry:
                            raise TransferProceedingTooSlowException(tfp.getChannelsFilesSamplerateAndLastRecordEndTime())
                    else:
                        self.transferBelowThresholdCount = 0

                ##
                # Dump a transfer checkpoint to the log
                ##
                if self.mseedMode and self.checkpointReportingFunction:
                    stats = tfp.getChannelStats()
                    currentLine = '  '

                    sortedChannels = stats.keys()
                    sortedChannels.sort()
                    self.checkpointReportingFunction('Transfer Checkpoint (%d channels):' %len(sortedChannels))
                    numBytesString = isti.utils.convertUtils.formatBytes(bytesSinceLastCheckpoint)
                    perSecondString = isti.utils.convertUtils.formatBytes(bps, bias='k')
                    self.checkpointReportingFunction('  %s since last checkpoint (%s/s)' %(numBytesString, perSecondString))
                    for channel in sortedChannels:
                        currentLine += '%s:%d ' %(channel, stats[channel])
                        if len(currentLine) > 40:
                            self.checkpointReportingFunction(currentLine)
                            currentLine = '  '
                    if currentLine != '  ':
                        # there's more that hasn't been written
                        self.checkpointReportingFunction(currentLine)

                bytesSinceLastCheckpoint = 0
                lastCheckpointTime = time.time()
                        
                        

                
        fp.close()
        tfp.close()
        del fp
        del tfp
        return result
#####
# End of urllib code
#####

_OurOpener = AccountingURLopener

class AccountingURL:
    """
    This is a wrapper class for dealing with URLs.  It allows for somewhat
    poor bandwidth accounting (headers are ignored)
    """
    def __init__(self, toOpen, txCallback=None, rxCallback=None, stopRequestCallback=None, retryPattern=None, connectedSocketTimeout=None):
        self.txCallback = txCallback
        self.rxCallback = rxCallback
        self.incrementBytesSent(10 + len(toOpen))
        #self.opener = WGetURLopener()
        #self.opener = AccountingURLopener()
        self.opener = _OurOpener()
        self.opener.setRetryPattern(retryPattern)
        self.opener.setConnectedSocketTimeout(connectedSocketTimeout)
        self.opener.setStopRequestCallback(stopRequestCallback)
        self.urlOb = self.opener.open(toOpen)
        
    def __del__(self):
        try:
            self.opener.close()
        except:
            pass

        try:
            self.urlOb.close()
        except:
            pass
        
    def incrementBytesSent(self, numBytes):
        if self.txCallback:
            self.txCallback(numBytes)
            
    def incrementBytesReceived(self, numBytes):
        if self.rxCallback:
            self.rxCallback(numBytes)
                           
    def read(self):
        f = self.urlOb.read()
        self.incrementBytesReceived(len(f))
        return f
    
    def readline(self):
        f = self.urlOb.readline()
        self.incrementBytesReceived(len(f))
        return f

    def close(self):
        self.opener.close()
        self.urlOb.close()

    def info(self):
        return self.urlOb.info()

    def geturl(self):
        return self.urlOb.geturl()
    
class Baler(QDPDevice):
    """
    An interface for talking to a Baler.

    This class extends the QDPDevice class to include methods that
    are specific to dealing with the baler14.
    """
    def __init__(self):
        QDPDevice.__init__(self)        
        self.setDeviceType("Baler14")
        self.setBasePort(5331)
        self.versionMajor = None
        self.versionMinor = None
        self.versionModifier = None
        self.hasRawFiles = None
        self.balerType = None
        self.Q330SerialNumber = None
        self.tagID = None
        self.displayName = None
        self.retrievedData = None
        self.stopRequestCallback=None
        self.currentTransferSize = 0
        self.setWebPort(80)
        self.expressModeReload = False
        self.displayName = ''
        
    def openUrl(self, url):
        success = False
        failureCount = 0
        retryPattern = [4, 4, 4, 8, 8, 8, 12, 12, 12]
        while not success: 
            try:
                ret = AccountingURL(url, txCallback=self.incrementBytesSent, rxCallback=self.incrementBytesReceived, stopRequestCallback=self.stopRequestCallback, retryPattern=retryPattern, connectedSocketTimeout=120)
                success = True
            except Exception, e:
                if failureCount > 5:
                    raise e
                failureCount += 1
        return ret

    def openUrlAndGetText(self, url):
        failureCount = 0
        urlOb = self.openUrl(url)
        success = False
        while not success:
            try:
                ret = urlOb.read()
                urlOb.close()
                success = True
            except Exception, e:
                if failureCount > 5:
                    raise e
                else:
                    try:
                        urlOb.close()
                    except:
                        pass
                    urlOb = self.openUrl(url)
                    failureCount += 1
        return ret
            
    def retrieveUrl(self, url, fileName=None, postData=None, dirName=None, mseedMode=False,  auxInfoMap=None, filenameTemplate=None, socketTimeout=0, checkpointReportingFunction=None, forcedDatafileName=None, maxFileSize=None, ignoreDataStartingBefore=None):
        #opener = WGetURLopener()
        opener = _OurOpener()
        opener.setMSEEDMode(mseedMode)
        if socketTimeout:
            opener.setTimeout(socketTimeout)
        opener.setIgnoreDataStartingBefore(ignoreDataStartingBefore)
        opener.setCheckpointReportingFunction(checkpointReportingFunction)
        opener.setStopRequestCallback(self.stopRequestCallback)
        opener.setFilesizeCallback(self.filesizeCallback)
        opener.setForcedDatafileName(forcedDatafileName)
        opener.setMaxFileSize(maxFileSize)
        ret = opener.retrieve(url, fileName, self.urlRetrieveReportingCallback, postData, dirName=dirName, remoteFileName=True, auxInfoMap=auxInfoMap, filenameTemplate=filenameTemplate)
        opener.close()
        urllib.urlcleanup()
        return ret

    def setStopRequestCallback(self, func):
        self.stopRequestCallback = func
        
    def urlRetrieveReportingCallback(self, numBlocks, numBytes, totalBytes):
        self.incrementBytesReceived(numBytes)
        self.currentTransferSize = totalBytes

    def getCurrentTransferSize(self):
        return self.currentTransferSize
        
    def getBalerType(self):
        """
        Return the type of baler this is ('Desktop' or 'Field')
        """
        if self.balerType == None:
            self.getGeneralInfo()
        return self.balerType

    def setSwappedBalerSerialNumber(self, num):
        swappedSN = struct.unpack('>Q', struct.pack('<Q', num))[0]
        self.setBalerSerialNumber(swappedSN)

    def getDisplayName(self):
        """
        Get the "display name" for a baler.  This is it's tagID if available, it's
        serial number if not.  This is returned by a string
        """
        if self.displayName:
            return self.displayName
        ret = self.getTagID()
        if not ret:
            ret = '%x' %self.getBalerSerialNumber()

        self.setDisplayName(ret)
        
        return ret

    def setDisplayName(self, displayName):
        self.displayName = displayName
        
    def getPortForCommand(self, cmd):
        """ 
        we have two ports we need to worry about.  5331 for RL_CMD and
        our internal port for everything else.  This is called during a sendCommand()
        call, to determine which port to use for the command being sent.
        """
        if cmd.QDPCommand == CmdID.RL_CMD:
            return self.getBasePort()
        return self.getInternalPort()
        
    def ping(self):
        """
        Using a c2_bcmd, send a "0 command"
        """
        bcmd = Cmds.c2_bcmd()
        bcmd.setBalerCommand(Cmds.BCMD_PING)
        return self.sendCommand(bcmd)
    
    def deallocate(self):
        """
        We're using the undocumented RL_CMD packet to do the shutdown,
        since we don't need any prior knowledge (what port the baler is on)
        for this
        """
        #bcmd = Cmds.c2_bcmd()
        #bcmd.setBalerCommand(Cmds.BCMD_DEALLOC)
        #return self.sendCommand(bcmd, skipReceive=1)
        self.login()
        rlcmd = Cmds.rl_cmd()
        rlcmd.setCommandType(Cmds.RLCMD_REBOOT)
        self.sendCommand(rlcmd, skipReceive=1)

    def serialLoopbackEnabled(self):
        """
        Is the serial loopback currently enabled
        """
        serialInfo = self.getSerialStatus()
        return serialInfo.has_key('Loopback Packets Sent')

    def setSerialLoopback(self, newState):
        """
        Set the serial loopback to a particular state.
        This method only sets up the baler.ini, no reboot is
        started.
        """

        if self.versionIsAtLeast('1.46'):
            bcmd = Cmds.c2_bcmd()
            bcmd.setMode(Cmds.BCMD_SETLOOPBACK)
            bcmd.setCommandSpecificInformation(newState)
            return self.sendCommand(bcmd)
    
    def login(self, expressModeRequest = False):
        """
        request a login
        """

        rlcmd = Cmds.rl_cmd()
        rlcmd.setBlockNumber(0)
        rlcmd.setCommandType(Cmds.RLCMD_LOGIN_REQUEST)
        if expressModeRequest:
            rlcmd.setExpressMode(0x552E)
        else:
            rlcmd.setExpressMode(0)
        tmpRT = self.getReceiveTimeout()
        loginAck = self.sendCommand(rlcmd)
        #print loginAck
        #print 'ack: %x' %loginAck.getExpressMode()
        if loginAck.getExpressMode() == 0xD4AA:
            self.expressModeReload = True
            if not expressModeRequest:
                print 'We got express mode and did not want it!!!'
        #self.setReceiveTimeout(1)
        #try:
        #    self.sendCommand(rlcmd)
        #    self.setReceiveTimeout(tmpRT)
        #except:
        #    self.setReceiveTimeout(tmpRT)

        
    def doAllocDelete(self, opList):
        """
        Perform a "type 2" c2_bcmd
        opList is a list of bits to set
        """
        bcmd = Cmds.c2_bcmd()
        bcmd.setMode(Cmds.BCMD_ALLOC_DELETE)
        bitmask = 0
        for val in opList:
            bitmask = bitmask | val
        bcmd.setCommandSpecificInformation(bitmask)
        return self.sendCommand(bcmd)

    def setBalerTime(self):
        """
        set baler's time
        """
        baseTime = calendar.timegm( (2000, 1, 1, 0, 0, 0, 0, 0, 0) )
        rightNow = time.time() - baseTime

        bcmd = Cmds.c2_bcmd()
        bcmd.setMode(Cmds.BCMD_SETCLOCK)
        bcmd.setBalerCommand(Cmds.BCMD_SETCLOCK)
        bcmd.setCommandSpecificInformation(long(rightNow))
        #print 'Setting time'
        ret = self.sendCommand(bcmd)
        #print 'done'
        return ret
    
    def getAllocationResults(self):
        """
        Perform a "type 3" c2_bcmd and return an array of strings
        """

        bcmd = Cmds.c2_bcmd()
        bcmd.setBalerCommand(Cmds.BCMD_GETALLOC)
        resultStrings = []
        
        bcmd.setSequencingField(0)
        result = self.sendCommand(bcmd)
        info = result.getInfo()
        currentByte = 0
        
        while currentByte < len(info):
            strlen = ord(info[currentByte])
            if strlen > 0:
                resultStrings.append(info[currentByte+1:currentByte+strlen+1])
            currentByte = currentByte+strlen+1
        
        return resultStrings
                                     
    def getTagID(self):

        if self.getStation():
            return self.getStation().getName()
        
        """
        get a baler's tagID.  This is gathered from the baler's c:\tag.id file
        """
        if self.tagID:
            return self.tagID
        
        try:
            tag = string.strip(self.getFile('tag.id'))
            self.tagID = tag
            return tag
        except:
            return None

    def setTagID(self, newID):
        """
        Set a baler's tagID.  This is intended to be used to tell a baler it's ID if it has
        none, or correct it if it's wrong (if a baler's guts end up in another baler's body
        """
        self.putFile('tag.id', '%s' %newID)

    def getQ330SerialNumber(self):
        """
        Get the serial number of the Q330 that the baler will try to communicate with.
        This comes from the baler's station.ini (d:\IDX\station.ini).  This does not
        mean the baler has ever successfully talked with the Q330 in question
        """
        if self.Q330SerialNumber not in  (None, 1):
            return self.Q330SerialNumber

        stationIniLines = string.split(self.getFile('d:\\IDX\\station.ini'), '\r\n')
        self.Q330SerialNumber = 0
        for line in stationIniLines:
            if not line:
                continue
            if 'q330sn' in line:
                sn = long( string.strip(string.split(line, '=')[1]), 16)
                self.Q330SerialNumber = struct.unpack('>Q', struct.pack('<Q', sn))[0]
        return self.Q330SerialNumber

    def setQ330SerialNumber(self, num):
        self.Q330SerialNumber = num
        
    def getFile(self, filename):
        """ 
        get a file off of the baler
        """
        self.login()
        rlcmd = Cmds.rl_cmd()
        fnameAsPascalString = struct.pack('200p', filename)
        fnameAsPascalString = fnameAsPascalString[: (ord(fnameAsPascalString[0])+1)]
        rlcmd.setCommandType(Cmds.RLCMD_READ_REQUEST, '                %s' %fnameAsPascalString)
        rlcmd.setBlockNumber(0)
        rlcmd.setFilename(filename)
        fileparts = self.sendCommand(rlcmd, receiveMultiple=1)
        fileBytes = []
        for part in fileparts:
            if part.getData():
                fileBytes.append(part.getData())
        return string.join(fileBytes, '')
        
    def putFile(self, filename, dataBytes, forceNonExpressMode=False, stopRequestCallback=None):
        """
        send a file to the baler
        """

        #dos-ify .ini and .bat files.  The logic here is that anything that looks like
        #\r, \n, or \r\n should all look like \r\n.
        if '.' in filename:
            ext = string.split(filename, '.')[1]
            if filename in ('config.sys', ) or ext in ('ini', 'bat'):
                dataBytes = dataBytes.replace('\r\n', '<SLASHRSLASHN>')
                dataBytes = dataBytes.replace('\n', '\r\n')
                dataBytes = dataBytes.replace('\r\n', '<SLASHRSLASHN>')
                dataBytes = dataBytes.replace('\r', '\r\n')
                dataBytes = dataBytes.replace('<SLASHRSLASHN>', '\r\n')

        displayName = self.getDisplayName()
        
        # We _need_ to be in express mode to put a file remotely
        if self.getViaStation():
            forceNonExpressMode = False
            
        if not forceNonExpressMode:
            self.login(True)
        else:
            self.login()
            
        fnameAsPascalString = struct.pack('200p', filename)
        fnameAsPascalString = fnameAsPascalString[: (ord(fnameAsPascalString[0])+1)]

        rlcmd = Cmds.rl_cmd()
        rlcmd.setCommandType(Cmds.RLCMD_WRITE_REQUEST, '                %s' %fnameAsPascalString)
        rlcmd.setBlockNumber(0)
        rlcmd.setFilename(filename)
        ack = self.sendCommand(rlcmd)
        dataPtr = 0
        blockCounter = 1
        numBytesToSend = 0

        numDataBytes = len(dataBytes)
        sizeContainer512 = struct.pack(">BBBBBBH", 0, 0, 0, 0, 0, 0, 512 + 4)
        slidingWindow = []
        #duringTransferTimeout = .1
        ##
        # make this long for VERY slow connections.  This will only be reached if we receive ZERO
        # bytes for this ammount of time
        ##
        duringTransferTimeout = 10

        if self.expressModeReload:
            oldTimeout = self.getReceiveTimeout()
            self.setReceiveTimeout(duringTransferTimeout)

        while dataPtr < numDataBytes:
            if callable(stopRequestCallback) and stopRequestCallback():
                # we've been asked to abort
                return #break
            numBytesToSend = numDataBytes - dataPtr
            if numBytesToSend >= 512:
                data = dataBytes[dataPtr:dataPtr + 512]    
                numBytesToSend = 512
                sizeContainer = sizeContainer512
            else:
                data = dataBytes[dataPtr:numDataBytes]
                sizeContainer = struct.pack(">BBBBBBH", 0, 0, 0, 0, 0, 0, numBytesToSend + 4)  

            dataPtr = dataPtr + numBytesToSend

            # hack here, to make the setCommandType work properly
            rlcmd = Cmds.rl_cmd()
            rlcmd.setCommandType(Cmds.RLCMD_DATA, sizeContainer)

            rlcmd.setBlockNumber(blockCounter)
            blockCounter += 1
            rlcmd.setData(data)
            if forceNonExpressMode or not self.expressModeReload:
                ack = self.sendCommand(rlcmd)
            else:
                acks = []
                    
                slidingWindow.append(rlcmd)
                #print '[%s] Sending block %d' %(displayName, rlcmd.getBlockNumber())
                self.sendCommand(rlcmd, singleSend=True, skipReceive=True)

                lastPacketSent = False
                if dataPtr == len(dataBytes):
                    lastPacketSent = True


                previousFirstBlock = 0

                while (len(slidingWindow) == 4) or (lastPacketSent and len(slidingWindow) > 0):
                    if callable(stopRequestCallback) and stopRequestCallback():
                        # we've been asked to abort
                        return #break

                    resendWindow = False
                    try:
                        #print '[%s] Waiting for acks' %displayName
                        acks = self.receiveResponse()
                        if type(acks) != list:
                            acks = [acks]
                        #print '[%s] Got %d acks' %(displayName, len(acks))
                    except socket.timeout:
                        #print '[%s] Got socket timeout' %displayName
                        resendWindow = True
                    except Quasar.QDPDevice.TimeoutException:
                        #print '[%s] Got TimeoutException' %displayName
                        resendWindow = True


                    for data_ack in acks:
                        baseBlock = data_ack.getBlockNumber()
                        ackBits = data_ack.getAcknowledgementMask()
                        #print '  AckBits: %d' %ackBits
                        
                        for bitPower in range(0, 4):
                            if bitPower > (len(slidingWindow)-1):
                                continue
                            bitVal = pow(2, bitPower)
                            if ackBits & bitVal:
                                #print '    AckBit power %d (%d) is true' %(bitPower, pow(2, bitPower))

                                # this means we're acking this, and any earlier blocks
                                ackedBlock = baseBlock + bitPower
                                for i in range(0, len(slidingWindow)):
                                    pkt = slidingWindow[i]
                                    if not pkt:
                                        continue
                                    # anything before the 'base' is ack'd implicitly
                                    # then, using that as the first in the window, ack the packet represented by this bit
                                    if pkt.getBlockNumber() < baseBlock or pkt.getBlockNumber() == ackedBlock:
                                        #print "      Ackd block number %d" %pkt.getBlockNumber()
                                        slidingWindow[i] = None

                    while len(slidingWindow) and slidingWindow[0] == None:
                        slidingWindow = slidingWindow[1:]

                    # process resends if the first block is still the first
                    if (len(slidingWindow) and previousFirstBlock == slidingWindow[0].getBlockNumber()) or resendWindow:
                        for sentPacket in slidingWindow:
                            if sentPacket:
                                #print '[%s] Resending block %d' %(displayName, sentPacket.getBlockNumber())
                                self.sendCommand(sentPacket, singleSend=True, skipReceive=True)

                        previousFirstBlock = slidingWindow[0].getBlockNumber()
                    else:
                        previousFirstBlock = 0
                    
                        
        # The baler only considers a file "done" when it receives a RLCMD_DATA with
        # < 512 bytes in it.  If this file's size was an even multiple of 512, we need to
        # send a zero-byte RLCMD_DATA
        if numBytesToSend == 512: 
            time.sleep(1)
            rlcmd = Cmds.rl_cmd()
            sizeContainer = struct.pack(">BBBBBBH", 0, 0, 0, 0, 0, 0, 4)  
            rlcmd.setCommandType(Cmds.RLCMD_DATA, sizeContainer)
            rlcmd.setBlockNumber(blockCounter)
            ack = self.sendCommand(rlcmd)

        if self.expressModeReload:
            self.setReceiveTimeout(oldTimeout)
            m = hashlib.new("md5")
            m.update(dataBytes)
            mdCmd = Cmds.rl_cmd()
            mdCmd.setCommandType(Cmds.RLCMD_MD5_RES)
            mdCmd.setMD5Result(m.digest())
            #print 'Sending MD5'
            ack = self.sendCommand(mdCmd)
            #print 'Sent, got:\n %s' %ack
                               
        return ack
             
    def getThreadStatus(self):
        """
        get information from threads.htm
        """
        #urlOb = self.openUrl('http://%s:%d/threads.htm' %(self.getIPAddress(), self.getWebPort()))
        #rawInfo = urlOb.read()
        #urlOb.close()

        rawInfo = self.openUrlAndGetText('http://%s:%d/threads.htm' %(self.getIPAddress(), self.getWebPort()))
        rawInfo = string.split(rawInfo, "<PRE>")[1]
        rawInfo = string.split(rawInfo, "</PRE>")[0]
        rawInfo = rawInfo.replace('<U>', '')
        rawInfo = rawInfo.replace('</U>', '')
        return rawInfo

    def supportsRawFileMode(self):
        """
        Does this baler support "rawfiles" mode.  This mode allows any file
        on any partition to be retrieved via the web server (therefor much faster
        than retrieval via the UDP retrieve protocol
        """
        if self.hasRawFiles != None:
            return self.hasRawFiles
        else:
            test = self.getRawFile('c:\\baler.ini')
            if '404 Not Found' in test:
                self.hasRawFiles = 0
            else:
                self.hasRawFiles = 1

            return self.hasRawFiles
        
    def getRawFile(self, filename):
        """
        get a file using the "rawfiles" method
        """
        drive, path = string.split(filename, ':')
        path = path.replace('\\', '/')
        drive = 'raw%s_' %string.upper(drive)
        newfilename = '%s%s' %(drive, path)
        ret = self.openUrlAndGetText('http://%s:%d/%s' %(self.getIPAddress(), self.getWebPort(), newfilename))
        return ret

    def getLogfile(self, fileOb, oneLineAtATime=0):
        """
        Get the baler's logfile.  This uses the same mechanism inside the baler as
        getting "messages" from the retrieve.htm page
        """
        logdata = self.openUrl('http://%s:%d/RETRIEVE.HTM?REQ=Messages' %(self.getIPAddress(), self.getWebPort()))

        if oneLineAtATime:
            line = logdata.readline()
            while line:
                fileOb.write(line)
                line = logdata.readline()
        else:
            fileOb.write(logdata.read())
            
        logdata.close()

    def getVersionString(self):
        """
        Get the baler's software version as a string
        """
        return '%d.%d%s' %self.getVersionTuple()
    
    def getVersionTuple(self):
        """ return the baler software rev as a major,minor,modifier tuple """

        # return it, if we have it already
        if self.versionMajor != None and self.versionMinor != None:
            return (self.versionMajor, self.versionMinor, self.versionModifier)
        
        versionString = self.getGeneralInfo()['SoftwareVersion']
        major, rawMinor = string.split(versionString, '.')

        minor = []
        modifier = []

        foundNonNum = 0
        for char in rawMinor:
            if foundNonNum:
                modifier.append(char)
            else:
                if char in '0123456789':
                    minor.append(char)
                else:
                    modifier.append(char)
                    foundNonNum = 1

        self.versionMajor = int(major)
        self.versionMinor = int(string.join(minor, ''))
        self.versionModifier = string.join(modifier, '')
        
        return (self.versionMajor, self.versionMinor, self.versionModifier)

    def setVersion(self, minor, major, modifier):
        """
        Set this baler object instance's version.  This does not affect the physical baler
        at all and is meant to be used internally
        """
        self.versionMajor = major
        self.versionMinor = minor
        self.versionModifier = modifier

    def versionIsAtLeast(self, target):
        """ Is this baler at least "target" version.  Target is supplied as a string"""
        ourMajor, ourMinor, modifier = self.getVersionTuple()
        targetMajor, targetMinor = string.split(target, '.')

        ourMajor = ourMajor
        ourMinor = ourMinor
        targetMajor = int(targetMajor)
        targetMinor = int(targetMinor)

        if targetMajor > ourMajor:
            return 0

        if targetMajor < ourMajor:
            return 1

        if targetMinor > ourMinor:
            return 0

        return 1

    def getStationInfo(self):
        """
        This only works when we're connected to a Q330
        """
        info = {}
        if self.getViaStation():
            rawInfo = self.openUrlAndGetText('http://%s:%d/info.htm' %(self.getIPAddress(), self.getWebPort()))

            try:
                info['Q330Serial'] = re.search('Q330 Serial Number: (.*)>(.*)</A>(.*)', rawInfo).group(2)
            except:
                info['Q330Serial'] = "Unavailable"
            return info
        else:
            info['Q330Serial'] = ""
    
    def getGeneralInfo(self):
        """
        Get the pieces of info available on the /baler.htm page
        """
        rawBalerInfo = self.openUrlAndGetText('http://%s:%d/baler.htm' %(self.getIPAddress(), self.getWebPort()))

        info = {}
        try:
            info['BalerModel'] = re.search("Baler Model: ([^ ^<^\n^\r]*)", rawBalerInfo).group(1)
        except:
            info['BalerModel'] = 'Unknown'

        try:
            info['SoftwareVersion'] = re.search("Software Version: ([^ ^<^\n^\r]*)", rawBalerInfo).group(1)
        except:
            info['SoftwareVersion'] = 'Unknown'

        try:
            info['MAC Address'] = re.search("MAC Address: ([^ ^<^\n^\r]*)", rawBalerInfo).group(1)
        except:
            info['MAC Address'] = 'Unknown'

        try:
            info['DiskSize'] = int(re.search("Disk Size: ([^ ^<^\n^\r]*)", rawBalerInfo).group(1))
        except:
            info['DiskSize'] = 'Unknown'

        try:
            info['Baler TAGID'] = int(re.search("Baler TAGID: ([^ ^<^\n^\r]*)", rawBalerInfo).group(1))
        except:
            info['Baler TAGID'] = 0
            
        if rawBalerInfo.find('DMU1') != -1:
            info['DMU1SoftwareVersion'] = re.search("DMU1 Software Version=([^ ^<^\n^\r]*)", rawBalerInfo).group(1)
            self.balerType = 'Desktop'
        if rawBalerInfo.find('DMU2') != -1:
            dmuMatch = re.search("DMU2 Software Version=([^,]*), Serial Number=([^ ^<^\n^\r]*)", rawBalerInfo)
            info['DMU2SoftwareVersion'] = dmuMatch.group(1)
            info['DMU2SerialNumber'] = dmuMatch.group(2)
            self.balerType = 'Field'
            
        if rawBalerInfo.find('Supply Voltage') != -1:
            info['SupplyVoltage'] = re.search("Supply Voltage=([^ ^<^\n^\r]*)", rawBalerInfo).group(1)

        if rawBalerInfo.find('Supply Current') != -1:
            info['SupplyCurrent'] = re.search("Supply Current=([^ ^<^\n^\r]*)", rawBalerInfo).group(1)
            
        dataFileMatch = re.search("Percent of ([0-9]*) data files in use: ([^ ^<^\n^\r]*)", rawBalerInfo)
        if dataFileMatch:
            info['NumDataFiles'] = dataFileMatch.group(1)
            info['PercentageDataFilesInUse'] = dataFileMatch.group(2)

        if rawBalerInfo.find('Temperature') != -1:
            info['Temperature'] = re.search("Temperature=([^ ^<^\n^\r]*)", rawBalerInfo).group(1)[:-1]

        if rawBalerInfo.find('Disk Model') != -1:
            diskMatch = re.search("Disk Model: (.*) Revision: ([^ ^<^\n^\r]*)", rawBalerInfo)
            info['DiskModel'] = diskMatch.group(1)
            info['DiskRevision'] = diskMatch.group(2)
        return info
        
    def getEthernetStatus(self):
        """
        Get the ethernet port status
        """
        return self.internal_getStatusItemsBetween('<H3>Baler Ethernet Status</H3>', '<H3>Baler Serial Port Status</H3>')

    def getSerialStatus(self):
        """
        Get the serial port status
        """
        return self.internal_getStatusItemsBetween('Baler Serial Port Status', '</HTML>')
        


        
    def getAvailableDatafileInfo(self):
        """
        Return information about the data files.  This is gathered from files.htm
        """
        ret = []
        rawInfo = self.openUrlAndGetText('http://%s:%d/files.htm' %(self.getIPAddress(), self.getWebPort()))
        rawInfo = string.split(rawInfo, "<PRE>")[1]
        rawInfo = string.split(rawInfo, "</PRE>")[0]
        lines = string.split(rawInfo, '\r\n')
        lineSplitter = re.compile('<A HREF="([^"]*)">[^<]*</A>([^b]*)bytes, from ([^t]*)to (.*)')
        for line in lines:
            match = lineSplitter.search(line)
            if match == None:
                continue
            thisFile = {}
            thisFile['fileName'] = string.strip(match.group(1))
            thisFile['fileSize'] = int(string.strip(match.group(2)))
            thisFile['startDate'] = isti.utils.convertUtils.makeEpochTime(string.strip(match.group(3)))
            thisFile['endDate'] = isti.utils.convertUtils.makeEpochTime(string.strip(match.group(4)))
            ret.append(thisFile)
        return ret                

    def getAvailableData(self, globChannelThreshold=86400, channels='??-???', startTime='', endTime=''):
        """
        Return a list of (channel, start, end) tuples representing the available data
        This information is gathered using the "list data avail" mechanism from retrieve.htm,
        with the SEED name "???"
        """
        channels = urllib.quote(channels)
        startTime = urllib.quote(startTime)
        endTime = urllib.quote(endTime)
        
        availableData = self.openUrlAndGetText('http://%s:%d//RETRIEVE.HTM?SEED=%s&MAX=&BEG=%s&END=%s&FILE=&REQ=List+Data+Avail.&DONE=YES' %(self.getIPAddress(), self.getWebPort(), channels, startTime, endTime))

        lines = availableData.split('\n')
        insideData = 0
        ret = []
        CombineChannelInfo = {'LOG' : [],
                              'OCF' : [],
                              'ACE' : []}

        #print '--------------------'
        for line in lines:
            #print line
            line = line.strip()
            if line == '</PRE>':
                insideData = 0

            if insideData:
                #channel = line[0:6].strip()
                #start = line[5:24]
                #end = line[27:46]
                parts = line.split()
                channel = parts[0]
                start = '%s %s' %(parts[1], parts[2])
                end = '%s %s' %(parts[4], parts[5])

                if channel in CombineChannelInfo.keys():
                    if (CombineChannelInfo[channel] == []) or (isti.utils.convertUtils.makeEpochTime(end) -
                                                               isti.utils.convertUtils.makeEpochTime(CombineChannelInfo[channel][-1]['end'])) > globChannelThreshold:

                        CombineChannelInfo[channel].append( {'start' : start, 'end' : end} )
                    else:
                        CombineChannelInfo[channel][-1]['end'] = end
                else:
                    ret.append((channel, start, end))
                
            if line == '<PRE>':
                insideData = 1

        for combinedChannel in CombineChannelInfo.keys():
            for chunk in CombineChannelInfo[combinedChannel]:
                ret.append( (combinedChannel, chunk['start'], chunk['end']) )
            
        return ret
        
    def getDatafile(self, dataFileName):
        """
        Get an entire datafile from the baler.  This is one step above getting the raw
        datafile.  The baler may perform some pre-retrieval operations on this data.  THis
        is the equivilent of clicking on a file on the files.htm page
        """
        ret = self.openUrlAndGetText('http://%s:%d/%s' %(self.getIPAddress(), self.getWebPort(), dataFileName))
        return ret

    def getDataMarkedAsRetrieved(self):
        """
        return a list of (channel, dataStartInUnixEpoch, dataEndInUnixEpoch) representing the
        data that this baler has been told to mark as "retrieved"
        """
        
        logFile = self.getFile('dataretr.log')
        lines = logFile.split('\r\n')
        ret = []
        for line in lines:
            if line:
                channel, start, end = line.split('|')
                ret.append((channel, convertBalerTimeToEpochTime(start), convertBalerTimeToEpochTime(end)))
        return ret
    
    def markDataAsRetrieved(self, dataChunks=[]):
        """
        takes a list of 3-tuples (seedNames, startingTime, endingTime) describing the
        timespans of data to be marked as retrieved.  A single tuple may be passed in
        to handle a single piece of data
        """
        # remove our internal list, it'll be rebuilt when needed
        self.retrievedData = None
        
        if type(dataChunks) == type( (1, ) ) and len(dataChunks==3):
            dataChunks = [ dataChunks ]

        logFile = self.getFile('dataretr.log')

        for chunk in dataChunks:
            newLine = '%s|%s|%s\r\n' %chunk
            if newLine not in logFile:
                logFile += newLine

        self.putFile('dataretr.log', logFile)

    def clearRetrievalLog(self):
        """
        Blank the list of data that has been marked as retrieved
        """
        self.putFile('dataretr.log', '\r\n')

    def buildRetrievedDataList(self):
        """
        read in, and store the list of data that has been marked as retrieved.  This is
        meant for internal use (populates self.retrievedData)
        """
        self.retrievedData = self.getDataMarkedAsRetrieved()
        
    def dataRetrieved(self, seedName, startingTime, endingTime):
        """
        Has the data represented by seedName, startingTime, endingTime been marked as retrieved?
        startingTime and endingTime may be strings (baler retrieve time) or numeric (epoch time)
        """
        if not self.retrievedData:
            self.buildRetrievedDataList()

        # if these are strings, then they're not yet in epoch time (in the case of a
        # recursive call, they'll already be in epoch time
        if type(startingTime) == type(' '):
            startingTime = convertBalerTimeToEpochTime(startingTime)
        if type(endingTime) == type(' '):
            endingTime = convertBalerTimeToEpochTime(endingTime)

            
        for chunk in self.retrievedData:
            if seedUtils.channelMatch(seedName, chunk[0]):
                chunkStart = chunk[1]
                chunkEnd = chunk[2]
                # see if we're contained completely within this chunk
                if startingTime >= chunkStart and endingTime <= chunkEnd:
                    return 1
                # we hang off the end of this chunk, so recurse with the hanging-off part
                if (startingTime >= chunkStart) and (startingTime < chunkEnd) and (endingTime > chunkEnd):
                    return self.dataRetrieved(seedName, chunkEnd, endingTime)
                # we hang off the start of this chunk.  Recurse with the hanging off part
                if (startingTime < chunkStart) and (endingTime > chunkStart) and (endingTime <= chunkEnd):
                    return self.dataRetrieved(seedName, startingTime, chunkStart)
                # finally, we hang off both sides
                if startingTime < chunkStart and endingTime > chunkEnd:
                    return self.dataRetrieved(seedName, chunkEnd, endingTime) and self.dataRetrieved(seedName, startingTime, chunkStart)

        return 0

    def getDataSize(self, seedNames='', recordLimit='', startingTime='', endingTime=''):
        rqData = {
            'SEED' : seedNames,
            'MAX' : recordLimit,
            'BEG' : startingTime,
            'END' : endingTime,
            'REQ' : 'Download Data'
            }
        rqQS = urllib.urlencode(rqData)
        url = 'http://%s:%d/RETRIEVE.HTM?%s' %(self.getIPAddress(), self.getWebPort(), rqQS)
        urlOb = self.openUrl(url)
        headers = urlOb.info()
        urlOb.close()
        if headers['Content-type'] == 'text/html':
            return 0

        print '%s : %s' %(self.getDisplayName(), headers['Content-length'])
        return int(headers['Content-length'])
            
    def getData(self, dataDirectory, seedNames='', recordLimit='', startingTime='', endingTime='', filesizeCallback=None, auxInfoMap=None, filenameTemplate=None, checkpointReportingFunction=None, forcedDatafileName=None, maxFileSize=None, ignoreDataBeforeStartTime=False):
        """
        get data from the baler, and write it to a file in dataDirectory.  The file name used
        is dictated by the baler
        """
        self.filesizeCallback=filesizeCallback
        startTimeAsEpoch = None
        if ignoreDataBeforeStartTime:
            startTimeAsEpoch = convertBalerTimeToEpochTime(startingTime)
        rqData = {
            'SEED' : seedNames,
            'MAX' : recordLimit,
            'BEG' : startingTime,
            'END' : endingTime,
            'REQ' : 'Download Data'
            }
        rqQS = urllib.urlencode(rqData)
        url = 'http://%s:%d/RETRIEVE.HTM?%s' %(self.getIPAddress(), self.getWebPort(), rqQS)
        #f = self.openUrl('http://%s/RETRIEVE.HTM?%s' %(self.getIPAddress(), rqQS))
        #urlOb = self.openUrl(url)
        #if urlOb.info()['Content-type'] == 'text/html':
            # data wasn't available
        #    urlOb.close()
        #    del urlOb
        #    return None
        #filename = string.split(urlOb.geturl(), '/')[-1]
        #urlOb.close()
        #del urlOb
        #outFileName = os.path.join(dataDirectory, filename)
        #count = 2
        #while os.path.isfile('%s_%d' %(outFileName, count)):
        #    count += 1
        #outFileName += "_%d" %count
        #outFile = open(outFileName, 'wb')
        #outFile.write(f.read())
        #outFile.close()
        ret = self.retrieveUrl(url, dirName=dataDirectory, mseedMode=True, auxInfoMap=auxInfoMap, filenameTemplate=filenameTemplate, socketTimeout=30, checkpointReportingFunction=checkpointReportingFunction, forcedDatafileName=forcedDatafileName, maxFileSize=maxFileSize, ignoreDataStartingBefore=startTimeAsEpoch)
        return ret[0]
        
##
# From here on down are "internal" functions.  They're intended to be used internally
# only
##

    def internal_getStatusItemsBetween(self, beginString, endString):
        """
        Find all of the status lines (something1 : something2<BR>), split the
        status name (something1) from the status value (something2) and 
        return the dict made up of all status lines
        """

        rawInfo = self.openUrlAndGetText('http://%s:%d/intface.htm' %(self.getIPAddress(), self.getWebPort()))

        rawInfo = string.split(string.split(rawInfo, beginString)[1], endString)[0]
        rawInfo = rawInfo.replace(',   ', '<BR>\r\n')
        rawInfo = rawInfo.replace('<HR>', '')
        lines = string.split(rawInfo, '\r\n')
        ret = {}
        for line in lines:
            if not line.endswith('<BR>'):
                continue
            line = line[:-4]
            name, value = string.split(line, ':')
            value = string.strip(value)
            try:
                value = int(value)
            except:
                pass
            ret[string.strip(name)] = value
        return ret    

class RemoteBaler(Baler):

    def __init__(self, stationInfo):
        """
        stationInfo is a config file with the required information for talking to
        a remote baler:
        Baler.WebPort
        
        """
