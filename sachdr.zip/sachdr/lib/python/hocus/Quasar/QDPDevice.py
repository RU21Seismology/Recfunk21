"""
This module contains a base class for anything that can talk QDP
"""

from isti.utils.GetSet import GetSet
import socket
from Quasar import Cmds
import time
from isti.utils import structWrapper
from Quasar import CmdID

class QDP_C1_CERR(Exception):
    """
    An exception class to be raised when a
    c1_err is returned
    """
    def __init__(self, errCode, errMsg):
        Exception.__init__(self, errMsg)
        self.setErrorCode(errCode)
        
    def setErrorCode(self, num):
        self.errorCode = num
        
    def getErrorCode(self):
        return self.errorCode
        



class TimeoutException(Exception):
    """
    An exception used for simulating a socket timeout
    in pre 2.3 versions of python
    """
    
class QDPDevice(GetSet):
    """
    The base class for any other classes that speak QDP.
    """
    def __init__(self):
        self.connection = None
        self.seqNum = -1
        self.setDeviceType("Generic QDP Device")
        self.setBroadcastIP('255.255.255.255')
        self.commandsSent = 0
        self.packetsReceived = 0
        self.txBytes = 0
        self.rxBytes = 0

    def incrementBytesSent(self, toAdd):
        self.txBytes += toAdd

    def incrementBytesReceived(self, toAdd):
        self.rxBytes += toAdd

    def getBytesReceived(self):
        return self.rxBytes

    def getBytesSent(self):
        return self.txBytes
    
    def getNextSequenceNumber(self):
        """
        Get the next unused sequence number, for QDP use
        """
        if self.seqNum == 65536:
            self.seqNum = 0
        
        self.seqNum += 1
        return self.seqNum

    def setReceiveTimeout(self, newTimeoutValue):
        """
        Set the number of seconds we should wait for a packet to arrive, before we
        give up
        """
        self.receiveTimeout = newTimeoutValue
        if self.connection != None:
            #self.closeConnection()
            #self.connection = None
            self.connection.settimeout(newTimeoutValue)
            
    def getReceiveTimeout(self):
        """
        return the receive timeout, or the default (20) if one has not been set
        """
        try:
            return self.receiveTimeout
        except:
            return 20
        
    def openConnection(self, cmd=None):
        """
        Prepare our socket connection.
        """
        # dont open if we're already open
        if self.connection != None:
            return
        host = self.getIPAddress()
        if cmd != None:
            port = self.getPortForCommand(cmd)
        else:
            port = self.getBasePort()
        #info = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_DGRAM)
        #af, socktype, proto, canonname, sa = info[0]
        #self.connection = socket.socket(af, socktype, proto)
        self.connection = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # only set the socket timeout if we're running a socket API that has the
        # ability to do so
        if 'settimeout' in dir(self.connection):
            self.connection.settimeout(self.getReceiveTimeout())


            
    def closeConnection(self):
        """
        Finalize, and close our socket connection.
        """
        self.connection.close()
        self.connection = None
        
    def getPortForCommand(self, cmd):
        """
        What port do we use to send a particular command packet?
        """
        return self.getBasePort()

    def getVersionTuple(self):
        return (1,0,'generic')
    
    def sendCommand(self, cmd, receiveMultiple=0, preservePortForBroadcast=0, skipReceive=0, singleSend=0):
        """
        Send cmd onto the wire.  The packet sent to the IP address and port
        that has been set by the setIPAddress() and setBasePort() methods.

        receiveMultiple - If non-zero, a list of responses (possibly containing a
        single response) will be returned
        """
        if not self.connection:
            self.openConnection(cmd)

        cmd.setQDPSequenceNumber(self.getNextSequenceNumber())
        cmd.getPacketBytes()
        cmd.computeCRC()

        if cmd.getIsBroadcast() and self.getIPAddress() == '255.255.255.255':
            if 'SO_BROADCAST' in dir(socket):
                self.connection.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            host = self.getBroadcastIP() #'255.255.255.255'
            if preservePortForBroadcast == 0:
                port = 65535
            else:
                port = self.getPortForCommand(cmd)
        else:
            host = self.getIPAddress()
            port = self.getPortForCommand(cmd)

        cmd.prepareForSending()
        bytesToSend = cmd.getPacketBytes()

        # this is being injected here because the Q330 seems to want it
        time.sleep(.05)

        recvConnection = None
        alreadySent = None
        recvConnectionListenPort = 0
        
        ##
        # Below is a hack for the "replying on byteswapped port number" bug in early
        # Baler releases
        ##
        if self.getDeviceType() == 'Baler14' and cmd.getQDPCommand() == CmdID.C2_BCMD:
            major, minor, mod = self.getVersionTuple()
            if major == 1 and ( (minor < 40) or (minor == 40 and mod in ('RC1',)) ):
                recvConnection = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                try:
                    recvConnection.bind( ('0.0.0.0', socket.ntohs(self.connection.getsockname()[1]) ))
                    recvConnectionListenPort = socket.ntohs(self.connection.getsockname()[1])
                except:
                    try:
                        self.connection.sendto(bytesToSend, 0, (host, port))
                    except:
                        self.connection.sendto(bytesToSend, (host, port))
                    alreadySent = 1
                    recvConnection.bind( ('0.0.0.0', socket.ntohs(self.connection.getsockname()[1]) ))


        if not alreadySent:
            try:
                self.connection.sendto(bytesToSend, 0, (host, port))
            except:
                self.connection.sendto(bytesToSend, (host, port))

        self.incrementBytesSent(len(bytesToSend))


        if skipReceive != 0:
            return None
        ##
        # Here we do different things if we're expecting to receive multiple items or
        # not
        ##
        if receiveMultiple == 0:
            ##
            # We want a single response
            ##
            rsp = cmd
            
                    
            while rsp == cmd or rsp.getQDPAcknowledgeNumber() != cmd.getQDPSequenceNumber():
                result = ''
                gotData = 0
                attempts = 0
                
                # we're going to re-try 3 times, and give up if we havent heard back
                while gotData == 0 and attempts < 3:
                    if recvConnection and recvConnectionListenPort == 0 and self.connection.getsockname()[1] != 0:
                        recvConnection = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                        recvConnection.bind( ('0.0.0.0', socket.ntohs(self.connection.getsockname()[1]) ))
                        
                    attempts = attempts + 1
                    if socket.__dict__.has_key('timeout'):
                        if recvConnection:
                            recvConnection.settimeout(self.getReceiveTimeout())
                        else:
                            self.connection.settimeout(self.getReceiveTimeout())
                        try:
                            if recvConnection:
                                result, addr = recvConnection.recvfrom(2048)
                            else:
                                result, addr = self.connection.recvfrom(2048)
                            gotData = 1
                        except socket.error, e:
                            pass
                    else:
                        timeoutVal = self.getReceiveTimeout()
                        startTime = time.time()
                        if recvConnection:
                            recvConnection.setblocking(0)
                        else:
                            self.connection.setblocking(0)
                        while (time.time() - startTime) < timeoutVal:
                            try:
                                if recvConnection:
                                    result, addr = recvConnection.recvfrom(2048)
                                else:
                                    result, addr = self.connection.recvfrom(2048)
                                gotData = 1
                            except socket.error, e:
                                pass
                            if gotData == 1:
                                if recvConnection:
                                    recvConnection.setblocking(1)
                                else:
                                    self.connection.setblocking(1)
                                break
                        if recvConnection:
                            recvConnection.setblocking(1)
                        else:
                            self.connection.setblocking(1)
                        
                    # resend, if we got nothing    
                    if gotData == 0 and not singleSend :
                        try:
                            self.connection.sendto(bytesToSend, 0, (host, port))
                        except:
                            self.connection.sendto(bytesToSend, (host, port))
                        self.incrementBytesSent(len(bytesToSend))
                        
                if not gotData:
                    raise TimeoutException('recv timed out')

                self.incrementBytesReceived(len(result))
                
                # decide what type of packet we received
                cid = structWrapper.unpack('B', result[4])[0]
                # return the received packet class
                rsp = Cmds.cmdToClass[cid](result)
                rsp.setSourceIPAddressInfo(addr)
                
            if (isinstance(rsp, Cmds.c1_cerr)) or (isinstance(rsp, Cmds.rl_cmd) and rsp.getCommandType() == Cmds.RLCMD_ERROR):
                # this is an error
                raise QDP_C1_CERR(rsp.getErrorCode(), rsp.getErrorText())

            if recvConnection:
                recvConnection.close()
                del recvConnection
        else:
            ##
            # we want multiple responses
            ##
            # do this once outside the loop, so that we can be sure the timeout period is waited
            # if there's nothing on the line
            result = 'foof'
            addr = (None, None)
            rsp = []
            iteration = 0
            timeoutVal = self.getReceiveTimeout()
            while(result not in (None, '')):
                ## take into account pythons without settimeout()
                if socket.__dict__.has_key('timeout'):
                    ## This python has timeout
                    try:
                        result, addr = self.connection.recvfrom(2048)
                    except socket.timeout,e:
                        ##
                        # Only rethrow the exception if we timed out the first time.  This
                        # is really the only time we should do so here
                        ##
                        if iteration == 0:
                            raise TimeoutException('recv timed out')
                        else:
                            break
                else:
                    ## this python has no timeout
                    startTime = time.time()
                    try:
                        self.connection.setblocking(0)
                        gotData = 0
                        while (time.time() - startTime) < timeoutVal:
                            try:
                                result, addr = self.connection.recvfrom(2048)
                                gotData = 1
                                break
                            except socket.error, e:
                                pass
                        if not gotData: 
                            self.connection.setblocking(1)
                            raise TimeoutException('recv timed out')
                    except TimeoutException, e:
                        if iteration == 0:
                            self.connection.setblocking(1)
                            raise e
                        else:
                            break
                        
                    self.setblocking(1)
                        
                    
                cid = structWrapper.unpack('B', result[4])[0]
                responsePacket = Cmds.cmdToClass[cid](result)
                responsePacket.setSourceIPAddressInfo(addr)


                ##
                # Communicating with the baler is somewhat different.  In the case of the baler,
                # RL_CMD responses to a read request need to be ACK'd one at a time.  We'll
                # do this here.  Also, duplicated 
                #
                # We do our special stuff if we're a baler, we got an RL_CMD and it's an RLCMD_DATA packet
                ##
                if self.getDeviceType() == 'Baler14' and responsePacket.getQDPCommand() == CmdID.RL_CMD and responsePacket.getCommandType() == Cmds.RLCMD_DATA:
                    # first, lets ack
                    rlcmd = Cmds.rl_cmd()
                    rlcmd.setCommandType(Cmds.RLCMD_ACK)
                    rlcmd.setBlockNumber(responsePacket.getBlockNumber())
                    self.sendCommand(rlcmd, skipReceive=1)
                    
                    # now, lets append this packet to the list if we havent gotten it yet
                    alreadyReceived = 0
                    for received in rsp:
                        if received.getBlockNumber() == responsePacket.getBlockNumber():
                            alreadyReceived = 1
                            break
                    if alreadyReceived == 0:
                        rsp.append(responsePacket)
                else:
                    if responsePacket.getQDPAcknowledgeNumber() == cmd.getQDPSequenceNumber():
                        rsp.append(responsePacket)
                    


                ##
                # after we're gotten the first packet that is a response to the initial
                # command, drop the timeout to almost nothing, because data is flowing
                ##
                if iteration == 0 and len(rsp) != 0:
                    iteration += 1
                    try:
                        self.connection.settimeout(1)
                    except:
                        # settimeout only exists in python2.3 and higher
                        timeoutVal = 1
                
            ##
            # put the timeout back to the way we found it
            ##
            try:
                self.connection.settimeout(self.getReceiveTimeout())
            except:
                pass


            
        return rsp



    def receiveResponse(self, sentCommand=None, receiveMultiple=False, auxReceiveSocket=None):
        ##
        # Here we do different things if we're expecting to receive multiple items or
        # not
        ##
        recvConnection = self.connection
        if auxReceiveSocket:
            recvConnection = auxReceiveSocket
        if not receiveMultiple:
            ##
            # We want a single response
            ##
            rsp = sentCommand
            
                    
            while not rsp or rsp == sentCommand or (sentCommand and rsp.getQDPAcknowledgeNumber() != sentCommand.getQDPSequenceNumber()):
                result = ''
                gotData = 0
                attempts = 0
                
                # we're going to re-try 3 times, and give up if we havent heard back
                while gotData == 0 and attempts < 3:
                    if auxReceiveSocket and self.connection.getsockname()[1] != 0:
                        recvConnection = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                        recvConnection.bind( ('0.0.0.0', socket.ntohs(self.connection.getsockname()[1]) ))
                        
                    attempts = attempts + 1
                    if socket.__dict__.has_key('timeout'):
                        recvConnection.settimeout(self.getReceiveTimeout())
                        try:
                            result, addr = recvConnection.recvfrom(2048)
                            gotData = 1
                        except socket.error, e:
                            pass
                    else:
                        timeoutVal = self.getReceiveTimeout()
                        startTime = time.time()
                        recvConnection.setblocking(0)
                        while (time.time() - startTime) < timeoutVal:
                            try:
                                result, addr = recvConnection.recvfrom(2048)
                                gotData = 1
                            except socket.error, e:
                                pass
                            if gotData == 1:
                                recvConnection.setblocking(1)
                                break
                        recvConnection.setblocking(1)
                        
                    # resend, if we got nothing    
                    if gotData == 0 and sentCommand :
                        try:
                            self.connection.sendto(sentCommand.getPacketBytes(), 0, (host, port))
                        except:
                            self.connection.sendto(sentCommand.getPacketBytes(), (host, port))
                        self.incrementBytesSent(len(sentCommand.getPacketBytes()))
                        
                if not gotData:
                    raise TimeoutException('recv timed out')

                self.incrementBytesReceived(len(result))
                
                # decide what type of packet we received
                cid = structWrapper.unpack('B', result[4])[0]
                # return the received packet class
                rsp = Cmds.cmdToClass[cid](result)
                rsp.setSourceIPAddressInfo(addr)
                
            if (isinstance(rsp, Cmds.c1_cerr)) or (isinstance(rsp, Cmds.rl_cmd) and rsp.getCommandType() == Cmds.RLCMD_ERROR):
                # this is an error
                raise QDP_C1_CERR(rsp.getErrorCode(), rsp.getErrorText())

            #if recvConnection:
            #    recvConnection.close()
            #    del recvConnection
            
        else:
            ##
            # we want multiple responses
            ##
            # do this once outside the loop, so that we can be sure the timeout period is waited
            # if there's nothing on the line
            result = 'foof'
            addr = (None, None)
            rsp = []
            iteration = 0
            timeoutVal = self.getReceiveTimeout()
            while(result not in (None, '')):
                ## take into account pythons without settimeout()
                if socket.__dict__.has_key('timeout'):
                    ## This python has timeout
                    try:
                        result, addr = recvConnection.recvfrom(2048)
                    except socket.timeout,e:
                        ##
                        # Only rethrow the exception if we timed out the first time.  This
                        # is really the only time we should do so here
                        ##
                        if iteration == 0:
                            raise TimeoutException('recv timed out')
                        else:
                            break
                else:
                    ## this python has no timeout
                    startTime = time.time()
                    try:
                        recvConnection.setblocking(0)
                        gotData = 0
                        while (time.time() - startTime) < timeoutVal:
                            try:
                                result, addr = recvConnection.recvfrom(2048)
                                gotData = 1
                                break
                            except socket.error, e:
                                pass
                        if not gotData: 
                            recvConnection.setblocking(1)
                            raise TimeoutException('recv timed out')
                    except TimeoutException, e:
                        if iteration == 0:
                            recvConnection.setblocking(1)
                            raise e
                        else:
                            break
                        
                    self.setblocking(1)
                        
                    
                cid = structWrapper.unpack('B', result[4])[0]
                responsePacket = Cmds.cmdToClass[cid](result)
                responsePacket.setSourceIPAddressInfo(addr)


                ##
                # Communicating with the baler is somewhat different.  In the case of the baler,
                # RL_CMD responses to a read request need to be ACK'd one at a time.  We'll
                # do this here.  Also, duplicated 
                #
                # We do our special stuff if we're a baler, we got an RL_CMD and it's an RLCMD_DATA packet
                ##
                if self.getDeviceType() == 'Baler14' and responsePacket.getQDPCommand() == CmdID.RL_CMD and responsePacket.getCommandType() == Cmds.RLCMD_DATA:
                    # first, lets ack
                    rlcmd = Cmds.rl_cmd()
                    rlcmd.setCommandType(Cmds.RLCMD_ACK)
                    rlcmd.setBlockNumber(responsePacket.getBlockNumber())
                    self.sendCommand(rlcmd, skipReceive=1)
                    
                    # now, lets append this packet to the list if we havent gotten it yet
                    alreadyReceived = 0
                    for received in rsp:
                        if received.getBlockNumber() == responsePacket.getBlockNumber():
                            alreadyReceived = 1
                            break
                    if alreadyReceived == 0:
                        rsp.append(responsePacket)
                else:
                    if sentCommand:
                        if responsePacket.getQDPAcknowledgeNumber() == cmd.getQDPSequenceNumber():
                            rsp.append(responsePacket)
                    else:
                        rsp.append(responsePacket)
                    


                ##
                # after we're gotten the first packet that is a response to the initial
                # command, drop the timeout to almost nothing, because data is flowing
                ##
                if iteration == 0 and len(rsp) != 0:
                    iteration += 1
                    try:
                        recvConnection.settimeout(1)
                    except:
                        # settimeout only exists in python2.3 and higher
                        timeoutVal = 1
                
            ##
            # put the timeout back to the way we found it
            ##
            try:
                recvConnection.settimeout(self.getReceiveTimeout())
            except:
                pass


            
        return rsp
