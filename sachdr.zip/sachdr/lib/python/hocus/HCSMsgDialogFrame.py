#! /usr/bin/env python

from Tkinter import *
from tkFont import Font
import tkFileDialog

class HCSMsgDialogFrame:
    def __init__(self, master, name="hcs"):
        self.master = master
        if name:
            self.name = name + '.msg'
        self.fd = None

    def openMsg(self):
        ofile = tkFileDialog.askopenfilename(
            filetypes = [('HCS Message File', '.msg'),
                         ('All Files', '*')])
        if not ofile or ofile=='': return None

        try:
            self.fd = open(ofile, 'r')
            cont = self.fd.read(1024*1024)
            self.closeMsg()
            self.master.gui.msgText.settext(cont)
        except IOError:
            tkMessageBox('Open error...',
                         'Could not open %s to read' % ofile)
            return None
        return 1

    def saveAsMsg(self):
        ofile = tkFileDialog.asksaveasfilename(
            initialfile = self.name,
            filetypes = [('HCS Message File', '.msg'),
                         ('All Files', '*')])
        if not ofile: return None
        self.name = ofile
        try:
            txt = self.master.gui.msgText.get()
            self.fd = open(ofile, 'w')
            self.fd.write(txt)
            self.closeMsg()
        except IOError:
            tkMessageBox('Open error...',
                         'Could not open %s to write.' % ofile)
            return None
        return 1

    def closeMsg(self):
        if self.fd: self.fd.close()

if __name__ == '__main__':
    root = Tk()
    f = HCSXMLFrame(root, '799')
    btn = Button(root, text = 'open', command=f.saveAsXML).pack()
    root.mainloop()
