#!/usr/bin/env python

from Tkinter import *
from HCSQ330 import *
from HCSMisc import *
from HCSQ330 import HCSQ330
from isti.gui.RequestQueue import *
import tkMessageBox
import threading


class HCSSetIPsFrame:
    def __init__(self, master, itms):
	self.frame = Toplevel(master)
	self.frame.title("IP Set Dialog")
	self.master = master
	self.items = itms
	self.frame.bind("<Destroy>", self.closedMe)
	self.IP1 = StringVar()
	self.IP1.set('192')
	self.IP2 = StringVar()
	self.IP2.set('168')
	self.IP3 = StringVar()
	self.IP4 = StringVar()
	self.option = IntVar()
	self.createWidgets()

    def createWidgets(self):
	frmSet = Frame(self.frame, borderwidth = 1, relief = GROOVE)
	frmIP = Frame(frmSet, borderwidth = 5)
	Label(frmIP, text = "IP address: ").pack(side = LEFT)
	self.entryIP1 = Entry(frmIP,
			      bg = "white",
			      textvariable = self.IP1,
			      state = DISABLED,
			      width = 3)
	self.entryIP1.pack(side = LEFT)
	Label(frmIP, text = ".").pack(side = LEFT)
	self.entryIP2 =  Entry(frmIP,
			       bg = "white",
			       textvariable = self.IP2,
			       state = DISABLED,
			       width = 3)
	self.entryIP2.pack(side = LEFT)
	Label(frmIP, text = ".").pack(side = LEFT)
	self.entryIP3 = Entry(frmIP,
			      bg = "white",
			      textvariable = self.IP3,
			      state = DISABLED,
			      width = 3)
	self.entryIP3.pack(side = LEFT)
	Label(frmIP, text = ".").pack(side = LEFT)
	self.entryIP4 = Entry(frmIP,
			      bg = "white",
			      textvariable = self.IP4,
			      state = DISABLED,
			      width = 3)
	self.entryIP4.pack(side = LEFT)
	frmIP.pack(side = TOP)

	frmOption = Frame(frmSet, borderwidth = 5)
	self.radOpt1 = Radiobutton(frmOption,
				   text = "Use Tag #",
				   value = 1,
				   variable = self.option)
	self.radOpt1.pack(anchor = W)
	self.radOpt1.bind("<Button-1>", self.radEvt1)
	self.radOpt2 = Radiobutton(frmOption,
				   text = "Sequential",
				   value = 2,
				   variable = self.option)
	self.radOpt2.pack(anchor = W)
	self.radOpt2.bind("<Button-1>", self.radEvt2)
	self.radOpt3 = Radiobutton(frmOption,
				   text = "Use as entered",
				   value = 3,
				   variable = self.option)
	self.radOpt3.pack(anchor = W)
	self.radOpt3.bind("<Button-1>", self.radEvt3)
	self.option.set(1)
	frmOption.pack(side = TOP)

	frmButton = Frame(frmSet, borderwidth = 5)
	Button(frmButton,
	       text = "   OK   ",
	       command = self.ok,
	       bg = "grey").pack(side = LEFT)
	Label(frmButton, text = "    ").pack(side = LEFT)
	Button(frmButton,
	       text = " Cancel ",
	       command = self.frame.destroy,
	       bg = "grey").pack(side = LEFT)
	frmButton.pack(side = TOP)
	frmSet.pack(side = TOP, expand = YES, fill = X)

    def radEvt1(self, e):
	self.radEvts(1)

    def radEvt2(self, e):
	self.radEvts(2)

    def radEvt3(self, e):
	self.radEvts(3)

    def radEvts(self, opt):
	if opt == 3:
	    self.entryIP1.configure(state = DISABLED)
	    self.entryIP2.configure(state = DISABLED)
	    self.entryIP3.configure(state = NORMAL)
	    self.entryIP4.configure(state = NORMAL)
	elif opt == 2:
	    self.entryIP1.configure(state = DISABLED)
	    self.entryIP2.configure(state = DISABLED)
	    self.entryIP3.configure(state = NORMAL)
	    self.entryIP4.configure(state = NORMAL)
	else:
	    self.entryIP1.configure(state = DISABLED)
	    self.entryIP2.configure(state = DISABLED)
	    self.entryIP3.configure(state = DISABLED)
	    self.entryIP4.configure(state = DISABLED)	    
	

    def closedMe(self, e):
	self.master.btnSetIPs.configure(state = NORMAL)

    def ok(self):
	self.frame.destroy()
	self.master.master.master.msgQueue.put('\nStart setting IP(s).\n')
	self.master.master.master.lockQueue.put(1) #not lock yet
	if self.option.get() == 1:
	    ip1 = int(self.IP1.get())
	    ip2 = int(self.IP2.get())
	    t = threading.Thread(target = self.setIPbyTag,
				 args = (ip1, ip2))
	    t.start()
	elif self.option.get() == 2:
	    if self.validIP():
		ip1 = self.IP1.get()
		ip2 = self.IP2.get()
		ip3 = self.IP3.get()
		ip4 = self.IP4.get()
		newIP = ip1 + '.' + ip2 + '.' + ip3 + '.' + ip4
		t = threading.Thread(target = self.setIPbySeq,
				     args = (newIP,))
		t.start()
            else:
                self.master.master.master.lockQueue.put(0)
	elif self.option.get() == 3:
	    if self.validIP():
		ip1 = self.IP1.get()
		ip2 = self.IP2.get()
		ip3 = self.IP3.get()
		ip4 = self.IP4.get()
		newIP = ip1 + '.' + ip2 + '.' + ip3 + '.' + ip4
		t = threading.Thread(target = self.setIPbyMan,
				     args = (newIP,))
		t.start()
            else:
                self.master.master.master.lockQueue.put(0)
	    
    def setIPbyTag(self, ip1, ip2):
	while len(self.items): #try forever until list empty
	    item = self.items[0] #(tag, serialNum)
	    self.master.master.master.msgQueue.put('Try %s ... ' % item[0])
	    newIP = num2DottedDouble(ip1, ip2, int(item[0]))
	    q330 = HCSQ330(serialNumber = eval('0x'+item[1]))
	    isSucc = q330.setEthernetIP(newIP) #we try here!
	    self.items.remove(item)
	    if isSucc:
		self.master.master.master.msgQueue.put('done\n')
	    else: #put it in the end of queue and try again later
		self.master.master.master.msgQueue.put('failed. Try again later.\n')
		self.items.append(item)
	self.master.master.master.msgQueue.put('Set IP(s) successfully.\n')
	self.master.master.master.lockQueue.put(0)

    def setIPbySeq(self, newIP):
	while len(self.items): #try forever until list empty
	    item = self.items[0]
	    self.master.master.master.msgQueue.put('Try %s ... ' % item[0])
	    q330 = HCSQ330(eval('0x'+item[1]))
	    isSucc = q330.setEthernetIP(newIP)
	    self.items.remove(item)
	    if isSucc:
		self.master.master.master.msgQueue.put('done\n')
		#increment ip address
		newIPn = dottedIP2Num(newIP)
		newIPn += 1
		newIP = num2DottedIP(newIPn)
	    else: #moved to the end
		self.master.master.master.msgQueue.put('failed. Try again later.\n')
		self.items.append(item)
	self.master.master.master.msgQueue.put('Set IP(s) successfully.\n')
	self.master.master.master.lockQueue.put(0)

    def setIPbyMan(self, newIP):
	while len(self.items): #try forever until list empty
	    item = self.items[0]
	    self.master.master.master.msgQueue.put('Try %s ... ' % item[0])
	    q330 = HCSQ330(serialNumber = eval('0x'+item[1]))
	    isSucc = q330.setEthernetIP(newIP) #try here
	    self.items.remove(item)
	    if isSucc:
		self.master.master.master.msgQueue.put('done\n')
	    else: #moved to the end
		self.master.master.master.msgQueue.put('failed. Try again later.\n')
		self.items.append(item)
	self.master.master.master.msgQueue.put('Set IP(s) successfully.\n')
	self.master.master.master.lockQueue.put(0)
			
    def validIP(self):
	flag = 1
	try:
	    ip1 = int(self.IP1.get())
	    ip2 = int(self.IP2.get())
	    ip3 = int(self.IP3.get())
	    ip4 = int(self.IP4.get())
	    if ip1 < 0 or ip1 > 255: flag = 0
	    if ip2 < 0 or ip2 > 255: flag = 0
	    if ip3 < 0 or ip3 > 255: flag = 0
	    if ip4 < 0 or ip4 > 255: flag = 0
	except:
	    flag = 0

	if not flag:
	    tkMessageBox.showerror(title="Oops!",
				   message="The IP(s) is not correct or out of range.")

	return flag
	    
	
