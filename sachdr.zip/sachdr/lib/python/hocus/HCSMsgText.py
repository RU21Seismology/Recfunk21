#! /usr/bin/env python

import Pmw
import Tkinter

class HCSMsgText:
    def __init__(self, parent):
	# Create the ScrolledText with headers.
	fixedFont = Pmw.logicalfont('Fixed')
        self.st = Pmw.ScrolledText(parent,
				   labelpos = 'n',
				   label_text='Messages',
				   usehullsize = 1,
				   hull_width = 550,
				   hull_height = 80,
				   text_wrap='none',
				   text_font = fixedFont,
				   text_padx = 4,
				   text_pady = 4,
				   text_background = 'white'
				   )

        self.st.pack(padx = 5, pady = 5, fill = 'both', expand = 1)

	# Prevent users' modifying text
        self.st.configure(text_state = 'disabled',)

    def appendtext(self, text):
	self.st.appendtext(text)

    def clear(self):
	self.st.clear()

    def bbox(self, index):
	self.st.bbox(index)

    def get(self, first=None, last=None):
	return self.st.get(first, last)
	
    def exportfile(self, filename):
	self.st.exportfile(filename)

    def getvalue(self):
	return self.st.getvalue()

    def importfile(self, filename, where='end'):
	self.st.importfile(filename, where)

    def settext(self, text):
	self.st.setvalue(text)

    def setvalue(self, text):
	self.st.setvalue(text)
	

if __name__ == '__main__':
    root = Tkinter.Tk()
    Pmw.initialise(root)
    d = Demo(root)
    root.mainloop()
