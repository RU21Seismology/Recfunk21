#! /usr/bin/env python

from Tkinter import *

class HCSSubParmFrame(Frame):
    def __init__(self, master):
	Frame.__init__(self, master, borderwidth = 1, relief = GROOVE)
	#intVar for 5 checkboxes
	self.rebStatVar = IntVar()
	self.rebStatVar.set(1)
	self.parmsStatVar = IntVar()
	self.parmsStatVar.set(1)
	self.gpsStatVar = IntVar()
	self.gpsStatVar.set(1)
	self.diskStatVar = IntVar()
	self.diskStatVar.set(1)
	self.voltStatVar = IntVar()
	self.voltStatVar.set(1)
	self.createWidgets()
	self.pack(side = LEFT, expand = YES, fill = BOTH)

    def sepline(self):
	Frame(self,
	      height = 2,
	      borderwidth = 1,
	      relief = GROOVE).pack(side = TOP, fill = BOTH)

    def createTimeFrm(self):
	frmTime = Frame(self, borderwidth = 5)
	btnSysTm = Button(frmTime,
			  text = "System Time",
			  command = "",
			  bg = "grey")
	btnSysTm.pack(side = TOP, fill = X)
	btnSetTm = Button(frmTime,
			  text = "Set DAS Time",
			  command = "",
			  bg = "grey")
	btnSetTm.pack(side = TOP, fill = X)
	frmTime.pack(side = TOP, fill = X)
	self.sepline()

    def createParaFrm(self):
	frmPara = Frame(self, borderwidth = 5)
	btnReceive = Button(frmPara,
			    text = "Receive\nParameters",
			    command = "",
			    bg = "white")
	btnReceive.pack(side = TOP, fill = X)
	frmPara.pack(side = TOP, fill = X)

	frmPara = Frame(self, borderwidth = 5)
	btnEdit = Button(frmPara,
			 text = "Edit\nParameters",
			 command = "",
			 bg = "white")
	btnEdit.pack(side = TOP, fill = X)
	btnSummary = Button(frmPara,
			    text = "Summary",
			    command = "",
			    bg = "white")
	btnSummary.pack(side = TOP, fill = X)
	frmPara.pack(side = TOP, fill = X)

	frmPara = Frame(self, borderwidth = 5)
	btnSend = Button(frmPara,
			 text = "Send\nParameters",
			 command = "",
			 bg = "white")
	btnSend.pack(side = TOP, fill = X)
	frmPara.pack(side = TOP, fill = X)
	self.sepline()

    def createStatusFrm(self):
	frmPara = Frame(self, borderwidth = 5)
	frmPara.pack(side = TOP, fill = BOTH)
	frmStat = Frame(frmPara, borderwidth = 5)
	frmStat.pack()
	frmrbt = Frame(frmStat)
	chkReboots = Checkbutton(frmrbt,
				 text = "Reboots",
				 variable = self.rebStatVar)
	chkReboots.pack(side = TOP)
	frmrbt.pack(side = TOP)
	frmPG = Frame(frmStat)
	chkParms = Checkbutton(frmPG,
			       text = "Parms",
			       variable = self.parmsStatVar)
	chkParms.pack(side = LEFT)
	chkGPS = Checkbutton(frmPG,
			     text = "GPS",
			     variable = self.gpsStatVar)
	chkGPS.pack(side = LEFT)
	frmPG.pack(side = TOP)
	frmDV = Frame(frmStat)
	chkDisk = Checkbutton(frmDV,
			      text = "Disk",
			      variable = self.diskStatVar)
	chkDisk.pack(side = LEFT)
	chkVolts = Checkbutton(frmDV,
			       text = "Volts",
			       variable = self.voltStatVar)
	chkVolts.pack(side = LEFT)
	frmDV.pack(side = TOP)	
	btnStatus = Button(frmPara,
			   text = "DAS Status",
			   command = "",
			   bg = "grey")
	btnStatus.pack(side = TOP, fill = X)
	frmPara.pack(side = TOP, fill = X)
	self.sepline()

    def createTestFrm(self):
	frmTest = Frame(self, borderwidth = 5)
	btnTest = Button(frmTest,
			 text = "Test",
			 command = "",
			 bg = "grey")
	btnTest.pack(side = TOP, fill = X)
	frmTest.pack(side = TOP, fill = X)
	self.sepline()	

    def createVerFrm(self):
	frmVer = Frame(self, borderwidth = 5)
	btnVer = Button(frmVer,
			text = "Versions/SNs",
			command = "",
			bg = "grey")
	btnVer.pack(side = TOP, fill = X)
	frmVer.pack(side = TOP, fill = X)
	self.sepline()	
	
    def createWidgets(self):
	self.createTimeFrm()
	self.createParaFrm()
	self.createStatusFrm()
	self.createTestFrm()
	self.createVerFrm()
