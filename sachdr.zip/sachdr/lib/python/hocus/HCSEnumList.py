#!/usr/bin/env python

import Pmw
import Tkinter
from tkFont import Font

class HCSEnumList:
    def __init__(self, parent, width, height):
	self.box = Pmw.ScrolledListBox(parent,
				       listbox_selectmode = Tkinter.MULTIPLE,
				       items = (),
				       labelpos='nw',
				       label_text='', #'Q330 List',
				       listbox_height = 6,
				       listbox_font = Font(family = 'Courier', size = "12"),
				       selectioncommand=self.selectionCmd,
				       dblclickcommand=self.defCmd,
				       usehullsize = 1,
				       hull_width = width,
				       hull_height = height,
				       )
	self.box.pack(fill = 'both', expand = 1, padx = 5, pady = 5)
	self.box.configure(hscrollmode = 'dynamic')
	self.box.configure(vscrollmode = 'static')
	
    def selectionCmd(self):
	sels = self.box.getcurselection()
	if len(sels) == 0:
	    pass #for future
	else:
	    pass #for future

    def defCmd(self):
	sels = self.box.getcurselection()
	if len(sels) == 0:
	    pass #for future
	else:
	    pass #for future

    def getSelectedItems(self):
	return self.box.getvalue()
    

if __name__=='__main__':
    import Tkinter
    r = Tkinter.Tk()
    l = HCSEnumList(r, 10, 200)
    print "selected are: " + str(l.getSelectedItems())
    r.mainloop()
