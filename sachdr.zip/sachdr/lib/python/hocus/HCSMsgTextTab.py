#! /usr/bin/env python

import Pmw
import Tkinter
from HCSMsgText import HCSMsgText
import math, string

class HCSMsgTextTab(HCSMsgText):
    def __init__(self, parent):
# Create the ScrolledText with headers.
	fixedFont = Pmw.logicalfont('Fixed')
        self.st = Pmw.ScrolledText(parent,
				   labelpos = 'n',
				   label_text= 'Q330s\' Informaiton',
				   columnheader = 1,
				   usehullsize = 1,
				   hull_width = 465,
				   hull_height = 300,
				   text_wrap='none',
				   #text_font = fixedFont,
				   #Header_font = fixedFont,
				   Header_foreground = 'blue',
				   text_padx = 4,
				   text_pady = 4,
				   Header_padx = 4,
				   )

        self.st.pack(padx = 5, pady = 5, fill = 'both', expand = 1)

        heads = 'Tag IP Baseport Serial'
        heads = string.split(heads)

        # Create the column headers
	headerLine = ('%-9s   ' % ('Tag',)) + ('%-6s   ' % ('IP',)) + ('%-10s   ' % ('Baseport',)) + ('%-10s   ' % ('Serial',) + ('%-9s ' % ('Firmware',)))
        self.st.component('columnheader').insert('0.0', headerLine)

        # Prevent users' modifying text and headers
        self.st.configure(
            text_state = 'disabled',
            Header_state = 'disabled',
        )

if __name__ == '__main__':
    root = Tkinter.Tk()
    Pmw.initialise(root)
    d = HCSMsgTextTab(root)
    root.mainloop()
	
