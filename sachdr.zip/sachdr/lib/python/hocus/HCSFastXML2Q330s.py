#! /usr/bin/env python
from Quasar.Q330 import Q330, QDP_C1_CERR
from HCSXMLParser import *
from HCSMisc import *
from HCSQ330 import *
from time import sleep
import threading

class HCSFastXML2Q330s:
    def __init__(self, master, items, xmlfile):
        self.master = master
        self.items = items
        self.xmlfile = xmlfile

    def go(self):
        t = threading.Thread(target = self.goT,
                             args = ())
        t.start()

    def goT(self):
        self.master.master.msgQueue.put("Check IPs and load XML file...")
        self.enumQ330T()
        if self.isDuplicateIPs():
            self.master.master.msgQueue.put("done.\nDuplicate IPs found. Try regular XML saving operation.\n")
        else:
            self.handler = doParser(self.xmlfile)
            self.master.master.msgQueue.put("done.\n")
            self.master.master.statQueue.put(10)
        self.xmlfile.close()
        

    def saveXML2Q330s(self):

        pf = myplatform()
        if pf == 'win32': popen2("arp -d")
        elif pf == 'linux': popen2("/sbin/arp -d")
        lck = threading.Lock()

        self.master.master.msgQueue.put("Try to save to Q330(s)...\n")
        self.done = 0
        self.failed = 0
        for item in self.items:
            t = threading.Thread(target = self.saveXML2Q330T,
                                 args = (item, lck))
            t.start()
        
    def saveXML2Q330T(self, item, lck):

        q330 = HCSQ330(serialNumber = eval('0x' + item[1]))
        q330.setReceiveTimeout(400)
        try:
            InterfaceRes = q330.broadcastPhysicalInterfaces() #before reg
            q330.realRegister(lck)
            self.saveToken2Q330(q330, item[0])
            self.saveCFG2Q330(q330, item[0], InterfaceRes)
                        
            q330.saveToEEPROM()
            sleep(1)
            q330.reboot()
            sleep(2)
            self.master.master.msgQueue.put("%s done.\n" % item[0])
            lck.acquire()
            self.done += 1
            if (self.done+self.failed)==len(self.items):
                self.master.master.msgQueue.put("Total %d: %d done and %d failed\n" % (len(self.items), self.done, self.failed))
            lck.release()
        except: # QDP_C1_CERR, e:
            try:
                self.master.master.msgQueue.put("%s FAILED.\n" % item[0])
                lck.acquire()
                self.failed += 1
                if (self.done+self.failed)==len(self.items):
                    self.master.master.msgQueue.put("Total %d: %d done and %d failed\n" % (len(self.items), self.done, self.failed))
                lck.release()
                q330.deregister()
            except:
                pass

            
    def saveCFG2Q330(self, q330, tag, InterfaceRes):
        
        c1fix = q330.sendCommand(c1_rqfix()) #for advanced interfaces
        dataPortMemorySizes = []
        dataPortMemorySizes.append(c1fix.getDataPort1PacketMemorySize())
        dataPortMemorySizes.append(c1fix.getDataPort2PacketMemorySize())
        dataPortMemorySizes.append(c1fix.getDataPort3PacketMemorySize())
        dataPortMemorySizes.append(c1fix.getDataPort4PacketMemorySize())

        for i in range(len(self.handler.configs)):
            config = self.handler.configs[i]
            sleep(0.3)
            if config.getName() == 'Interfaces':
                #keep MAC,...
                c1sphy = c1_sphy(InterfaceRes.getPacketBytes())
                config.setConfigCommand(c1sphy)
                q330.sendCommand(config.getCommand())
            elif config.getName() == 'Data':
                #get the old data
                c1rqlog = c1_rqlog()
                c1rqlog.setDataPortNumber(config.getDataPortNumber())
                c1log = q330.sendCommand(c1rqlog)
                #set the new data and 'some' old data
                c1slog = c1_slog(c1log.getPacketBytes())
                config.setConfigCommand(c1slog)
                q330.sendCommand(config.getCommand())
            elif config.getName() == 'Global':
                c1glob = q330.sendCommand(c1_rqglob())
                c1sglob = c1_sglob(c1glob.getPacketBytes())
                config.setConfigCommand(c1sglob)
                q330.sendCommand(config.getCommand())
            elif config.getName() == 'Sensor':
                c1sc = q330.sendCommand(c1_rqsc())
                c1ssc = c1_ssc(c1sc.getPacketBytes())
                config.setConfigCommand(c1ssc)
                q330.sendCommand(config.getCommand())
            elif config.getName() == 'Slave': #stop here
                pass
                #c1spp = q330.sendCommand(c1_rqspp())
                #c1sspp = c1_sspp(c1spp.getPacketBytes())
                #config.setConfigCommand(c1sspp)
                #q330.sendCommand(config.getCommand())
            elif config.getName() == 'Advanced':
                c2rqphy = c2_rqphy()
                serNum = config.getSerial()
                c2rqphy.setPhysicalInterfaceNumber(serNum)
                c2phy = q330.sendCommand(c2rqphy)
                c2sphy = c2_sphy2(c2phy.getPackageBytes())
                if c2sphy.getDialOutPassword() == 0:
                    c2sphy.setDialOutPassword("")
                if c2sphy.getDialInPassword() == 0:
                    c2sphy.setDialInPassword("")
                config.setConfigCommand(c2sphy)
                new_c2sphy = config.getCommand()
                mtl = new_c2sphy.getMemoryTriggerLevel()#<trigger>mtl</trigger>
                lognum = new_c2sphy.getDataPortNumber()

                #The following is new to fix coupling problem
                #get the total memory after this boot
                totalsize = 0
                for i in range(4):
                    totalsize += dataPortMemorySizes[i]
                #now we get mem size from XML rather than from querying from q330
                #adjust 0.2 here,e.g.from 60 to 60.2 to make solution look better
                memsize = totalsize * (int(self.handler.percent4dataPorts[lognum])+0.2)/100.0
                #The following is old
                #memsize = dataPortMemorySizes[lognum]
                
                dpm = int(memsize)
                mtl_size = int(dpm * mtl/100.0) # like 10M times 80%
                new_c2sphy.setMemoryTriggerLevel(mtl_size)
                q330.sendCommand(new_c2sphy)
            elif config.getName() == 'gps':
                c2gps = q330.sendCommand(c2_rqgps())
                c2sgps = c2_sgps(c2gps.getPacketBytes())
                config.setConfigCommand(c2sgps)
                q330.sendCommand(config.getCommand())
            elif config.getName() == 'pll':
                #The same as 'gps' but not in Willard Config menu
                pass
            elif config.getName() == 'AutoMass':
                c2amass = q330.sendCommand(c2_rqamass())
                c2samass = c2_samass(c2amass.getPacketBytes())
                config.setConfigCommand(c2samass)
                q330.sendCommand(config.getCommand())
            elif config.getName() == 'Announce':
                try: # for old firmware without announce yet
                    c3annc = q330.sendCommand(c3_rqannc())
                    c3sannc = c3_sannc(c3annc.getPacketBytes())
                except:
                    c3sannc = c3_sannc()
                    c3sannc.setC3_rqannc(2) #Why? by comparing with above try
                config.setConfigCommand(c3sannc)
                q330.sendCommand(config.getCommand())
            else:
                pass


    def saveToken2Q330(self, q330, tag):
        for i in range(1,5): #4 data ports
            q330.setTokenSet(self.handler.tokenLists[i-1], i)


    def isDuplicateIPs(self):
        IPs = []
        selectedTags = []
        if not len(self.items):
            return 1
        for item in self.items:
            selectedTags.append(item[0])
        for tagNum in self.dictOfDASs.keys():
            if tagNum in selectedTags: # selected ones
                thisDevice = self.dictOfDASs[tagNum]
                IPs.append(dottedIP2Num(thisDevice['IP']))
        IPs.sort()
        for i in range(len(IPs)-1):
            if IPs[i] == IPs[i+1]:
                return 1
        return 0


    def enumQ330T(self):
        discovered = searchQ330s()
        self.dictOfDASs = discovered.getDeviceMap()
            
if __name__ == '__main__':
    items = (['769', '10000044D99D169'],) #tag 769
    xmlfile = open("769.xml","r")
    o = HCSFastXML2Q330s(None, items, xmlfile)
    xmlfile.close()
    o.go()
    o.saveXML2Q330s()
