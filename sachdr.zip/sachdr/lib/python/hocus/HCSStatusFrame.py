#! /usr/bin/env python

from Tkinter import *
from tkFont import Font
from time import gmtime, strftime
import Pmw

Y2K = 946684800 # Y2K is epoch 2000-01-01 00:00:00

class HCSStatus:
    def __init__(self, master, stat):
	Pmw.initialise()
	noteBook = Pmw.NoteBook(master)
	noteBook.pack(fill = 'both',
		      expand = 1,
		      padx = 10,
		      pady = 10)
	
	flag = 1
	for tag in stat.keys():
	    page = noteBook.add('# ' + tag)
	    if flag:
		noteBook.tab('# ' + tag).focus_set()
		flag = 0
	    s = stat[tag]
	    str = '\n'
	    for name in s.keys():
		if name != 'Timestamp of Status':
		    str = str + "%24s:  %s\n" % (name,s[name])
	    ts = long(s['Timestamp of Status']) + Y2K
	    ts = strftime("%Y-%m-%d %H:%M:%S", gmtime(ts))
	    str = str + "\n%24s:  %s\n" % ('Stamped at', ts)
	    lbl = Label(page,
			font = Font(family = 'Courier', size = 10),
			text = str,
			justify = LEFT)
	    lbl.pack(side = TOP, fill = BOTH)
	btnClose = Button(master,
			  text = 'Close',
			  command = master.destroy,
			  bg = 'grey')
	btnClose.pack(side = TOP)
	noteBook.setnaturalsize()

    def unitConverter(self, stat):
	return stat #implemented by derived class

    def tmFormat(self, tm):
	return strftime("%a, %d %b %y %H:%M:%S", gmtime(tm))

    def sec2hr(self, tm):
	hr, remainder = self.divide(tm, 3600)
	min, sec = self.divide(remainder, 60)
	return '%s(h),%s(m),%s(s)' % (hr, min, sec)

    def divide(self, a, b):
	q = a / b
	r = a - q * b
	return q, r
	

class HCSGeneralStatus(HCSStatus):
    def __init__(self, master, stat):
	self.unitConverter(stat)
	HCSStatus.__init__(self, master, stat)
	
    def unitConverter(self, stat):
	for tag in stat.keys():
	    s = stat[tag]
	    tm = long(s['Time of Last Boot']) + Y2K
	    stat[tag]['Time of Last Boot'] = self.tmFormat(tm)
	    tm = long(s['Time of Last Re-Syncs']) + Y2K
	    stat[tag]['Time of Last Re-Syncs'] = self.tmFormat(tm)
	    stat[tag]['Total Hours'] = self.sec2hr(long(stat[tag]['Total Hours']))
	    stat[tag]['Power On Time'] = self.sec2hr(long(stat[tag]['Power On Time']))

	    
class HCSGPSStatus(HCSStatus):
    def __init__(self, master, stat):
	HCSStatus.__init__(self, master, stat)


if __name__ == '__main__':
    status = {'1042': {'Total Number of Re-Syncs': '211',
		       'Time of Last Boot': '160086192',
		       'Status Inputs': '0',
		       'AMB Voltage Control': '4',
		       'Power On Time': '2373381',
		       'Total Hours': '18730650',
		       'Total Number of Boots': '332',
		       'Time of Last Re-Syncs':'160086261',
		       'Timestamp of Status': '160086261'},
	      '760': {'Total Number of Re-Syncs': '229',
		      'Time of Last Boot': '160086072',
		      'Status Inputs': '0',
		      'AMB Voltage Control': '4',
		      'Power On Time': '7343083',
		      'Total Hours': '35859296',
		      'Total Number of Boots': '362',
		      'Time of Last Re-Syncs': '160086141',
		      'Timestamp of Status': '160086261'},
	      '1038': {'Total Number of Re-Syncs': '362',
		       'Time of Last Boot': '160086427',
		       'Status Inputs': '0',
		       'AMB Voltage Control': '4',
		       'Power On Time': '3971541',
		       'Total Hours': '17547391',
		       'Total Number of Boots': '656',
		       'Time of Last Re-Syncs': '160086496',
		       'Timestamp of Status': '160086261'},
	      '1034': {'Total Number of Re-Syncs': '379',
		       'Time of Last Boot': '160086102',
		       'Status Inputs': '0',
		       'AMB Voltage Control': '4',
		       'Power On Time': '5476208',
		       'Total Hours': '18757338',
		       'Total Number of Boots': '637',
		       'Time of Last Re-Syncs': '160086171',
		       'Timestamp of Status': '160086261'},
	      '1033': {'Total Number of Re-Syncs': '235',
		       'Time of Last Boot': '160086159',
		       'Status Inputs': '0',
		       'AMB Voltage Control': '4',
		       'Power On Time': '3131629',
		       'Total Hours': '18756212',
		       'Total Number of Boots': '356',
		       'Time of Last Re-Syncs': '160086228',
		       'Timestamp of Status': '160086261'}}
    
    root = Tk()
    widget = HCSGeneralStatus(root, status)
    root.mainloop()
    
