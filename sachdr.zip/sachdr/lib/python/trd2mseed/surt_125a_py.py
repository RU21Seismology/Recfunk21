
from distutils.core import setup, Extension

setup (name = "rt_125a_py", version = "2010.169",
       ext_modules = [
    Extension (
    "rt_125a_py", ["rt_125a_py.c", "rt_125awrapper_py.c"],
    #extra_link_args = ["-m32"]
)])
