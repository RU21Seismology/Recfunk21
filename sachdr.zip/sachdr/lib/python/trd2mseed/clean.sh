#!/bin/bash

rm -rvf *.pyc *.so
