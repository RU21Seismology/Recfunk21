#!/usr/bin/env python

#
#   Offload data from 125 units
#
#   Steve Azevedo, December 2001
#
from Version import *
PORT = '50000'

import getopt, sys, string
from CommandServer import *

class DasList :
    def __init__ (self) :
        self.server = None
        self.port = None
        self.list = []

#
#    Calculate max, min, mean and standard deviation of data x[]:
#
def meanstdv (x) :
    from math import sqrt
    from sys import maxint
    n, mean, std = len(x), 0, 0
    if n == 0 : return (None, None, None, None)
    max, min = float (maxint) * -1, float (maxint)
    for a in x:
        if a > max :
            max = a
            
        if a < min :
            min = a
            
        mean = mean + a
        
    mean = mean / float(n)
    for a in x:
        std = std + (a - mean)**2

    if n <= 1 :
        n = 2
        
    std = sqrt(std / float(n-1))    
    return max, min, mean, std

#
#   Return a list of elements that there are not duplicates.
#
def unique (a, b) :
    s = a + b
    n = len (s)
    if n == 0 : return []

    ret = []
    u = {}
    
    try :
        for x in s :
            if u.has_key (x) :
                u[x] += 1
            else :
                u[x] = 1

    except TypeError :
        del u
    else :
        for d in s :
            if u[d] == 1 :
                ret.append (d)
                
        return ret

def offload (cs) :
    BAD = {}
    OFFLOAD = {}

    if MODE == 'S' :
        sys.stderr.write ("Offloading (DAS PCT):         ")
        transfers, daspct = cs.dt (1)
    else :
        sys.stderr.write ("Offloading (DAS):         ")
        transfers, daspct = cs.dt (1, MODE)

    dass = transfers.keys ()

    if len (dass) != len (cs.dass) :
        failed = unique (dass, cs.dass)
        for f in failed :
            BAD[f] = "No data offloaded"

    sizes = transfers.values ()

    max, min, mean, std = meanstdv (sizes)

    outlow = mean - std

    pct = daspct.values ()

    max, min, mean, std = meanstdv (pct)

    outpartial = mean - std

    for d in dass :
        if not daspct.has_key (d) :
            BAD[d] = "No offload: %d" % d
            continue
        if outpartial > daspct[d] :
            transfers[d] *= daspct[d]
        if outlow > transfers[d] :
            BAD[d] = "Partial offload: %d bytes approximately" % transfers[d]
        else :
            OFFLOAD[d] = "Offloaded: %d" % transfers[d]

    sys.stdout.write ("\nOffloaded %d DASs\n" % len (OFFLOAD))

    bdass = BAD.keys ()
    bdass.sort ()
    for d in bdass :
        sys.stdout.write ("DAS: %s %s\n" % (d, BAD[d]))

#
#   -f daslist - file containing list of dases
#   -d das:server
#
try :
    opts, args = getopt.getopt (sys.argv[1:], "lf:d:va")
except getopt.GetoptError :
    sys.stderr.write ("Offload data to bridge.\n")
    sys.stderr.write (
        "USAGE: offl [-a][-l][-f daslist.txt]|[-d das:server][-v]\n")
    sys.exit ()

DAS = None
LOGGING = OFF
MODE = 'S'
DASLIST = 'daslist.txt'
TABLE = 'reftek125.tet'

#   Read options
for o, a in opts :
    if o[1] == 'f' :
        DASLIST = a
    elif o[1] == 'd' :
        DAS = a + ':' + PORT
    elif o[1] == 'v' :
        sys.stderr.write ("%s\n" % PROG_VERSION)
        sys.exit ()
    elif o[1] == 'l' :
        LOGGING = ON
    elif o[1] == 'a' :
        MODE = 'A'

#   Read daslist
servers = []
if not DAS :
    if not os.path.exists (DASLIST) :
        sys.stderr.write ("Failed to open: %s\n" % DASLIST)
        sys.exit (-1)
    fh = open (DASLIST, 'r')
    if not fh :
        sys.stderr.write ('Failed to open: %s\n' % DASLIST)
        sys.exit (-1)
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == 'B' :
            line = line[1:]
            s, p = string.split (line, ':')
            o = DasList ()
            o.server = s
            o.port = string.atoi (p)
            servers.append (o)
        elif len (line) == 4 :
            o.list.append (line)
    fh.close ()
else :
    d, s, p = string.split (DAS, ':')
    o = DasList ()
    o.server = s
    o.port = string.atoi (p)
    d = "%04d" % string.atoi (d)
    o.list.append (d)
    servers.append (o)

for s in servers :
    cs = CommandServer (s.server, s.port)
    if LOGGING == ON :
        cs.logging (ON)
    cs.setDass (s.list)
    cs.connect (1)
    offload (cs)
    cs.disconnect (1)
