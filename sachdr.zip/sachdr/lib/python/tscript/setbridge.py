#!/usr/bin/env python

# Read GPS and send the time to the bridge. Needs rtimed.stdout.
#
# Steve Azevedo, December 2004
#
import struct
import socket
import time
import sys
import getopt
from CommandServer import *
from Version import *
import TimeDoy

HOST = ""
PORT = 50007
DASLIST = 'daslist.txt'
SERVERS = []

class DasList :
    def __init__ (self) :
        self.server = None
        self.port = None
        self.list = []

def setbridge (now) :
    ''' Open connection, send time, wait for response '''
    global HOST, PORT
    sock = socket.socket (socket.AF_INET, socket.SOCK_STREAM)

    try :
        sock.connect ((HOST, PORT))
    except :
        print "Connection failed to %s" % HOST
        sys.exit ()

    packet = now
    #
    sock.send (packet)

    try :
        print "Time set on %s. Now: %s" % (HOST, sock.recv (4096)),
    except :
        print "Time not set, lost communication with bridge"

    sock.close ()

def getOptions () :
    ''' Read command line options '''
    global DASLIST
    try :
        opts, args = getopt.getopt (sys.argv[1:], "f:v")
    except getopt.GetoptError :
        sys.stderr.write ("Set time on bridge.\n")
        sys.stderr.write ("USAGE: setbridge [-f daslist.txt] [-v]\n")
        sys.exit ()

    for o, a in opts :
        if o[1] == 'f' :
            DASLIST = a
        elif o[1] == 'v' :
            sys.stderr.write ("%s\n" % PROG_VERSION)
            sys.exit ()

def readdaslist () :
    ''' Read das list '''
    global DASLIST, SERVERS

    if not os.path.exists (DASLIST) :
        sys.stderr.write ("Failed to open: %s\n" % DASLIST)
        sys.exit (-1)
    
    fh = open (DASLIST, 'r')
    if not fh :
        sys.stderr.write ('Failed to open: %s\n' % DASLIST)
        sys.exit (-1)
    
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == 'B' :
            line = line[1:]
            s, p = string.split (line, ':')
            o = DasList ()
            o.server = s
            o.port = string.atoi (p)
            SERVERS.append (o)
        elif len (line) == 4 :
            # We never really use this!
            o.list.append (line)
            
    fh.close ()

def waittime (cs) :
    ''' Get the year, wait to top of minute, return time '''
    year = input ("Input year YYYY: ")
    sys.stderr.write ("GPS:                    ")
    
    while 1 :
        l, s = cs.timeQuery (1)
        if l != 'N' :
            #
            if s[5] == '00' :
                tm = TimeDoy.TimeDoy ()
                #yr = int (s[1])
                yr = year
                doy = int (s[2])
                mo, da = tm.getMonthDay (yr, doy)
                mo += 1
                hr = int (s[3])
                mn = int (s[4])
                sc = int (s[5])
                tstring = "%02d%02d%02d%02d%04d.%02d" % (mo,
                                                         da,
                                                         hr,
                                                         mn,
                                                         yr,
                                                         0)
                sys.stderr.write ('\n')
                return tstring
        else :
            time.sleep (0.1)
    
    cs.disconnect (None)

if __name__ == "__main__" :
    #
    getOptions ()
    readdaslist ()
    #print SERVERS
    for s in SERVERS :
        cs = CommandServer (s.server, s.port)
        cs.setDass (s.list)
        cs.connect (None)
        #now = time.strftime ("%m%d%H%M%Y.%S", time.localtime (time.time ()))
        now = waittime (cs)
        HOST = s.server
        setbridge (now)
