#!/usr/bin/env python

import shutil, os, stat, sys
from compileall import *

#   Location of PASSCAL distribution
ROOTDIR = '/opt/local/passcal'
#

if os.environ.has_key ('PASSCAL') :
    ROOTDIR = os.environ['PASSCAL']
else :
    sys.stderr.write ("PASSCAL environment variable not set!\n")
    sys.exit ()

PROGDIR = os.getcwd ()
PROG = os.path.basename (PROGDIR)
LIBDIR = ROOTDIR + '/lib/python'
BINDIR = ROOTDIR + '/bin'
LIBPROG = LIBDIR + '/' + PROG

PROGS = ('acqd',
         'acqe',
         'asts',
         'batt',
         'bhlt',
         'cgps',
         'enum',
         'flgs',
         'fkit',
         'junk',
         'memo',
         'mlog',
         'offl',
         'para',
         'rset',
         'setpc',
         'setbridge',
	 'stat',
         'tdeploy',
         'tims',
         'tretrieve',
         'vers')

#   compile
for p in PROGS :
    p = p + '.pyc'
    try :
        os.remove (p)
    except OSError :
        pass

try :
    os.remove ('CommandServer.pyc')
except OSError :
    pass

try :
    os.remove ('logger.pyc')
except OSError :
    pass

try :
    os.remove ('rtime.stdout.pyc')
except OSError :
    pass

try :
    os.remove ('Version.pyc')
except OSError :
    pass

compile_dir (".")

command = 'mkdir -p ' + LIBDIR
os.system (command)

try :
    shutil.rmtree (LIBPROG)
except OSError :
    pass

#   install libraries
shutil.copytree (PROGDIR, LIBPROG)

command = 'mkdir -p ' + BINDIR
os.system (command)

#   install programs
for p in PROGS :
    src = p
    dst = BINDIR + '/' + p
    try :
        os.remove (dst)
    except OSError :
        pass
    shutil.copy (src, dst)
    os.chmod (dst, 0557)
