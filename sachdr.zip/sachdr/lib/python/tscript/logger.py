
# logger.py
# logger functions  that logs messages for rt125 command server
# Lloyd Carothers
#
# to use call log("string to log")

# format for input string
# CAUTION, has changed, see CommandServer.py
# mod = os.path.basename(sys._getframe().f_back.f_code.co_filename)
# logger.log("%s\t%s\tOPTS" % ("T" or "R",mod, optvars))

#file names to log to
logfiles = ["125tscript.log", "/tmp/125tscript.log"]

from Version import *
import os
import sys
import time

# Get packet type
def packettype (packet) :
    plen = len (packet)
    filler = plen - 8
    form = "8b%dx" % filler
    ret = struct.unpack (form, packet)
    print "%x\n" % ret[2]
    
#check if log files exist
def check ():
    for lfile in logfiles:
        if os.path.isfile(lfile):
            try:
                os.chmod(file,0644)
            except:
                sys.stderr.write("Failed to change mode of " +lfile+ "\n")
                                
#open logs to write
def openlogs():
    fdList = []
    #print logfiles
    for lfile  in logfiles:
        #print "Open: " + lfile
        try:
            fdList.append( open( lfile, 'a+' ) )
        except  :
            sys.stderr.write("Failed to open "+lfile+" for writing\n")
        
    #write (fdList, "Version: " + PROG_VERSION)
    return fdList
        
#returns log style timestamp string
def timestamp():
    timetuple = time.gmtime(time.time())
    return  "%04d:%03d:%02d:%02d:%02d"%(timetuple[0],
                                        timetuple[7],
                                        timetuple[3],
                                        timetuple[4],
                                        timetuple[5]
                                        )

#write string to logs
def write(fdList, torr, caller, packet):
    string = "%s\t%s\t%r\n" % (torr, caller, packet)
    for fd in fdList:
        fd.write( timestamp() + " " + string)
        #sys.stderr.write ( timestamp () + " " + string + "\n")

#close logs and set permissions
def close (fdList ):
    for fd in fdList:
        fd.close()
        
    #make first (permenant) log READONLY
    #os.chmod(logfiles[0], 0444)

def log(torr, caller, packet):
    #check()
    fdList = openlogs()
    write(fdList, torr, caller, packet)
    #print "Log\n"
    close(fdList)
