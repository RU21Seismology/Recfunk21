#!/usr/bin/env python

# A simple program to set time on bridge from a remote location
#
#   Steve Azevedo, December 2004
#
# Run from xinetd on bridge, sets time on texan bridge
# The Client is setbridge.
#
'''
#
# This goes in /etc/xinetd.d/rtimed
#
service rtimed
{
        disable         = yes
        socket_type     = stream
        protocol        = tcp
        user            = root
        wait            = no
        server          = /etc/reftek/bin/rtimed.stdout.py
}

#  Add this entry to /etc/services
rtimed          50007/tcp                       # Set time remotely
#  Then run "chkconfig --level 345 rtimed on"
'''

import os, os.path
import time
import sys

# Where the date command lives
DATE = "/bin/date"
# Used to sync hardware and system clocks
HWCLOCK = "/sbin/hwclock"

def setTime (timeString) :
    # Set system clock
    if os.path.exists (DATE) :
        command = DATE + " --utc " + timeString + " > /dev/null 2>&1"
        ret = os.system (command)
    else :
        #sys.stderr.write ("Can't find %s\n" % DATE)
        return 0
    # Sync hw clock to sys clock
    if os.path.exists (HWCLOCK) :
        command = HWCLOCK + " --systohc --utc > /dev/null 2>&1"
        ret = os.system (command)
    else :
        #sys.stderr.write ("Can't find %s\n" % HWCLOCK)
        return 0

    if ret == 0 :
        return 1

    return 0

if __name__ == '__main__' :
    # Read time from client
    # Return time on bridge or fail
    receivedData = sys.stdin.read (15)
    if setTime (receivedData) :
        now = time.asctime (time.gmtime (time.time ()))
        #
        sys.stdout.write (now + '\r\n')
    else :
        sys.stdout.write ("OOPS! FAILED!\r\n")

    sys.exit (0)
