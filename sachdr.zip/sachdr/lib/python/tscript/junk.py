#!/usr/bin/env python

#
#   Display erase data from 125 units
#
#   Steve Azevedo, December 2001
#
from Version import *
PORT = '50000'

import getopt, sys, string
from CommandServer import *

class DasList :
    def __init__ (self) :
        self.server = None
        self.port = None
        self.list = []

def de (cs) :
    '''   Data erase   '''
    n = 0
    daslist = []
    head, das, tail = struct.unpack ("!10s4s34s", cs.DE)
    sys.stderr.write ("Erase data: 0000 -")
    now = time.time ()
    for d in cs.dass :
        #   Send each DAS in turn the erase command
        packet = struct.pack ("!10s4s34s", head, d, tail)
        ret = cs.sendPacket (packet)
        if not ret :
            continue
        retPacket = cs.getPackets (deRE)
        if retPacket :
            #   Get which dass responded
            n = 1 + n
            r = deRE.match (retPacket)
            das = r.groups ()[0]
            daslist.append (das)
            cs.pp (das)
            
    #   Sleep to let all dass erase
    daslist.sort ()
    i = 0
    while 1 :
        i = i + 1
        cs.pp (None)
        dass = cs.id ()
        if len (dass) == n :
            break
        if i >= 10 :
            n = len (dass)
            sys.stderr.write ("\nError: Timeout...")
            break

    sys.stderr.write ("\nErased: %d DASs\n" % n )
    #self.dingDong (1)

#
#   -f daslist - file containing list of dases
#   -d das:server
#
try :
    opts, args = getopt.getopt (sys.argv[1:], "lf:d:v")
except getopt.GetoptError :
    sys.stderr.write ("Data erase.\n")
    sys.stderr.write (
        "USAGE: junk [-l][-f daslist.txt]|[-d das:server][-v]\n")
    sys.exit ()

DAS = None
LOGGING = OFF
DASLIST = 'daslist.txt'

#   Read options
for o, a in opts :
    if o[1] == 'f' :
        DASLIST = a
    elif o[1] == 'd' :
        DAS = a + ':' + PORT
    elif o[1] == 'v' :
        sys.stderr.write ("%s\n" % PROG_VERSION)
        sys.exit ()
    elif o[1] == 'l' :
        LOGGING = ON

#   Read daslist
servers = []
if not DAS :
    if not os.path.exists (DASLIST) :
        sys.stderr.write ("Failed to open: %s\n" % DASLIST)
        sys.exit (-1)
    fh = open (DASLIST, 'r')
    if not fh :
        sys.stderr.write ('Failed to open: %s\n' % DASLIST)
        sys.exit (-1)
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == 'B' :
            line = line[1:]
            s, p = string.split (line, ':')
            o = DasList ()
            o.server = s
            o.port = string.atoi (p)
            servers.append (o)
        elif len (line) == 4 :
            o.list.append (line)
    fh.close ()
else :
    d, s, p = string.split (DAS, ':')
    o = DasList ()
    o.server = s
    o.port = string.atoi (p)
    d = "%04d" % string.atoi (d)
    o.list.append (d)
    servers.append (o)

for s in servers :
    cs = CommandServer (s.server, s.port)
    if LOGGING == ON :
        cs.logging (ON)
    cs.setDass (s.list)
    cs.connect (1)
    de (cs)
    cs.disconnect (1)
