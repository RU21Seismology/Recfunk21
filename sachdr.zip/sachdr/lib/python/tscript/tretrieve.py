#!/usr/bin/env python

#
#   Script to retreive data from texans after deployment.
#   Takes as input the IP address of a bridge.
#
#   Does the following in sequence, checking for success after each step:
#   Enumerate, Disable acquisition, Set to GPS time, Check parameter file in
#   each DAS, Check memory, and memory usage in each DAS, High speed offload.
#
#   Prints to stdout and to log list of DASs that failed to offload and reason.
#
#   Steve Azevedo, November 2003
#
from Version import *

import getopt, sys, string, time
from CommandServer import *
import signal

#   Port on bridge
PORT = 50000
#   Bridge IP
IP = ''
#   Master DAS list
DASMASTER = []
#   Command server object
CS = None
#   Error message keyed by DAS
BAD = {}
#   Bytes offloaded keyed by DAS
OFFLOAD = {}
#   Log file instance
LOG = -1
#  Meta info
META = ''
#
LOGGING = OFF

class DasList :
    def __init__ (self) :
        self.server = None
        self.port = None
        self.list = []

def usage () :
    sys.stderr.write (
        "Usage: tretrieve -i bridge-ip-address [-h][-v][-l][-m]\n")
    sys.exit ()

#
#   Print to stdout, and log file DASs that failed
#
def printBAD () :
    global BAD, LOG
    keys = BAD.keys ()
    keys.sort ()
    if LOG and len (BAD) :
        LOG.write ("------------- FAILED ------------\n")
    for d in keys :
        sys.stdout.write ("%04d\t%s\n" % (int (d), BAD[d]))
        if LOG != -1 :
            LOG.write ("%04d\t%s\n" % (int (d), BAD[d]))
#
#   Print to log file offload amounts by DAS
#
def printGOOD () :
    global OFFLOAD, LOG
    if LOG == -1 : return
    keys = OFFLOAD.keys ()
    keys.sort ()
    LOG.write ("------------ OFFLOADED ------------\n")
    for d in keys :
        LOG.write ("%04d\t%s bytes\n" % (int (d), OFFLOAD[d]))

#
#    Calculate max, min, mean and standard deviation of data x[]:
#
def meanstdv (x) :
    from math import sqrt
    from sys import maxint
    n, mean, std = len(x), 0, 0
    if n <= 1 : return (None, None, None, None)
    max, min = float (maxint) * -1, float (maxint)
    for a in x:
        if a > max :
            max = a
            
        if a < min :
            min = a
            
        mean = mean + a
        
    mean = mean / float(n)
    for a in x:
        std = std + (a - mean)**2
        
    std = sqrt(std / float(n-1))    
    return max, min, mean, std

#
#   Return a list of elements that there are not duplicates.
#
def unique (a, b) :
    s = a + b
    n = len (s)
    if n == 0 : return []

    ret = []
    u = {}
    
    try :
        for x in s :
            if u.has_key (x) :
                u[x] += 1
            else :
                u[x] = 1

    except TypeError :
        del u
    else :
        for d in s :
            if u[d] == 1 :
                ret.append (d)
                
        return ret
#
#   Open log file :IP-YYYY:JJJ:HH:MM:SS.log
#
def openLog (IP) :
    log = '/dev/null'
    now = time.strftime ("%Y_%j_%H_%M_%S.log")
    filename = 'R-' + IP + "-" + now
    #log = os.open (filename, os.O_CREAT)
    try :
        log = open (filename, 'w')
    except :
        sys.stderr.write ("Failed to open log file: %s\n" % filename)

    log.write ("%s\n" % filename)
        
    return log

#
#   Get meta info, and write it to the log
#
def getMeta () :
    global META, LOG
    xcase = raw_input ("Enter transcase number(s): ")
    line = raw_input ("Enter line/team number: ")
    
    LOG.write ("x-case: %s\nLine/Team: %s\n" % (xcase, line))

def readDASLIST (DASLIST = 'daslist.txt') :
    #   Read daslist
    servers = []
    if not os.path.exists (DASLIST) :
        sys.stderr.write ("Failed to open: %s\n" % DASLIST)
        sys.exit (-1)
    fh = open (DASLIST, 'r')
    if not fh :
        sys.stderr.write ('Failed to open: %s\n' % DASLIST)
        sys.exit (-1)
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == 'B' :
            line = line[1:]
            s, p = string.split (line, ':')
            o = DasList ()
            o.server = s
            o.port = string.atoi (p)
            servers.append (o)
        elif len (line) == 4 :
            o.list.append (line)
            o.list.append (line)

    fh.close ()

    if len (servers) :
        ip = servers[0].server
    else :
        ip = None

    return ip
    
#
#   Read command line
#   i -> Bridge IP address
#   h -> Heellllppppppp
#
def getCommandLine () :
    global MIN_VOLTS, LOGGING
    ip = par = meta = None
    try :
        opts, args = getopt.getopt (sys.argv[1:], "li:mhv")
    except getopt.GetoptError :
        usage ()

    for o, a in opts :
        if o[1] == 'i' :
            ip = a
        elif o[1] == 'h' :
            usage ()
        elif o[1] == 'm' :
            meta = 1
        elif o[1] == 'v' :
            sys.stderr.write ("%s\n" % PROG_VERSION)
            sys.exit ()
        elif o[1] == 'l' :
            LOGGING = ON

    if ip :
        flds = string.split (ip, '.')
        if len (flds) != 4 :
            sys.stderr.write ("Error: Invalid bridge IP\n")
            sys.exit ()
    else :
        ip = readDASLIST ()
        if not ip :
            usage ()

    return ip, meta

#
#   Get an instance of the command server
#   Return a command server instance
#
def commandServer () :
    cs = CommandServer (IP, PORT)
    if LOGGING == ON :
        cs.logging (ON)
    ret = cs.connect ()
    if not ret : return None
    return cs

#
#   Do an network enumerate
#   Return a list of DASs
#
def enumerate (cs) :
    cs.flushPackets ()
    dass = cs.ne ()
    cs.setDass (dass)
    return dass

#
#   Set time
#
def setTime (cs) :
    global BAD
    goodDas = []
    cs.flushPackets ()
    #   Start timing sequence
    n = cs.ts ()
    time.sleep (1)
    cs.flushPackets ()
    #   See if time flag was set for each unit
    cs.fl ()
    time.sleep (1)
    for s in cs.statFl :
        #print s.das, s.time_set, s.time_set_req
        if s.time_set != '*' :
            BAD[s.das] = "Time not set"
        else :
            goodDas.append (s.das)

    cs.setDass (goodDas)

#
#   Acquisition enable
#
def disable (cs) :
    global BAD
    cs.flushPackets ()
    #   Broadcast enable command
    e, d = cs.aqED ('D')
    time.sleep (0.2)
    cs.flushPackets ()
    cs.aqState ()
    #   See which DASs we heard back from
    for s in cs.statAq :
        #print s.state
        if s.state != 'D' :
            BAD[s.das] = "Acquisition NOT disabled"

#
#   Check parameter file
#
def parameter (cs) :
    global BAD

    from sys import maxint
    
    goodDas = []
    dasLines = {}
    tot = 0
   
    cs.flushPackets () 
    cs.aqState ()
    time.sleep (0.2)

    n = 0
    for s in cs.statAq :
        #   Number of program lines in DAS
        lines = eval ('0x' + s.et_length)
        dasLines[s.das] = lines
        if lines != 0 :
            tot += lines
            n += 1
            
    #   Average number of program lines
    if n != 0 :
        ave = int (tot / n)
    else :
        ave = maxint 

    for d in dasLines.keys () :
        if dasLines[d] < ave :
            BAD[d] = "Lost program: %d lines" % dasLines[d]
        else :
            goodDas.append (d)

    #   Passed
    cs.setDass (goodDas)

#
#   Check memory
#
def memory (cs) :
    global BAD
    goodDas = []
    stsize = []
    offloads = {}
    blocksize = {}
    cs.flushPackets ()

    dass = cs.dm ()
    time.sleep (0.5)

    for m in cs.statDm :
        #   Data block size
        s = int (m.db_size, 16)
        #   Total memory
        tot = int (m.db_total, 16) * s
        #   Available memory
        avail = int (m.db_avail, 16) * s
        #   Used memory
        used = int (m.db_used, 16) * s
        #   Bad memory
        bad = int (m.db_bad, 16) * s
        if bad != 0 :
            BAD[m.das] = "Bad memory: %d" % bad
            continue
        
        offloads[m.das] = used
        #nblocks = float (used / s)
        blocksize[m.das] = s
        stsize.append (used)
        #print m.das, nblocks

    #   Do statistics on number of blocks used
    min, max, mean, std = meanstdv (stsize)
    #   Bounds of standard deviation
    low = int (mean - std + 0.5); high = int (mean + std + 0.5)
    #
    for d in offloads.keys () :
        bs = blocksize[d]
        if (offloads[d] < (low - bs)) or (offloads[d] > (high + bs)):
            BAD[d] = "Memory use suspect: %d No offload" % offloads[d]
        else :
            goodDas.append (d)

    cs.setDass (goodDas)
    
#
#   Data offload
#
def offload (cs) :
    global BAD, OFFLOAD

    cs.flushPackets ()
    transfers, daspct = cs.dt (1)

    dass = transfers.keys ()

    if len (dass) != len (cs.dass) :
        failed = unique (dass, cs.dass)
        for f in failed :
            BAD[f] = "No data offloaded"

    sizes = transfers.values ()

    max, min, mean, std = meanstdv (sizes)

    try :
        outlow = mean - std
    except :
        outlow = 0

    pct = daspct.values ()

    max, min, mean, std = meanstdv (pct)

    try :
        outpartial = mean - std
    except :
        outpartial = 0

    for d in dass :
        if outpartial > daspct[d] :
            transfers[d] *= daspct[d]
        if outlow > transfers[d] :
            BAD[d] = "Partial offload: %d bytes approximately" % transfers[d]
        else :
            OFFLOAD[d] = "Offloaded: %d" % transfers[d]

def goByeBye (a, b) :
    sys.stderr.write ("\n")
    printBAD ()
    printGOOD ()
    CS.disconnect ()
    LOG.close ()
    
    sys.exit ()

def checkn (n) :
    if n <= 0 :
        goByeBye (None, None)

def lastword (cs) :
    nstart = len (DASMASTER)
    ngood = len (cs.dass)
    bad = BAD.keys ()
    nbad = len (bad)
    if (nbad + ngood) == nstart :
        return

    diff = unique (cs.dass, DASMASTER)
    quest = unique (bad, diff)

    for q in quest :
        BAD[q] = "DAS unresponsive"


if __name__ == '__main__' :
    signal.signal (signal.SIGINT, goByeBye)
    IP, PROMPT = getCommandLine ()
    LOG = openLog (IP)
    CS = commandServer ()
    if not CS : sys.exit ()

    if PROMPT :
        getMeta ()
        
    sys.stderr.write ("Net enumerate...")
    DASMASTER = enumerate (CS)
    n = len (CS.dass)
    sys.stderr.write ("%d\nDisable acquisition..." % n)
    checkn (n)
    disable (CS)
    n = len (CS.dass)
    sys.stderr.write ("%d\nSetting time                     " % n)
    checkn (n)
    setTime (CS)
    n = len (CS.dass)
    sys.stderr.write ("...%d\nCheck program..." % n)
    checkn (n)
    parameter (CS)
    n = len (CS.dass)
    sys.stderr.write ("%d\nCheck memory..." % n)
    checkn (n)
    memory (CS)
    n = len (CS.dass)
    sys.stderr.write ("%d\nOffloading data (DAS PCT):         " % n)
    checkn (n)
    offload (CS)
    n = len (OFFLOAD)
    sys.stderr.write ("...%d\n" % n)
    checkn (n)
    lastword (CS)
    goByeBye (None, None)
