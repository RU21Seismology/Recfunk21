#!/usr/bin/env python

from Version import *
PORT = '50000'

import getopt, sys, string
from CommandServer import *

class DasList :
    def __init__ (self) :
        self.server = None
        self.port = None
        self.list = []

def kit (cs) :
    sys.stderr.write ("Loading firmware files (2 per DAS):\n")
    sys.stderr.write ("DAS PCT:         ")
    sys.stderr.flush ()
    cs.fw (1)

try :
    opts, args, = getopt.getopt (sys.argv[1:], "lf:d:v")
except getopt.GetoptError :
    sys.stderr.write ("Display acquisition status.\n")
    sys.stderr.write (
        "USAGE: fkit [-l][-d das:server][-f daslist.txt][-v]\n")
    sys.exit ()

DAS = None
LOGGING = OFF
DASLIST = 'daslist.txt'

for o, a in opts :
    if o[1] == 'f' :
        DASLIST = a
    elif o[1] == 'd' :
        DAS = a + ':' + PORT
    elif o[1] == 'v' :
        sys.stderr.write ("%s\n" % PROG_VERSION)
        sys.exit ()
    elif o[1] == 'l' :
        LOGGING = ON

#   Read daslist
servers = []
if not DAS :
    if not os.path.exists (DASLIST) :
        sys.stderr.write ("Failed to open: %s\n" % DASLIST)
        sys.exit (-1)
    fh = open (DASLIST, 'r')
    if not fh :
        sys.stderr.write ('Failed to open: %s\n' % DASLIST)
        sys.exit (-1)
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == 'B' :
            line = line[1:]
            s, p = string.split (line, ':')
            o = DasList ()
            o.server = s
            o.port = string.atoi (p)
            servers.append (o)
        elif len (line) == 4 :
            o.list.append (line)
    fh.close ()
else :
    d, s, p = string.split (DAS, ':')
    o = DasList ()
    o.server = s
    o.port = string.atoi (p)
    d = "%04d" % string.atoi (d)
    o.list.append (d)
    servers.append (o)

for s in servers :
    cs = CommandServer (s.server, s.port)
    if LOGGING == ON :
        cs.logging (ON)
    cs.setDass (s.list)
    cs.connect (1)
    kit (cs)
    cs.disconnect (1)
