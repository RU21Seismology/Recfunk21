#!/usr/bin/env python

#
#   Class to ease conversion from year/doy to year/month/day
#
#   Steve Azevedo, 000119
#
class TimeDoy :
    def __init__ (self) :
        self.days_in_month = (31,28,31,30,31,30,31,31,30,31,30,31,31)
        self.days_in_month_leap = (31,29,31,30,31,30,31,31,30,31,30,31,31)

    def is_leap_year (self, year) :
        return (year % 4 == 0 and year % 100 != 0 or year % 400 == 0)

    def getMonthDay (self, year, doy) :
        if self.is_leap_year (year) :
            days_in_month = self.days_in_month_leap
        else :
            days_in_month = self.days_in_month
        
        totalDays = 0
        month = 0
        day = 0
        for i in range (12) :
            totalDays = totalDays + days_in_month[i]
            if totalDays > doy :
                totalDays = totalDays - days_in_month[i]
                #   Month = 0-11
                month = i
                day = doy - totalDays
                if day == 0 :
                    day = days_in_month[i - 1]
                #print totalDays, doy, days_in_month[i]
                break

        return (month, day)
        
if __name__ == "__main__" :
    print "Year: 2004, Doy: 335"
    tm = TimeDoy ()
    moda = tm.getMonthDay (2004, 335)
    print ("Month: %d Day: %d" % (moda))

    print "Year: 2004, Doy: 31"
    moda = tm.getMonthDay (2004, 31)
    print ("Month: %d Day: %d" % (moda))

    print "Year: 2004, Doy: 60"
    moda = tm.getMonthDay (2004, 60)
    print ("Month: %d Day: %d" % (moda))

    print "Year: 1980, Doy: 360"
    moda = tm.getMonthDay (1980, 360)
    print ("Month: %d Day: %d" % (moda))

    





