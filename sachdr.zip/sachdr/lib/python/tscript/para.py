#!/usr/bin/env python

#
#   Load event table to 125 units
#
#   Steve Azevedo, December 2001
#
from Version import *
PORT = '50000'

import getopt, sys, string
from CommandServer import *

class DasList :
    def __init__ (self) :
        self.server = None
        self.port = None
        self.list = []

def ee (cs, eventFile = 'reftek125.tet', isLocal = None) :
    '''   Load event table to all connected dass   '''
    termcnt = 0
        
    #   Single das at a time
    if isLocal :
        sys.stderr.write ("Loading event table DAS: 0000 -")
        dl = cs.dass
        termbrk = 1
    #   Broadcast to all DASs (requires ne in same connection)
    else :
        sys.stderr.write ("Loading event table %: 0000 -")
        dl = ['0000']
        termbrk = 2
            
    for d in dl :
        alldone = 0
        #cs.pp (d)
        packet, plines = cs.buildEventPacket (eventFile, d)
        if not packet :
            continue
        
        ret = cs.sendPacket (packet)
        #print "%r" % packet
        #print "Send packet"
        if ret == 1 :
            while 1 :
                if alldone == 1 : break
                retPacket = cs.getPackets (None)
                #print "Get packet"
                if retPacket :
                    pkts = string.split (retPacket, "@#")
                    #print "Split packet"
                    for pkt in pkts :
                        cs.pp (None)
                        #   Read percent complete packets
                        r = pcRE.match (pkt)
                        #print pkt
                        if r :
                            pct, das = r.groups ()
                            if not isLocal :
                                das = pct
                                
                            cs.pp (das)
                            #print "%s %s" % (pct, das)
                            npct = int (pct)
                            if npct >= 100 :
                                #alldone = 1
                                #print "All done one"
                                #break
				pass
                        else :
                            #   Check for 0x81 (server terminate) packets
                            #print "Not PC packet"
                            if len (pkt) == 6 :
                                k, j = struct.unpack ("!B5s", pkt)
                                if int (k) == 129 :
                                    termcnt = 1 + termcnt
                                    if termcnt >= termbrk :
                                        termcnt = 0
                                        alldone = 1
                                        #print "All done"
                                        break
                else :
                    #print "Big break"
                    break
        else :
            sys.stderr.write ("Loading event table DAS: 0000 -")
    #   Get number of lines loaded
    cs.aqState ()            
    sys.stderr.write ('\n')
    #   Print number of lines loaded for each DAS
    dasLines = {}
    tot = 0
    for s in cs.statAq :
        lines = eval ('0x' + s.et_length)
        tot = lines + tot
        dasLines[lines] = s.das
        
    n = len (cs.statAq)
    ave = tot / n
    sys.stderr.write ("Sent %d DASs %d lines\n" %
                      (n, ave))
    for l in dasLines.keys () :
        if l != ave :
            sys.stderr.write ("DAS: %s Lines: %d\n" %
                              (dasLines[l], l))
    #self.dingDong (1)

#
#   -f daslist - file containing list of dases
#   -d das:server:port
#   -t eventtable
#
try :
    opts, args = getopt.getopt (sys.argv[1:], "lf:d:p:nv")
except getopt.GetoptError :
    sys.stderr.write (
        "Load event table.\nDefault event table: 'reftek125.tet'\n")
    sys.stderr.write (
        "USAGE: para [-l][-f daslist.txt]|[-d das:server] [-p eventtable] [-v]\n")
    sys.exit ()

DAS = None
LOGGING = OFF
DASLIST = 'daslist.txt'
TABLE = 'reftek125.tet'
NET = None

#   Read options
for o, a in opts :
    if o[1] == 'f' :
        DASLIST = a
    elif o[1] == 'd' :
        DAS = a + ':' + PORT
    elif o[1] == 'p' :
        TABLE = a
    elif o[1] == 'n' :
        NET = 1
    elif o[1] == 'v' :
        sys.stderr.write ("%s\n" % PROG_VERSION)
        sys.exit ()
    elif o[1] == 'l' :
        LOGGING = ON

if not os.path.exists (TABLE) :
    sys.stderr.write ("Failed to find: %s\n" % TABLE)
    sys.exit ()
    
#   Read daslist
servers = []
if not DAS :
    if not os.path.exists (DASLIST) :
        sys.stderr.write ("Failed to open: %s\n" % DASLIST)
        sys.exit (-1)
    fh = open (DASLIST, 'r')
    if not fh :
        sys.stderr.write ('Failed to open: %s\n' % DASLIST)
        sys.exit (-1)
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == 'B' :
            line = line[1:]
            s, p = string.split (line, ':')
            o = DasList ()
            o.server = s
            o.port = string.atoi (p)
            servers.append (o)
        elif len (line) == 4 :
            o.list.append (line)
    fh.close ()
else :
    d, s, p = string.split (DAS, ':')
    o = DasList ()
    o.server = s
    o.port = string.atoi (p)
    d = "%04d" % string.atoi (d)
    o.list.append (d)
    servers.append (o)

for s in servers :
    cs = CommandServer (s.server, s.port)
    if LOGGING == ON :
        cs.logging (ON)
    cs.connect (1)
    
    if not NET :
        cs.setDass (s.list)
        ee (cs, TABLE, 1)
    else :
        cs.ne ()
        ee (cs, TABLE, None)
    
    cs.disconnect (1)
