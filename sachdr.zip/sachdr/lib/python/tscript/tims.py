#!/usr/bin/env python

#
#   Set time on 125 units
#
#   Steve Azevedo, December 2001
#
from Version import *
PORT = '50000'

BAD = {}

import getopt, sys, string
from CommandServer import *

class DasList :
    def __init__ (self) :
        self.server = None
        self.port = None
        self.list = []
        
#
#   Set time
#
def setTime (cs) :
    global BAD
    goodDas = []
    #   Start timing sequence
    n = cs.ts ()
    time.sleep (1)
    #   See if time flag was set for each unit
    cs.fl ()
    time.sleep (1)
    for s in cs.statFl :
        #print s.das, s.time_set, s.time_set_req
        if s.time_set != '*' :
            BAD[s.das] = "Time not set"
        else :
            goodDas.append (s.das)
                
    sys.stderr.write ("\nSet time on %d DASs\n" % len (goodDas))
    
    for k in BAD.keys () :
        sys.stderr.write ("%04d %s\n" % (int (k), BAD[k]))

#
#   -f daslist - file containing list of dases
#   -d das:server
#
try :
    opts, args = getopt.getopt (sys.argv[1:], "lf:d:v")
except getopt.GetoptError :
    sys.stderr.write ("Time units from locked GPS.\n")
    sys.stderr.write (
        "USAGE: tims [-l][-f daslist.txt]|[-d das:server][-v]\n")
    sys.exit ()

DAS = None
LOGGING = OFF
DASLIST = 'daslist.txt'

#   Read options
for o, a in opts :
    if o[1] == 'f' :
        DASLIST = a
    elif o[1] == 'd' :
        DAS = a + ':' + PORT
    elif o[1] == 'v' :
        sys.stderr.write ("%s\n" % PROG_VERSION)
        sys.exit ()
    elif o[1] == 'l' :
        LOGGING = ON

#   Read daslist
servers = []
if not DAS :
    if not os.path.exists (DASLIST) :
        sys.stderr.write ("Failed to open: %s\n" % DASLIST)
        sys.exit (-1)
    fh = open (DASLIST, 'r')
    if not fh :
        sys.stderr.write ('Failed to open: %s\n' % DASLIST)
        sys.exit (-1)
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == 'B' :
            line = line[1:]
            s, p = string.split (line, ':')
            o = DasList ()
            o.server = s
            o.port = string.atoi (p)
            servers.append (o)
        elif len (line) == 4 :
            o.list.append (line)
    fh.close ()
else :
    d, s, p = string.split (DAS, ':')
    o = DasList ()
    o.server = s
    o.port = string.atoi (p)
    d = "%04d" % string.atoi (d)
    o.list.append (d)
    servers.append (o)

for s in servers :
    cs = CommandServer (s.server, s.port)
    if LOGGING == ON :
        cs.logging (ON)
    cs.setDass (s.list)
    cs.connect (1)
    #   For the server to handle time it must have a net enumerate
    #cs.ne ()
    setTime (cs)
    cs.disconnect (1)
