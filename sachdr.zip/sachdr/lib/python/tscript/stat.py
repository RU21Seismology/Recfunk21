#!/usr/bin/env python

#
#   Display status 125 units
#
#   Steve Azevedo, December 2001
#
from Version import *
PORT = '50000'

import getopt, sys, string
from CommandServer import *

class DasList :
    def __init__ (self) :
        self.server = None
        self.port = None
        self.list = []

def status (cs) :
    DM = {}
    ID = {}
    FL = {}
    cs.aqState ()
    cs.dm ()
    cs.id ()
    cs.fl ()

    for o in cs.statDm :
        s = int (o.db_size, 16)
        used = "%09d" % (int (o.db_used, 16) * s)
        bad = "0x" + o.db_bad
        DM[o.das] = (used, bad)

    for o in cs.statId :
        ID[o.das] = "%3.1f" % float (o.batt_volts)

    for o in cs.statFl :
        if o.time_set == '*' :
            FL[o.das] = 'OK'
        else :
            FL[o.das] = '*** NO ***'
            
    for s in cs.statAq :
        print "DAS: %s Lines: %d Used: %s Bad: %s Volts: %s Set: %s" % (
            s.das,
            eval ('0x' + s.et_length),
            DM[s.das][0],
            DM[s.das][1],
            ID[s.das],
            FL[s.das]) 

#
#   -f daslist - file containing list of dases
#   -d das:server
#
try :
    opts, args = getopt.getopt (sys.argv[1:], "lf:d:v")
except getopt.GetoptError :
    sys.stderr.write ("Display acquisition status.\n")
    sys.stderr.write (
        "USAGE: asts [-l][-f daslist.txt]|[-d das:server][-v]\n")
    sys.exit ()

DAS = None
LOGGING = OFF
DASLIST = 'daslist.txt'

#   Read options
for o, a in opts :
    if o[1] == 'f' :
        DASLIST = a
    elif o[1] == 'd' :
        DAS = a + ':' + PORT
    elif o[1] == 'v' :
        sys.stderr.write ("%s\n" % PROG_VERSION)
        sys.exit ()
    elif o[1] == 'l' :
        LOGGING = ON

#   Read daslist
servers = []
if not DAS :
    if not os.path.exists (DASLIST) :
        sys.stderr.write ("Failed to open: %s\n" % DASLIST)
        sys.exit (-1)
    fh = open (DASLIST, 'r')
    if not fh :
        sys.stderr.write ('Failed to open: %s\n' % DASLIST)
        sys.exit (-1)
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == 'B' :
            line = line[1:]
            s, p = string.split (line, ':')
            o = DasList ()
            o.server = s
            o.port = string.atoi (p)
            servers.append (o)
        elif len (line) == 4 :
            o.list.append (line)
    fh.close ()
else :
    d, s, p = string.split (DAS, ':')
    o = DasList ()
    o.server = s
    o.port = string.atoi (p)
    d = "%04d" % string.atoi (d)
    o.list.append (d)
    servers.append (o)

for s in servers :
    cs = CommandServer (s.server, s.port)
    if LOGGING == ON :
        cs.logging (ON)
    cs.setDass (s.list)
    cs.connect (1)
    status (cs)
    cs.disconnect (1)
