#!/usr/bin/env python

#
#   Disable acquisition on 125 units
#
#   Steve Azevedo, December 2001
#
from Version import *
PORT = '50000'

import getopt, sys, string, os
from CommandServer import *

class DasList :
    def __init__ (self) :
        self.server = None
        self.port = None
        self.list = []
        
def aq (cs, state) :
    '''   Set and report on acquisition state   '''
    if state == 'E' :
        sys.stderr.write ("Enable acquisition: 0000 -")
        #for i in range (120) :
        #    cs.pp (None)
        #    time.sleep (0.5)
            
        enabled, disabled = cs.aqED (state)
    elif state == 'D' :
        sys.stderr.write ("Disable acquisition: 0000 -")
        enabled, disabled = cs.aqED (state)
    else :
        return None
    
    sys.stderr.write ('\n')
    if state == 'E' :
        if len (disabled) != 0 :
            k = disabled.keys ()
            k.sort ()
            for d in k :
                sys.stderr.write ("Das: %s NOT enabled\n" % d)
        else :
            sys.stderr.write ("Enabled %d DASs\n" % len (enabled))
    elif state == 'D' :
        if len (enabled) != 0 :
            k = enabled.keys ()
            k.sort ()
            for d in k :
                sys.stderr.write ("Das: %s STILL enabled\n" % d)
        else :
            sys.stderr.write ("Disabled %d DASs\n" % len (disabled))
        #self.dingDong (1)

#
#   -f daslist - file containing list of dases
#   -d das:server:port
#
try :
    opts, args = getopt.getopt (sys.argv[1:], "lf:d:v")
except getopt.GetoptError :
    sys.stderr.write ("Acquisition disable.\n")
    sys.stderr.write (
        "USAGE: acqd [-l][-f daslist.txt]|[-d das:server][-v]\n")
    sys.exit ()

DAS = None
DASLIST = 'daslist.txt'
TABLE = 'reftek125.tet'
LOGGING = OFF

#   Read options
for o, a in opts :
    if o[1] == 'f' :
        DASLIST = a
    elif o[1] == 'd' :
        DAS = a + ':' + PORT
    elif o[1] == 'v' :
        sys.stderr.write ("%s\n" % PROG_VERSION)
        sys.exit ()
    elif o[1] == 'l' :
        LOGGING = ON

#   Read daslist
servers = []
if not DAS :
    if not os.path.exists (DASLIST) :
        sys.stderr.write ("Failed to open: %s\n" % DASLIST)
        sys.exit (-1)
    fh = open (DASLIST, 'r')
    if not fh :
        sys.stderr.write ('Failed to open: %s\n' % DASLIST)
        sys.exit (-1)
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == 'B' :
            line = line[1:]
            s, p = string.split (line, ':')
            o = DasList ()
            o.server = s
            o.port = string.atoi (p)
            servers.append (o)
        elif len (line) == 4 :
            o.list.append (line)
    fh.close ()
else :
    d, s, p = string.split (DAS, ':')
    o = DasList ()
    o.server = s
    o.port = string.atoi (p)
    d = "%04d" % string.atoi (d)
    o.list.append (d)
    servers.append (o)

for s in servers :
    cs = CommandServer (s.server, s.port)
    if LOGGING == ON :
        cs.logging (ON)
    cs.setDass (s.list)
    cs.connect (1)
    aq (cs, 'D')
    cs.disconnect (1)
