#!/usr/bin/env python

#
#   A class to communicate with the RefTek 125 command server.
#
#   Steve Azevedo, December 2001
#

import socket
import select
import struct
import string
import sys
import re
import time
import os
import logger

#   PROG_VERSION 2004.328d (set in Version.py)
from Version import *
VERBOSE = 0
ON = 1
OFF = 0
#   Write log file?
WLOG = OFF
#

connectedRE = re.compile (".*SSREADY.*")
packetRE = re.compile ("@#.*")
neRE = re.compile (".*(\d\d\d\d)NENE.*")
neRespRE = re.compile (".*NE(\d\d\d\d)(\d\d\d\d).*")
idRE = re.compile (".*STID(.{74}).*")
dmRE = re.compile (".*STDM(.{36}).*")
flRE = re.compile (".*STFL(.{24}).*")
deRE = re.compile (".*(\d\d\d\d)DEDE.*")
rsRE = re.compile (".*(\d\d\d\d)RS.{8}RS.*")
pcRE = re.compile (".*PC(\d{4})(\d{4}).*")
aqRE = re.compile (".*(\d{4}AQ.{10})AQ.*")
tqRE = re.compile (".*TS\d{13}.TS.*")
tsRE = re.compile (".*(\d{4})TSOKTS.*")
dtRE = re.compile (".*(\d{4})DT. (.{4})(.{4})    (..)DT.*")
msRE = re.compile (".*MS(\w{5})(.*)\n")
fwRE = re.compile (".*FW(\d{4})(\w\w)")

#   Status FL structure
class Fl :
    def __init__ (self) :
        self.das = '?'
        self.watchdog = '?'
        self.powerup = '?'
        self.xtal = '?'
        self.time_set_req = '?'
        self.time_set = '?'
        self.test_code = '?'
        self.id_set = '?'
        self.fpga_valid = '?'
        self.vcxo = '?'
        self.question = '?'
        self.memory_irq = '?'
        self.fpga_irq = '?'
        self.event_table = '?'
        self.acquisition = '?'
        self.event_in_progress = '?'
        self.ad_irq = '?'
        self.ad_power = '?'
        self.sprom_error = '?'
        self.sprom_protect = '?'
        self.serial_receive = '?'
        self.serial_xmit = '?'
        self.memory_error = '?'
        self.memory_page = '?'
        
#   Status ID structure
class Id :
    def __init__ (self) :
        self.das = "?"
        self.reset = "?"
        self.sys_time = "?"
        self.cpu_code_ver = "?"
        self.cpu_soft_crc = "?"
        self.fpga_id = "?"
        self.fpga_ver = "?"
        self.fpga_firm_crc = "?"
        self.cpu_clock_speed = "?"
        self.ad_clock_speed = "?"
        self.ad_fs_volts = "?"
        self.batt_volts = "?"

#   Status DM structure
class Dm :
    def __init__ (self) :
        self.das = "?"
        self.db_size = "?"
        self.db_total = "?"
        self.db_avail = "?"
        self.db_used = "?"
        self.db_bad = "?"

#   Acquisition status structure
class Aq :
    def __init__ (self) :
        self.das = '?'
        self.state = '?'
        self.et_length = '?'
        self.et_entry = '?'

class CommandServer :
    #   Net enumerate packet
    NE = struct.pack ("!24B",
                      0x40, 0x23, 0x80, 0x00, 0x00, 0x00, 0x00, 0x18,
                      0x82,
                      0x00,
                      0x30,
                      0x30,
                      0x30,
                      0x30,
                      0x4E,
                      0x45,
                      0x4E,
                      0x45,
                      0x30,
                      0x30,
                      0x30,
                      0x30,
                      0x0D,
                      0x0A)
    #   Status ID packet
    ST = struct.pack ("!26B",
                      0x40, 0x23, 0x80, 0x00, 0x00, 0x00, 0x00, 0x1A,
                      0x82,
                      0x00,
                      0x30,
                      0x30,
                      0x30,
                      0x30,
                      0x53,
                      0x54,
                      0x49,
                      0x44,
                      0x53,
                      0x54,
                      0x00,
                      0x00,
                      0x00,
                      0x00,
                      0x0D,
                      0x0A)
    #   Data Erase packet
    DE = struct.pack ("!48B",
                      0x40, 0x23, 0x80, 0x00, 0x00, 0x00, 0x00, 0x30,
                      0x82,
                      0x00,
                      0x00,
                      0x00,
                      0x00,
                      0x00,
                      0x44,
                      0x45,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x44,
                      0x45,
                      0x00,
                      0x00,
                      0x00,
                      0x00,
                      0x0D,
                      0x0A)
    #   Reset packet
    RS = struct.pack ("!32B",
                      0x40, 0x23, 0x80, 0x00, 0x00, 0x00, 0x00, 0x20,
                      0x82,
                      0x00,
                      0x30,
                      0x30,
                      0x30,
                      0x30,
                      0x52,
                      0x53,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x52,
                      0x53,
                      0x00,
                      0x00,
                      0x00,
                      0x00,
                      0x0D,
                      0x0A)
    #   Acquisition packet
    AQ = struct.pack ("!32B",
                      0x40, 0x23, 0x80, 0x00, 0x00, 0x00, 0x00, 0x20,
                      0x82,
                      0x00,
                      0x30,
                      0x30,
                      0x30,
                      0x30,
                      0x41,
                      0x51,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x41,
                      0x51,
                      0x00,
                      0x00,
                      0x00,
                      0x00,
                      0x0D,
                      0x0A)
    #   Time query packet
    TQ = struct.pack ("!14B",
                      0x40, 0x23, 0x90, 0x00, 0x00, 0x00, 0x00, 0x0E,
                      0x54,
                      0x53,
                      0x54,
                      0x53,
                      0x0D,
                      0x0A)
    #   Time set packet
    TS = struct.pack ("!42B",
                      0x40, 0x23, 0x80, 0x00, 0x00, 0x00, 0x00, 0x2A,
                      0x82,
                      0x00,
                      0x30,
                      0x30,
                      0x30,
                      0x30,
                      0x54,
                      0x53,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x58,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x54,
                      0x53,
                      0x00,
                      0x00,
                      0x00,
                      0x00,
                      0x0D,
                      0x0A)
    #   Data transfer packet
    DT = struct.pack ("!50B",
                      0x40, 0x23, 0x80, 0x00, 0x00, 0x00, 0x00, 0x32,
                      0x82,
                      0x00,
                      0x30,
                      0x30,
                      0x30,
                      0x30,
                      0x44,
                      0x54,
                      0x53,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x44,
                      0x54,
                      0x00,
                      0x00,
                      0x00,
                      0x00,
                      0x0D,
                      0x0A)
    #   Firmware loader packet
    FW = struct.pack ("!32B",
                      0x40, 0x23, 0x80, 0x00, 0x00, 0x00, 0x00, 0x20,
                      0x82,
                      0x00,
                      0x30,
                      0x30,
                      0x30,
                      0x30,
                      0x46,
                      0x57,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x20,
                      0x46,
                      0x57,
                      0x00,
                      0x00,
                      0x00,
                      0x00,
                      0x0D,
                      0x0A)
                      
    def __init__ (self, server, port) :
        #   Server IP
        self.server = server
        #   Server port
        self.port = port
        #   Get the socket
        self.socket = socket.socket (socket.AF_INET, socket.SOCK_STREAM)
        #   List of DASs from enumerate
        self.dass = []
        #   List of status id objects
        self.statId = []
        #   List of status memory objects
        self.statDm = []
        #   List of status flags objects
        self.statFl = []
        #   List of acquisition status objects
        self.statAq = []
        #   Dictionary of transfer (recorded) amounts keyed on das
        self.transfers = {}
        self.ii = 0
        # Read trys in getPackets
        self.readTrys = 60000

    def version (self) :
        return self.PROG_VERSION

    def logging (self, what) :
        global WLOG
        WLOG = what
        #print "logging " + str (WLOG)
    
    def setDass (self, daslist) :
        '''   Set dass without net enumerate   '''
        self.dass = []
        for d in daslist :
            self.dass.append (d)
        self.dass.sort ()

    def ne (self) :
        '''  Net enumerate, place result in self.dass, return self.dass   '''
        self.dass = []
        alldone = 0
        ret = self.sendPacket (self.NE)
        if not ret :
            sys.stderr.write ("Failed: net enumerate on timeout\n")
            return None

        while 1 :
            if alldone : break
            #   Read pending command server packets
            dat = self.getPackets (None)
            if not dat : break

            #if didServerTerminate (dat) :
                #break
            #   Loop through all the packets
            pkts = string.split (dat, '@#')
            for pkt in pkts :
                d = neRE.match (pkt)       #   Net enumerate packet
                if d :
                    self.dass.append (d.groups ()[0])
                    continue

                d = neRespRE.match (pkt)   #   Decade being enumerated
                if d :
                    max, cur = d.groups ()
                    max = string.atoi (max); cur = string.atoi (cur)
                    if (cur + 100) >= max :
                        alldone = 1

        self.dass.sort ()
        return self.dass

    def pp (self, d) :
        '''   Activity indicator   '''
        mod = self.ii % 2
        if mod != 0 :
            if d :
                sys.stderr.write ("\b\b\b\b\b\b%s >" % d)
            else :
                sys.stderr.write ("\b>")
        else :
            if d :
                sys.stderr.write ("\b\b\b\b\b\b%s -" % d)
            else :
                sys.stderr.write ("\b-")
        self.ii = 1 + self.ii
        sys.stderr.flush ()

    def didServerTerminate (self, ret) :
        ''' Check return for server termination '''
        pkts = string.split (ret, "@#")
        for pkt in pkts :
            if len (pkt) == 6 :
                k, j = struct.unpack ("!B5s", pkt)
                # Server term packet 0x81
                if int (k) == 129 :
                    return 1

        return 0

    def getPackets (self, m, pause = 0) :
        '''
        Read packets from socket until match on RE m is found, if RE == None
        return last packet(s)
        if pause == 1 an additional delay is added to catch server termination
        if there is an error during offload.
        '''
        s = [self.socket]
        buf = None
        alldone = 0

        #   Find who called us
        #mod = os.path.basename(sys._getframe().f_back.f_code.co_filename)
        mod = '????'
        for i in range (6) :
            try :
                mod = sys._getframe(i).f_code.co_filename
                #print mod
                modold = mod
            except : break
            mod = modold

        #   Try to read this many times
        trys = self.readTrys
        while 1 :
            if alldone == 1 : break
            #   Non-blocking
            i, o, e = select.select (s, s, s, 0.1)
            #   if i then there is input waiting in the buffer
            if i :
                dat = self.socket.recv (1024)
                if VERBOSE :
                    print "getPackets: %r" % dat
                #   This appears to be a server packet
                if packetRE.match (dat) :
                    #   No RE so return whole string
                    if not m :
                        buf = dat
                        break
                    ret = string.split (dat, "@#")
                    #   Loop through all the packets
                    for p in ret :
                        #   Return ONLY the packet that matches the RE
                        if m.match (p) :
                            buf = '@#' + p
                            if VERBOSE :
                                print "getPackets: %r" % buf
                            alldone = 1
                            break
            else :
                if VERBOSE :
                    pass
                    #print "getPackets: %s" % trys
                trys -= 1
                if pause :
                    time.sleep (0.05)
                if trys <= 0 :
                    break
        #print "getPackets " + str (WLOG)
        if WLOG :
            #print mod
            logger.log("R", mod, buf)

        return buf

    def flushPackets (self) :
        ''' Flush any packets remaining in buffer '''
        trys = self.readTrys
        self.readTrys = 5000
        while 1 :
            ret = self.getPackets (None)
            if not ret : break

        self.readTrys = trys

    def sendPacket (self, packet, to = 10) :
        '''
        Attempt to send 'packet' to the server and timeout after 'to' seconds
        '''

        #   Find who called us
        #mod = os.path.basename(sys._getframe().f_back.f_code.co_filename)
        mod = '????'
        for i in range (6) :
            try :
                mod = sys._getframe(i).f_code.co_filename
                #print mod
                modold = mod
            except : break
            mod = modold

        if VERBOSE :
            print "sendPacket: %r" % packet
        s = [self.socket]
        ret = []
        i, o, e = select.select (s, s, s, to)
        if o :
            self.socket.send (packet)
            if WLOG :
                #print mod
                logger.log ("T", mod, packet)
        
            return 1
        else :
            sys.stderr.write ("\nFailed: Send packet on timeout: %d\n" % to)
            return None
        
    def das (self) :
        '''   Print a list of DASs found by enumerate   '''
        for d in self.dass :
            sys.stdout.write ("%04d\n" % int (d))
        
    def timeQuery (self, p = 0) :
        '''   Query GPS for time and status   '''
        pctime = time.gmtime (time.time ())
        pcyear = pctime[0]
        ret = self.sendPacket (self.TQ)
        if ret == 1 :
            dat = self.getPackets (tqRE)
            if not dat :
                return None, None
            sTuple = struct.unpack ("!10s4s3s2s2s2ss4s", dat)
            bridgeyear = int (sTuple[1])
            #print sTuple[6]
            if sTuple[6] == ' ' :
                lu = 'L'
            else :
                lu = 'N'

            #   Bridge clock year and PC clock year do not agree
            if pcyear != bridgeyear :
                lu = 'U'
                
            tstring = ("%s:%s:%s:%s:%s %s" % (sTuple[1],
                                              sTuple[2],
                                              sTuple[3],
                                              sTuple[4],
                                              sTuple[5],
                                              lu))
            if p :
                sys.stderr.write ("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b")
                sys.stderr.write ("%s" % tstring)
                sys.stderr.flush ()
            #   Return status and seconds
            return lu, sTuple

    def timeSet (self, p = 0) :
        '''   Time stamp units, return number responding   '''
        head, das, tail = struct.unpack ("!10s4s28s", self.TS)
        n = 0
        alldone = 0
        l = len (self.dass)
        if l == 0 : return 0
        for d in self.dass :
            packet = struct.pack ("!10s4s28s", head, d, tail)
            #print "%r" % packet
            ret = self.sendPacket (packet)
            if not ret :
                sys.stderr.write ("Time set message not correct\n")
                return None
        while 1 :
            #print "waiting"
            if alldone == 1 : break
            retPacket = self.getPackets (None)
            if retPacket :
                pkts = string.split (retPacket, "@#")
                for pkt in pkts :
                    #print "%r" % pkt
                    r = tsRE.match (pkt)
                    if r :
                        das = r.groups ()[0]
                        if p : self.pp (das)
                        n = 1 + n
                        #print das, n
                        if n >= l :
                            alldone = 1
                    else :
                        #   Check for server terminate packets
                        if len (pkt) == 6 :
                            k, j = struct.unpack ("!B5s", pkt)
                            if int (k) == 129 :
                                alldone = 1
        return n

    def ts (self) :
        '''   Time set   '''
        daslist = []
        notset = 1

        tries = 0
        while notset :
            tries += 1
            while 1 :
                l, s = self.timeQuery (1)
                min = string.atoi (s[5])
                #   Locked and 5 seconds before the minute
                if l == 'L' and (min >= 55 and min < 56) :
                    break
                #   Sleep for 1/5 second
                time.sleep (0.2)
                
            #   Send time set request
            n = self.timeSet (0)
            time.sleep (0.3)
            l, s = self.timeQuery (1)
            time.sleep (0.3)
            #   Still locked
            if l == 'L' :
                notset = 0
                
            if tries >= 3 :
                notset = 0
                n = 0

            if l == 'L' :
                for i in range (30) :
                    l, s = self.timeQuery (1)
                    if string.atoi (s[5]) == 0 :
                        break
                    time.sleep (0.2)

        return n

    def de (self) :
        '''   Data erase, returns list of das message sent to   '''
        daslist = []
        
        head, das, tail = struct.unpack ("!10s4s34s", self.DE)
        
        for d in self.dass :
            packet = struct.pack ("!10s4s34s", head, d, tail)
            ret = self.sendPacket (packet)
            if not ret : continue

            retPacket = self.getPackets (deRE)
            if retPacket :
                r = deRE.match (retPacket)
                das = r.groups ()[0]
                daslist.append (das)

        return daslist

    def dt (self, p = 0, m = 'S') :
        '''   Data transfer   '''
        self.transfers = {}
        daspct = {}

        head, das, tail = struct.unpack ("!10s4s36s", self.DT)
        # Set transfer mode
        tail = tail[:2] + m + tail[3:]
        #ReTry = 0
        for d in self.dass :
            alldone = 0
            packet = struct.pack ("!10s4s36s", head, d, tail)
            ret = self.sendPacket (packet)
            if ret == 1 :
                while 1 :
                    if alldone :
                        break

                    dat = self.getPackets (None, 1)
                    if not dat :
                        #print "Server timed out"
                        time.sleep (3)
                        continue

                    pkts = string.split (dat, "@#")
                    for pkt in pkts :
                        r = dtRE.match (pkt)
                        if r :
                            #   Initial response from das
                            das, bs, bc, hs = r.groups ()
                            bs = eval ('0x' + bs); bc = eval ('0x' + bc)
                            tot = bs * bc
                            self.transfers[das] = tot
                            if p :
                                sys.stderr.write ("\b\b\b\b\b\b\b\b")
                                sys.stderr.write ("%s 000" % das)
                            continue

                        if p :
                            r = pcRE.match (pkt)
                            if r :
                                #   Read PC packets
                                pct, das = r.groups ()
                                sys.stderr.write ("\b\b\b%03d" % int (pct))
                                daspct[das] = float (pct) / 100.0
                                continue
                        
                        if len (pkt) == 6 :
                            k, j = struct.unpack ("!B5s", pkt)
                            #   Server term packet 0x81
                            if int (k) == 129 :
                                alldone = 1
                                
        #   Return dictionary of data bytes offloaded keyed by das
        return self.transfers, daspct

    def ee (self, eventFile = 'reftek125.tet', isLocal = 1) :
        '''   Load event table   '''
        termcnt = 0
        daslist = []
        plines = -1

        #   One at a time
        if isLocal :
            dl = self.dass
            termbrk = 1
        #   Broadcast to all das
        else :
            dl = ['0000']
            termbrk = 2

        #   For each das
        for d in dl :
            alldone = 0
            packet, plines = self.buildEventPacket (eventFile, d)
            if not packet :
                continue

            ret = self.sendPacket (packet, 30)
            if ret == 1 :
                daslist.append (d)
                while 1 :
                    if alldone == 1 : break

                    retPacket = self.getPackets (None)
                    if retPacket :
                        pkts = string.split (retPacket, '@#')
                        for pkt in pkts :
                            r = pcRE.match (pkt)
                            if r :
                                pct, das = r.groups ()
                                if not isLocal :
                                    das = pct

                                npct = int (pct)
                                if npct >= 100 :
                                    #alldone = 1
                                    #break
                                    pass
                                
                            else :
                                #   Check for server terminate packets, 0x81
                                if len (pkt) == 6 :
                                    k, j = struct.unpack ("!B5s", pkt)
                                    if int (k) == 129 :
                                        termcnt = termcnt + 1
                                        if termcnt >= termbrk :
                                            termcnt = 0
                                            alldone = 1
                                            break

                    else :
                        break
        return daslist.sort (), plines

    def rs (self) :
        '''   Re-set each das   '''
        head, das, tail = struct.unpack ("!10s4s18s", self.RS)
        daslist = []
        for d in self.dass :
            packet = struct.pack ("!10s4s18s", head, d, tail)
            ret = self.sendPacket (packet)
            if not ret : continue
            time.sleep (0.2)
            retPacket = self.getPackets (rsRE)
            if retPacket :
                r = rsRE.match (retPacket)
                das = r.groups ()[0]
                daslist.append (das)
                #time.sleep (0.2)

        return daslist

    def id (self) :
        '''   Get Status ID of units  '''
        daslist = []
        self.statId = []
        head, das, j1, fl, tail = struct.unpack ("!10s4s2s2s8s", self.ST)
        #sys.stderr.write ("Status ID: 0000 -")
        for d in self.dass :
            #   Build packet for each DAS
            packet = struct.pack ("!10s4s2sBB8s",
                                  head,
                                  d,
                                  j1,
                                  0x49,
                                  0x44,
                                  tail)
            ret = self.sendPacket (packet)
            #   We sent the packet now wait for the return
            if ret == 1 :
                retPacket = self.getPackets (idRE)
                if retPacket :
                    #   Fill the fields
                    r = idRE.match (retPacket)
                    #self.pp (d)
                    g = r.groups ()[0]
                    sTuple = struct.unpack ("!4s14s8s4s8s6s4s8s8s6s4s", g)
                    o = Id ()
                    o.das = d
                    o.reset = sTuple[0]
                    o.sys_time = sTuple[1]
                    o.cpu_code_ver = sTuple[2]
                    o.cpu_soft_crc = sTuple[3]
                    o.fpga_id = sTuple[4]
                    o.fpga_ver = sTuple[5]
                    o.fpga_firm_crc = sTuple[6]
                    o.batt_volts = sTuple[10]
                    self.statId.append (o)
                    daslist.append (d)
                    #time.sleep (5)

        return daslist
            
    def buildSpacket (self, cnt, line, das) :
        '''   Build packet from line in event table   '''
        spacket = struct.pack ("!BB4sBBBBBB16sBBBBBBBBBB",
                               0x82,
                               0x00,
                               das,
                               0x45,
                               0x45,
                               cnt[0],
                               cnt[1],
                               cnt[2],
                               cnt[3],
                               line,
                               0x20,
                               0x20,
                               0x45,
                               0x45,
                               0x00,
                               0x00,
                               0x00,
                               0x00,
                               0x0D,
                               0x0A)
        return spacket
            
    def buildEventPacket (self, eventFile, das = '0000') :
        '''   Build a command server packet from an event table   '''
        fh = open (eventFile, "r")
        #   The finished packet
        packet = None
        #   The packet containing a line from the event table
        spacket = None
        #   The packet containing all the lines
        bpacket = ''
        #   Count of lines in event table
        lcount = 0
        while 1 :
            cnt = []
            line = fh.readline ()
            if not line : break
            #   Skip comments
            s = line[0:4]
            if not s.isdigit () : continue
            #   Format the line to satisfy the command spec
            line = string.join (string.split (string.strip (line), ':'), '')
            line = line[0:15] + line[-1]
            #   Trailer
            f0 = line[0:-2] + 'F0'
            #   Get the entry number 0000 to 4999
            if lcount > 4999 :
                sys.stderr.write ("Error: Event table over 4999 lines!\n")
                return None
            scount = "%04d" % lcount
            for c in scount :
                cnt.append (ord (c))
            lcount = 1 + lcount
            #   Build line packet and append to built packet
            spacket = self.buildSpacket (cnt, line, das)
            bpacket = bpacket + spacket

        fh.close ()
        scount = "%04d" % lcount
        for c in scount :
            cnt.append (ord (c))
        lcount = 1 + lcount
        #   Build and append trailer
        spacket = self.buildSpacket (cnt, f0, '0000')
        bpacket = bpacket + spacket
        #   Now build command server packet
        #   Calculate total packet length
        lenp = "%08X" % ((lcount * 38) + 10)
        h = []
        for i in range (0, 8, 2) :
            h.append ('0x' + lenp[i:i+2])
        
        head = struct.pack ("!BBBBBBBBBB",
                            0x40,
                            0x23,
                            0x90,
                            0x00,
                            eval (h[0]),
                            eval (h[1]),
                            eval (h[2]),
                            eval (h[3]),
                            0x45,
                            0x45)
        #   Build final packet
        packet = head + bpacket
        return packet, lcount - 1


    def dm (self) :
        '''   Get status memory   '''
        daslist = []
        self.statDm = []
        head, das, j1, fl, tail = struct.unpack ("!10s4s2s2s8s", self.ST)
        #sys.stderr.write ("Status DM: 0000 -")
        for d in self.dass :
            packet = struct.pack ("!10s4s2sBB8s",
                                  head,
                                  d,
                                  j1,
                                  0x44,
                                  0x4D,
                                  tail)
            ret = self.sendPacket (packet)
            if ret == 1 :
                retPacket = self.getPackets (dmRE)
                if retPacket :
                    r = dmRE.match (retPacket)
                    #self.pp (d)
                    g = r.groups ()[0]
                    sTuple = struct.unpack ("!4s8s8s8s8s", g)
                    #print sTuple
                    o = Dm ()
                    o.das = d
                    o.db_size = string.strip (sTuple[0])
                    o.db_total = string.strip (sTuple[1])
                    o.db_avail = string.strip (sTuple[2])
                    o.db_used = string.strip (sTuple[3])
                    o.db_bad = string.strip (sTuple[4])
                    self.statDm.append (o)
                    daslist.append (o.das)

        return daslist

    def fl (self) :
        '''   Read status Flags   '''
        self.statFl = []
        head, das, j1, fl, tail = struct.unpack ("!10s4s2s2s8s", self.ST)
        for d in self.dass :
            #   Build packet for each DAS
            packet = struct.pack ("!10s4s2sBB8s",
                                  head,
                                  d,
                                  j1,
                                  0x46,
                                  0x4C,
                                  tail)
            #print "%r" % packet
            ret = self.sendPacket (packet)
            #   We sent the packet now wait for the return
            if ret == 1 :
                retPacket = self.getPackets (flRE)
                if retPacket :
                    #   Fill the fields
                    r = flRE.match (retPacket)
                    g = r.groups ()[0]
                    sTuple = struct.unpack ("!24B", g)
                    #print sTuple
                    o = Fl ()
                    o.das = d
                    o.watchdog = chr (sTuple[0])
                    o.powerup = chr (sTuple[1])
                    o.xtal = chr (sTuple[2])
                    o.time_set_req = chr (sTuple[3])
                    o.time_set = chr (sTuple[4])
                    o.test_code = chr (sTuple[5])
                    o.id_set = chr (sTuple[6])
                    o.fpga_valid = chr (sTuple[7])
                    o.vcxo = chr (sTuple[8])
                    o.question = chr (sTuple[9])
                    o.memory_irq = chr (sTuple[10])
                    o.fpga_irq = chr (sTuple[11])
                    o.event_table = chr (sTuple[12])
                    o.acquisition = chr (sTuple[13])
                    o.event_in_progress = chr (sTuple[14])
                    o.ad_irq = chr (sTuple[15])
                    o.ad_power = chr (sTuple[16])
                    o.sprom_error = chr (sTuple[17])
                    o.sprom_protect = chr (sTuple[18])
                    o.serial_receive = chr (sTuple[19])
                    o.serial_xmit = chr (sTuple[20])
                    o.memory_error = chr (sTuple[21])
                    o.memory_page = chr (sTuple[22])
                    self.statFl.append (o)


    def fw (self, p = None) :
        '''   Firmware loader, assumes rt125.hex, rt125.kit, x44601d.hex
              are in firmware directory on bridge.
              Inputs: p = enable print
        '''
        dass = []
        head, das, tail = struct.unpack ("!10s4s18s", self.FW)

        dass = self.dass

        for d in dass :
            packet = struct.pack ("!10s4s18s", head, d, tail)
            ret = self.sendPacket (packet)
            alldone = 0
            if p :
                sys.stderr.write ("\b\b\b\b\b\b\b\b")
                sys.stderr.write ("%s 000" % d)
            if ret == 1:
                while 1 :
                    if alldone:
                        sys.stderr.write ("\n")
                        break
                    dat = self.getPackets (None)
                    #print dat
                    if dat :
                        #   Message packet
                        r = msRE.match (dat)
                        if r :
                            type, message = r.groups ()
                            #print message
                            continue
                        #   Percent packet
                        r = pcRE.match (dat)
                        if r :
                            pct, das = r.groups ()
                            #print das, pct
                            if p :
                                sys.stderr.write ("\b\b\b%03d" % int (pct))
                            continue
                        #   FW OK?
                        r = fwRE.match (dat)
                        if r :
                            das, mes = r.groups ()
                            #print das, mes
                            alldone = 1
                            if mes != 'OK' :
                                sys.stderr.write (
                                    "\nFirmware load failed: %s %s" %
                                    (d, mes))
                            continue
                        #   Server terminate
                        if len (dat) == 6 :
                            k, j = struct.unpack ("!B5s", dat)
                            if int (k) == 129 :
                                print "Server Terminate"
                                alldone = 1
                    else :
                        #   Timeout
                        sys.stderr.write ("Timeout on read: %d\n" % d)
                        alldone = 1

    def aqState (self) :
        '''   Get acquisition state of each DAS   '''
        
        self.statAq = []
        num = 0
        head, das, tail = struct.unpack ("!10s4s18s", self.AQ)
        for d in self.dass :
            packet = struct.pack ("!10s4s18s", head, d, tail)
            ret = self.sendPacket (packet)
            if ret == 1 :
                dat = self.getPackets (aqRE)
                if dat :
                    r = aqRE.match (dat)
                    num += 1
                    g = r.groups ()[0]
                    sTuple = struct.unpack ("!4s2sss4s4s", g)
                    #print sTuple
                    o = Aq ()
                    o.das = sTuple[0]
                    o.state = sTuple[2]
                    o.et_length = sTuple[4]
                    o.et_entry = sTuple[5]
                    self.statAq.append (o)
        return num
                    
    def aqED (self, state) :
        '''   Set acquisition state (E or D)   '''
        head, das, code, s, tail = struct.unpack ("!10s4s2ss15s", self.AQ)
        enabled = {}; disabled = {}
        for d in self.dass :
            packet = struct.pack ("!10s4s2ss15s", head, d, code, state, tail)
            ret = self.sendPacket (packet)
            if ret == 1 :
                #self.pp (d)
                dat = self.getPackets (aqRE)
                if dat :
                    s = dat[16]
                else :
                    continue
                #print s
                if s == 'E' :
                    enabled[d] = 1
                    
                elif s == 'D' :
                    disabled[d] = 1
                    
        return enabled, disabled

        
    def connect (self, p = 0) :
        '''   Attempt connect to server   '''
        if p :
            sys.stderr.write ("Connect attempt...")
        try :
            self.socket.connect ((self.server, self.port))
        except :
            sys.stderr.write ("Failed to open a socket to %s:%d\n" % (
                self.server, self.port ))
            #self.dingDong (5)
            return None

        i = 0
        while 1 :
            dat = self.socket.recv (1024)
            if not dat : break

            if connectedRE.match (dat) :
                if p :
                    sys.stderr.write ("%s\n" % self.server)
                return 1

    def disconnect (self, p = 0) :
        '''   Disconnect from server   '''
        if p :
            sys.stderr.write ("Disconnect\n")
            self.dingDong (1)
        try :
            self.socket.close ()
        except :
            sys.stderr.write ("Failed to close socket to %s:%d\n" % (
                self.server, self.port))

    def dingDong (self, n) :
        '''   Ring bell n times   '''
        for i in range (n) :
            sys.stderr.write ("\a")
            if (i + 1) == n : break
            time.sleep (0.25)

if __name__ == "__main__" :
    cs = CommandServer ("129.138.26.91", 50000)
    print cs.version ()
    #cs.connect ()
    #cs.ne ()
    #cs.fw (None, 1)
    #cs.fl ()
    #cs.dm ()
    #cs.id ()
    #cs.aq ('D')
    #cs.rs ()
    #cs.de ()
    #cs.ee ()
    #cs.ts ()
    #cs.dt ()
    #cs.aq ('E')
    #cs.disconnect ()
    sys.exit ()
    
    cs.das ()
    
    
    cs.volts (2.9)
    cs.cpu ()
    cs.memory ()

