#!/usr/bin/env python
import string
fh = open ("NNewZealand.deploy")
CASE = {}
while 1 :
    line = fh.readline ()
    if not line : break

    flds = string.split (line)
    xcase = "%03d" % int (flds[3])
    CASE[xcase] = flds[3]

fh.close ()

k = CASE.keys ()

k.sort ()

for i in k :
    fh = open ("NNewZealand.deploy")
    while 1 :
        line = fh.readline ()
        if not line : break

        flds = string.split (line)

        if flds[3] == CASE[i] :
            print line,

    
