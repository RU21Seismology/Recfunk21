#!/usr/bin/env python

#
#   Net enumerate 125 units
#
#   Steve Azevedo, December 2001
#
from Version import *
PORT = '50000'

import getopt, sys, string
from CommandServer import *

def ne (cs, daslist = 'daslist.txt') :
    '''   Net enumerate   '''
    cs.flushPackets ()
    cs.dass = []
    alldone = 0
    sys.stderr.write ("Net Enumerate: 0000 -")
    ret = cs.sendPacket (cs.NE)
    if not ret :
        sys.stderr.write ("\nFailed on timeout\n")
        return None
    while 1 :
        if alldone :
            break
        #   Get all pending command server packets
        dat = cs.getPackets (None)
        if not dat :
            break
        pkts = string.split (dat, "@#")
        #   Loop through all packets
        for pkt in pkts :
            #   Read Net enumerate packets for found DASs
            d = neRE.match (pkt)
            if d :
                cs.dass.append (d.groups ()[0])
                cs.pp (d.groups ()[0])
                continue
            #   Read decade being enumerated
            d = neRespRE.match (pkt)
            if d :
                max, cur = d.groups ()
                max = string.atoi (max); cur = string.atoi (cur)
                cs.pp (None)
                if (cur + 100) >= max :
                    alldone = 1
        
    num = len (cs.dass)
    cs.dass.sort ()
    sys.stderr.write ("\n")
    #   Write list of enumerated DASs to file
    fh = open (daslist, "w")
    fh.write ("B%s:%d\n" % (cs.server, cs.port))
    for d in cs.dass :
        #print d
        d = int (d)
        fh.write ("%04d\n" % d)
        
    sys.stderr.write ("\bFound %d DASs at %s\n" % (num, cs.server))
    #self.dingDong (1)
    fh.close ()
    
#
#   -r	das-das - DAS range
#   -i  bridges - File containing list of bridge IPs
#   -f	outfile - DAS list outfile
#   -V  Be verbose
#
try :
    opts, args = getopt.getopt (sys.argv[1:], "lr:i:b:f:vV")
except getopt.GetoptError :
    sys.stderr.write ("Net enumerate.\n(-v prints das list)\n")
    sys.stderr.write (
        "USAGE: enum [-l][-r das1-dasN] [-f outfile] -i ip_address [-v][-V]\n")
    sys.exit ()

DAS_RANGE = [None, None]
DAS = None
LOGGING = OFF
DASLIST = 'daslist.txt'
BRIDGES = 'bridges.txt'
IPADDRESS = None
VERBOSE = None
IPADDRESS = None

#   Read options
for o, a in opts :
    if o[1] == 'r' :
        DAS_RANGE = string.split (a, '-')
    elif o[1] == 'f' :
        DASLIST = a
    elif o[1] == 'b' :
        BRIDGES = a
    elif o[1] == 'i' :
        IPADDRESS = a
    elif o[1] == 'V' :
        VERBOSE = 1
    elif o[1] == 'v' :
        sys.stderr.write ("%s\n" % PROG_VERSION)
        sys.exit ()
    elif o[1] == 'l' :
        LOGGING = ON

#   Read bridges
'''
fh = open (BRIDGES, 'r')
if not fh :
    sys.stderr.write ("Failed to open: %s\n" % BRIDGES)
    sys.exit (-1)
bridge_list = []
while 1 :
    line = fh.readline ()
    if not line : break
    line = line[:-1]
    server, port = string.split (line, ':')
    bridge_list.append ((server, int (port)))

#   Get list of command server objects
cs_list = []
for sp in bridge_list :
    cs = CommandServer (sp[0], sp[1])
    cs_list.append (cs)

#   Do net enumerate
for cs in cs_list :
    cs.connect (1)
    ne (cs, DASLIST)
    if VERBOSE :
        cs.das ()
    cs.disconnect (1)
'''
if IPADDRESS == None :
    sys.stderr.write ("IP address of bridge required!\n")
    sys.stderr.write (
        "USAGE: enum [-f outfile] -i ip_address [-v][-V]\n")
    sys.exit ()

if os.path.exists (DASLIST) :
    sys.stderr.write ("*** Creating new DAS list: %s ***\n" % DASLIST)
cs = CommandServer (IPADDRESS, int (PORT))
if LOGGING == ON :
    cs.logging (ON)
cs.connect (1)
ne (cs, DASLIST)
if VERBOSE :
    cs.das ()

cs.disconnect (1)
