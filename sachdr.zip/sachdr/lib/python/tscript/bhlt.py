#!/usr/bin/env python
#
#   Halt remote (or local) bridge
#   This program uses ssh to halt a remote machine.
#   On the remote machine:
#      There is an account hlt, that is in the root group
#      The hlt account has the same password as the root account
#      The home directory for hlt is /root
#      The shell for hlt is /root/halt
#      /root/halt is suid root
#
#   Steve Azevedo, January 2004
#
from Version import *
PORT = 50000

import os, getopt, sys, string, time

class DasList :
    def __init__ (self) :
        self.server = None
        self.port = None
        self.list = []

#
#   -i IP addr
#   -f file
#   -v
#
try :
    opts, args = getopt.getopt (sys.argv[1:], "i:f:v")
except getopt.GetoptError :
    sys.stderr.write ("Halt bridge.\n")
    sys.stderr.write (
        "USAGE: bhlt [-i IP address] [-f daslist.txt] [-v]\n")
    sys.exit ()

DASLIST = 'daslist.txt'
IP = None

#   Read options
for o, a in opts :
    if o[1] == 'f' :
        DASLIST = a
    elif o[1] == 'i' :
        IP = a
    elif o[1] == 'v' :
        sys.stderr.write ("%s\n" % PROG_VERSION)
        sys.exit ()

#   Read daslist
servers = []
if not IP :
    if not os.path.exists (DASLIST) :
        sys.stderr.write ("Failed to open: %s\n" % DASLIST)
        sys.exit (-1)
    fh = open (DASLIST, 'r')
    if not fh :
        sys.stderr.write ('Failed to open: %s\n' % DASLIST)
        sys.exit (-1)
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == 'B' :
            line = line[1:]
            s, p = string.split (line, ':')
            o = DasList ()
            o.server = s
            o.port = string.atoi (p)
            servers.append (o)
        elif len (line) == 4 :
            o.list.append (line)
    fh.close ()
else :
    #d, s, p = string.split (DAS, ':')
    o = DasList ()
    o.server = IP
    o.port = PORT
    d = "%04d" % string.atoi ('0000')
    o.list.append (d)
    servers.append (o)

for s in servers :
    command = "ssh hlt@" + s.server
    ret = os.system (command)
    if ret != 0 :
        sys.stderr.write ("Warning %s not halted cleanly\n" % s.server)
    else :
        sys.stderr.write ("Please standby...")
        time.sleep (60)
        sys.stderr.write ("\nIt is now safe to power down %s\n" % s.server)
