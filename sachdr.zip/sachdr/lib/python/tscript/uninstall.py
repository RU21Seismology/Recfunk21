#!/usr/bin/env python

import shutil, os, stat, sys
from compileall import *

#   Location of PASSCAL distribution
ROOTDIR = '/opt/local/passcal'
#

if os.environ.has_key ('PASSCAL') :
    ROOTDIR = os.environ['PASSCAL']
else :
    sys.stderr.write ("PASSCAL environment variable not set!\n")
    sys.exit ()

PROGDIR = os.getcwd ()
PROG = os.path.basename (PROGDIR)
LIBDIR = ROOTDIR + '/lib/python'
BINDIR = ROOTDIR + '/bin'
LIBPROG = ROOTDIR + '/lib/python/tscript'

PROGS = ('acqd',
         'acqe',
         'asts',
         'batt',
         'bhlt',
         'cgps',
         'enum',
         'flgs',
         'fkit',
         'junk',
         'memo',
         'mlog',
         'offl',
         'para',
         'rset',
         'setpc',
         'setbridge',
	 'stat',
         'tdeploy',
         'tims',
         'tretrieve',
         'vers')

#   uninstall libraries
try :
    command = "rm -rf " + LIBPROG
    os.system(command)
except OSError :
    pass
#   uninstall programs
for p in PROGS :
    src = p
    dst = BINDIR + '/' + p
    try :
        os.remove (dst)
    except OSError :
        pass
