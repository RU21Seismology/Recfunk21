#!/usr/bin/env python

#
#   Script to prepare texans for deployment.
#   Takes as input the IP address of a bridge, and the name of a texan event
#   table, and optionally a minimum battery voltage (3.0v is default).
#
#   Does the following in sequence, checking for success at each step:
#   Enumerate, Reset, Battery check, Junk data, Send event table.
#   Time to minute pulse of GPS, Acquisition enable.
#
#   Prints to stdout list of failed DASs and reason for failure.
#
#   Steve Azevedo, November, 2003
#
from Version import *

import getopt, sys, string, time
from CommandServer import *
import signal

#   Port on bridge
PORT = 50000
#   Bridge IP
IP = ''
#   Master das list
DASMASTER = []
#   Command server object
CS = None
#   Event list
PARAMETER = ''
#   Minimum voltage
MIN_VOLTS = 3.0
#   Error messages keyed by das
BAD = {}
#   Log file instance
LOG = None
#  Memory in unit keyed by DAS
MEMORY = {}
#  Meta info
META = ''
#
LOGGING = OFF

class DasList :
    def __init__ (self) :
        self.server = None
        self.port = None
        self.list = []

def usage () :
    sys.stderr.write (
        "Usage: tdeploy -i bridge-ip-address -p parameter-file [-b voltage][-v][-l]\n")
    sys.exit ()

#
#   Open log file :IP-YYYY:JJJ:HH:MM:SS.log
#
def openLog (IP) :
    log = '/dev/null'
    now = time.strftime ("%Y_%j_%H_%M_%S.log")
    filename = 'D-' + IP + "-" + now
    #log = os.open (filename, os.O_CREAT)
    try :
        log = open (filename, 'w')
    except :
        sys.stderr.write ("Failed to open log file: %s\n" % filename)

    log.write ("%s\n" % filename)
    log.write ("Parameter: %s\n" % PARAMETER)
    
    return log

#
#   Get meta info, and write it to the log
#
def getMeta () :
    global META, LOG
    xcase = raw_input ("Enter transcase number(s): ")
    line = raw_input ("Enter line/team number: ")
    
    LOG.write ("x-case: %s\nLine/Team: %s\n" % (xcase, line))

#
#   Print to stdout DASs that failed
#
def printBAD () :
    global BAD, LOG
    keys = BAD.keys ()
    keys.sort ()
    if LOG and len (BAD) :
        LOG.write ("------------- FAILED ------------\n")
    for d in keys :
        sys.stdout.write ("%04d\t%s\n" % (int (d), BAD[d]))
        if LOG != -1 :
            LOG.write ("%04d\t%s\n" % (int (d), BAD[d]))

def printGOOD () :
    global CS, BAD, LOG, MEMORY

    good = []
    bad = BAD.keys ()

    if len (bad) :
        good = unique (CS.dass, bad)
    else :
        good = CS.dass

    if LOG :
        LOG.write ("-------------   OK   ------------\n")
        for d in good :
            if MEMORY.has_key (d) :
                mem = float (MEMORY[d]) / 1024.0 /1024.0
                LOG.write ("%d\t%dMB\n" % (int (d), int (mem)))

#
#   Return a list of elements that there are not duplicates.
#
def unique (a, b) :
    #if len (a) == len (b) : return []
    s = a + b
    n = len (s)
    if n == 0 : return []

    ret = []
    u = {}
    
    try :
        for x in s :
            if u.has_key (x) :
                u[x] += 1
            else :
                u[x] = 1

    except TypeError :
        del u
    else :
        for d in s :
            if u[d] == 1 :
                ret.append (d)
                
        return ret
    
def readDASLIST (DASLIST = 'daslist.txt') :
    #   Read daslist
    servers = []
    if not os.path.exists (DASLIST) :
        sys.stderr.write ("Failed to open: %s\n" % DASLIST)
        sys.exit (-1)
    fh = open (DASLIST, 'r')
    if not fh :
        sys.stderr.write ('Failed to open: %s\n' % DASLIST)
        sys.exit (-1)
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == 'B' :
            line = line[1:]
            s, p = string.split (line, ':')
            o = DasList ()
            o.server = s
            o.port = string.atoi (p)
            servers.append (o)
        elif len (line) == 4 :
            o.list.append (line)
            o.list.append (line)

    fh.close ()

    if len (servers) :
        ip = servers[0].server
    else :
        ip = None

    return ip


#
#   Read command line
#   m -> Get meta info 
#   i -> Bridge IP address
#   p -> Texan event table
#   b -> Minimum voltage
#   h -> Heellllppppppp
#
def getCommandLine () :
    global MIN_VOLTS, LOGGING
    ip = par = meta = None
    try :
        opts, args = getopt.getopt (sys.argv[1:], "li:mp:b:h")
    except getopt.GetoptError :
        usage ()

    for o, a in opts :
        if o[1] == 'i' :
            ip = a
        elif o[1] == 'm' :
            meta = 1
        elif o[1] == 'p' :
            par = a
        elif o[1] == 'b' :
            MIN_VOLTS = float (a)
        elif o[1] == 'h' :
            usage ()
        elif o[1] == 'v' :
            sys.stderr.write ("%s\n" % PROG_VERSION)
            sys.exit ()
        elif o[1] == 'l' :
            LOGGING = ON

    if ip :
        flds = string.split (ip, '.')
        if len (flds) != 4 or ip != 'localhost' :
            sys.stderr.write ("Error: Invalid bridge IP\n")
            sys.exit ()
    else :
        ip = readDASLIST ()
        if not ip :
            usage ()
        
    if par :
        if not os.path.exists (par) :
            sys.stderr.write ("Error: Can't find parameter file: %s\n" % par)
            sys.exit ()
    else :
        usage ()

    return ip, par, meta

#
#   Get an instance of the command server
#   Return a command server instance
#
def commandServer () :
    cs = CommandServer (IP, PORT)
    if LOGGING == ON :
        cs.logging (ON)
    ret = cs.connect ()
    if not ret : return None
    return cs

#
#   Do an network enumerate
#   Return a list of DASs
#
def enumerate (cs) :
    cs.flushPackets ()
    dass = cs.ne ()
    cs.setDass (dass)
    return dass
#
#   Reset 
#
def reset (cs) :
    global BAD
    #   Do reset, try hard!
    cs.flushPackets ()
    for i in range (5) :
        dass = cs.rs ()
        if len (dass) == len (cs.dass) : break
        time.sleep (5)
        
    #   Check if any failed to reset
    #if len (dass) != len (cs.dass) :
    #    print dass, cs.dass
    #    failed = unique (dass, cs.dass)
    #    print failed
    #    for f in failed :
    #        BAD[f] = "Can't reset"
        #    
        #cs.setDass (dass)

#
#   Check battery voltages
#
def battery (cs) :
    global BAD
    goodDas = []
    #   Check ID
    cs.flushPackets ()
    for i in range (3) :
        dass = cs.id ()
        if len (dass) == len (cs.dass) : break
        time.sleep (5)
        
    #if len (dass) != len (cs.dass) :
        #print dass, cs.dass
        #fail = unique (dass, cs.dass)
        #print fail
        #for f in fail :
            #BAD[f] = "Failed status id:"
            
    #print dass, cs.dass, fail
    #   Check if any voltage is low
    #cs.id ()
    for o in cs.statId :
        bv = float (o.batt_volts)
        #   No batteries?
        if bv > 4.0 :
            BAD[o.das] = "Low voltage: 0.0"
        elif bv < MIN_VOLTS :
            BAD[o.das] = "Low voltage: %3.1f" % bv
        else :
            goodDas.append (o.das)

    cs.setDass (goodDas)

#
#   Load event table
#
def parameter (cs) :
    global PARAMETER, BAD
    goodDas = []
    cs.flushPackets ()
    #   Load event table
    dass, l = cs.ee (PARAMETER)
    #   Check if number of lines loaded is correct
    cs.flushPackets ()
    cs.aqState ()
    #   
    for s in cs.statAq :
        lines = eval ('0x' + s.et_length)
        #print l, lines
        if lines != l :
            BAD[s.das] = "Programing failed"
        else :
            goodDas.append (s.das)

    cs.setDass (goodDas)

#
#   Set time
#
def setTime (cs) :
    global BAD
    goodDas = []
    cs.flushPackets ()
    #   Start timing sequence
    n = cs.ts ()
    time.sleep (1)
    #   See if time flag was set for each unit
    cs.flushPackets ()
    cs.fl ()
    time.sleep (1)
    for s in cs.statFl :
        #print s.das, s.time_set, s.time_set_req
        if s.time_set != '*' :
            BAD[s.das] = "Time not set"
        else :
            goodDas.append (s.das)

    cs.setDass (goodDas)

#
#   Erase data
#
def junk (cs) :
    global BAD, MEMORY
    goodDas = []
    cs.flushPackets ()
    #   Broadcast data erase
    dass = cs.de ()
    #   Poll each unit until they respond
    n = len (dass)
    i = 0
    cs.flushPackets ()
    while 1 :
        i += 1
        d = cs.dm ()
        if len (d) == n : break
        if i >= 10 :
            #   Timeout
            break
    #   Check to see if each unit erased correctly
    for o in cs.statDm :
        #print o
        s = int (o.db_used, 16)
        b = int (o.db_bad, 16)
        a = int (o.db_avail, 16)
        
        MEMORY[o.das] = int (o.db_total, 16) * int (o.db_size, 16)
        
        if s != 0 :
            BAD[o.das] = "Erase failed"
        elif b != 0 :
            BAD[o.das] = "Bad memory"
        elif a == 0 :
            BAD[o.das] = "No memory available"
        else :
            goodDas.append (o.das)

    cs.setDass (goodDas)

#
#   Blindly broadcast acq disable
#
def disable (cs) :
    cs.flushPackets ()
    e, d = cs.aqED ('D')
    
#
#   Acquisition enable
#
def enable (cs) :
    global BAD
    #   Broadcast enable command
    #print "enable"
    cs.flushPackets ()
    e, d = cs.aqED ('E')
    #print e.keys ()
    #return
    cs.flushPackets ()
    time.sleep (2)
    #print "state"
    cs.aqState ()
    #   See which DASs we heard back from
    for s in cs.statAq :
        #print s.state
        if s.state != 'E' :
            BAD[s.das] = "Acquisition NOT enabled"

def goByeBye (a, b) :
    global CS, LOG
    sys.stderr.write ("\n")
    printBAD ()
    printGOOD ()
    CS.disconnect ()
    LOG.close ()
    sys.exit ()

def checkn (n) :
    if n <= 0 :
        goByeBye (None, None)

def lastword (cs) :
    nstart = len (DASMASTER)
    ngood = len (cs.dass)
    bad = BAD.keys ()
    nbad = len (bad)
    if (nbad + ngood) == nstart :
        return

    diff = unique (cs.dass, DASMASTER)
    quest = unique (bad, diff)

    for q in quest :
        BAD[q] = "DAS unresponsive"

if __name__ == "__main__" :
    signal.signal (signal.SIGINT, goByeBye)
    IP, PARAMETER, PROMPT = getCommandLine ()
    CS = commandServer ()
    if not CS :
        sys.exit ()
        
    LOG = openLog (IP)
    if PROMPT :
        getMeta ()

    sys.stderr.write ("Net enumerate...")
    DASMASTER = enumerate (CS)
    n = len (DASMASTER)
    checkn (n)
    sys.stderr.write ("%d\nReset..." % n)
    disable (CS)
    reset (CS)
    n = len (CS.dass)
    checkn (n)
    sys.stderr.write ("%d\nChecking batteries..." % n)
    battery (CS)
    n = len (CS.dass)
    checkn (n)
    sys.stderr.write ("%d\nErasing memory..." % n)
    junk (CS)
    n = len (CS.dass)
    checkn (n)
    sys.stderr.write ("%d\nLoading parameter file..." % n)
    parameter (CS)
    n = len (CS.dass)
    checkn (n)
    sys.stderr.write ("%d\nSetting time                     " % n)
    setTime (CS)
    n = len (CS.dass)
    checkn (n)
    sys.stderr.write ("...%d\nEnable acquisition..." % n)
    enable (CS)
    lastword (CS)
    #sys.stderr.write ("\n")
    #printBAD ()
    #CS.disconnect ()
    goByeBye (None, None)
