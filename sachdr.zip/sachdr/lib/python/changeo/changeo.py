#! /usr/bin/env picpython
# BEGIN PROGRAM: CHANGEO
# Started: 2004.058
# By: Bob Greschke
#   Tests and programs Reftek RT130 units.
from sys import argv, exit, platform
PROGSystem = platform[:3].lower()
PROG_NAME = "CHANGEO"
PROG_NAMELC = "changeo"
PROG_LONGNAME = "RT130 Controller"
PROG_VERSION = "2010.322"
PFILE_VERSION = "B"

# Allow a serial port on the command line.
CLAPort = ""
PROGLang = "-LE"
# If set it tells the program that the user is running it from the command
# line which affects how the initial paths are set.
PROGCLRunning = 0
for Arg in argv[1:]:
    if Arg == "-#":
        print(PROG_VERSION)
        exit()
    elif Arg == "-LE":
        PROGLang = "-LE"
    elif Arg == "-LS":
        PROGLang = "-LS"
    elif Arg == "-c":
        PROGCLRunning = 1
    else:
        CLAPort = Arg

# Check for this.
from sys import version_info
if version_info[0] != 2:
    print("%s only runs on Python 2."%PROG_NAME)
    exit()
# For putting Python 3 support in.
PYVERSION = version_info[0]

# Where all of the translations will be kept.
PROGTrans = {}

from Tkinter import *
from calendar import monthcalendar, setfirstweekday
from os import access, environ, getcwd, listdir, makedirs, sep, umask, W_OK
from os.path import basename, dirname, exists, getsize, isdir
from socket import socket, AF_INET, SOCK_STREAM
from string import rstrip, strip
from struct import pack
from sys import maxint
from time import sleep, gmtime, localtime, strftime, time
from tkFont import Font
from urllib import urlopen

# For old versions of Python.
try:
    True
except NameError:
    True = 0 == 0
    False = not True

setfirstweekday(6)

# This is way up here so StringVars and IntVars can be declared throughout the
# code and for the option_add stuff.
Root = Tk()
Root.withdraw()

# All files will be created with u=rw g=rw o=r.
umask(0003)

#####################
# BEGIN: option_add()
# LIB:option_add():2010.252
#   Fonts: a constant nagging problem, though less now. I've stopped trying
#   to micromanage them and mostly let the user suffer with what the system
#   decides to use.
PROGScreenWidth = Root.winfo_screenwidth()
PROGScreenHeight = Root.winfo_screenheight()
PROGConfiguration = ""
if PROGSystem == "dar":
    PROGProportionalFont = "(system's choice)"
    PROGFixedFont = "Fixed"
# A "new" version of PASSCAL Tkinter sets this to 1.
    Root.option_add("*Button*borderWidth", "2")
    Root.option_add("*Text*font", (PROGFixedFont, -14, ""))
    PROGKBFont = (PROGFixedFont, -12, "bold")
    PROGConfiguration = "Darwin %dx%d\nProportional font: %s\nFixed font: %s"% \
            (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
            PROGFixedFont)
elif PROGSystem == "lin":
    PROGProportionalFont = "Helvetica"
    PROGFixedFont = "Courier"
# This is for LUNCH-sized displays (and VMWare on a 13" MacBook Pro).
    if PROGScreenHeight < 800:
        Root.option_add("*Button*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Checkbutton*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Radiobutton*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Entry*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Label*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Text*font", (PROGFixedFont, -11, ""))
        PROGKBFont = (PROGFixedFont, -11, "")
        PROGConfiguration = "Linux (<800) %dx%d\nProportional font: %s\nFixed font: %s"% \
                (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
                PROGFixedFont)
# This is for VMWare on a 13" MacBook, full screen. Open up a few things to
# makeit easier on the eyes.
    elif PROGScreenHeight == 800:
        Root.option_add("*Button*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Checkbutton*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Radiobutton*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Entry*font", (PROGProportionalFont, -12, ""))
        Root.option_add("*Label*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Text*font", (PROGFixedFont, -12, ""))
        PROGKBFont = (PROGFixedFont, -11, "")
        PROGConfiguration = "Linux (=800) %dx%d\nProportional font: %s\nFixed font: %s"% \
                (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
                PROGFixedFont)
    else:
        Root.option_add("*Button*font", (PROGProportionalFont, -12, ""))
        Root.option_add("*Checkbutton*font", (PROGProportionalFont, -12, ""))
        Root.option_add("*Radiobutton*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Entry*font", (PROGProportionalFont, -12, ""))
        Root.option_add("*Label*font", (PROGProportionalFont, -12, ""))
        Root.option_add("*Text*font", (PROGFixedFont, -12, ""))
        PROGKBFont = (PROGFixedFont, -12, "bold")
        PROGConfiguration = "Linux %dx%d\nProportional font: %s\nFixed font: %s"% \
                (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
                PROGFixedFont)
elif PROGSystem == "sun":
    PROGProportionalFont = "(system's choice)"
    PROGFixedFont = "Courier"
    Root.option_add("*Text*font", (PROGFixedFont, -12, ""))
    PROGKBFont = (PROGFixedFont, -12, "bold")
    PROGConfiguration = "Sun %dx%d\nProportional font: %s\nFixed font: %s"% \
            (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
            PROGFixedFont)
elif PROGSystem == "win":
    PROGProportionalFont = "(system's choice)"
    PROGFixedFont = "Courier New"
    Root.option_add("*Text*font", (PROGFixedFont, 9, ""))
    PROGKBFont = (PROGFixedFont, 9, "bold")
    PROGConfiguration = "Windows %dx%d\nProportional font: %s\nFixed font: %s"% \
            (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
            PROGFixedFont)
else:
    PROGProportionalFont = "(system's choice)"
    PROGFixedFont = "Courier"
    Root.option_add("*Text*font", (PROGFixedFont, 10, ""))
    PROGKBFont = (PROGFixedFont, 10, "bold")
    PROGConfiguration = "Other %dx%d\nProportional font: %s\nFixed font: %s"% \
            (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
            PROGFixedFont)
# This will help on some systems, and have no effect on others.
Root.option_add("*Menu*font", Button().cget("font"))
PROGCascadeFont = Menu().cget("font")
# For things that might not get pack()'ed and have to have their fonts set.
PROGCheckbuttonFont = Checkbutton().cget("font")
# Sometimes the fonts in the picker go crazy so set this.
PROGMYDFFont = Entry().cget("font")
# Depending on the Tkinter version or how it was compiled the scroll bars can
# be pretty narrow.
if Scrollbar().cget("width") < "15":
    Root.option_add("*Scrollbar*width", "15")
# PIL on OSX doesn't handle "green" correctly, so use RGB for everything.
# B = black, C = cyan, G = green, M = magenta, R = red, O = orange, W = white
# Y = yellow, E = light gray, A = gray, K = dark gray, U = blue, N = dark green
# S = dark red, y = light yellow, D = default widget color.
# Orange should be #FF7F00, but #DD5F00 is easier to see on a white background
# and it still looks OK on a black background.
Clr = {"B":"#000000", "C":"#00FFFF", "G":"#00FF00", "M":"#FF00FF", \
        "R":"#FF0000", "O":"#FF7F00", "W":"#FFFFFF", "Y":"#FFFF00", \
        "E":"#DFDFDF", "A":"#8F8F8F", "K":"#3F3F3F", "U":"#0000FF", \
        "N":"#007F00", "S":"#7F0000", "y":"#7F7F00", "D":Root.cget("bg")}
Root.option_add("*Button*takeFocus", "0")
Root.option_add("*Checkbutton*anchor", "w")
Root.option_add("*Checkbutton*takeFocus", "0")
Root.option_add("*Entry*background", Clr["W"])
Root.option_add("*Entry*foreground", Clr["B"])
Root.option_add("*Entry*highlightThickness", "2")
Root.option_add("*Entry*insertWidth", "3")
Root.option_add("*Entry*highlightColor", Clr["B"])
Root.option_add("*Entry*disabledBackground", Clr["D"])
Root.option_add("*Entry*disabledForeground", Clr["B"])
Root.option_add("*Listbox*background", Clr["W"])
Root.option_add("*Listbox*foreground", Clr["B"])
Root.option_add("*Listbox*selectBackground", Clr["G"])
Root.option_add("*Listbox*selectForeground", Clr["B"])
Root.option_add("*Listbox*takeFocus", "0")
Root.option_add("*Listbox*exportSelection", "0")
Root.option_add("*Radiobutton*takeFocus", "0")
Root.option_add("*Scrollbar*takeFocus", "0")
Root.option_add("*Text*background", Clr["W"])
Root.option_add("*Text*foreground", Clr["B"])
Root.option_add("*Text*takeFocus", "0")
Root.option_add("*Text*highlightThickness", "0")
Root.option_add("*Text*insertWidth", "0")
Root.option_add("*Text*width", "0")
Root.option_add("*Text*padX", "3")
Root.option_add("*Text*padY", "3")
PROGMonoFont = Text().cget("font")
# Message fields don't need to be the fixed width Text() font.
PROGMsgFont = Label().cget("font")
# For Canvas stuff.
PROGLabelFont = Label().cget("font")
PROGLabelFontFont = Font(font = PROGLabelFont)
PROGLabelFontHeight = PROGLabelFontFont.metrics("ascent")+ \
        PROGLabelFontFont.metrics("descent")
# To control the color of the buttons better in X-Windows programs.
Root.option_add("*Button*activeBackground", Clr["D"])
Root.option_add("*Checkbutton*activeBackground", Clr["D"])
Root.option_add("*Radiobutton*activeBackground", Clr["D"])
# END: option_add

# Changes to option_adds for CHANGEO.
Root.option_add("*Checkbutton*takeFocus", "1")
Root.option_add("*Radiobutton*takeFocus", "1")

# For the program's forms, message areas, etc.
Frm = {}
Can = {}
Msg = {}
Txt = {}

PROGSetups = ()
PROGWhoAmILCVar = StringVar()

# For the <something>2Epoch-type library functions.
PROGYEF70 = {}
PROGYEI70 = {}
PROGYEF84 = {}
PROGYEI84 = {}




# ==============================================
# BEGIN: ========== COMMAND UTILITIES ==========
# ==============================================


##############################
# BEGIN: class BButton(Button)
# LIB:BButton():2009.238
class BButton(Button):
    def __init__(self, master = None, **kw):
        if PROGSystem == "win" and "text" in kw:
            if kw["text"].find("\n") == -1:
                kw["text"] = " "+kw["text"]+" "
            else:
# Add " " to each end of each line so all lines get centered.
                parts = kw["text"].split("\n")
                ntext = ""
                for part in parts:
                    ntext += " "+part+" \n"
                kw["text"] = ntext[:-1]
# Some systems have the button change color when rolled over.
        if "bg" in kw:
            kw["activebackground"] = kw["bg"]
        if "fg" in kw:
            kw["activeforeground"] = kw["fg"]
        Button.__init__(self, master, **kw)
# END: BButton




################################
# BEGIN: beep(Howmany, e = None)
# LIB:beep():2010.256
PROGNoBeepingCRVar = IntVar()
PROGSetups += ("PROGNoBeepingCRVar", )

def beep(Howmany, e = None):
    if PROGNoBeepingCRVar.get() == 0:
        for i in xrange(0, Howmany):
            Root.bell()
            if i < Howmany-1:
                updateMe(0)
                sleep(.15)
    return
# END: beep




#############################################
# BEGIN: buttonBG(Butt, Colr, State = NORMAL)
# LIB:buttonBG():2009.287
def buttonBG(Butt, Colr, State = NORMAL):
# Try since this may get called without the button even existing.
    try:
        if isinstance(Butt, str):
# Set both items to keep the button from changing colors on *NIXs when the
# mouse rolls over. Also only use the first character of the passed value so
# we can pass bg/fg color pairs (I don't think this will ever actually happen).
            Buts[Butt].configure(bg = Clr[Colr[0]], \
                    activebackground = Clr[Colr[0]], state = State)
        else:
            Butt.configure(bg = Clr[Colr[0]], \
                    activebackground = Clr[Colr[0]], state = State)
        updateMe(0)
    except:
        pass
    return
# END: buttonBG




############################################
# BEGIN: buttonControl(Button, Colur, State)
# FUNC:buttonControl():2008.040
#   Change the state of the passed button and change the state of the STOP
#   button as appropriate.
def buttonControl(Butt, Colur, State):
    global WorkState
# Test over.
    if State == 0:
        if Butt != None:
            buttonBG(Butt, "D")
        buttonBG("STOP", "D")
        Buts["STOP"].configure(state = DISABLED)
        WorkState = 0
# Test starting.
    elif State == 1:
        if Butt != None:
            buttonBG(Butt, Colur)
        Buts["STOP"].configure(state = NORMAL)
        buttonBG("STOP", "R")
    if Butt != None:
        Buts[Butt].update()
    Buts["STOP"].update()
    return
# END: buttonControl




###############################################################################
# BEGIN: center(Parent, TheFrame, Where, InOut, Show, CenterX = 0, CenterY = 0)
# LIB:center():2009.326
#   Where tells the function where in relation to the Parent TheFrame should
#   show up.  Use the diagram below to figure out where things will end up.
#
#      +---------------+
#      | NW    N    NE |
#      |               |
#      | W     C     E |
#      |               |
#      | SW    S    SE |
#      +---------------+
#
#   Set Parent to None to use the whole display as the parent.
#   Set InOut to "I" or "O" to control if TheFrame shows "I"nside or "O"outside
#   the Parent (does not apply if the Parent is None).
#
#   CenterX and CenterY not equal to zero overrides everything.
#
def center(Parent, TheFrame, Where, InOut, Show, CenterX = 0, CenterY = 0):
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    if isinstance(TheFrame, str):
        TheFrame = Frm[TheFrame]
# Kiosk mode. Just take over the whole screen. Doesn't check for, but only
# works for Root.
    if Where == "K":
        Root.geometry("%dx%d+0+0"%(Root.winfo_screenwidth(), \
                Root.winfo_screenheight()-30))
        Root.lift()
        Root.deiconify()
        updateMe(0)
        return
# So all of the dimensions get updated.
    updateMe(0)
    FW = TheFrame.winfo_reqwidth()
    if TheFrame == Root:
# Different systems have to be compensated for a little because of differences
# in the reported heights (mostly title and menu bar heights).
        if PROGSystem == "dar" or PROGSystem == "win":
            FH = TheFrame.winfo_reqheight()
        else:
            FH = TheFrame.winfo_reqheight()+50
    else:
        FH = TheFrame.winfo_reqheight()
# Find the center of the Parent.
    if CenterX == 0 and CenterY == 0:
        if Parent == None:
            PX = 0
            PY = 0
            PW = Root.winfo_screenwidth()
            PH = Root.winfo_screenheight()
# A PW of >1920 (the width of a 24" iMac) probably means the user has two
# monitors. Tkinter just gets fed the total width and the smallest display's
# height, so just set the size to 1024x768 and then let the user resize and
# reposition as needed. It's what they get for being so lucky.
            if PW > 1920:
                PW = 1024
                PH = 768
            CenterX = PW/2
            CenterY = PH/2-25
        elif Parent == Root:
            PX = Parent.winfo_x()
            PW = Parent.winfo_width()
            CenterX = PX+PW/2
# Macs, Linux and Suns think the top of the Root window is below the title
# and menu bars.  Windows thinks the top of the window is the top of the
# window, so adjust the window heights accordingly to try and cover that up.
            if PROGSystem == "win":
                PY = Parent.winfo_y()
                PH = Parent.winfo_height()
            else:
                PY = Parent.winfo_y()-50
                PH = Parent.winfo_height()+50
            CenterY = PY+PH/2
        else:
            PX = Parent.winfo_x()
            PW = Parent.winfo_width()
            CenterX = PX+PW/2
            PY = Parent.winfo_y()
            PH = Parent.winfo_height()
            CenterY = PY+PH/2
# Can't put forms outside the whole display.
        if Parent == None or InOut == "I":
            InOut = 1
        else:
            InOut = -1
        if Where == "C":
            TheFrame.geometry("+%i+%i"%(CenterX-FW/2, CenterY-FH/2))
        elif Where == "N":
            TheFrame.geometry("+%i+%i"%(CenterX-FW/2, PY+(50*InOut)))
        elif Where == "NE":
            TheFrame.geometry("+%i+%i"%(PX+PW-FW-(50*InOut), PY+(50*InOut)))
        elif Where == "E":
            TheFrame.geometry("+%i+%i"%(PX+PW-FW-(50*InOut), \
                    CenterY-TheFrame.winfo_reqheight()/2))
        elif Where == "SE":
            TheFrame.geometry("+%i+%i"%(PX+PW-FW-(50*InOut), \
                    PY+PH-FH-(50*InOut)))
        elif Where == "S":
            TheFrame.geometry("+%i+%i"%(CenterX-TheFrame.winfo_reqwidth()/2, \
                    PY+PH-FH-(50*InOut)))
        elif Where == "SW":
            TheFrame.geometry("+%i+%i"%(PX+(50*InOut), PY+PH-FH-(50*InOut)))
        elif Where == "W":
            TheFrame.geometry("+%i+%i"%(PX+(50*InOut), \
                    CenterY-TheFrame.winfo_reqheight()/2))
        elif Where == "NW":
            TheFrame.geometry("+%i+%i"%(PX+(50*InOut), PY+(50*InOut)))
    else:
        TheFrame.geometry("+%i+%i"%(CenterX-FW/2, CenterY-FH/2))
    if Show == True:
        TheFrame.lift()
        TheFrame.deiconify()
    updateMe(0)
    return
# END: center




#######################
# BEGIN: check130ID(ID)
# FUNC:check130ID():2009.030
#   Returns True if the passed Unit ID is OK, False if not.
def check130ID(ID):
    if len(ID) != 4:
        return False
    ID = ID.upper()
# RT130's only. 2007JAN09 - Got our first Model "A".
    if ID[0] != "9" and ID[0] != "A":
        return False
    for Char in ID:
        if Char not in "0123456789ABCDEF":
            return False
    return True
# END: check130ID




##########################################################
# BEGIN: checkCParms(Ret, Chan, Gain, Name, Gain, Comment)
# FUNC:checkCParms():2009.082
#   Checks the Channel parameters and generates error messages if anything
#   is wrong. Returns True if OK, False if not.
def checkCParms(Ret, Chan, Gain, Name, Comment):
    MAXCHANNAMELEN = 10
    MAXCHANCOMMENTLEN = 40
# If the Gain.get() is 0 then this channel will be considered not in use.
    if Gain.get() == 0:
        return True
    AllOK = True
    Name.set(Name.get().strip())
    if len(Name.get()) > MAXCHANNAMELEN:
        msgLn(0, "R", "Channel %d name is too long (%dchrs)."%(Chan, \
                MAXCHANNAMELEN), True, 2)
        if Ret == True:
            return False
        AllOK = False
    Comment.set(Comment.get().strip())
    if len(Comment.get()) > MAXCHANCOMMENTLEN:
        msgLn(0, "R", "Channel %d comment is too long (%dchrs)."%(Chan, \
                MAXCHANCOMMENTLEN), True, 2)
        if Ret == True:
            return False
        AllOK = False
    return AllOK
# END: checkCParms




#################
# BEGIN: getCWD()
# LIB:getCWD():2008.209
def getCWD():
    CWD = getcwd()
    if CWD.endswith(sep) == False:
        CWD += sep
    return CWD
# END: getCWD




#################################################
# BEGIN: getPROGStarted(Warn = True, Load = True)
# LIB:getPROGStarted():2010.180
#   Used by everyone to look for the setups file and get the party started.
#   Warn = if False the function won't generate any error responses, except
#          True or False.
#   Load = some programs will just want PROGSetupsDirVar set.
# This does not get saved in the setups file.
PROGSetupsDirVar = StringVar()

def getPROGStarted(Warn = True, Load = True):
    try:
        if PROGSystem == 'dar' or PROGSystem == 'lin' or PROGSystem == 'sun':
            Dir = environ["HOME"]
            LookFor = "HOME"
# Of course Windows had to be different.
        elif PROGSystem == 'win':
            Dir = environ["HOMEDRIVE"]+environ["HOMEPATH"]
            LookFor = "HOMEDRIVE+HOMEPATH"
        else:
            if Warn == False:
                return False
            else:
                return (2, "RW", \
                        "I don't know how to get the HOME directory on this system. This system is not supported: %s"% \
                        PROGSystem, 2)
        if Dir.endswith(sep) == False:
            Dir += sep
    except:
        if Warn == False:
            return False
        else:
            return (2, "MW", \
                    "This program cannot get the environment variable(s) %s from the operating system. This will need to be corrected before this program can be used."% \
                    LookFor, 3)
    if access(Dir, W_OK) == False:
        if Warn == False:
            return False
        else:
            return (2, "MW", \
                    "The %s directory\n\n%s\n\nis not accessible for writing. This will need to be corrected before this program may be used."% \
                    (LookFor, Dir), 3)
    PROGSetupsDirVar.set(Dir)
    if Load == False:
        return True
    else:
        Ret = loadPROGSetups()
        return Ret
###############################
# BEGIN: getPROGStartDir(Which)
# FUNC:getPROGStartDir():2010.180
def getPROGStartDir(Which):
# PETM
    if Which == 0:
        Answer = formMYDF(Root, 1, "Pick A Starting Directory", \
                PROGSetupsDirVar.get(), "", \
                "This may be the first time this program has been started on\nthis computer or in this account. Select a directory for\nthe program to use as the directory where all files should\nstart out being saved. Click the OK button IF the displayed\ndirectory is OK to use.")
# POCUS, CHANGEO...
    elif Which == 1:
        Answer = formMYDF(Root, 1, "Pick A Starting Directory", \
                PROGSetupsDirVar.get(), "", \
                "This may be the first time this program has been started on\nthis computer or in this account. Select a directory for\nthe program to use as the directory where all files should\nstart out being saved -- NOT necessarily where any data files\nmay be. We'll get to that later. Click the OK button if the\ndisplayed directory is OK to use.")
    elif Which == 2:
# LOGPEEK (no messages file).
        Answer = formMYDF(Root, 1, "Pick A Starting Directory...", \
                PROGSetupsDirVar.get(), "", \
                "This may be the first time this program has been started\non this computer or in this account. Select a directory\nfor the program to use as a starting point.\nClick the OK button to use the displayed\ndirectory.")
    return Answer
# END: getPROGStarted




#############################
# BEGIN: checkDSParms(Ret, d)
# FUNC:checkDSParms():2009.082
#   Checks the data stream  parameters and generates error messages if anything
#   is wrong. Returns True if OK, False if not.
def checkDSParms(Ret, d):
# If the type is 0 then this data stream will be considered not used.
    if eval("PDS%dTType"%d).get() == 0:
        return True
    AllOK = True
    if eval("PDS%dChan1"%d).get() == 0 and \
            eval("PDS%dChan2"%d).get() == 0 and \
            eval("PDS%dChan3"%d).get() == 0 and \
            eval("PDS%dChan4"%d).get() == 0 and \
            eval("PDS%dChan5"%d).get() == 0 and \
            eval("PDS%dChan6"%d).get() == 0:
        msgLn(0, "R", "DS%d no channels selected."%d, True, 2)
        if Ret == True:
            return False
        AllOK = False
    else:
# If some channels are selected make sure that the gain for those channels
# have been set to something (i.e. check that the channels have been
# activated).
        for i in xrange(1, 1+6):
            if eval("PDS%dChan%d"%(d,i)).get() != 0:
                if eval("PC%dGain"%i).get() == 0:
                    msgLn(0, "R", \
                            "DS%d channel %d used, but no gain selected."% \
                            (d, i), True, 2)
                    if Ret == True:
                        return False
                    AllOK = False
    eval("PDS%dSampRate"%d).set(eval("PDS%dSampRate"%d).get().strip())
    if checkSampRate(eval("PDS%dSampRate"%d).get()) == False:
        msgLn(0, "R", "DS%d sample rate is bad."%d, True, 2)
        if Ret == True:
            return False
        AllOK = False
    if eval("PDS%dSampRate"%d).get() == "":
        msgLn(0, "R", "DS%d no sample rate entered."%d, True, 2)
        if Ret == True:
            return False
        AllOK = False
    Value = eval("PDS%dFormat"%d).get()
    if eval("PDS%dFormat"%d).get() == "":
        msgLn(0, "R", "DS%d no data format selected."%d, True, 2)
        if Ret == True:
            return False
        AllOK = False
    elif Value not in PARMSFormatCodes:
        msgLn(0, "R", "DS%d bad format code: %s"%(d, Value), True, 2)
        if Ret == True:
            return False
        AllOK = False
    eval("PDS%dName"%d).set(eval("PDS%dName"%d).get().strip())
    if len(eval("PDS%dName"%d).get()) > 16:
        msgLn(0, "R", "DS%d name is too long."%d, True, 2)
        if Ret == True:
            return False
        AllOK = False
    if eval("PDS%dDisk"%d).get() == 0 and eval("PDS%dEther"%d).get() == 0 and \
            eval("PDS%dSerial"%d).get() == 0 and eval("PDS%dRam"%d).get() == 0:
        msgLn(0, "R", "DS%d no data destination selected."%d, True, 2)
        if Ret == True:
            return False
        AllOK = False
    return AllOK
# END: checkDSParms




######################
# BEGIN: checkIP(Addr)
# FUNC:checkIP():2009.053
#   Takes the input and check to make sure it is something in the neighborhood
#   of a valid Ethernet address. Returns "" if it is not, otherwise the fixed
#   up address.
def checkIP(Addr):
    New = ""
# First off there needs to be 4 or 6 tuples.
    Tups = Addr.split(".")
    if len(Tups) != 4 and len(Tups) != 6:
        return New
# If there is a *.* group make sure it is just *.*.
    for i in xrange(0, len(Tups)):
        Value = str(Tups[i])
        if Value == "*" or Value == "**" or Value == "***":
            Tups[i] = "*"
            continue
# If not a * then only integers.
        try:
            Value = int(Value)
        except ValueError:
            return New
        if Value < 0 or Value > 255:
            return New
# Rebuild the passed IP address.
    for i in xrange(0, len(Tups)):
        if Tups[i] == "*":
            New = New+"*."
        else:
            New = New+"%d."%int(Tups[i])
    New = New[:len(New)-1]
    return New
# END: checkIP




########################
# BEGIN: checkParms(Ret)
# FUNC:checkParms():2009.082
#   Runs through all of the parameters and checks them to see if everything
#   is OK. If Ret == True returns False as soon as something is found to
#   not be OK. If everything is OK returns True. If Ret == False then True
#   will always be returned after examining all of the parameters.
def checkParms(Ret):
    AllOK = True
# Check the station parameters.
    PExpName.set(PExpName.get().strip())
    if len(PExpName.get()) > 24:
        msgLn(0, "R", "Experiment name is too long (24chrs).", True, 2)
        if Ret == True:
            return False
        AllOK = False
    PExpComment.set(PExpComment.get().strip())
    if len(PExpComment.get()) > 40:
        msgLn(0, "R", "Experiment comment is too long (40chrs).", True, 2)
        if Ret == True:
            return False
        AllOK = False
# Check to see that there are some channels marked "in use".
# Setting the gain to something "activates" a channel.
    if PC1Gain.get() == 0 and PC2Gain.get() == 0 and PC3Gain.get() == 0 and \
            PC4Gain.get() == 0 and PC5Gain.get() == 0 and PC6Gain.get() == 0:
        msgLn(0, "R", "No channels have been set up.", True, 2)
        if Ret == True:
            return False
        AllOK = False
# Check each channel.
    for c in xrange(1, 1+6):
        if checkCParms(Ret, c, eval("PC%dGain"%c), eval("PC%dName"%c), \
                eval("PC%dComment"%c)) == False:
            if Ret == True:
                return False
            AllOK = False
# Begin checking the data streams.
# Selecting a trigger type "activates" a stream.
    if PDS1TType.get() == 0 and PDS2TType.get() == 0 and \
            PDS3TType.get() == 0 and PDS4TType.get() == 0:
        msgLn(0, "R", "No data stream trigger types have been selected.", \
                True, 2)
        if Ret == True:
            return False
        AllOK = False
    for d in xrange(1, 1+4):
        if checkDSParms(Ret, d) == False:
            if Ret == True:
                return False
            AllOK = False
# Only certain combinations of sample rates are allowed between the different
# data streams.
    if checkSRCombinations(PDS1SampRate, PDS2SampRate, PDS3SampRate, \
                    PDS4SampRate) == False:
        if Ret == True:
            return False
        AllOK = False
# Check the trigger parameters.
    for d in xrange(1, 1+4):
        if checkTrigParms(Ret, d) == False:
            if Ret == True:
                return False
            AllOK = False
# Auxiliary Data Parameters.
    if PAuxSPer.get() != "":
        PAuxMarker.set(PAuxMarker.get().strip())
        if len(PAuxMarker.get()) > 2:
            msgLn(0, "R", "Auliliary data marker too long (2digts).", True, 2)
            if Ret == True:
                return False
            AllOK = False
        if PAuxDisk.get() == 0 and PAuxEther.get() == 0 and \
                PAuxSerial.get() == 0 and PAuxRam.get() == 0:
            msgLn(0, "R", "No auxiliary data destination selected.", True, 2)
            if Ret == True:
                return False
            AllOK = False
        if PAuxChan1.get() == 0 and PAuxChan2.get() == 0 and \
                PAuxChan3.get() == 0 and PAuxChan4.get() == 0 and \
                PAuxChan5.get() == 0 and PAuxChan6.get() == 0 and \
                PAuxChan7.get() == 0 and PAuxChan8.get() == 0 and \
                PAuxChan9.get() == 0 and PAuxChan10.get() == 0 and \
                PAuxChan11.get() == 0 and PAuxChan12.get() == 0 and \
                PAuxChan13.get() == 0 and PAuxChan14.get() == 0 and \
                PAuxChan15.get() == 0 and PAuxChan16.get() == 0:
            msgLn(0, "R", "No auxiliary data channel(s) selected.", True, 2)
            if Ret == True:
                return False
            AllOK = False
        PAuxRl.set(PAuxRl.get().strip())
        if checkValue(PAuxRl.get(), "F", 0.0, 99999999.0) == False or \
                len(PAuxRl.get()) > 8:
            msgLn(0, "R", \
                    "Auxiliary data record length is bad (0.000-99999999).", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
# Auto-centering Parameters.
    if PACGroup.get() != 0:
# It's just a warning.
        if PACEnable.get() == 0:
            msgLn(0, "Y", "Auto-centering parameters are disabled.", True, 2)
        PACCycle.set(PACCycle.get().strip())
        if checkValue(PACCycle.get(), "I", 0, 99) == False:
            msgLn(0, "R", "Auto-centering cycle interval is bad (0-99).", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        PACThresh.set(PACThresh.get().strip())
        if checkValue(PACThresh.get(), "F", 0.1, 9.9) == False:
            msgLn(0, "R", "Auto-centering threshold is bad (0.1-9.9).", True, \
                    2)
            if Ret == True:
                return False
            AllOK = False
        PACAttempt.set(PACAttempt.get().strip())
        if checkValue(PACAttempt.get(), "I", 0, 99) == False:
            msgLn(0, "R", "Auto-centering attempts per cycle is bad (0-99).", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        PACRetry.set(PACRetry.get().strip())
        if checkValue(PACRetry.get(), "I", 1, 99) == False:
            msgLn(0, "R", "Auto-centering retry interval is bad (1-99).", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
# Disk Parameters.
    PDThresh.set(PDThresh.get().strip())
    if checkValue(PDThresh.get(), "I", 1, 99) == False:
        msgLn(0, "R", "Disk dump threshold value is bad (1-99).", True, 2)
        if Ret == True:
            return False
        AllOK = False
    PDRetry.set(PDRetry.get().strip())
# Networking Parameters.
    if PNPort.get() == 1 or PNPort.get() == 3:
        if PNEPortPow.get() == 0:
            msgLn(0, "R", "Ethernet port power parameter not selected.", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        if PNEKeep.get() == 0:
            msgLn(0, "R", \
                    "Ethernet port line down action parameter not selected.", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        PNETDelay.set(PNETDelay.get().strip())
# Toss selected...
        if PNEKeep.get() == 2:
            if checkValue(PNETDelay.get(), "I", 2, 99) == False:
                msgLn(0, "R", \
                      "Toss delay Ethernet network parameter is bad (2-99).", \
                        True, 2)
                if Ret == True:
                    return False
                AllOK = False
# Format and check all of the addresses.
# Special check for the IP address.
        for i in xrange(1, 1+4):
            Tup = intt(eval("PNEIP%d"%i).get())
            if Tup < 0 or Tup > 255:
                msgLn(0, "R", \
                        "IP address Ethernet network parameter is bad.", \
                        True, 2)
                if Ret == True:
                    return False
                AllOK = False
                break
            else:
                eval("PNEIP%d"%i).set(str(Tup))
        Addr = checkIP(PNEMask.get())
        if Addr == "":
            msgLn(0, "R", "Net mask Ethernet network parameter is bad.", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        else:
            PNEMask.set(Addr)
        Addr = checkIP(PNEGateway.get())
        if Addr == "":
            msgLn(0, "R", \
                    "Gateway address Ethernet network parameter is bad.", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        else:
            PNEGateway.set(Addr)
        Addr = checkIP(PNEHost.get())
        if Addr == "":
            msgLn(0, "R", \
                    "Remote host address Ethernet network parameter is bad.", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        else:
            PNEHost.set(Addr)
# The serial host address must be "0.0.0.0" or "000.000.000.000" when using
# the Ethernet only (from Ref Tek manual).
        if PNSHost.get() != "0.0.0.0" and PNSHost.get() != "000.000.000.000":
            msgLn(1, "R", "Serial port host address must be set to 0.0.0.0", \
                    True, 2)
            msgLn(0, "R", "or 000.000.000.000.", True, 2)
            if Ret == True:
                return False
            AllOK = False
# If the serial port is being programmed...
    elif PNPort.get() == 2 or PNPort.get() == 3:
        if PNSKeep.get() == 0:
            msgLn(0, "R", \
                    "Serial port line down action parameter not selected.", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        PNSTDelay.set(PNSTDelay.get().strip())
        if PNSKeep.get() == 2:
            if checkValue(PNSTDelay.get(), "I", 2, 99) == False:
                msgLn(0, "R", \
                        "Toss delay serial network parameter is bad (2-99).", \
                        True, 2)
                if Ret == True:
                    return False
                AllOK = False
        if PNSMode.get() == 0:
            msgLn(0, "R", "Serial port mode parameter not selected.", True, 2)
            if Ret == True:
                return False
            AllOK = False
        if PNSSpeed.get() == 0:
            msgLn(0, "R", "Serial port speed parameter not selected.", True, 2)
            if Ret == True:
                return False
            AllOK = False
# Special IP address-only stuff.
        for i in xrange(1, 1+4):
            Tup = intt(eval("PNSIP%d"%i).get())
            if Tup < 0 or Tup > 255:
                msgLn(0, "R", "IP address serial network parameter is bad.", \
                        True, 2)
                if Ret == True:
                    return False
                AllOK = False
                break
            else:
                eval("PNSIP%d"%i).set(str(Tup))
        Addr = checkIP(PNSMask.get())
        if Addr == "":
            msgLn(0, "R", "Net mask serial network parameter is bad.", True, 2)
            if Ret == True:
                return False
            AllOK = False
        else:
            PNSMask.set(Addr)
        Addr = checkIP(PNSGateway.get())
        if Addr == "":
            msgLn(0, "R", "Gateway address serial network parameter is bad.", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        else:
            PNSGateway.set(Addr)
        Addr = checkIP(PNSHost.get())
        if Addr == "":
            msgLn(0, "R", \
                    "Remote host address serial network parameter is bad.", \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        else:
            PNSHost.set(Addr)
# External clock control parameters (nothing to check).
    return AllOK
# END: checkParms




#########################
# BEGIN: checkRp(DAS, Rp)
# FUNC:checkRp():2009.098
#   Checks that the passed DAS number matches the Unit ID field in the passed
#   string (that supposedly came from a DAS's response)
#   Returns True if everything is OK.
def checkRp(DAS, Rp):
    if DAS == "0000":
        return True
    if len(Rp) > 6 and DAS == Rp[2:2+4]:
        return True
# We'll stick this message printing here since there are going to be so many
# calls to this function.
    if Rp != "":
        msgLn(1, "M", "A DAS may be talking out of turn!", True, 3)
        if len(Rp) > 6:
            msgLn(1, "", "It might be DAS %s"%Rp[2:2+4])
    return False
# END: checkRp




############################
# BEGIN: checkSampRate(Rate)
# FUNC:checkSampRate():2008.012
#   If the passed sample rate is OK return True.
def checkSampRate(Rate):
    if Rate != "" and Rate != "1000" and Rate != "500" and Rate != "250" and \
            Rate != "200" and Rate != "125" and Rate != "100" and \
            Rate != "50" and Rate != "40" and Rate != "25" and \
            Rate != "20" and Rate != "10" and Rate != "5" and Rate != "1":
        return False
    return True
# END: checkSampRate




########################################################
# BEGIN: checkSRCombinations(Rate1, Rate2, Rate3, Rate4)
# FUNC:checkSRCombinations():2008.012
def checkSRCombinations(Rate1, Rate2, Rate3, Rate4):
    SR1 = intt(Rate1.get())
    SR2 = intt(Rate2.get())
    SR3 = intt(Rate3.get())
    SR4 = intt(Rate4.get())
    Status = True
    if SR1 > 0 and PDS1TType.get() != 0:
        if SR1 == 1 or SR1 == 5 or SR1 == 10 or SR1 == 20 or SR1 == 40 or \
                SR1 == 100 or SR1 == 200:
            if SR2 > 0 and PDS2TType.get() != 0:
                if SR2 != 1 and SR2 != 5 and SR2 != 10 and SR2 != 20 and \
                        SR2 != 40 and SR2 != 100 and SR2 != 200:
                    Status = False
            if SR3 > 0 and PDS3TType.get() != 0:
                if SR3 != 1 and SR3 != 5 and SR3 != 10 and SR3 != 20 and \
                        SR3 != 40 and SR3 != 100 and SR3 != 200:
                    Status = False
            if SR4 > 0 and PDS4TType.get() != 0:
                if SR4 != 1 and SR4 != 5 and SR4 != 10 and SR4 != 20 and \
                        SR4 != 40 and SR4 != 100 and SR4 != 200:
                    Status = False
        if SR1 == 25 or SR1 == 50 or SR1 == 125 or SR1 == 250 or \
                SR1 == 500 or SR1 == 1000:
            if SR2 > 0 and PDS2TType.get() != 0:
                if SR2 != SR1:
                    Status = False
            if SR3 > 0 and PDS3TType.get() != 0:
                if SR3 != SR1:
                    Status = False
            if SR4 > 0 and PDS4TType.get() != 0:
                if SR4 != SR1:
                    Status = False
    if SR2 > 0 and PDS2TType.get() != 0:
        if SR2 == 1 or SR2 == 5 or SR2 == 10 or SR2 == 20 or SR2 == 40 or \
                SR2 == 100 or SR2 == 200:
            if SR3 > 0 and PDS3TType.get() != 0:
                if SR3 != 1 and SR3 != 5 and SR3 != 10 and SR3 != 20 and \
                        SR3 != 40 and SR3 != 100 and SR3 != 200:
                    Status = False
            if SR4 > 0 and PDS4TType.get() != 0:
                if SR4 != 1 and SR4 != 5 and SR4 != 10 and SR4 != 20 and \
                        SR4 != 40 and SR4 != 100 and SR4 != 200:
                    Status = False
        if SR2 == 25 or SR2 == 50 or SR2 == 125 or SR2 == 250 or \
                SR2 == 500 or SR2 == 1000:
            if SR3 > 0 and PDS3TType.get() != 0:
                if SR3 != SR2:
                    Status = False
            if SR4 > 0 and PDS4TType.get() != 0:
                if SR4 != SR2:
                    Status = False
    if SR3 > 0 and PDS3TType.get() != 0:
        if SR3 == 1 or SR3 == 5 or SR3 == 10 or SR3 == 20 or SR3 == 40 or \
                SR3 == 100 or SR3 == 200:
            if SR4 > 0 and PDS4TType.get() != 0:
                if SR4 != 1 and SR4 != 5 and SR4 != 10 and SR4 != 20 and \
                        SR4 != 40 and SR4 != 100 and SR4 != 200:
                    Status = False
        if SR3 == 25 or SR3 == 50 or SR3 == 125 or SR3 == 250 or \
                SR3 == 500 or SR3 == 1000:
            if SR4 > 0 and PDS4TType.get() != 0:
                if SR4 != SR3:
                    Status = False
# We don't have to check SR4 since any problems with it will be detected above.
    if Status == False:
        msgLn(0, "R", "Bad data stream sample rate combination.", True, 2)
        return False
    return True
# END: checkSRCombinations




########################################
# BEGIN: checkTMLTime(DS, Which, InTime)
# FUNC:checkTMLTime():2008.012
def checkTMLTime(d, Which, InTime):
    InTime.set(InTime.get().strip())
    if len(InTime.get()) != 13 and len(InTime.get()) != 0:
        msgLn(0, "R", "DS%d TML start time %d is bad."%(d, Which), 1, 1)
        return False
    return True
# END: checkTMLTime




################################
# BEGIN: checkTrigParms(Ret , d)
# FUNC:checkTrigParms():2009.082
#   Checks the trigger parameters. Returns True if everything is OK, False
#   if not. If Ret is False it will keep going through the parameters and
#   print all of the problems that it finds, otherwise it will return as soon
#   as a problem is found.
def checkTrigParms(Ret, d):
    AllOK = True
# Not used, so it must be good.
    if eval("PDS%dTType"%d).get() == 0:
        return True
# CON
    elif eval("PDS%dTType"%d).get() == 1:
        eval("PDS%dStart1"%d).set(eval("PDS%dStart1"%d).get().strip())
        if len(eval("PDS%dStart1"%d).get()) != 13:
            msgLn(0, "R", "DS%d CON start time is bad."%d, True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dRl"%d).set(eval("PDS%dRl"%d).get().strip())
        if checkValue(eval("PDS%dRl"%d).get(), "F", 0.0, \
                99999999.0) == False or len(eval("PDS%dRl"%d).get()) > 8:
            msgLn(0, "R", \
                    "DS%d CON record length is bad (0.000-99999999)."%d, True,
                    2)
            if Ret == True:
                return False
            AllOK = False
# CRS
    elif eval("PDS%dTType"%d).get() == 2:
        if eval("PDS%dTStrm"%d).get() == 0:
            msgLn(0, "R", "DS%d CRS no trigger stream selected."%d, True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dPretl"%d).set(eval("PDS%dPretl"%d).get().strip())
        if checkValue(eval("PDS%dPretl"%d).get(), "F", 0.0, 999.9) == False:
            msgLn(0, "R", \
                    "DS%d CRS pre-trigger length is bad (0.0-999.9)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dRl"%d).set(eval("PDS%dRl"%d).get().strip())
        if checkValue(eval("PDS%dRl"%d).get(), "F", 0.0, \
                99999999.0) == False or len(eval("PDS%dRl"%d).get()) > 8:
            msgLn(0, "R", \
                    "DS%d CRS record length is bad (0.000-99999999)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
# EVT
    elif eval("PDS%dTType"%d).get() == 3:
        if eval("PDS%dTChan1"%d).get() == 0 and \
                eval("PDS%dTChan2"%d).get() == 0 and \
                eval("PDS%dTChan3"%d).get() == 0 and \
                eval("PDS%dTChan4"%d).get() == 0 and \
                eval("PDS%dTChan5"%d).get() == 0 and \
                eval("PDS%dTChan6"%d).get() == 0:
            msgLn(0, "R", "DS%d EVT no trigger channels selected."%d, True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dTwin"%d).set(eval("PDS%dTwin"%d).get().strip())
        if checkValue(eval("PDS%dTwin"%d).get(), "F", 0.1, 99.9) == False:
            msgLn(0, "R", "DS%d EVT trigger window is bad (0.1-99.9)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dMc"%d).set(eval("PDS%dMc"%d).get().strip())
        if checkValue(eval("PDS%dMc"%d).get(), "I", 1, 6) == False:
            msgLn(0, "R", "DS%d EVT minimum channels is bad (1-6)."%d, True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dPretl"%d).set(eval("PDS%dPretl"%d).get().strip())
        if checkValue(eval("PDS%dPretl"%d).get(), "F", 0.0, 999.9) == False:
            msgLn(0, "R", \
                    "DS%d EVT pre-trigger length is bad (0.0-999.9)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dRl"%d).set(eval("PDS%dRl"%d).get().strip())
        if checkValue(eval("PDS%dRl"%d).get(), "F", 0.0, \
                99999999.0) == False or len(eval("PDS%dRl"%d).get()) > 8:
            msgLn(0, "R", \
                    "DS%d EVT record length is bad (0.000-99999999)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dPostl"%d).set(eval("PDS%dPostl"%d).get().strip())
        if checkValue(eval("PDS%dPostl"%d).get(), "F", 0.0, 999.9) == False:
            msgLn(0, "R", \
                    "DS%d EVT post-trigger length is bad (0.0-999.9)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dSta"%d).set(eval("PDS%dSta"%d).get().strip())
        if checkValue(eval("PDS%dSta"%d).get(), "F", 0.0, 999.9) == False:
            msgLn(0, "R", \
                    "DS%d EVT short term average is bad (0.0-999.9)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dLta"%d).set(eval("PDS%dLta"%d).get().strip())
        if checkValue(eval("PDS%dLta"%d).get(), "F", 0.1, 999.9) == False:
            msgLn(0, "R", "DS%d EVT long term average is bad (0.1-999.9)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dTr"%d).set(eval("PDS%dTr"%d).get().strip())
        if checkValue(eval("PDS%dTr"%d).get(), "F", 0.1, 99.9) == False:
            msgLn(0, "R", "DS%d EVT trigger ratio is bad (0.1-99.9)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dDtr"%d).set(eval("PDS%dDtr"%d).get().strip())
        if checkValue(eval("PDS%dDtr"%d).get(), "F", 0.0, 99.9) == False:
            msgLn(0, "R", "DS%d EVT de-trigger ratio is bad (0.0-99.9)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
# EXT
    elif eval("PDS%dTType"%d).get() == 4:
        eval("PDS%dPretl"%d).set(eval("PDS%dPretl"%d).get().strip())
        if checkValue(eval("PDS%dPretl"%d).get(), "F", 0.0, 999.9) == False:
            msgLn(0, "R", \
                    "DS%d EXT pre-trigger length is bad (0.0-999.9)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dRl"%d).set(eval("PDS%dRl"%d).get().strip())
        if checkValue(eval("PDS%dRl"%d).get(), "F", 0.0, \
                99999999.0) == False or len(eval("PDS%dRl"%d).get()) > 8:
            msgLn(0, "R", \
                    "DS%d EXT record length is bad (0.000-99999999)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
# LEV
    elif eval("PDS%dTType"%d).get() == 5:
# The trigger level has some special forms.
        eval("PDS%dTlvl"%d).set(eval("PDS%dTlvl"%d).get().strip().upper())
        TrigLevel = eval("PDS%dTlvl"%d).get()
        if TrigLevel.startswith("G"):
            if len(TrigLevel) == 1:
                msgLn(0, "R", \
                     "DS%d LEV \"G\" trigger level missing numerical value."% \
                        d, True, 2)
                if Ret == True:
                    return False
                AllOK = False
            else:
                if checkValue(TrigLevel[1:], "F", 0.0001, 99.9999) == False:
                    msgLn(0, "R", \
               "DS%d LEV trigger level G's value is bad (0.0001-99.9999)."%d, \
                            True, 2)
                    if Ret == True:
                        return False
                    AllOK = False
        elif TrigLevel.startswith("M"):
            if len(TrigLevel) == 1:
                msgLn(0, "R", \
                     "DS%d LEV \"M\" trigger level missing numerical value."% \
                        d, True, 2)
                if Ret == True:
                    return False
                AllOK = False
            else:
                if checkValue(TrigLevel[1:], "F", 0.01, 999.99) == False:
                    msgLn(0, "R", \
                   "DS%d LEV trigger level percentage is bad (0.01-999.99)."% \
                            d, True, 2)
                    if Ret == True:
                        return False
                    AllOK = False
        elif TrigLevel.startswith("%"):
            if len(TrigLevel) == 1:
                msgLn(0, "R", \
                     "DS%d LEV \"%\" trigger level missing numerical value."% \
                        d, True, 2)
                if Ret == True:
                    return False
                AllOK = False
            else:
                if checkValue(TrigLevel[1:], "I", 1, 99) == False:
                    msgLn(0, "R", \
                        "DS%d LEV trigger level percentage is bad (1-99)."%d, \
                            True, 2)
                    if Ret == True:
                        return False
                    AllOK = False
        elif TrigLevel.startswith("H"):
            if len(TrigLevel) == 1:
                msgLn(0, "R", \
                   "DS%d LEV \"Hex\" trigger level missing numerical value."% \
                        d, True, 2)
                if Ret == True:
                    return False
                AllOK = False
            else:
                if checkValue(TrigLevel[1:], "H", 0x0, 0xFFFFFFF) == False:
                    msgLn(0, "R", \
                      "DS%d LEV trigger level hex value is bad (0-FFFFFFF)."% \
                            d, True, 2)
                    if Ret == True:
                        return False
                    AllOK = False
        else:
            if checkValue(TrigLevel, "I", 0, 9999999) == False:
                msgLn(0, "R", \
                       "DS%d LEV trigger level counts is bad (0-9999999)."%d, \
                        True, 2)
                if Ret == True:
                    return False
                AllOK = False
        eval("PDS%dPretl"%d).set(eval("PDS%dPretl"%d).get().strip())
        if checkValue(eval("PDS%dPretl"%d).get(), "F", 0.0, 999.9) == False:
            msgLn(0, "R", \
                    "DS%d LEV pre-trigger length is bad (0.0-999.9)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dRl"%d).set(eval("PDS%dRl"%d).get().strip())
        if checkValue(eval("PDS%dRl"%d).get(), "F", 0.0, \
                99999999.0) == False or len(eval("PDS%dRl"%d).get()) > 8:
            msgLn(0, "R", \
                    "DS%d LEV record length is bad (0.000-99999999)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
# TIM
    elif eval("PDS%dTType"%d).get() == 6:
        eval("PDS%dStart1"%d).set(eval("PDS%dStart1"%d).get().strip())
        if len(eval("PDS%dStart1"%d).get()) != 13:
            msgLn(0, "R", "DS%d TIM start time is bad."%d, True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dRepInt"%d).set(eval("PDS%dRepInt"%d).get().strip())
        if len(eval("PDS%dRepInt"%d).get()) != 8:
            msgLn(0, "R", "DS%d TIM repeat interval is bad (1sec-45days)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dNumTrig"%d).set(eval("PDS%dNumTrig"%d).get().strip())
        if checkValue(eval("PDS%dNumTrig"%d).get(), "I", 0, 9999) == False:
            msgLn(0, "R", \
                    "DS%d TIM number of triggers is bad (0-9999)."%d, True, 2)
            if Ret == True:
                return False
            AllOK = False
        eval("PDS%dRl"%d).set(eval("PDS%dRl"%d).get().strip())
        if checkValue(eval("PDS%dRl"%d).get(), "F", 0.0, \
                99999999.0) == False or len(eval("PDS%dRl"%d).get()) > 8:
            msgLn(0, "R", \
                    "DS%d TIM record length is bad (0.000-99999999)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
# TML
    elif eval("PDS%dTType"%d).get() == 7:
        if checkTMLTime(d, 1, eval("PDS%dStart1"%d).get()) == False:
            if Ret == True:
                return False
            AllOK = False
# I'm assuming that the user will want at least one of these.
        if len(eval("PDS%dStart1"%d).get()) == 0:
            msgLn(0, "R", "DS%d TML no starting time entered."%d, True, 2)
            if Ret == True:
                return False
            AllOK = False
        for i in xrange(2, 1+11):
            if checkTMLTime(d, i, eval("PDS%dStart%d"%(d,i))) == False:
                if Ret == True:
                    return False
                AllOK = False
        eval("PDS%dRl"%d).set(eval("PDS%dRl"%d).get().strip())
        if checkValue(eval("PDS%dRl"%d).get(), "F", 0.0, \
                99999999.0) == False or len(eval("PDS%dRl"%d).get()) > 8:
            msgLn(0, "R", \
                    "DS%d TML record length is bad (0.000-99999999)."%d, \
                    True, 2)
            if Ret == True:
                return False
            AllOK = False
    return AllOK
# END: checkTrigParms




###########################################
# BEGIN: checkValue(Value, Type, Low, High)
# FUNC:checkValue():2008.303
#   Checks the passed Value to make sure it is OK. Value should be a string.
#   Type tells the routine what kind of number the passed Value is:
#      "I" = integer, "" not allowed
#      "F" = float, "" not allowed
#      "H" = hex values, "" not allowed
#      "Ib" = integer, "" allowed
#      "Fb" = float, "" allowed
#   Returns True if OK, False if not.
def checkValue(Value, Type, Low, High):
    Value = Value.strip()
    if Type == "I" or Type == "F" or Type == "H":
        if Value == "":
            return False
    if Type == "I" or Type == "Ib":
# If there is a decimal point in an integer tsk tsk tsk.
        try:
            Value.index(".")
            return False
        except ValueError:
            pass
        if intt(Value) < Low or intt(Value) > High:
            return False
    elif Type == "F" or Type == "Fb":
        if Value == "":
            return True
        if floatt(Value) < Low or floatt(Value) > High:
            return False
    elif Type == "H":
        try:
            if int(Value, 16) < Low or int(Value, 16) > High:
                return False
        except ValueError:
            return False
    return True
# END: checkValue




#######################
# BEGIN: closeCmdPort()
# FUNC:closeCmdPort():2009.097
#   Closes the global CmdPort.
def closeCmdPort():
    try:
        CmdPort.close()
    except:
        pass
    CmdPortLab.config(bg = Clr["D"])
    CmdPortLab.update()
    return
# END: closeCmdPort




#################################
# BEGIN: closeForm(Who, e = None)
# LIB:closeForm():2010.204
#   Handles closing a form.
def closeForm(Who, e = None):
# In case it is a "busy" form that takes a long time to close.
    updateMe(0)
# The form may not exist or Frm[Who] may be pointing to a "lost" form, so try.
    try:
        if Frm[Who] == None:
            return
        Frm[Who].destroy()
    except:
        pass
    try:
        Frm[Who] = None
    except:
        pass
    return
###############################
# BEGIN: closeFormAll(e = None)
# FUNC:closeFormAll():2010.255
#   Goes through all of the forms and shuts them down.
def closeFormAll(e = None):
    for Frmm in Frm.keys():
# Try to call a formXControl() function. Some may have them and some may not.
        try:
            Ret = eval("form%sControl"%Frmm)("close")
# Simple forms that may just still have stuff running return 1 and a message.
# More complex forms may take care of everything themselves and return 2.
            if Ret[0] == 1:
                showUp(Frmm)
                formMYD(Frmm, (("(OK)", TOP, "ok"), ), "ok", Ret[1], "Oops!", \
                        Ret[2])
                break
            elif Ret[0] == 2:
                break
        except:
            closeForm(Frmm)
    return
# END: closeForm




######################
# BEGIN: class Command
# LIB:Command():2006.112
#   Pass arguments to functions from button presses and menu selections! Nice!
#   In your declaration:  ...command = Command(func, args,...)
#   Also use in bind() statements
#       x.bind("<****>", Command(func, args...))
class Command:
    def __init__(self, func, *args, **kw):
        self.func = func
        self.args = args
        self.kw = kw
    def __call__(self, *args, **kw):
        args = self.args+args
        kw.update(self.kw)
        apply(self.func, args, kw)
# END: Command




##############################################################
# BEGIN: dateTimeMath(DeltaDD, DeltaSS, YYYY, DDD, HH, MM, SS)
# LIB:dateTimeMath():2009.102
#   Adds or subtracts (depending on the sign of DeltaDD/DeltaSS) the requested
#   amount of time to/from the passed date.  Returns a tuple with the results:
#           (YYYY, DDD, HH, MM, SS)
#   Only does whole days or seconds.
def dateTimeMath(DeltaDD, DeltaSS, YYYY, DDD, HH, MM, SS):
    DeltaDD = int(DeltaDD)
    DeltaSS = int(DeltaSS)
    if DeltaDD != 0:
        if DeltaDD > 0:
            Forward = 1
        else:
            Forward = 0
        while 1:
# Speed limit the change to keep things simpler.
            if DeltaDD < -365 or DeltaDD > 365:
                if Forward == 1:
                    DDD += 365
                    DeltaDD -= 365
                else:
                    DDD -= 365
                    DeltaDD += 365
            else:
                DDD += DeltaDD
                DeltaDD = 0
            Leap = isLeap(YYYY)
            if DDD < 1 or DDD > 365+Leap:
                if Forward == 1:
                    DDD -= 365+Leap
                    YYYY += 1
                else:
                    YYYY -= 1
                    Leap = isLeap(YYYY)
                    DDD += 365+Leap
            if DeltaDD == 0:
                break
    if DeltaSS != 0:
        if DeltaSS > 0:
            Forward = 1
        else:
            Forward = 0
        while 1:
# Again, just to keep the code reasonable.
            if DeltaSS < -59 or DeltaSS > 59:
                if Forward == 1:
                    SS += 59
                    DeltaSS -= 59
                else:
                    SS -= 59
                    DeltaSS += 59
            else:
                SS += DeltaSS
                DeltaSS = 0
            if SS < 0 or SS > 59:
                if Forward == 1:
                    SS -= 60
                    MM += 1
                    if MM > 59:
                        MM = 0
                        HH += 1
                        if HH > 23:
                            HH = 0
                            DDD += 1
                            if DDD > 365:
                                Leap = isLeap(YYYY)
                                if DDD > 365+Leap:
                                    YYYY += 1
                                    DDD = 1
                else:
                    SS += 60
                    MM -= 1
                    if MM < 0:
                        MM = 59
                        HH -= 1
                        if HH < 0:
                            HH = 23
                            DDD -= 1
                            if DDD < 1:
                                YYYY -= 1
                                if isLeap(YYYY) == 1:
                                    DDD = 366
                                else:
                                    DDD = 365
            if DeltaSS == 0:
                 break
    return (YYYY, DDD, HH, MM, SS)
# END: dateTimeMath




#######################
# BEGIN: deciDeg(InPos)
# FUNC:deciDeg():2009.328
#   Returns the passed lat or long as decimal degrees.
def deciDeg(InPos):
    OutPos = ""
    if InPos != "":
        OutPos = InPos[0:0+1]
        M = InPos.index(":")
        OutPos = OutPos+InPos[1:M]
        Value = float(InPos[M+1:])/60.0
        OutPos = OutPos+("%.6f"%Value)[1:]
    return OutPos
# END: deciDeg




#######################
# BEGIN: delay(Seconds)
# FUNC:delay():2008.012
def delay(Seconds):
    if Seconds < 1:
        sleep(Seconds)
    else:
        for i in xrange(0, Seconds*4):
            updateMe(0)
            sleep(.25)
            if WorkState == 999:
                break
    return
# END: delay




###################
# BEGIN: floatt(In)
# LIB:floatt():2009.102
#    Handles all of the annoying shortfalls of the float() function (vs C).
#    Does not handle scientific notation numbers.
def floatt(In):
    In = str(In).strip()
    if In == "":
        return 0.0
# At least let the system give it the ol' college try.
    try:
        return float(In)
    except:
        Number = ""
        for c in In:
            if c.isdigit() or c == ".":
                Number += c
            elif Number == "" and (c == "-" or c == "+"):
                Number += c
            elif c == ",":
                continue
            else:
                break
        try:
            return float(Number)
        except ValueError:
            return 0.0
# END: floatt




####################
# BEGIN: fmti(Value)
# LIB:fmti():2010.138
#   Just couldn't rely on the system to do this, although this won't handle
#   European-style numbers.
def fmti(Value):
    Value = int(Value)
    if Value > -1000 and Value < 1000:
        return str(Value)
    Value = str(Value)
    NewValue = ""
# There'll never be a + sign.
    if Value[0] == "-":
        Offset = 1
    else:
        Offset = 0
    CountDigits = 0
    for i in xrange(len(Value)-1, -1+Offset, -1):
        NewValue = Value[i]+NewValue
        CountDigits += 1
        if CountDigits == 3 and i != 0:
            NewValue = ","+NewValue
            CountDigits = 0
    if Offset != 0:
        if NewValue.startswith(","):
            NewValue = NewValue[1:]
        NewValue = Value[0]+NewValue
    return NewValue
# END: fmti




##########################################
# BEGIN: formFind(Who, WhereMsg, e = None)
# LIB:formFind():2010.285
#   The caller must set up the global Vars:
#      <Who>FindLookForVar = StringVar()
#      <Who>FindLastLookForVar = StringVar()
#      <Who>FindLinesVar = StringVar()
#      <Who>FindIndexVar = IntVar()
#   Then on the form whose Text field wants to be searched set up an Entry
#   field and two Buttons like
#
#   LEnt = Entry(Sub, width = 20, textvariable = HELPFindLookForVar)
#   LEnt.pack(side = LEFT)
#   LEnt.bind("<Double-Button-1>", Command(formKB, "HELP", "Find", \
#           HELPFindLookForVar))
#   LEnt.bind("<Return>", Command(formFind, "HELP", "HELP"))
#   LEnt.bind("<KP_Enter>", Command(formFind, "HELP", "HELP"))
#   BButton(Sub, text = "Find", command = Command(formFind, "HELP", \
#           "HELP")).pack(side = LEFT)
#   BButton(Sub, text = "Next", command = Command(formFindNext, \
#           "HELP", "HELP")).pack(side = LEFT)
#
def formFind(Who, WhereMsg, e = None):
    setMsg(WhereMsg, "CB", "Finding...")
    LTxt = Txt[Who]
    LookFor = eval("%sFindLookForVar"%Who).get().lower()
    if LookFor == "":
        LTxt.tag_delete("FI")
        LTxt.tag_delete("FIN")
        eval("%sFindLinesVar"%Who).set("")
        eval("%sFindIndexVar"%Who).set(-1)
        setMsg(WhereMsg, "", "")
        return 0
    Found = 0
    LTxt.tag_delete("FI")
    LTxt.tag_delete("FIN")
    eval("%sFindLastLookForVar"%Who).set(LookFor)
    eval("%sFindLinesVar"%Who).set("")
    eval("%sFindIndexVar"%Who).set(-1)
    FindLines = ""
    N = 1
    while 1:
        if LTxt.get("%d.0"%N) == "":
            break
        Line = LTxt.get("%d.0"%N, "%d.0"%(N+1)).lower()
        if Line.find(LookFor) != -1:
            TagStart = "%d.%d"%(N, Line.find(LookFor))
            TagEnd = "%d.%d"%(N, Line.find(LookFor)+len(LookFor))
            LTxt.tag_add("FI", TagStart, TagEnd)
            LTxt.tag_config("FI", background = Clr["U"], \
                    foreground = Clr["W"])
            FindLines += " %s,%s"%(TagStart, TagEnd)
            Found += 1
        N += 1
    if Found == 0:
        setMsg(WhereMsg, "", "No matches found.")
    else:
        eval("%sFindLinesVar"%Who).set(FindLines)
        formFindNext(Who, WhereMsg, True)
        setMsg(WhereMsg, "", "Matches found: %d"%Found)
    return Found
############################################################
# BEGIN: formFindNext(Who, WhereMsg, Find = False, e = None)
# FUNC:formFindNext():2010.284
def formFindNext(Who, WhereMsg, Find = False, e = None):
    LTxt = Txt[Who]
    LTxt.tag_delete("FIN")
    FindLines = eval("%sFindLinesVar"%Who).get().split()
    if len(FindLines) == 0:
        beep(1)
        return
    Index = eval("%sFindIndexVar"%Who).get()
    Index += 1
    try:
        Line = FindLines[Index]
        eval("%sFindIndexVar"%Who).set(Index)
    except IndexError:
        Index = 0
        Line = FindLines[Index]
        eval("%sFindIndexVar"%Who).set(0)
# Make the "current find" red.
    TagStart, TagEnd = Line.split(",")
    LTxt.tag_add("FIN", TagStart, TagEnd)
    LTxt.tag_config("FIN", background = Clr["R"], foreground = Clr["W"])
    Txt[Who].see(TagStart)
# If this is the first find just let the caller set a message.
    if Find == False:
        setMsg(WhereMsg, "", "Match %d of %d."%(Index+1, len(FindLines)))
    return
# END: formFind




#############################################
# BEGIN: formKB(Parent, Title, Var, e = None)
# LIB:formKB():2009.154
Frm["KB"] = None
KBEntryVar = StringVar()

def formKB(Parent, Title, Var, e = None):
    if Frm["KB"] != None:
        Frm["KB"].deiconify()
        Frm["KB"].lift()
        beep(2)
        return
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    LFrm = Frm["KB"] = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.resizable(0, 0)
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "KB"))
    LFrm.title(Title)
    LFrm.iconname("Keyboard")
    LEnt = Entry(LFrm, textvariable = KBEntryVar)
    LEnt.pack(side = TOP, fill = X)
    LEnt.bind("<Return>", Command(formKBReturn, Var))
    LEnt.bind("<KP_Enter>", Command(formKBReturn, Var))
    Sub = Frame(LFrm)
    for K in ("!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "+", \
            "|", "~"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Sub = Frame(LFrm)
    for K in ("1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", \
            "\\"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Frame(LFrm, height = 1, bg = Clr["B"], relief = GROOVE).pack(side = TOP, \
            fill = X, pady = 1)
    Sub = Frame(LFrm)
    for K in ("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "{", "}", \
            "BS"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Sub = Frame(LFrm)
    for K in ("A", "S", "D", "F", "G", "H", "J", "K", "L", ":"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    BButton(Sub, text = "RETURN", command = Command(formKBReturn, Var), \
            font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP)
    Sub = Frame(LFrm)
    for K in ("Z", "X", "C", "V", "B", "N", "M", "<", ">", "?"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Frame(LFrm, height = 1, bg = Clr["B"], relief = GROOVE).pack(side = TOP, \
            fill = X, pady = 1)
    Sub = Frame(LFrm)
    for K in ("q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", \
            "BS"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, fill = Y)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Sub = Frame(LFrm)
    for K in ("a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    BButton(Sub, text = "RETURN", command = Command(formKBReturn, Var), \
            font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Sub = Frame(LFrm)
    for K in ("z", "x", "c", "v", "b", "n", "m", ",", ".", "/"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Sub = Frame(LFrm)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "          SPACE          ", \
            command = Command(formKBHit, " "), \
            font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Cancel", font = PROGKBFont, \
            command = Command(closeForm, "KB")).pack(side = LEFT, padx = 1, \
            pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    KBEntryVar.set(Var.get())
    center(Parent, LFrm, "C", "I", True)
    LEnt.focus_set()
    LEnt.icursor(END)
    return
###############################
# BEGIN: formKBHit(K, e = None)
# FUNC:formKBHit():2008.012
Keysyms = {"!":"exclam", "@":"at", "#":"numbersign", "$":"dollar", \
        "%":"percent", "^":"asciicircum", "&":"ampersand", "*":"asterisk", \
        "(":"parenleft", ")":"parenright", "_":"underscore", "+":"plus", \
        "|":"bar", "~":"asciitilde", "-":"minus", "=":"equal", \
        "\\":"backslash", "{":"braceleft", "}":"braceright", \
        "[":"bracketleft", "]":"bracketright", ":":"colon", ";":"semicolon", \
        "'":"quoteright", "<":"less", ">":"greater", "?":"question", \
        ",":"comma", ".":"period", "/":"slash", " ":"space", "BS":"BackSpace"}

def formKBHit(K, e = None):
    if K == "BS":
        Root.event_generate("<KeyPress-BackSpace>")
        return
    elif (K >= "a" and K <= "z") or (K >= "A" and K <= "Z"):
        Root.event_generate("<KeyPress-"+K+">")
        return
    elif (K >= "0" and K <= "9"):
        Root.event_generate("<KeyPress-"+K+">")
        return
    try:
        Root.event_generate("<KeyPress-"+Keysyms[K]+">")
    except KeyError:
        beep(1)
    return
####################################
# BEGIN: formKBReturn(Var, e = None)
# FUNC:formKBReturn():2008.012
def formKBReturn(Var, e = None):
    Var.set(KBEntryVar.get().strip())
    closeForm("KB")
    return
# END: formKB




####################################################################
# BEGIN: formMYD(Parent, Clicks, Close, C, Title, Msg1, Msg2 = "", \
#                Bell = 0, CenterX = 0, CenterY = 0, Width = 0)
# LIB:formMYD():2010.257
#   The built-in dialog boxes cannot be associated with a particular frame, so
#   the Root/Main window kept popping to the front and covering up everything
#   on some systems when they were used, so I wrote this. I'm sure there is a
#   "classy" way of doing this, but I couldn't figure out how to return a
#   value after the window was destroyed from a classy-way.
#
#   The dialog box can contain an input field by using something like:
#
#   Answer = formMYD(Root, (("Input60", TOP, "input"), ("Write", LEFT, \
#           "input"), ("(Cancel)", LEFT, "cancel")), "cancel", "YB"\
#           "Let it be written...", \
#   "Enter a message to write to the Messages section (60 characters max.):")
#   if Answer == "cancel":
#       return
#   What = Answer.strip()
#   if len(What) == 0 or len(What) > 60:
#       Root.bell()
#   print(What)
#
#   The "Input60" tells the function to make an entry field 60 characters
#   long.  The "input" return value for the "Write" button tells the routine
#   to return whatever was entered into the input field. The "Cancel" button
#   will return "cancel", which, of course, could be confusing if the user
#   entered "cancel" in the input field and hit the Write button. In the case
#   above the Cancel button should probably return something like "!@#$%^&",
#   or something else that the user would never normally enter.
#
#   A "default" button may be designated by enclosing the text in ()'s.
#   Pressing the Return or keypad Enter keys will return that button's value.
#   The Cancel button is the default button in this example.
#
#   A caller must clear, or may set MYDAnswerVar to clear a previous
#   call's entry or to provide a default value for the input field before
#   calling formMYD().
#
#   To bring up a "splash dialog" for messages like "Working..." use
#
#       formMYD(Root, (), "", "", "", "Working...")
#
#   Call formMYDReturn to get rid of the dialog:
#
#       formMYDReturn("")
#
#   CenterX and CenterY can be used to position the dialog box when there is
#   no Parent if they are set to something other than 0 and 0.
#
#   Width may be set to something other than 0 to not use the default message
#   width.
MYDFrame = None
MYDLabel = None
MYDAnswerVar = StringVar()
PROGTrans["MYDyes-LE"] = "Yes"
PROGTrans["MYDyes-LS"] = unicode("S\xed", "iso8859-1")
PROGTrans["MYDno-LE"] = "No"
PROGTrans["MYDno-LS"] = "No"
PROGTrans["MYDclear-LE"] = "Clear"
PROGTrans["MYDclear-LS"] = "Limpio"
PROGTrans["MYDclose-LE"] = "Close"
PROGTrans["MYDclose-LS"] = "Cerrar"
PROGTrans["MYDcancel-LE"] = "Cancel"
PROGTrans["MYDcancel-LS"] = "Cancelar"
PROGTrans["MYDok-LE"] = "OK"
PROGTrans["MYDok-LS"] = "OK"

def formMYD(Parent, Clicks, Close, C, Title, Msg1, Msg2 = "", Bell = 0, \
        CenterX = 0, CenterY = 0, Width = 0):
    global MYDFrame
    global MYDLabel
    if Parent != None:
# Allow either way of passing the parent.
        if isinstance(Parent, str) == True:
            Parent = Frm[Parent]
# Without this update() sometimes when running a program through ssh everyone
# loses track of where the parent is and the dialog box ends up at 0,0.
        Parent.update()
    LFrm = MYDFrame = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.resizable(0, 0)
    LFrm.protocol("WM_DELETE_WINDOW", Command(formMYDReturn, Close))
# A number shows up in the title bar if you do .title(""), and if you don't
# set the title it ends up with the program name in it.
    if Title == "":
        Title = " "
    LFrm.title(Title)
    LFrm.iconname(Title)
# Gets rid of some of the extra title bar buttons.
    LFrm.transient(Parent)
    LFrm.bind("<Visibility>", formMYDStay)
    if C != "":
        LFrm.configure(bg = Clr[C[0]])
# Break up the incoming message about every 50 characters or whatever Width is
# set to.
    if Width == 0:
        Width = 50
    if len(Msg1) > Width:
        Count = 0
        Msg = ""
        for c in Msg1:
            if Count == 0 and c == " ":
                continue
            if Count > Width and c == " ":
                Msg += "\n"
                Count = 0
                continue
            if c == "\n":
                Msg += c
                Count = 0
                continue
            Count += 1
            Msg += c
        Msg1 = Msg
# This is an extra line that gets added to the message after a blank line.
    if Msg2 != "":
        if len(Msg2) > Width:
            Count = 0
            Msg = ""
            for c in Msg2:
                if Count == 0 and c == " ":
                    continue
                if Count > Width and c == " ":
                    Msg += "\n"
                    Count = 0
                    continue
                if c == "\n":
                    Msg += c
                    Count = 0
                    continue
                Count += 1
                Msg += c
            Msg1 += "\n\n"+Msg
        else:
            Msg1 += "\n\n"+Msg2
    if C == "":
        MYDLabel = Label(LFrm, text = Msg1, bd = 20)
        MYDLabel.pack(side = TOP)
        Sub = Frame(LFrm)
    else:
        MYDLabel = Label(LFrm, text = Msg1, bd = 20, bg = Clr[C[0]], \
                fg = Clr[C[1]])
        MYDLabel.pack(side = TOP)
        Sub = Frame(LFrm, bg = Clr[C[0]])
    One = False
    InputField = False
    for Click in Clicks:
        if Click[0].startswith("Input"):
            LEnt = Entry(LFrm, textvariable = MYDAnswerVar, \
                    width = intt(Click[0][5:]))
            LEnt.pack(side = TOP, padx = 10, pady = 10)
            LEnt.bind("<Double-Button-1>", Command(formKB, MYDFrame, "Input", \
                    MYDAnswerVar))
# So we know to do the focus_set at the end.
            InputField = True
            continue
        if One == True:
            if C == "":
                Label(Sub, text = " ").pack(side = LEFT)
            else:
                Label(Sub, text = " ", bg = Clr[C[0]]).pack(side = LEFT)
        But = BButton(Sub, text = Click[0], command = Command(formMYDReturn, \
                Click[2]))
        if Click[0].startswith(PROGTrans['MYDclear'+PROGLang]) or \
                Click[0].startswith("("+PROGTrans['MYDclear'+PROGLang]):
            But.configure(fg = Clr["U"], activeforeground = Clr["U"])
        elif Click[0].startswith(PROGTrans['MYDclose'+PROGLang]) or \
                Click[0].startswith("("+PROGTrans['MYDclose'+PROGLang]):
            But.configure(fg = Clr["R"], activeforeground = Clr["R"])
        But.pack(side = Click[1])
        if Click[0].startswith("(") and Click[0].endswith(")"):
            LFrm.bind("<Return>", Command(formMYDReturn, Click[2]))
            LFrm.bind("<KP_Enter>", Command(formMYDReturn, Click[2]))
        if Click[1] != TOP:
            One = True
    Sub.pack(side = TOP, padx = 3, pady = 3)
    center(Parent, LFrm, "C", "I", True, CenterX, CenterY)
# If the user clicks to dismiss the window before any one of these things get
# taken care of then there will be touble. This may only happen when the user
# is running the program over a network and not on the local machine. It has
# something to do with changes made to the beep() routine which fixed a
# problem of occasional missing beeps.
    try:
        LFrm.focus_set()
        LFrm.grab_set()
        if InputField == True:
            LEnt.focus_set()
            LEnt.icursor(END)
        if Bell != 0:
            beep(Bell)
# Everything will pause here until one of the buttons are pressed if there are
# any, then the box will be destroyed, but the value will still be returned.
# since it was saved in a "global".
        if len(Clicks) != 0:
            LFrm.wait_window()
    except:
        pass
# At least do this much cleaning for the caller.
    MYDAnswerVar.set(MYDAnswerVar.get().strip())
    return MYDAnswerVar.get()
######################################
# BEGIN: formMYDReturn(What, e = None)
# FUNC:formMYDReturn():2008.145
def formMYDReturn(What, e = None):
# If What is "input" just leave whatever is in the var in there.
    if What != "input":
        MYDAnswerVar.set(What)
    MYDAnswerVar.set(MYDAnswerVar.get().strip())
    MYDFrame.destroy()
    updateMe(0)
    return
############################
# BEGIN: formMYDMsg(Message)
# FUNC:formMYDMsg():2008.012
def formMYDMsg(Message):
    global MYDLabel
    MYDLabel.config(text = Message)
    updateMe(0)
    return
##############################
# BEGIN: formMYDStay(e = None)
# FUNC:formMYDStay():2010.257
def formMYDStay(e = None):
# The user may dismiss the dialog box before these get a chance to do their
# thing.
    try:
        MYDFrame.unbind("<Visibility>")
        MYDFrame.focus_set()
        MYDFrame.update()
        MYDFrame.lift()
        MYDFrame.bind("<Visibility>", formMYDStay)
    except TclError:
        pass
    return
# END: formMYD




#####################################################################
# BEGIN: formMYDF(Parent, Mode, Title, StartDir, StartFile, Msg = "",
#                EndsWith = "", SameCase = True)
# LIB:formMYDF():2010.248
#   Mode = 0 = allow picking a file
#          1 = just allow picking directories
#          2 = allow picking and making directories only
#          3 = pick/save as directories and files (the works)
#          4 = pick multiple files/change dirs
#   Msg = A message that can be displayed at the top of the form. It's a
#         Label, so \n's should be put in the passed Msg string.
#   EndsWith = The module will only display files ending with EndsWith, the
#              entered filename's case will be matched with the case of
#              EndsWith (IF it is all one case or another). EndsWith may be
#              a passed string of file extensions seperated by commas. EndsWith
#              will be added to the entered filename if it is not there before
#              returning, but only if there is one extension passed.
#   SameCase = If True then the case of the filename must match the case of
#              the EndsWith items.
#   Needs: PROGMYDFFont set (usually the same as the Entry() font)
MYDFFrame = None
MYDFModeVar = IntVar()
MYDFDirVar = StringVar()
MYDFFiles = None
MYDFFileVar = StringVar()
MYDFEndsWithVar = StringVar()
MYDFAnswerVar = StringVar()
MYDFHiddenCVar = IntVar()
MYDFSameCase = True

def formMYDF(Parent, Mode, Title, StartDir, StartFile, Msg = "", \
        EndsWith = "", SameCase = True):
    global MYDFFrame
    global MYDFFiles
    global MYDFMsg
    global MYDFSameCase
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    MYDFModeVar.set(Mode)
    MYDFEndsWithVar.set(EndsWith)
    MYDFSameCase = SameCase
# Without this update() sometimes when running a program through ssh everyone
# loses track of where the parent is and the dialog box ends up at 0,0.
    Parent.update()
    LFrm = MYDFFrame = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.protocol("WM_DELETE_WINDOW", Command(formMYDFReturn, None))
    LFrm.title(Title)
    LFrm.iconname("PickDF")
    LFrm.bind("<Visibility>", formMYDFStay)
    Sub = Frame(LFrm)
    if Msg != "":
        Label(Sub, text = Msg).pack(side = TOP)
    BButton(Sub, text = "up", command = formMYDFUp).pack(side = LEFT)
    LEnt = Entry(Sub, textvariable = MYDFDirVar, width = 65, \
            font = PROGMYDFFont)
    LEnt.pack(side = LEFT, fill = X, expand = YES)
    LEnt.bind("<Double-Button-1>", Command(formKB, MYDFFrame, "Dir", \
                    MYDFDirVar))
    LEnt.bind("<Return>", formMYDFFillFiles)
    LEnt.bind("<KP_Enter>", formMYDFFillFiles)
    if Mode == 2 or Mode == 3:
        But = BButton(Sub, text = "Mkdir", command = formMYDFNew)
        But.pack(side = LEFT)
        ToolTip(But, 25, \
                "Add the name of the new directory to the end of the current contents of the entry field and click this button to create the new directory.")
    Sub.pack(side = TOP, fill = X)
    Sub = Frame(LFrm)
    if Mode == 4:
        LLb = MYDFFiles = Listbox(Sub, relief = SUNKEN, bd = 2, \
                font = PROGMYDFFont, height = 15, selectmode = EXTENDED)
    else:
        LLb = MYDFFiles = Listbox(Sub, relief = SUNKEN, bd = 2, \
                font = PROGMYDFFont, height = 15, selectmode = SINGLE)
    LLb.pack(side = LEFT, expand = YES, fill = BOTH)
    LLb.bind("<ButtonRelease-1>", formMYDFPicked)
    Scroll = Scrollbar(Sub, command = LLb.yview)
    Scroll.pack(side = RIGHT, fill = Y)
    LLb.configure(yscrollcommand = Scroll.set)
    Sub.pack(side = TOP, expand = YES, fill = BOTH)
# The user can type in the filename.
    if Mode == 0 or Mode == 3:
        Sub = Frame(LFrm)
        Label(Sub, text = "Filename:=").pack(side = LEFT)
        LEnt = Entry(Sub, textvariable = MYDFFileVar, width = 65, \
                font = PROGMYDFFont)
        LEnt.pack(side = LEFT, fill = X, expand = YES)
        LEnt.bind("<Double-Button-1>", Command(formKB, MYDFFrame, "Filename", \
                    MYDFFileVar))
        LEnt.bind("<Return>", Command(formMYDFReturn, ""))
        LEnt.bind("<KP_Enter>", Command(formMYDFReturn, ""))
        Sub.pack(side = TOP, fill = X, padx = 3)
    Sub = Frame(LFrm)
    BButton(Sub, text = "OK", command = Command(formMYDFReturn, \
            "")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Cancel", \
            command = Command(formMYDFReturn, None)).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    LCb = Checkbutton(Sub, text = "Show hidden\nfiles", \
            variable = MYDFHiddenCVar, command = formMYDFFillFiles)
    LCb.pack(side = LEFT)
    ToolTip(LCb, 30, "Select this to show hidden/system files in the list.")
    Sub.pack(side = TOP, pady = 3)
    MYDFMsg = Text(LFrm, width = 1, height = 1, highlightthickness = 0, \
            insertwidth = 0, font = PROGMYDFFont, takefocus = 0)
    MYDFMsg.pack(side = TOP, expand = YES, fill = X)
    if len(StartDir) == 0:
        if PROGSystem == "dar" or PROGSystem == "lin" or PROGSystem == "sun":
            StartDir = sep
        elif PROGSystem == "win":
# Where else?
            StartDir = "C:"+sep
    if StartDir.endswith(sep) == False:
        StartDir += sep
    MYDFDirVar.set(StartDir)
    Ret = formMYDFFillFiles()
    if Ret == True and (Mode == 0 or Mode == 3):
        MYDFFileVar.set(StartFile)
    center(Parent, LFrm, "C", "I", True)
    MYDFFrame.grab_set()
# Set the cursor for the user.
    if Mode == 0 or Mode == 3:
        LEnt.focus_set()
        LEnt.icursor(END)
# Everything will pause here until one of the buttons are pressed, then the
# box will be destroyed, but the value will still be returned since it was
# saved in a "global".
    MYDFFrame.wait_window()
    return MYDFAnswerVar.get()
####################################
# BEGIN: formMYDFFillFiles(e = None)
# FUNC:formMYDFFillFiles():2010.248
def formMYDFFillFiles(e = None):
# Some directoryies may have a lot of files in them which could make listdir()
# take a long time, so do this.
    setMsg(MYDFMsg, "CB", "Working...")
# Make sure whatever is in the directory field ends in a separator.
    if len(MYDFDirVar.get()) == 0:
        if PROGSystem == "dar" or PROGSystem == "lin" or PROGSystem == "sun":
            MYDFDirVar.set(sep)
        elif PROGSystem == "win":
            MYDFDirVar.set("C:\\")
    if MYDFDirVar.get().endswith(sep) == False:
        MYDFDirVar.set(MYDFDirVar.get()+sep)
    Dir = MYDFDirVar.get()
    try:
        Files = listdir(Dir)
    except:
        MYDFFileVar.set("")
        setMsg(MYDFMsg, "YB", " There is no such directory.", 2)
        return False
    MYDFFiles.delete(0, END)
    Files.sort(formMYDFCmp)
# Always add this to the top of the list.
    MYDFFiles.insert(END, " .."+sep)
# To show or not to show.
    ShowHidden = MYDFHiddenCVar.get()
    Mode = MYDFModeVar.get()
# Do the directories first.
    for File in Files:
        if ShowHidden == 0:
# FUTUREME - This may need/want to be system dependent at some point (i.e. more
# than just files that start with a .).
            if File.startswith(".") or File.startswith("_"):
                continue
        if isdir(Dir+sep+File):
            MYDFFiles.insert(END, " "+File+sep)
# Check to see if we are going to be filtering.
    EndsWith = ""
    if MYDFEndsWithVar.get() != "":
        EndsWith = MYDFEndsWithVar.get()
    EndsWithParts = EndsWith.split(",")
    Found = False
    for File in Files:
        if ShowHidden == 0:
            if File.startswith(".") or File.startswith("_"):
                continue
        if isdir(Dir+sep+File) == False:
            if EndsWith == "":
# We only want to see the file sizes when we are looking for files.
                if Mode == 0 or Mode == 3:
# Trying to follow links will trip this so just show them.
                    try:
                        MYDFFiles.insert(END, " %s  (bytes: %s)"%(File, \
                                fmti(getsize(Dir+sep+File))))
                    except OSError:
                        MYDFFiles.insert(END, " %s  (a link?)"%File)
                else:
                    MYDFFiles.insert(END, " %s"%File)
                Found += 1
            else:
                for EndsWithPart in EndsWithParts:
                    if File.endswith(EndsWithPart):
                        if Mode == 0 or Mode == 3:
                            try:
                                MYDFFiles.insert(END, " %s  (bytes: %s)"% \
                                        (File, fmti(getsize(Dir+sep+File))))
                            except OSError:
                                MYDFFiles.insert(END, " %s  (a link?)"%File)
                        else:
                            MYDFFiles.insert(END, " %s"%File)
                        Found += 1
                        break
    if Mode == 0 or Mode == 3:
        if Found == 1:
            setMsg(MYDFMsg, "", " 1 file found.")
        else:
            setMsg(MYDFMsg, "", " %d files found."%Found)
    else:
        setMsg(MYDFMsg, "", "")
    MYDFMsg.focus_set()
    return True
##########################
# BEGIN: formMYDFCmp(x, y)
# FUNC:formMYDFCmp():2009.171
#   So the directory listings are sorted in alphabetical and not ASCII order.
def formMYDFCmp(x, y):
    x = x.lower()
    y = y.lower()
    if x < y:
        return -1
    if x == y:
        return 0
    if x > y:
        return 1
######################
# BEGIN: formMYDFNew()
# FUNC:formMYDFNew():2009.100
def formMYDFNew():
    setMsg(MYDFMsg, "", "")
# Make sure whatever is in the directory field ends in a separator.
    if len(MYDFDirVar.get()) == 0:
        MYDFDirVar.set(sep)
    if MYDFDirVar.get().endswith(sep) == False:
        MYDFDirVar.set(MYDFDirVar.get()+sep)
    Dir = MYDFDirVar.get()
    if exists(Dir):
        setMsg(MYDFMsg, "YB", " Directory already exists.", 2)
        return
    try:
        makedirs(Dir)
        formMYDFFillFiles()
        setMsg(MYDFMsg, "GB", " New directory made.", 1)
    except Exception, e:
# The system messages can be a bit cryptic and/or long, so simplifiy them here.
        if str(e).find("ermission") != -1:
            setMsg(MYDFMsg, "RW", " Permission denied.", 2)
        else:
            setMsg(MYDFMsg, "RW", " "+str(e), 2)
        return
    return
#################################
# BEGIN: formMYDFPicked(e = None)
# FUNC:formMYDFPicked():2008.208
def formMYDFPicked(e = None):
# This is just to get the focus off of the entry field if it was there since
# the user is now clicking on things.
    MYDFMsg.focus_set()
    setMsg(MYDFMsg, "", "")
# Make sure whatever is in the directory field ends with a separator.
    if len(MYDFDirVar.get()) == 0:
        MYDFDirVar.set(sep)
    if MYDFDirVar.get().endswith(sep) == False:
        MYDFDirVar.set(MYDFDirVar.get()+sep)
    Dir = MYDFDirVar.get()
    Mode = MYDFModeVar.get()
# Otherwise the selected stuff will just keep piling up.
    if Mode == 4:
        MYDFFileVar.set("")
# There could be multiple files selected. Go through all of them and see if any
# of them will make us change directories.
    Sel = MYDFFiles.curselection()
    SelectedFiles = ""
    for Index in Sel:
# If the user is not right on the money this will sometimes trip.
        try:
            Selected = MYDFFiles.get(Index).strip()
        except TclError:
            beep(1)
            return
        if Selected == ".."+sep:
            Parts = Dir.split(sep)
# If there are only two Parts then we have hit the top of the directory tree.
# If we don't do this things like "C:" will be wiped out.
            NewDir = ""
            if len(Parts) == 2 and Parts[1] == "":
                NewDir = Parts[0]+sep
            else:
                for i in xrange(0, len(Parts)-2):
                    NewDir += Parts[i]+sep
# Insurance.
            if len(NewDir) == 0:
                if PROGSystem == "dar" or PROGSystem == "lin" or \
                        PROGSystem == "sun":
                    NewDir = sep
# For lack of anyplace else.
                elif PROGSystem == "win":
                    NewDir = "C:"+sep
            MYDFDirVar.set(NewDir)
            formMYDFFillFiles()
            return
        if isdir(Dir+Selected):
            MYDFDirVar.set(Dir+Selected)
            formMYDFFillFiles()
            return
        if Mode == 1 or Mode == 2:
            setMsg(MYDFMsg, "YB", "That is not a directory.", 2)
            MYDFFiles.selection_clear(0, END)
            return
# Must have clicked on a file with byte size and that must be allowed.
        if Selected.find("  (") != -1:
            Selected = Selected[:Selected.index("  (")]
# Build the whole path for the multiple file mode.
        if Mode == 4:
            if SelectedFiles == "":
                SelectedFiles = Dir+Selected
            else:
# An * should be a safe separator, right?
                SelectedFiles += "*"+Dir+Selected
        else:
# This should end up the only file.
            SelectedFiles = Selected
    MYDFFileVar.set(SelectedFiles)
    return
#############################
# BEGIN: formMYDFUp(e = None)
# FUNC:formMYDFUp():2008.098
def formMYDFUp(e = None):
# This is just to get the focus off of the entry field if it was there.
    MYDFMsg.focus_set()
    setMsg(MYDFMsg, "", "")
    Dir = MYDFDirVar.get()
    Parts = Dir.split(sep)
# If there are only two Parts then we have hit the top of the directory tree.
# If we don't do this things like "C:" will be wiped out.
    NewDir = ""
    if len(Parts) == 2 and Parts[1] == "":
        NewDir = Parts[0]+sep
    else:
        for i in xrange(0, len(Parts)-2):
            NewDir += Parts[i]+sep
# Insurance.
    if len(NewDir) == 0:
        if PROGSystem == "dar" or PROGSystem == "lin" or PROGSystem == "sun":
            NewDir = sep
# For lack of anyplace else.
        elif PROGSystem == "win":
            NewDir = "C:"+sep
    MYDFDirVar.set(NewDir)
    formMYDFFillFiles()
    return
#########################################
# BEGIN: formMYDFReturn(Return, e = None)
# FUNC:formMYDFReturn():2008.210
def formMYDFReturn(Return, e = None):
# This update keeps the "OK" button from staying pushed in when there is a lot
# to do before returning.
    MYDFFrame.update()
    setMsg(MYDFMsg, "", "")
    Mode = MYDFModeVar.get()
    if Return == None:
        MYDFAnswerVar.set("")
    elif Return != "":
        MYDFAnswerVar.set(Return)
    elif Return == "":
        if Mode == 1 or Mode == 2:
            if MYDFDirVar.get() == "":
                setMsg(MYDFMsg, "YB", "There is no directory name.", 2)
                return
            if MYDFDirVar.get().endswith(sep) == False:
                MYDFDirVar.set(MYDFDirVar.get()+sep)
            MYDFAnswerVar.set(MYDFDirVar.get())
        elif Mode == 0 or Mode == 3:
# Just in case the user tries to pull a fast one.
            if MYDFDirVar.get() == "":
                setMsg(MYDFMsg, "YB", "There is no directory name.", 2)
                return
# What was the point of coming here??
            if MYDFFileVar.get() == "":
                setMsg(MYDFMsg, "YB", "No filename has been entered.", 2)
                return
            if MYDFEndsWithVar.get() != "":
# I'm sure this may come back to haunt US someday, but make sure that the case
# of the entered filename matches the passed 'extension'.  My programs, as a
# general rule, are written to handle all upper or lowercase file names, but
# not mixed. Of course, on some operating systems it won't make any difference.
                if MYDFSameCase == True:
                    if MYDFEndsWithVar.get().isupper():
                        if MYDFFileVar.get().isupper() == False:
                            setMsg(MYDFMsg, "YB", \
                              "Filename needs to be all uppercase letters.", 2)
                            return
                    elif MYDFEndsWithVar.get().islower():
                        if MYDFFileVar.get().islower() == False:
                            setMsg(MYDFMsg, "YB", \
                              "Filename needs to be all lowercase letters.", 2)
                            return
# If the user didn't put the 'extension' on the file add it so the caller
# won't have to do it, unless the caller passed multiple extensions, then don't
# do anything.
                if MYDFEndsWithVar.get().find(",") == -1:
                    if MYDFFileVar.get().endswith( \
                            MYDFEndsWithVar.get()) == False:
                        MYDFFileVar.set(MYDFFileVar.get()+ \
                            MYDFEndsWithVar.get())
            MYDFAnswerVar.set(MYDFDirVar.get()+MYDFFileVar.get())
        elif Mode == 4:
            MYDFAnswerVar.set(MYDFFileVar.get())
    MYDFFrame.destroy()
    updateMe(0)
    return
###############################
# BEGIN: formMYDFStay(e = None)
# FUNC:formMYDFStay():2008.012
def formMYDFStay(e = None):
    MYDFFrame.unbind("<Visibility>")
    MYDFFrame.focus_set()
    MYDFFrame.update()
    MYDFFrame.lift()
    MYDFFrame.bind("<Visibility>", formMYDFStay)
    return
# END: formMYDF




#########################
# BEGIN: formSTAT(Parent)
# FUNC:formSTAT():2009.047
#   Everything needed to draw and control the status display.
#   This one is for CHANGEO.
STATTXTOTAL = 15
STATTCBOXES = 1
STATTCCOLS = 1
STATTCROWS = 15
STATBoxes = {}
STATUnit = {}
STATEnumBoxRVar = StringVar()
STATEnumBoxRVar.set("all")
PROGSetups += ("STATEnumBoxRVar", )
STATLastEnumBoxRVar = StringVar()

def formSTAT(Parent):
    TopSub = Frame(Parent)
    Key = 0
    for Box in xrange(1, STATTCBOXES+1):
        STATBoxes[Box] = Frame(TopSub)
        for Col in xrange(1, STATTCCOLS+1):
            SSub = Frame(STATBoxes[Box], bg = Clr["A"])
            for Unit in xrange(1, STATTCROWS+1):
                SSSub = Frame(SSub, relief = GROOVE, bd = 1, bg = Clr["A"])
                IDLab = Label(SSSub, bd = 2, bg = Clr["A"], fg = Clr["B"])
                IDLab.pack(side = LEFT, fill = X, expand = YES, padx = 2, \
                        pady = 2)
                StatLab = Label(SSSub, text = " ", bg = Clr["B"], \
                        fg = Clr["B"], relief = SUNKEN, width = 5)
                StatLab.pack(side = RIGHT, fill = BOTH, padx = 2, pady = 2)
                SSSub.pack(side = TOP, fill = BOTH)
# Keys will be 1 thru STATTXTOTAL inclusive.
                Key += 1
                STATUnit[Key] = [IDLab, StatLab]
            SSub.pack(side = TOP, fill = BOTH, expand = YES)
        STATBoxes[Box].pack(side = TOP, fill = BOTH, expand = YES)
    TopSub.pack(side = TOP, fill = X)
    return
##########################
# BEGIN: formSTATAddID(ID)
# FUNC:formSTATAddID():2009.314
#   Sticks the passed ID into the next available slot.  This is different from
#   POCUS in that the same ID is allowed here more than once.
def formSTATAddID(ID):
    ID = str(ID).upper()
# You can only add to the currently selected box.
    Start, End = formSTATGetRange()
# Look for an open slot in the current box.
    for Key in xrange(Start, End+1):
        if STATUnit[Key][0].cget("text") == "":
            Lab = STATUnit[Key][0]
            Lab.configure(text = ID, bg = Clr["W"], relief = RAISED)
            Lab.bind("<Button-1>", formSTATSelectOne)
            Lab.bind("<Shift-Button-1>", formSTATSelectRange)
            Lab.bind("<Control-Button-1>", formSTATSelectAdditional)
            Lab.bind("<Command-Button-1>", formSTATSelectAdditional)
            STATUnit[Key][1].configure(bg = Clr["B"])
            updateMe(0)
            return (0, )
    return (2, "YB", "There are no positions open.", 2)
################################
# BEGIN: formSTATBoxControl(Box)
# FUNC:formSTATBoxControl():2008.223
# "BOX" CONCEPT NOT REALLY USED BY CHANGEO.
#   Box = -1 = turns on STATEnumBoxRVar.get()'s border
#          0 = turns off all box borders ("All")
#      1,2,3 = turns on Box's border
#
#   If the user clicks a box button when the program is busy STATEnumBoxRVar
#   will be set to the new value, but this function will detect that the
#   program is busy and not do anything. The value in STATLastEnumBoxRVar will
#   be given to STATEnumBoxRVar to put the before-click value back. This
#   function gets called while the program is starting so STATLastEnumBoxRVar
#   will get initialized then.
def formSTATBoxControl(Box):
    if isPROGRunning(None) == True:
        STATEnumBoxRVar.set(STATLastEnumBoxRVar.get())
        return
    if Box == -1:
        Value = STATEnumBoxRVar.get()
        if Value == "" or Value == "all":
            formSTATBoxControl(0)
        else:
            formSTATBoxControl(int(Value))
        return
    for i in xrange(1, 1+3):
        STATBoxes[i].config(bg = Clr["D"])
    if Box != 0:
        STATBoxes[Box].config(bg = Clr["Y"])
    STATLastEnumBoxRVar.set(STATEnumBoxRVar.get())
    updateMe(0)
    return
############################
# BEGIN: formSTATCheckEnum()
# FUNC:formSTATCheckEnum():2009.027
#   Checks to see if any units have been enumerated.
def formSTATCheckEnum():
    for Key in xrange(1, STATTXTOTAL+1):
        if STATUnit[Key][0].cget("text") != "":
            return True
    msgLn(0, "R", "You need to enumerate first.", True, 2)
    return False
############################
# BEGIN: formSTATClearID(ID)
# FUNC:formSTATClearID():2009.074
#   ID = "0" = clears the current box
#      other = clears that unit ID box
def formSTATClearID(ID):
    ID = str(ID)
    if ID == "0":
        Start, End = formSTATGetRange()
        for Key in xrange(Start, End+1):
            Lab = STATUnit[Key][0]
            Lab.configure(text = "", bg = Clr["A"], relief = FLAT)
            Lab.unbind("<Button-1>")
            Lab.unbind("<Shift-Button-1>")
            Lab.unbind("<Control-Button-1>")
            Lab.unbind("<Command-Button-1>")
            STATUnit[Key][1].configure(bg = Clr["B"])
    else:
        ID = ID.upper()
        Key = formSTATID2Key(ID, "any")
        if Key == -1:
            msgLn(0, "R", "No DAS %s has been enumerated."%ID, True, 2)
            return
        Lab = STATUnit[Key][0]
        Lab.configure(text = "", bg = Clr["A"], relief = FLAT)
        Lab.unbind("<Button-1>")
        Lab.unbind("<Shift-Button-1>")
        Lab.unbind("<Control-Button-1>")
        Lab.unbind("<Command-Button-1>")
        STATUnit[Key][1].configure(bg = Clr["B"])
    updateMe(0)
    return
##############################
# BEGIN: formSTATGetIDs(Which)
# FUNC:formSTATGetIDs():2009.137
#   Returns a List of unit IDs that depend on the value of Which.
#   Which = 0 = selected in the current box (the normal use)
#           1 = selected and non-selected in the current box
#           2 = all enumerated IDs
def formSTATGetIDs(Which):
    Units = []
    if Which == 0 or Which == 1:
        Start, End = formSTATGetRange()
        for Key in xrange(Start, End+1):
            Lab = STATUnit[Key][0]
            if Lab.cget("text") != "":
                if Which == 0 and Lab.cget("bg") == Clr["W"]:
                    Units.append(Lab.cget("text"))
                elif Which == 1:
                    Units.append(Lab.cget("text"))
    elif Which == 2:
        for Key in xrange(1, STATTXTOTAL+1):
            Lab = STATUnit[Key][0]
            if Lab.cget("text") != "":
                Units.append(Lab.cget("text"))
    return Units
###########################
# BEGIN: formSTATGetRange()
# FUNC:formSTATGetRange():2009.026
#   Return the range of key values given the current box selected.
def formSTATGetRange():
# CHANGEO doesn't use the "box concept".
    Box = STATEnumBoxRVar.get()
    return 1, 15
###################################
# BEGIN: formSTATGetStatusColor(ID)
# FUNC:formSTATGetStatusColor():2009.026
def formSTATGetStatusColor(ID):
    Key = formSTATID2Key(ID, "any")
    if Key == -1:
        return ""
    return STATUnit[Key][1].cget("bg")
##################################
# BEGIN: formSTATID2Key(ID, Scope)
# FUNC:formSTATID2Key():2009.026
#   Mostly for internal formSTAT() use to get the dict key of the passed ID,
#   but can be called by anyone to see if a unit with the passed ID has been
#   enumerated.
def formSTATID2Key(ID, Scope):
    if Scope == "any":
        Start = 1
        End = STATTXTOTAL
    elif Scope == "box":
        Start, End = formSTATGetRange()
    for Key in xrange(Start, End+1):
        if ID == STATUnit[Key][0].cget("text"):
            return Key
    return -1
############################
# BEGIN: formSTATKey2ID(Key)
# FUNC:formSTATKey2ID():2008.153
def formSTATKey2ID(Key):
    Key = intt(Key)
    if Key < 1 or Key > STATTXTOTAL:
        return ""
    return STATUnit[Key][0].cget("text")
#################################
# BEGIN: formSTATRRemoveDups(IDs)
# FUNC:formSTATRemoveDups():2009.051
#   Removes duplicate IDs and "0000" DASs from the List IDs then clears the
#   ID labels and fills them in with the final list. Passes back the final
#   list.
def formSTATRemoveDups(IDs):
# Sort alphanumerically.
    IDs = formSTATGetIDs(0)
    IDs.sort()
# Put the final list of DASs in the enumerated list area. Throw out any 0000s.
    formSTATClearID(0)
    ListOfDASs = []
    for DAS in IDs:
        if DAS == "0000":
            continue
        ListOfDASs.append(DAS)
        formSTATAddID(DAS)
    return ListOfDASs
###########################################
# BEGIN: formSTATSelectAdditional(e = None)
# FUNC:selectAdditional():2009.026
#    Just turns the clicked label on or off without turning off the rest IF the
#    clicked-on label is in the current box.
def formSTATSelectAdditional(e = None):
    if isPROGRunning(None) == True:
        return
    ID = e.widget.cget("text")
    Key = formSTATID2Key(ID, "box")
    if Key == -1:
        beep(1)
        return
    Lab = STATUnit[Key][0]
    if Lab.cget("bg") == Clr["A"]:
        Lab.configure(bg = Clr["W"])
    else:
        Lab.configure(bg = Clr["A"])
    updateMe(0)
    return
####################################
# BEGIN: formSTATSelectAll(e = None)
# FUNC:formSTATSelectAll():2008.153
def formSTATSelectAll(e = None):
    if isPROGRunning(None) == True:
        return
    Start, End = formSTATGetRange()
    for Key in xrange(Start, End+1):
        if STATUnit[Key][0].cget("text") != "":
            STATUnit[Key][0].configure(bg = Clr["W"])
    updateMe(0)
    return
###################################
# BEGIN: formSTATSelectColor(Color)
# FUNC:formSTATSelectColor():2008.153
#   Selects all of the units with status labels matching the passed Color in
#   the current box.
def formSTATSelectColor(Color):
    if isPROGRunning(None) == True:
        return
    Start, End = formSTATGetRange()
    for Key in xrange(Start, End+1):
        Lab = STATUnit[Key][0]
        if Lab.cget("text") != "":
            if STATUnit[Key][1].cget("bg") == Clr[Color]:
                Lab.configure(bg = Clr["W"])
            else:
                Lab.configure(bg = Clr["A"])
    updateMe(0)
    return
####################################
# BEGIN: formSTATSelectOne(e = None)
# FUNC:formSTATSelectOne():2009.026
#   Turn off all of the ID labels and then turn the clicked one back on IF the
#   clicked on is in the current box.
def formSTATSelectOne(e = None):
    if isPROGRunning(None) == True:
        return
    ID = e.widget.cget("text")
    Key = formSTATID2Key(ID, "box")
# If the clicked on label is not in the current box or the ID is not a hex
# number then just beep.
    if Key == -1:
        beep(1)
        return
    Start, End = formSTATGetRange()
    for Key2 in xrange(Start, End+1):
        STATUnit[Key2][0].configure(bg = Clr["A"])
    STATUnit[Key][0].configure(bg = Clr["W"])
    updateMe(0)
    return
######################################
# BEGIN: formSTATSelectRange(e = None)
# FUNC:formSTATSelectRange():2009.026
#   Start from the first on label (from the left or the top) and turn on all of
#   the labels up to the clicked-on one IF the clicked-on one is in the current
#   box.
def formSTATSelectRange(e = None):
    if isPROGRunning(None) == True:
        return
    On = False
    ID = e.widget.cget("text")
    Key = formSTATID2Key(ID, "box")
    if Key == -1:
        beep(1)
        return
    Start, End = formSTATGetRange()
    for Key2 in xrange(Start, Key+1):
        Lab = STATUnit[Key2][0]
        if Lab.cget("text") != "":
            if Lab.cget("bg") != Clr["A"]:
                On = True
            if On == True:
                Lab.configure(bg = Clr["W"])
    updateMe(0)
    return
###############################################
# BEGIN: formSTATSetStatus(ID, Color, Str = "")
# FUNC:formSTATSetStatus():2009.238
#    ID = all = set EVERY status label to the passed Color
#        used = set all in-use status labels
#         box = set all status labels in the current box
#          nb = all status indicators that are "working" (i.e. cyan)
#           x = set that unit's status label
def formSTATSetStatus(ID, Color, Str = ""):
    ID = str(ID)
    if ID == "all":
        for Key in xrange(1, STATTXTOTAL+1):
            STATUnit[Key][1].configure(text = Str, bg = Clr[Color[0]])
    elif ID == "box":
        Start, End = formSTATGetRange()
        for Key in xrange(Start, End+1):
            STATUnit[Key][1].configure(text = Str, bg = Clr[Color[0]])
    elif ID == "used":
        for Key in xrange(1, STATTXTOTAL+1):
            if STATUnit[Key][0].cget("text") != "":
                STATUnit[Key][1].configure(text = Str, bg = Clr[Color[0]])
    elif ID == "working":
        for Key in xrange(1, STATTXTOTAL+1):
            if STATUnit[Key][1].cget("bg") == "#00FFFF":
                STATUnit[Key][1].configure(text = Str, bg = Clr[Color[0]])
# Special for CHANGEO (same as "used").
    elif ID == "0000":
        for Key in xrange(1, STATTXTOTAL+1):
            if STATUnit[Key][0].cget("text") != "":
                STATUnit[Key][1].configure(text = Str, bg = Clr[Color[0]])
    else:
        ID = ID.upper()
        Key = formSTATID2Key(ID, "box")
# The passed ID should never trigger this, but you never know. This will at
# least point out what must be a bug.
        if Key != -1:
            STATUnit[Key][1].configure(text = Str, bg = Clr[Color[0]])
        else:
            print("formSTATSetStatus(): Bad unit ID: %s"%ID)
    updateMe(0)
    return
# END: formSTAT




############################################################################
# BEGIN: formWrite(Parent, WhereMsg, TextWho, Title, FilespecVar, AllowPick)
# LIB:formWrite():2009.162
#   Writes the contents of the passed TextWho Text() widget to a file.
def formWrite(Parent, WhereMsg, TextWho, Title, FilespecVar, AllowPick):
# Sometimes it can take a while if there is a lot of text.
    updateMe(0)
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    if AllowPick == True:
        Filespec = formMYDF(Parent, 0, Title, dirname(FilespecVar.get()), \
                basename(FilespecVar.get()))
        if Filespec == "":
            return ""
    setMsg(WhereMsg, "CB", "Working...")
    Answer = "over"
    if exists(Filespec):
        Answer = formMYD(Parent, (("Append", LEFT, "append"), \
                ("Overwrite", LEFT, "over"), ("Cancel", LEFT, "cancel")), \
                "cancel", "YB", "Keep Everything.", \
                "The file\n\n%s\n\nalready exists. Would you like to append to that file, overwrite it, or cancel?"% \
                Filespec)
        if Answer == "cancel":
            setMsg(WhereMsg, "", "")
            return ""
    try:
        if Answer == "over":
            Fp = open(Filespec, "wb")
        elif Answer == "append":
            Fp = open(Filespec, "ab")
    except Exception, e:
        setMsg(WhereMsg, "MW", "Error opening file\n   %s\n   %s"% \
                (Filespec, e), 3)
        return ""
# Now that the file is OK...
    FilespecVar.set(Filespec)
    LTxt = Txt[TextWho]
    N = 1
# In case the text field is empty.
    Line = "\n"
    while 1:
        if LTxt.get("%d.0"%N) == "":
            if Line != "\n":
                Fp.write(Line)
            break
# This is a little funny, but it keeps blank lines from sneaking in at the end
# of the written lines.
        if N > 1:
            Fp.write(Line)
        Line = LTxt.get("%d.0"%N, "%d.0"%(N+1))
        N += 1
    Fp.close()
    if Answer == "append":
        setMsg(WhereMsg, "WB", "Appended text to file\n   %s"%Filespec)
    elif Answer == "over":
        setMsg(WhereMsg, "WB", "Wrote text to file\n   %s"%Filespec)
# Return this in case the caller is interested.
    return Filespec
# END: formWrite




########################
# BEGIN: getAColor(What)
# LIB:getAColor():2010.146
# W->B no W (What = 1)
GACListWBNW = [("#FFBFFF", "black"), ("#FF7FFF", "black"), \
        ("#FF3FFF", "white"), ("#FF00FF", "white"), ("#FF00BF", "white"), \
        ("#FF007F", "white"), ("#FF003F", "white"), ("#FF0000", "white"), \
        ("#FF3F00", "white"), ("#FF7F00", "white"), ("#FFBF00", "black"), \
        ("#FFFF00", "black"), ("#BFFF00", "black"), ("#7FFF00", "black"), \
        ("#3FFF00", "black"), ("#00FF00", "black"), ("#00BF00", "white"), \
        ("#007F00", "white"), ("#003F00", "white"), ("#000000", "white")]
# W->B no B (What = 2)
GACListWBNB = [("#FFFFFF", "black"), ("#FFBFFF", "black"), \
        ("#FF7FFF", "black"), ("#FF3FFF", "white"), ("#FF00FF", "white"), \
        ("#FF00BF", "white"), ("#FF007F", "white"), ("#FF003F", "white"), \
        ("#FF0000", "white"), ("#FF3F00", "white"), ("#FF7F00", "white"), \
        ("#FFBF00", "black"), ("#FFFF00", "black"), ("#BFFF00", "black"), \
        ("#7FFF00", "black"), ("#3FFF00", "black"), ("#00FF00", "black"), \
        ("#00BF00", "white"), ("#007F00", "white"), ("#003F00", "white")]
# B->W no W (What = 3)
GACListBWNW = [("#003F00", "white"), ("#007F00", "white"), \
        ("#00BF00", "white"), ("#00FF00", "black"), ("#3FFF00", "black"), \
        ("#7FFF00", "black"), ("#BFFF00", "black"), ("#FFFF00", "black"), \
        ("#FFBF00", "black"), ("#FF7F00", "white"), ("#FF3F00", "white"), \
        ("#FF0000", "white"), ("#FF003F", "white"), ("#FF007F", "white"), \
        ("#FF00BF", "white"), ("#FF00FF", "white"), ("#FF3FFF", "white"), \
        ("#FF7FFF", "black"), ("#FFBFFF", "black"), ("#FFFFFF", "black")]
# B->W no B (What = 4)
GACListBWNB = [("#000000", "white"), ("#003F00", "white"), \
        ("#007F00", "white"), ("#00BF00", "white"), ("#00FF00", "black"), \
        ("#3FFF00", "black"), ("#7FFF00", "black"), ("#BFFF00", "black"), \
        ("#FFFF00", "black"), ("#FFBF00", "black"), ("#FF7F00", "white"), \
        ("#FF3F00", "white"), ("#FF0000", "white"), ("#FF003F", "white"), \
        ("#FF007F", "white"), ("#FF00BF", "white"), ("#FF00FF", "white"), \
        ("#FF3FFF", "white"), ("#FF7FFF", "black"), ("#FFBFFF", "black")]
# Primary Colors, White Background (What = 5)
GACListPCWB = [("#000000", "white"), ("#FF0000", "white"), \
        ("#FFBF00", "black"), ("#00FF00", "black"), ("#0000FF", "white"), \
        ("#00FFFF", "black"), ("#FFFF00", "black"), ("#00BF00", "white"), \
        ("#FF00FF", "white"), ("#7F7F7F", "white")]
# Primary Colors, Black Background (What = 6)
GACListPCBB = [("#FFFFFF", "black"), ("#FF0000", "white"), \
        ("#FFBF00", "black"), ("#00FF00", "black"), ("#0000FF", "white"), \
        ("#00FFFF", "black"), ("#FFFF00", "black"), ("#00BF00", "white"), \
        ("#FF00FF", "white"), ("#7F7F7F", "white")]
# 18 Colors, no black, no adjacent matches (What = 7)
# Green is first so "individual" graphs will be green on black in several
# routines that use getAColor().
GACListNBR = [("#00FF00", "black"), ("#FFBF00", "black"), \
        ("#FF0000", "white"), ("#0000FF", "white"), ("#00FFFF", "black"), \
        ("#7F7F7F", "white"), ("#00BF00", "white"), ("#FF00FF", "white"), \
        ("#FFFF00", "black"), ("#007F00", "white"), ("#007FFF", "white"), \
        ("#FF7F00", "black"), ("#BFFF00", "black"), ("#00007F", "white"), \
        ("#CFCFCF", "black"), ("#7F00FF", "white"), ("#339999", "white"), \
        ("#FFFFFF", "black")]
# Close to the above, but for white backgrounds so no white or light yellow
# colors (what = 8)
GACListWBG = [("#000000", "white"), ("#00FF00", "black"), \
        ("#FFBF00", "black"), ("#FF0000", "white"), ("#0000FF", "white"), \
        ("#00FFFF", "black"), ("#7F7F7F", "white"), ("#00BF00", "white"), \
        ("#FF00FF", "white"), ("#FFFF00", "black"), ("#007F00", "white"), \
        ("#007FFF", "white"), ("#FF7F00", "black"), ("#00007F", "white"), \
        ("#003F00", "white"), ("#7F00FF", "white"), ("#339999", "white"), \
        ("#BF0000", "white")]

def getAColor(What):
    global GACVar
    global GACLastClr
    if What == 0:
        GACVar = -1
        GACLastClr = ()
        return
    if What == -1:
        return GACLastClr
    GACVar += 1
    if What == 1:
        if GACVar >= len(GACListWBNW):
            GACVar = 0
        Clr = GACListWBNW[GACVar]
    elif What == 2:
        if GACVar >= len(GACListWBNB):
            GACVar = 0
        Clr = GACListWBNB[GACVar]
    elif What == 3:
        if GACVar >= len(GACListBWNW):
            GACVar = 0
        Clr = GACListBWNW[GACVar]
    elif What == 4:
        if GACVar >= len(GACListBWNB):
            GACVar = 0
        Clr = GACListBWNB[GACVar]
    elif What == 5:
        if GACVar >= len(GACListPCWB):
            GACVar = 0
        Clr = GACListPCWB[GACVar]
    elif What == 6:
        if GACVar >= len(GACListPCBB):
            GACVar = 0
        Clr = GACListPCBB[GACVar]
    elif What == 7:
        if GACVar >= len(GACListNBR):
            GACVar = 0
        Clr = GACListNBR[GACVar]
    elif What == 8:
        if GACVar >= len(GACListWBG):
            GACVar = 0
        Clr = GACListWBG[GACVar]
    GACLastClr = Clr
    return Clr
# END: getAColor




#######################
# BEGIN: getGMT(Format)
# LIB:getGMT():2008.168
#   Gets the time in various forms from the system.
def getGMT(Format):
# YYYY:DDD:HH:MM:SS
    if Format == 0:
        return strftime("%Y:%j:%H:%M:%S", gmtime(time()))
# YYYYDDDHHMMSS
    elif Format == 1:
        return strftime("%Y%j%H%M%S", gmtime(time()))
# YYYY-MM-DD
    elif Format == 2:
        return strftime("%Y-%m-%d", gmtime(time()))
# YYYY-MM-DD HH:MM:SS
    elif Format == 3:
        return strftime("%Y-%m-%d %H:%M:%S", gmtime(time()))
# YYYY, MM and DD returned as ints
    elif Format == 4:
        GMT = gmtime(time())
        return (GMT[0], GMT[1], GMT[2])
# YYYY-Jan-01
    elif Format == 5:
        return strftime("%Y-%b-%d", gmtime(time()))
# YYYYMMDDHHMMSS
    elif Format == 6:
        return strftime("%Y%m%d%H%M%S", gmtime(time()))
# Reftek Texan (year-1984) time stamp in BBBBBB format
    elif Format == 7:
        GMT = gmtime(time())
        return pack(">BBBBBB", (GMT[0]-1984), 0, 1, GMT[3], GMT[4], GMT[5])
# Number of seconds
    elif Format == 8:
        return time()
# YYYY-MM-DD/DDD HH:MM:SS
    elif Format == 9:
        return strftime("%Y-%m-%d/%j %H:%M:%S", gmtime(time()))
# YYYY-MM-DD/DDD
    elif Format == 10:
        return strftime("%Y-%m-%d/%j", gmtime(time()))
# YYYY, DDD, HH, MM, SS returned as ints
    elif Format == 11:
        GMT = gmtime(time())
        return (GMT[0], GMT[7], GMT[3], GMT[4], GMT[5])
# HH:MM:SS
    elif Format == 12:
        return strftime("%H:%M:%S", gmtime(time()))
# YYYY:DDD:HH:MM:SS in local time
    elif Format == 13:
        return strftime("%Y:%j:%H:%M:%S", localtime(time()))
# HHMMSS in GMT
    elif Format == 14:
        return strftime("%H%M%S", gmtime(time()))
    return ""
# END: getGMT




#######################
# BEGIN: getLTGMTDiff()
# LIB:getLTGMTDiff():2007.016
#   Returns the number of seconds between the system's GMT and LT.
def getLTGMTDiff():
# Use the same time for both.
    Secs = time()
    LT = localtime(Secs)
    GMT = gmtime(Secs)
    return ydhms2Epoch(LT[0], LT[7], LT[3], LT[4], LT[5])- \
            ydhms2Epoch(GMT[0], GMT[7], GMT[3], GMT[4], GMT[5])
# END: getLTGMTDiff




###########################
# BEGIN: getRange(Min, Max)
# LIB:getRange():2008.360
#   Returns the absolute value of the difference between Min and Max.
def getRange(Min, Max):
    if Min <= 0 and Max >= 0:
        return Max+abs(Min)
    elif Min <= 0 and Max <= 0:
        return abs(Min-Max)
    elif Max >= 0 and Min >= 0:
        return Max-Min
# END: getRange




########################
# BEGIN: hexInvert(Hstr)
# FUNC:hexInvert():2008.012
def hexInvert(Hstr):
    Value = ""
    for Digit in Hstr:
        if Digit == "0":
            Value = Value+"F"
            continue
        if Digit == "1":
            Value = Value+"E"
            continue
        if Digit == "2":
            Value = Value+"D"
            continue
        if Digit == "3":
            Value = Value+"C"
            continue
        if Digit == "4":
            Value = Value+"B"
            continue
        if Digit == "5":
            Value = Value+"A"
            continue
        if Digit == "6":
            Value = Value+"9"
            continue
        if Digit == "7":
            Value = Value+"8"
            continue
        if Digit == "8":
            Value = Value+"7"
            continue
        if Digit == "9":
            Value = Value+"6"
            continue
        if Digit == "A":
            Value = Value+"5"
            continue
        if Digit == "B":
            Value = Value+"4"
            continue
        if Digit == "C":
            Value = Value+"3"
            continue
        if Digit == "D":
            Value = Value+"2"
            continue
        if Digit == "E":
            Value = Value+"1"
            continue
        if Digit == "F":
            Value = Value+"0"
            continue
    return Value
# END: hexInvert




#################
# BEGIN: intt(In)
# LIB:intt():2009.102
#   Handles all of the annoying shortfalls of the int() function (vs C).
def intt(In):
    In = str(In).strip()
    if In == "":
        return 0
# Let the system try it first.
    try:
        return int(In)
    except ValueError:
        Number = ""
        for c in In:
            if c.isdigit():
                Number += c
            elif Number == "" and (c == "-" or c == "+"):
                Number += c
            elif c == ",":
                continue
            else:
                break
        try:
            return int(Number)
        except ValueError:
            return 0
# END: intt




##################################
# BEGIN: isgoodCALS(VarSet, Which)
# FUNC:isgoodCALS():2009.100
def isgoodCALS(VarSet, Which):
    try:
        Value = float(eval("%sAmplitudeVar"%VarSet).get())
        if Value < .01 or Value > 4.00:
            setMsg(VarSet, "RW", \
                    "The signal voltage must be .01 to 3.75 volts.", 2)
            return False
    except ValueError:
        setMsg(VarSet, "RW", "The signal voltage must be a number.", 2)
        return False
    eval("%sAmplitudeVar"%VarSet).set("%.2f"%Value)
# The user doesn't get to control anything else for the other signal types.
    if Which != "SINE" and Which != "STEP" and Which != "NOIS":
        return True
    try:
        Value = int(eval("%sDurationVar"%VarSet).get())
        if Value < 1 or Value > 500:
            setMsg(VarSet, "RW", "The duration must be 1 to 500 seconds.", 2)
            return False
    except ValueError:
        setMsg(VarSet, "RW", "The duration must be an integer.", 2)
        return False
    try:
        Value = int(eval("%sStepIntervalVar"%VarSet).get())
        if Value < 1 or Value > 250:
            setMsg(VarSet, "RW", \
                    "The step interval must be 1 to 250 seconds.", 2)
            return False
    except ValueError:
        setMsg(VarSet, "RW", "The step interval must be an integer.", 2)
        return False
    try:
        Value = int(eval("%sStepWidthVar"%VarSet).get())
        if Value < 1 or Value > 250:
            setMsg(VarSet, "RW", "The step width must be 1 to 250 seconds.", 2)
            return False
    except ValueError:
        setMsg(VarSet, "RW", "The step width must be an integer.", 2)
        return False
    return True
# END: isgoodCALS




#############################
# BEGIN: isItOKToStart(Which)
# FUNC:isItOKToStart():2009.314
#   Which = 0 = just checks to see if another action is already running
#           1 = one and only one DAS can be selected
#           2 = one or more selected, but ignores 0000 button
#           3 = uses 0000 button
#   Returns True if it is OK to continue, False if not.
def isItOKToStart(Which):
    if WorkState != 0:
        msgLn(0, "R", "Another action is already running.", True, 2)
        return False, []
# For functions that are only checking to see if something else is running.
    if Which == 0:
        return True, []
# Do this just to get the cursor out of any of the text fields when a command
# is invoked.
    Root.focus_set()
    ListOfDASs = formSTATGetIDs(0)
    HowManySelected = len(ListOfDASs)
    EnumeratedDASs = formSTATGetIDs(2)
    HowManyTotal = len(EnumeratedDASs)
# Must have one and only one selected in the list.
    if Which == 1:
        if HowManySelected <> 1:
            msgLn(0, "R", "Enumerate or select only one DAS.", True, 2)
            return False, []
# May have more than one selected, but ignores the 0000 state.
    elif Which == 2:
        if HowManySelected == 0:
            msgLn(0, "R", "Enumerate or select one or more DASs.", True, 2)
            return False, []
# Uses the 0000 state.
    elif Which == 3:
        if OPTPref0000CVar.get() == 0:
            if HowManySelected == 0:
                msgLn(0, "R", \
          "Enumerate, select a DAS, or check the 0000 Pref checkbutton.", \
                        True, 2)
                return False, []
        elif OPTPref0000CVar.get() == 1:
            if HowManySelected == 0 or HowManySelected == HowManyTotal:
                ListOfDASs = ["0000"]
    return True, ListOfDASs
# END: isItOKToStart




#####################
# BEGIN: isLeap(YYYY)
# LIB:isLeap():2007.015
def isLeap(YYYY):
    if YYYY%4 != 0:
        return 0
    elif YYYY%100 != 0 or YYYY%400 == 0:
        return 1
    else:
        return 0
# END: isLeap




################################
# BEGIN: isPROGRunning(WhereMsg)
# FUNC:isPROGRunning():2008.012
#   Just a dummy function for some of the library functions.
def isPROGRunning(WhereMsg):
    return False
# END: isPROGRunning




########################################################################
# BEGIN: labelEntry(Sub, Format, LabTx, LabTTTx, Var, Max, Flags = None,
#                VarSet = None, Bar = False)
# LIB:labelEntry():2010.126
#   For making simple  Label(): Entry() pairs
#   Format: 10 = Aligned LEFT-RIGHT, entry field is disabled
#           11 = Aligned LEFT-RIGHT, entry field is normal
#           12 = Aligned LEFT-RIGHT, entry field dimmed, but normal
#           20 = Aligned TOP-BOTTOM, entry field disabled
#           21 = Aligned TOP-BOTTOM, entry field is normal
#    LabTx = the text of the label. No LabTx, no label
#  LabTTTx = The text of the label's tooltip. No LabTTTx, no tooltip
#      Var = StringVar for the Entry or Text field
#      Max = an integer or an Fw{} key for the width of the entry field
#    Flags = Flags for chkKey()
#            None = don't set up chkKey() call
#   VarSet = Txt{} key and/or XBarSVar X for chkKey
#      Bar = False = no change bar fiddling
#            True = fiddle
def labelEntry(Sub, Format, LabTx, LabTTTx, Var, Max, Flags = None, \
        VarSet = None, Bar = False):
    if LabTx != "":
        Lab = Label(Sub, text = LabTx)
        if Format == 10 or Format == 11 or Format == 12:
            Lab.pack(side = LEFT)
        elif Format == 20 or Format == 21:
            Lab.pack(side = TOP)
        if LabTTTx != "":
            ToolTip(Lab, 20, LabTTTx)
    if isinstance(Max, str):
        Max = Fw[Max]
    LEnt = Entry(Sub, textvariable = Var, width = Max+1)
    if Format == 10 or Format == 11 or Format == 12:
        LEnt.pack(side = LEFT)
    elif Format == 20 or Format == 21:
        LEnt.pack(side = TOP)
    if Format == 10 or Format == 20:
        LEnt.configure(state = DISABLED, bg = Clr["D"], relief = GROOVE)
    elif Format == 12:
        LEnt.configure(bg = Clr["D"])
# This can only set up chkKey() for an Entry-type field, which makes sense
# since this IS labelENTRY().
    if Flags != None:
        LEnt.bind("<KeyRelease>", Command(chkKey, 0, Var, Max, Flags, \
                VarSet, Bar))
    return LEnt
# END: labelEntry




####################################################
# BEGIN: labelTip(Sub, LText, Side, TTWidth, TTText)
# LIB:labelTip():2006.262
#   Creates a label and assignes the passed ToolTip to it. Returns the Label()
#   widget.
def labelTip(Sub, LText, Side, TTWidth, TTText):
    Lab = Label(Sub, text = LText)
    Lab.pack(side = Side)
    ToolTip(Lab, TTWidth, TTText)
    return Lab
# END: labelTip




##########################
# BEGIN: setPROGMsgsFile()
# LIB:setPROGMsgsFile():2010.162
#   WARNING: Must call getPROGStarted() before calling setPROGMsgFile() (it
#            may use PROGSetupsDirVar if things go wrong).
#   WARNING: Must call setPROGMsgFile() before calling loadPROGMsgs() or at
#            least set the global variable PROGMsgsFile.
PROGMsgsFile = ""

def setPROGMsgsFile():
    global PROGMsgsFile
    PROGMsgsFile = ""
    StartsWith = PROGWhoAmILCVar.get()
    EndsWith = PROG_NAMELC+".msg"
    if StartsWith != "":
# Special case. Check to see if an "old style" (ccID+blah.msg) messages file
# is laying around before looking for the ccID-YYYYDDD-blah.msg style.
# If it is then use that one.
        if exists(PROGMsgsDirVar.get()+StartsWith+EndsWith):
            PROGMsgsFile = StartsWith+EndsWith
            msgLn(9, "", "Working with messages file\n   %s"% \
                    (PROGMsgsDirVar.get()+PROGMsgsFile))
            return
# If there isn't one just add the dash and look for the new style.
        StartsWith += "-"
# In case the setups file came from another machine (usually the reason).
    if exists(PROGMsgsDirVar.get()) == False:
# Hopefully PROGSetupsDirVar points to somewhere sensible.
        PROGMsgsDirVar.set(PROGSetupsDirVar.get())
    Files = listdir(PROGMsgsDirVar.get())
    Files.sort()
# Go through all of the files so we get the "latest" one (since they have been
# sorted).
    Temp = ""
    for File in Files:
        if File.endswith(EndsWith):
            if StartsWith != "":
                if File.startswith(StartsWith):
                    Temp = File
# If the user didn't enter anything then these are the only two acceptable
# possibilities.
            elif rtnPattern(File).startswith("0000000-"):
                Temp = File
            elif File == EndsWith:
                Temp = File
    if Temp == "":
        if StartsWith != "":
            PROGMsgsFile = StartsWith
        PROGMsgsFile += (getGMT(1)[:7]+"-"+EndsWith)
    else:
        PROGMsgsFile = Temp
# If this file doesn't exist just create an empty one so there will be
# something for the program to find next time it is started on the off chance
# that nothing gets written to it this time around.
    if exists(PROGMsgsDirVar.get()+PROGMsgsFile) == False:
        try:
            Fp = open(PROGMsgsDirVar.get()+PROGMsgsFile, "wb")
            Fp.close()
        except Exception, e:
            msgLn(9, "MW", "Error creating messages file\n   %s\n   %s"% \
                    ((PROGMsgsDirVar.get()+PROGMsgsFile), e), True, 3)
    msgLn(9, "", "Working with messages file\n   %s"%(PROGMsgsDirVar.get()+ \
            PROGMsgsFile))
    return
###############################################
# BEGIN: loadPROGMsgs(Speak = True, Ask = True)
# FUNC:loadPROGMsgs():2010.162
def loadPROGMsgs(Speak = True, Ask = True):
    try:
        if exists(PROGMsgsDirVar.get()+PROGMsgsFile):
            Fp = open(PROGMsgsDirVar.get()+PROGMsgsFile, "r")
            Lines = readFileLines(Fp)
            Fp.close()
# An empty messages file may get created before coming here.
            if len(Lines) != 0:
                if Ask == True:
                    Answer = formMYD(Root, (("(Yes)", LEFT, "yes"), ("No", \
                            LEFT, "no")), "no", "", "Load It?", \
                            "There already is a messages file named\n\n%s\n\nNumber of lines: %d\n\nThis file will be used for the messages. Do you want to load its current contents into the messages section?"% \
                            (PROGMsgsFile, len(Lines)))
                else:
                    Answer = "yes"
                if Answer == "yes":
# Write directly to the messages section rather than use msgLn. It's much
# faster.
                    for Line in Lines:
                        MMsg.insert(END, Line+"\n")
                    MMsg.see(END)
        if Speak == True:
            writeFile(0, "MSG", "==== "+PROG_NAME+" "+PROG_VERSION+ \
                    " started "+getGMT(0)+" ====\n")
    except Exception, e:
# Don't write this to the messages file since we can't get it open.
        msgLn(9, "M", "Error opening/reading "+PROGMsgsFile, True, 3)
        msgLn(9, "M", "   "+str(e))
        msgLn(9, "M", "This should be fixed before continuing.")
    return
# END: setPROGMsgsFile




####################
# BEGIN: loopDelay()
# FUNC:loopDelay():2008.012
def loopDelay():
    global WorkState
# Don't even think about it
    if WorkState == 999 or LoopRVar.get() == "off":
        return
# Sleep for 1/4sec, check, repeat. The Delay is 4x because of the 1/4sec cycle
    for i in xrange(0, intt(LoopRVar.get())*4):
        sleep(0.25)
        updateMe(0)
# Jump out as soon as someone wants to
        if WorkState == 999 or LoopRVar.get() == "off":
            break
    return
# END: loopDelay




#################################################################
# BEGIN: makeIP(Format, DASID, IDType, Count, IP1, IP2, IP3, IP4)
# FUNC:makeIP():2008.012
#   Passes back an IP address based on the inputs. IPV4 only.
#   Format = 1: The last two tuples are filled in by using the DAS ID
#            2: The passed IP is "incremented" by Count.
#            3: The passed tuple values are just combined as is.
#   Any blank tuples are given the value of 0.
#   IDType = 16: The DASID is a hex number (Reftek RT130s)
#            10: The DASID is a decimal number (just about everything else)
def makeIP(Format, DASID, IDType, Count, IP1, IP2, IP3, IP4):
    OutIP = ""
    if Format == 1:
        if IDType == 16:
            OutIP = IP1.strip()+"."+IP2.strip()+"."+ \
                    "%d."%int(DASID[0:2], 16)+ \
                    "%d"%int(DASID[2:5], 16)
        elif IDType == 10:
            OutIP = IP1.strip()+"."+IP2.strip()+"."+ \
                    "%d."%int(intt(DASID)/256)+ \
                    "%d"%int(intt(DASID)%256)
    elif Format == 2:
# Build an IP based on what we have, then split it apart, do the math, and
# recombine
        for i in xrange(1, 1+4):
            if eval("IP%d"%i).strip() == "":
                OutIP = OutIP+"0."
            else:
                OutIP = OutIP+eval("IP%d"%i).strip()+"."
        Tups = OutIP[:len(OutIP)-1].split(".")
        ITups = []
        for S in Tups:
            ITups.append(int(S))
        ITups[3] += Count
# Carry any 1 through the tuples
        for i in (3,2,1):
           if ITups[i] > 255:
                ITups[i] -= 256
                ITups[(i-1)] += 1
        if ITups[0] > 255:
            OutIP = ""
        else:
            OutIP = "%d.%d.%d.%d"%(ITups[0], ITups[1], ITups[2], ITups[3])
    elif Format == 3:
        for i in xrange(1, 1+4):
            if eval("IP%d"%i).strip() == "":
                OutIP = OutIP+"0."
            else:
                OutIP = OutIP+eval("IP%d"%i).strip()+"."
        return OutIP[:len(OutIP)-1]
    return OutIP
# END: makeIP




###############################
# BEGIN: messageEntry(e = None)
# LIB:messageEntry():2010.140
PROGMessageEntryVar = StringVar()
PROGSetups += ("PROGMessageEntryVar", )

def messageEntry(e = None):
    Message = PROGMessageEntryVar.get().strip()
# Don't change the focus or erase what the user entered since they may want to
# do something like make multiple similar entries in one sitting. Add the day
# and time by default so all of the messages can be extracted and looked at in
# time order from a whole experiment.
    if Message != "":
        msgLn(0, "", "USER: "+getGMT(0)[5:-3]+": "+Message.strip())
    else:
        beep(1)
    return
############################
# BEGIN: messageEntryClear()
# FUNC:messageEntryClear():2008.066
def messageEntryClear():
    PROGMessageEntryVar.set("")
# We'll assume the next thing the user will want to do is type something in.
    Ent["MM"].focus_set()
    return
# END: messageEntry




##########################################################################
# BEGIN: msgLn(Open, Color, What, Newline = True, Bell = 0, Update = True)
# LIB:msgLn():2010.066
#   Open is passed on to writeLine():
#      0 = close the messages file after writing the line
#      1 = leave the file open after writing the line (there's more to come)
#      9 = don't write anything to the messages file, just to the display
#
#   Instead of opening, writing, and closing the .msg file for everything
#   written to the messages section, just build everything in MSGLNLast,
#   and write to the file (via writeFile) only whole lines.
#   Requires MSGLNAlwaysScroll to be set.
#       True = Always scroll the messages section.
#       False = Only scroll when the scrollbar is all of the way "down".
MSGLNAlwaysScroll = False
MSGLNLast = ""

def msgLn(Open, Color, What, Newline = True, Bell = 0, Update = True):
    global MSGLNLast
    if Color == "" and What == "" and Newline == False and Bell == 0 and \
            Update == False:
        MMsg.delete(0.0, END)
        MMsg.tag_delete(*MMsg.tag_names())
        MMsg.update()
        MSGLNLast = ""
        return
    if Color != "":
# This mouthful keeps user mouse clicks in the messages section from screwing
# up the tag indexes. END always points to the "next" line so we have to back
# that up one to get the "current" line which INSERT (which used to be used)
# doesn't always point to if the user has clicked somewhere in the Text widget
# (which I thought was covered by the value in CURSOR).
        IdxS = MMsg.index(str(intt(MMsg.index(END))-1)+".end")
# The Color[0] allows us to pass BgFg Color values like "YB" without incident.
        MMsg.tag_config(IdxS, foreground = Clr[Color[0]])
        MMsg.insert(END, What, IdxS)
        MSGLNLast += What
    else:
        MMsg.insert(END, What)
        MSGLNLast += What
    if Newline == True:
        MMsg.insert(END, "\n")
        if Open != 9:
            writeFile(Open, "MSG", MSGLNLast+"\n")
        MSGLNLast = ""
    if Newline == True:
# Always scroll on a newline.
        if MSGLNAlwaysScroll == True:
            MMsg.see(END)
# Only scroll when the scroll bar is at the bottom.
        elif MMVSb.get()[1] == 1.0:
            MMsg.see(END)
# Instead of updating everything.
    if Update == True:
        MMsg.update()
    if Bell != 0:
        beep(Bell)
    return
# END: msgLn




###################################
# BEGIN: monitorDo(DAS, d, c, Data)
# FUNC:monitorDo():2009.315
#   Gets called once for each DS/Channel.
def monitorDo(DAS, d, c, Data):
    global WorkState
    if WorkState == 999:
# There is no message. The caller will catch this.
        return (0, )
    if OPTSummaryModeCVar.get() == 0:
        msgLn(1, "W", "      Monitoring channel %d..."%c)
# Send the command to start the DAS recording.
    Cmd = rt130CmdFormat(DAS, "DM"+" "+str(d)+padR(str(c), 2)+"DM")
    writePort(DAS, Cmd)
# It takes at least this long before the data starts coming back.
    delay(8)
    if WorkState == 999:
        return (0, )
    GotAllData = False
    DataPoints = []
# We'll give the DAS 20x3sec to send all of the data.
    Chances = 0
    if OPTSummaryModeCVar.get() == 0:
        msgLn(1, "", "         Waiting for data...")
# Delay is 0.0 below so reading the 8 or so sentences of monitor data will be
# quick (all 8 started coming in very quickly beginning with the 2.3.0 version
# of the RT130 firmware -- in fact all communications sped up with that
# version).
    while 1:
        Rp = rt130GetRp(0, 3, 0)
        if Rp == "":
            Chances += 1
# Keep the user calm if something should go wrong.
            if Chances%3 == 0:
                msgLn(1, "", "         Waiting...")
            if Chances == 7:
                msgLn(1, "", "         I feel like I'm in Casablanca...")
            if Chances == 10:
                break
            else:
                continue
        if checkRp(DAS, Rp) == False:
            WorkState = 999
            break
# At this point we should have a complete line so step through it and pick out
# the data points.
        DigPS = int(Rp[12:12+1])
        Samples = int(Rp[20:20+2], 16)
        Range = 1
        if DigPS == 4:
            Range = pow(2, 16)
        elif DigPS == 6:
            Range = pow(2, 24)
        elif DigPS == 8:
            Range = pow(2, 32)
        HRange = Range/2
#TESTING        for dp in range(22, 22+Samples*DigPS, DigPS):
        for dp in xrange(22, 22+Samples*DigPS, DigPS):
# TESTING - 2004AUG03
# I think that static may have caused one of the data lines to be too short
# and it tried to interpret the ending "DM" and the CRC as a data point.
# long() didn't like that. We'll try to trap that condition here and see
# what is going on.
            try:
                Value = long(Rp[dp:dp+DigPS], 16)
            except ValueError:
                msgLn(1, "R", "Data error!", True, 2)
                msgLn(1, "R", \
                      "DigPS %d  Samples %d  Range %f"%(DigPS, Samples, Range))
                msgLn(1, "R", \
                      "dp %s length %d"%(Rp[dp:dp+DigPS], len(Rp)))
                break
            if Value > HRange:
                Value = Value-Range
            DataPoints.append(Value)
# If we have received and processed all of the response packets then jump out.
        if int(Rp[16:16+1]) == int(Rp[17:17+1]):
            GotAllData = True
            break
    if GotAllData == True:
        Data.append([DAS, d, c, DataPoints])
        return (0, )
    else:
        return (1, "M", "Failed to get all of the monitor data!", 3)
# END: monitorDo




#########################
# BEGIN: mrDash(Incoming)
# FUNC:mrDash():2008.012
#   Inserts a dash character in any blank spot.
def mrDash(Incoming):
    Outgoing = ""
    for C in Incoming:
        if C == " ":
            Outgoing = Outgoing+"-"
        else:
            Outgoing = Outgoing+C
    return Outgoing
# END: mrDash




#######################
# BEGIN: notYet(Parent)
# LIB:notYet():2009.162
def notYet(Parent):
   formMYD(Parent, (("(OK)", LEFT, "ok"), ), "ok", "", "Coming Someday?", \
       "This feature is not yet available.", "", 1)
   return
# END: notYet




######################
# BEGIN: openCmdPort()
# FUNC:openCmdPort():2009.315
#   Just gets the port open using the global CmdPort.
def openCmdPort():
    global CmdPort
    try:
        CmdPort = Serial(port = CmdPortVar.get(),
                baudrate = 9600,
                bytesize = EIGHTBITS,
                parity = PARITY_NONE,
                stopbits = STOPBITS_ONE,
                timeout = 0,
                xonxoff = 0,
                rtscts = 0)
        CmdPortLab.config(bg = "green")
        CmdPortLab.update()
# TESTING - is this needed? opening takes long enough just by itself.
# The port just takes longer to get set up and ready on Macs. Don't know why.
#        if PROGSystem == "dar":
#            sleep(.25)
    except Exception, e:
        if CmdPortVar.get() != "":
            msgLn(1, "R", "Error opening command port '%s'."% \
                    CmdPortVar.get(), True, 2)
            msgLn(0, "R", "   "+str(e))
        else:
            msgLn(0, "R", "No Command Port device has been entered.", True, 2)
        return False
    return True
# END: openCmdPort




############################
# BEGIN: padR(What, Howmuch)
# LIB:padR():2008.012
#    A little different than using ljust().
def padR(What, Howmuch):
    return "%-*.*s"%(Howmuch, Howmuch, What)
# END: padR




##########################################
# BEGIN: popDirDevice(Var, Title, e= None)
# FUNC:popDirDevice():2010.194
def popDirDevice(Var, Title, e = None):
    Xx = Root.winfo_pointerx()
    Yy = Root.winfo_pointery()
    PMenu = Menu(Root, tearoff = 0, bg = Clr["D"])
    PMenu.add_command(label = "Select A Device...", \
            command = Command(popDirDeviceCmd, Var, Title))
    PMenu.tk_popup(Xx, Yy)
    return
####################################
# BEGIN: popDirDeviceCmd(Var, Title)
# FUNC:popDirDeviceCmd():2010.194
def popDirDeviceCmd(Var, Title):
    Dir = sep+"dev"+sep
    Device = formMYDF(Root, 0, Title, Dir, "")
# Set it even if the return is blank.
    Var.set(Device)
    return
# END: popDirDevice




################################################
# BEGIN: popDirFID(Parent, Which, Var, e = None)
# LIB:popDirFID():2010.162
#   Provides a popup menu for things to use to set their associated Var to the
#   value of the "main" directory vars or the main FID var.
#   Which can be something like "self work" to get more than one menu item.
#   Usage:
#     Thing.bind("<Button-3>", Command(popDir, "<form>", "<Which>", Var))
#
#   Not all of these will be used by all programs.
def popDirFID(Parent, Which, Var, e = None):
    Xx = Root.winfo_pointerx()
    Yy = Root.winfo_pointery()
    if isinstance(Parent, str):
# Only do this if the caller passed what we need.
        setMsg(Parent, "", "")
        Parent = Frm[Parent]
    PMenu = Menu(Parent, tearoff = 0, bg = Clr["D"])
    if Which == "thedata":
        PMenu.add_command(label = "Change The Data Directory To...", \
                command = Command(popDirFIDCmd, Parent, "thedata", Var))
        PMenu.tk_popup(Xx, Yy)
        return
    if Which == "thework":
        PMenu.add_command(label = "Change The Work Directory To...", \
                command = Command(popDirFIDCmd, Parent, "thework", Var))
        PMenu.tk_popup(Xx, Yy)
        return
    if Which == "thecut":
        PMenu.add_command(label = "Change The Cut Directory To...", \
                command = Command(popDirFIDCmd, Parent, "thecut", Var))
        PMenu.tk_popup(Xx, Yy)
        return
    if Which == "theorig":
        PMenu.add_command(label = "Change The Orig Directory To...", \
                command = Command(popDirFIDCmd, Parent, "theorig", Var))
        PMenu.tk_popup(Xx, Yy)
        return
    if Which.find("self") != -1:
        PMenu.add_command(label = "Change To Directory...", \
                command = Command(popDirFIDCmd, Parent, "self", Var))
    if Which.find("data") != -1:
        PMenu.add_command(label = "Set To Main Data Directory", \
                command = Command(popDirFIDCmd, Parent, "data", Var))
    elif Which.find("fid") != -1:
        PMenu.add_command(label = "Set To Main FID Value", \
                command = Command(popDirFIDCmd, Parent, "fid", Var))
    elif Which.find("msgs") != -1:
        PMenu.add_command(label = "Set To Main Messages Directory", \
                command = Command(popDirFIDCmd, Parent, "msgs", Var))
    elif Which.find("work") != -1:
        PMenu.add_command(label = "Set To Main Work Directory", \
                command = Command(popDirFIDCmd, Parent, "work", Var))
    elif Which.find("cut") != -1:
        PMenu.add_command(label = "Set To Main Cut Directory", \
                command = Command(popDirFIDCmd, Parent, "cut", Var))
    elif Which.find("orig") != -1:
        PMenu.add_command(label = "Set To Main Orig Directory", \
                command = Command(popDirFIDCmd, Parent, "orig", Var))
    PMenu.tk_popup(Xx, Yy)
    return
#########################################
# BEGIN: popDirFIDCmd(Parent, Which, Var)
# FUNC:popDirFIDCmd():2010.162
def popDirFIDCmd(Parent, Which, Var):
    if Which == "thedata":
        changeDirsCmd(Parent, "data", 1, Var)
        return
    if Which == "thework":
        changeDirsCmd(Parent, "work", 1, Var)
        return
    if Which == "thecut":
        changeDirsCmd(Parent, "cut", 1, Var)
        return
    if Which == "theorig":
        changeDirsCmd(Parent, "orig", 1, Var)
        return
    if Which == "self":
        Filespec = formMYDF(Parent, 1, "Pick A Directory", \
                dirname(Var.get()), "")
        if Filespec != "":
            Var.set(Filespec)
        return
    if Which == "data":
        Var.set(PROGDataDirVar.get())
    elif Which == "fid":
        Var.set(PROGFileIDVar.get())
    elif Which == "msgs":
        Var.set(PROGMsgsDirVar.get())
    elif Which == "work":
        Var.set(PROGWorkDirVar.get())
    elif Which == "cut":
        Var.set(TCUTCutDirVar.get())
    elif Which == "orig":
        Var.set(CLTRDOrigDirVar.get())
    return
# END: popDirFID




##########################
# BEGIN: progQuitter(Save)
# FUNC:progQuitter():2010.140
def progQuitter(Save):
    writeFile(0, "MSG", "==== Program stopped "+getGMT(0)+" ====\n")
    if Save == True:
        savePROGSetups()
    exit()
# END: progQuitter




################################################
# BEGIN: readFileLines(Fp, Strip = False, N = 0)
# LIB:readFileLines():2009.290
#   Reads the passed file and determines how to split the lines which may end
#   differently depending on which operating system the file was written by.
def readFileLines(Fp, Strip = False, N = 0):
    if N == 0:
        RawLines = Fp.readlines()
    else:
        RawLines = Fp.readlines(N)
    Lines = []
# In case the file was empty.
    try:
# The order is important: \r\n  then  \r  then  \n.
        if RawLines[0].find("\r\n") != -1:
            Count = RawLines[0].count("\r\n")
# If there is only one \r\n (presumably at the end of the line) then the OS
# must have split the file up correctly. In that case just run the map() and
# clean off the ends of the lines.
            if Count == 1:
                if Strip == False:
                    Lines += map(rstrip, RawLines)
                else:
                    Lines += map(strip, RawLines)
# If there is more than one \r\n in the string then it could mean that all of
# the file lines are all jammed together into one long string. In that case
# split the line up first then add the parts to Lines, but leave off the
# "extra" blank line ([:-1]) that the split() will produce.
            else:
                for Line in RawLines:
                    Parts = Line.split("\r\n")
                    if Strip == False:
                        Lines += Parts[:-1]
                    else:
                        Lines += map(strip, Parts[:-1])
# Same as \r\n.
        elif RawLines[0].find("\r") != -1:
            Count = RawLines[0].count("\r")
            if Count == 1:
                if Strip == False:
                    Lines += map(rstrip, RawLines)
                else:
                    Lines += map(strip, RawLines)
            else:
                for Line in RawLines:
                    Parts = Line.split("\r")
                    if Strip == False:
                        Lines += Parts[:-1]
                    else:
                        Lines += map(strip, Parts[:-1])
# Same as \r.
        elif RawLines[0].find("\n") != -1:
            Count = RawLines[0].count("\n")
            if Count == 1:
                if Strip == False:
                    Lines += map(rstrip, RawLines)
                else:
                    Lines += map(strip, RawLines)
            else:
                for Line in RawLines:
                    Parts = Line.split("\n")
                    if Strip == False:
                        Lines += Parts[:-1]
                    else:
                        Lines += map(strip, Parts[:-1])
# What else can we do?
        else:
            Lines += RawLines
    except:
        pass
    return Lines
# END: readFileLines




################
# BEGIN: ready()
# LIB:ready():2007.241
def ready():
    try:
        msgLn(9, "R", "R", False)
        msgLn(9, "G", "e", False)
        msgLn(9, "Y", "a", False)
        msgLn(9, "C", "d", False)
        msgLn(9, "M", "y", False)
        msgLn(9, "", ".")
    except NameError:
        setMsg("MM", "", "Ready.")
    return
# END: ready




#####################################
# BEGIN: rt130CmdFormat(Who, CmdBody)
# LIB:rt130CmdFormat():2006.297
#   Builds a command string with the proper control characters, DAS ID, and
#   CRC. The caller must have pre-formatted the body of the command. Returns
#   a command string ready for sending to the DAS.
def rt130CmdFormat(Who, CmdBody):
    Length = len(CmdBody)+6
    ToCRC = Who+"%04d"%Length+CmdBody
    CRC = "%04X"%rt130CRCMe(ToCRC, False)
    Cmd = "%c"%0x84+"%c"%0x00+ToCRC+CRC+"%c"%0x0D+"%c"%0x0A
    return Cmd
# END: rt130CmdFormat




#################################
# BEGIN: rt130CRCMe(String, Flip)
# LIB:rt130CRCMe():2008.151
#   Returns the CRC-16/Reftek value of the passed character string.
#   Doing a lookup is faster than doing math.
crc16tab = (0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241, \
            0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440, \
            0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40, \
            0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841, \
            0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40, \
            0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41, \
            0x1400, 0xD4C1, 0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641, \
            0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040, \
            0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240, \
            0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441, \
            0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41, \
            0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840, \
            0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41, \
            0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40, \
            0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640, \
            0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041, \
            0xA001, 0x60C0, 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240, \
            0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480, 0xA441, \
            0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41, \
            0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840, \
            0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41, \
            0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40, \
            0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640, \
            0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041, \
            0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241, \
            0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440, \
            0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40, \
            0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901, 0x59C0, 0x5880, 0x9841, \
            0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40, \
            0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41, \
            0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641, \
            0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040)

def rt130CRCMe(String, Flip):
    CCRC = 0xFFFF
    for Char in String:
        Temp = CCRC^(ord(Char))
        CCRC = (CCRC >> 8)^crc16tab[(Temp & 0xFF)]
    if Flip == True:
        CCRC = (CCRC & 0x00FF)*256+(CCRC & 0xFF00)/256
    return CCRC
# END: rt130CRCMe




#######################################
# BEGIN: rt130GetRp(Delay, Tryfor, Lag)
# LIB:rt130GetRp():2009.238
#   Delay = amount to delay before beginning to try to read the port
#           (this was really only added because the Monitor command response
#            comes back in about 8 sentences, so pausing for 1 second at the
#            top of the reading loop made it take much longer to draw the
#            graphs than necessary).
#   Tryfor = trys for that many seconds to wait for a response to come back.
#   Lag = lags for that many seconds after a response has been received.
def rt130GetRp(Delay, Tryfor, Lag):
    Rp = ""
    Rp1 = ""
    if Delay != 0:
        delay(Delay)
        if WorkState == 999:
            return ""
    for i in xrange(0, Tryfor):
        Rp1 = CmdPort.readline()
        if OPTDebugCVar.get() == 1:
            print("<<<<%d "%(i+Rp1))
        Rp = Rp+Rp1
# If we have a complete sentence then leave otherwise sleep a bit and try
# again.
        if Rp != "" and ord(Rp[0]) == 0x85 and \
                ord(Rp[len(Rp)-1]) == 0x0A:
            break
        if WorkState == 999:
            return ""
        delay(1)
# If Rp has something in it, but it is not a complete sentence (i.e. we
# ran out of TryFor loop above) then pause a bit and try once more.
    if Rp != "" and ord(Rp[len(Rp)-1]) != 0x0A:
        if OPTDebugCVar.get() == 1:
            print("<<<<FU1 %s"%Rp)
        delay(2)
        Rp1 = CmdPort.readline()
        if OPTDebugCVar.get() == 1:
            print("<<<<FU2 %s"%Rp1)
        Rp = Rp+Rp1
# Most commands will want to delay some amount of time after a response (the
# DAS may still be working). This is just a nice place to do it instead of
# putting a bunch of delay() lines throughout the code.
    if Rp != "" and ord(Rp[0]) == 0x85 and ord(Rp[len(Rp)-1]) == 0x0A:
        if Lag != 0:
            delay(Lag)
    else:
# If the sentence is incomplete after all of this don't return anything.
        Rp = ""
    if OPTDebugCVar.get() == 1:
        print("<<<<%s"%Rp)
    return Rp
# END: rt130GetRp




#######################
# BEGIN: rtnPattern(In)
# LIB:rtnPattern():2006.113
def rtnPattern(In):
    Rtn = ""
    for c in In:
        if c.isdigit():
            Rtn += "0"
        elif c.isupper():
            Rtn += "A"
        elif c.islower():
            Rtn += "a"
        else:
            Rtn += c
    return Rtn
# END: rtnPattern




####################################################
# BEGIN: sendChanParms(DAS, Ch, Name, Gain, Comment)
# FUNC:sendChanParms():2009.315
def sendChanParms(DAS, Ch, Name, Gain, Comment):
    global WorkState
# If the gain is not set then just return. This channel has not been
# "activated".
    if Gain.get() == 0:
        return True
    if OPTSummaryModeCVar.get() == 0:
        msgLn(1, "C", "   Channel %d..."%Ch)
    Cmd = rt130CmdFormat(DAS, "PC"+padR("%d"%Ch, 2)+padR(Name.get(), 10)+ \
            padR("", 58)+padR(str(Gain.get()), 4)+padR("", 24)+ \
            padR(Comment.get(), 40)+"PC")
    writePort(DAS, Cmd)
    if DAS == "0000":
        delay(3)
        if WorkState == 999:
            return False
    else:
        Rp = rt130GetRp(1, 5, 2)
        if Rp == "":
            msgLn(1, "M", "   No Channel %d Parameters command response!"%Ch, \
                    True, 3)
            return False
        if checkRp(DAS, Rp) == False:
            WorkState = 999
            return False
    return True
# END: sendChanParms




############################
# BEGIN: sendDSParms(DAS, d)
# FUNC:sendDSParms():2009.315
def sendDSParms(DAS, d):
    global WorkState
# If the trigger type is set to Not Used we will consider the data stream.
# to not be "active"
    if eval("PDS%dTType"%d).get() == 0:
        return True
    if OPTSummaryModeCVar.get() == 0:
        msgLn(1, "C", "   Data stream %d..."%d)
# Get everything ready for the rt130CmdFormat call.
    Dest = ""
    for s in ("Ram", "Disk", "Ether", "Serial"):
        if eval("PDS%d%s"%(d,s)).get() != 0:
            Dest = Dest+"Y"
        else:
            Dest = Dest+" "
    Chans = ""
    for c in xrange(1, 1+6):
        if eval("PDS%dChan%d"%(d,c)).get() != 0:
            Chans = Chans+"Y"
        else:
            Chans = Chans+" "
    Form = eval("PDS%dFormat"%d).get()
# This should never happen since the checkbuttons get checked.
    if Form == "":
        Form = "  "
# This part of the command is common to all trigger types.
    Cmd = "PD"+padR("%d"%d, 2)+padR(eval("PDS%dName"%d).get(), 16)+ \
            Dest+padR("", 4)+padR(Chans, 16)+ \
            padR(eval("PDS%dSampRate"%d).get(), 4)+Form
# Add on the parts of the command for each trigger type.
# CON
    if eval("PDS%dTType"%d).get() == 1:
        Cmd = Cmd+padR("CON", 4)+padR(eval("PDS%dRl"%d).get(), 8)+ \
                padR(eval("PDS%dStart1"%d).get(), 14)+padR("", 140)
# CRS
    elif eval("PDS%dTType"%d).get() == 2:
        Cmd = Cmd+padR("CRS", 4)+padR("%d"%eval("PDS%dTStrm"%d).get(), 2)+ \
                padR(eval("PDS%dPretl"%d).get(), 8)+ \
                padR(eval("PDS%dRl"%d).get(), 8)+padR("", 144)
# EVT
    elif eval("PDS%dTType"%d).get() == 3:
        TChans = ""
        for c in xrange(1, 1+6):
            if eval("PDS%dTChan%d"%(d,c)).get() != 0:
                TChans = TChans+"Y"
            else:
                TChans = TChans+" "
        LP = ""
        if eval("PDS%dLPFreq"%d).get() == 0:
            LP = "OFF"
        elif eval("PDS%dLPFreq"%d).get() == 1:
            LP = "0"
        elif eval("PDS%dLPFreq"%d).get() == 2:
            LP = "12"
        HP = ""
        if eval("PDS%dHPFreq"%d).get() == 0:
            HP = "OFF"
        elif eval("PDS%dHPFreq"%d).get() == 1:
            HP = "0"
        elif eval("PDS%dHPFreq"%d).get() == 2:
            HP = "0.1"
        elif eval("PDS%dHPFreq"%d).get() == 3:
            HP = "2"
        Holdv = ""
        if eval("PDS%dHold"%d).get() == 0:
            Holdv = "OFF"
        else:
            Holdv = "ON"
        Cmd = Cmd+padR("EVT", 4)+ \
                padR(TChans, 16)+padR(eval("PDS%dMc"%d).get(), 2)+ \
                padR(eval("PDS%dTwin"%d).get(), 8)+ \
                padR(eval("PDS%dPretl"%d).get(), 8)+ \
                padR(eval("PDS%dPostl"%d).get(), 8)+ \
                padR(eval("PDS%dRl"%d).get(), 8)+padR("", 8)+ \
                padR(eval("PDS%dSta"%d).get(), 8)+ \
                padR(eval("PDS%dLta"%d).get(), 8)+padR("", 8)+ \
                padR(eval("PDS%dTr"%d).get(), 8)+ \
                padR(eval("PDS%dDtr"%d).get(), 8)+padR(Holdv, 4)+ \
                padR(LP, 4)+padR(HP, 4)+padR("", 52)
# EXT
    elif eval("PDS%dTType"%d).get() == 4:
        Cmd = Cmd+padR("EXT", 4)+ \
                padR(eval("PDS%dPretl"%d).get(), 8)+ \
                padR(eval("PDS%dRl"%d).get(), 8)+padR("", 146)
# LEV
    elif eval("PDS%dTType"%d).get() == 5:
        LP = ""
        if eval("PDS%dLPFreq"%d).get() == 0:
            LP = "OFF"
        elif eval("PDS%dLPFreq"%d).get() == 1:
            LP = "0"
        elif eval("PDS%dLPFreq"%d).get() == 2:
            LP = "12"
        HP = ""
        if eval("PDS%dHPFreq"%d).get() == 0:
            HP = "OFF"
        elif eval("PDS%dHPFreq"%d).get() == 1:
            HP = "0"
        elif eval("PDS%dHPFreq"%d).get() == 2:
            HP = "0.1"
        elif eval("PDS%dHPFreq"%d).get() == 3:
            HP = "2"
        Cmd = Cmd+padR("LEV", 4)+padR(eval("PDS%dTlvl"%d).get(), 8)+ \
                padR(eval("PDS%dPretl"%d).get(), 8)+ \
                padR(eval("PDS%dRl"%d).get(), 8)+ \
                padR(LP, 4)+padR(HP, 4)+padR("", 130)
# TIM
    elif eval("PDS%dTType"%d).get() == 6:
        Cmd = Cmd+padR("TIM", 4)+ \
                padR(eval("PDS%dStart1"%d).get(), 14)+ \
                padR(eval("PDS%dRepInt"%d).get(), 8)+ \
                padR(eval("PDS%dNumTrig"%d).get(), 4)+ \
                padR("", 8)+padR(eval("PDS%dRl"%d).get(), 8)+padR("", 120)
# TML
    elif eval("PDS%dTType"%d).get() == 7:
        Cmd = Cmd+padR("TML", 4)+ \
                padR(eval("PDS%dStart1"%d).get(), 14)+ \
                padR(eval("PDS%dStart2"%d).get(), 14)+ \
                padR(eval("PDS%dStart3"%d).get(), 14)+ \
                padR(eval("PDS%dStart4"%d).get(), 14)+ \
                padR(eval("PDS%dStart5"%d).get(), 14)+ \
                padR(eval("PDS%dStart6"%d).get(), 14)+ \
                padR(eval("PDS%dStart7"%d).get(), 14)+ \
                padR(eval("PDS%dStart8"%d).get(), 14)+ \
                padR(eval("PDS%dStart9"%d).get(), 14)+ \
                padR(eval("PDS%dStart10"%d).get(), 14)+ \
                padR(eval("PDS%dStart11"%d).get(), 14)+ \
                padR(eval("PDS%dRl"%d).get(), 8)
# VOT
    elif eval("PDS%dTType"%d).get() == 8:
        pass
# The last bit.
    Cmd = Cmd+"PD"
    Cmd = rt130CmdFormat(DAS, Cmd)
    writePort(DAS, Cmd)
    if DAS == "0000":
        delay(3)
        if WorkState == 999:
            return False
    else:
        Rp = rt130GetRp(1, 5, 2)
        if Rp == "":
            msgLn(1, "M", \
                    "   No Data Stream %d Parameters command response!"%d, \
                    True, 3)
            return False
        if checkRp(DAS, Rp) == False:
            WorkState = 999
            return False
    return True
# END: sendDSParms




##############################################################
# BEGIN: setMsg(WhichMsg, Colors, Message, Beep = 0, e = None)
# LIB:setMsg():2008.269
def setMsg(WhichMsg, Colors, Message, Beep = 0, e = None):
# So callers don't have to always be checking for this.
    if WhichMsg == None:
        return
# This might get called when a window is not, or never has been up so try.
    try:
        if isinstance(WhichMsg, str):
            LMsg = Msg[WhichMsg]
        else:
            LMsg = WhichMsg
        LMsg.configure(state = NORMAL)
        LMsg.delete(0.0, END)
        if Colors == "":
            LMsg.configure(bg = Clr["W"], fg = Clr["B"])
        else:
            LMsg.configure(bg = Clr[Colors[0]], fg = Clr[Colors[1]])
        LMsg.insert(END, Message)
        LMsg.update()
        LMsg.configure(state = DISABLED)
# This may get called from a generated event with no Beep value set.
        if isinstance(Beep, int) and Beep > 0:
            beep(Beep)
        updateMe(0)
    except (KeyError, TclError):
        pass
    return
# END: setMsg




#####################
# BEGIN: showUp(Fram)
# LIB:showUp():2010.177
def showUp(Fram):
# If anything should go wrong just close the form and let the caller fix it
# (i.e. redraw it).
    try:
        if Frm[Fram] != None:
            Frm[Fram].deiconify()
            Frm[Fram].lift()
            return True
    except TclError:
# This call makes sure that the Frm[] value gets set to None.
        closeForm(Fram)
    return False
########################
# BEGIN: showForms(Fram)
# FUNC:showWindows():2010.177
#   A simple way for the program to implement an OSX Windows-like menu item.
def showForms(Fram):
    if showUp(Fram) == False:
        beep(1)
    return
# END: showUp




##################################
# BEGIN: stoppedMe(WorkState, DAS)
# FUNC:stoppedMe():2009.315
def stoppedMe(WorkState, DAS):
    if WorkState == 999:
        msgLn(0, "Y", "Stopped.")
    else:
        if DAS == "0000":
            msgLn(0, "", "Commands sent.")
        else:
            msgLn(0, "", "Done.")
            if OPTDoneBeepCVar.get() != 0:
                beep(1)
    return
# END: stoppedMe




######################
# BEGIN: class ToolTip
# LIB:ToolTip():2009.179
#   Add tooltips to objects.
#   Usage: ToolTip(obj, Len, "text")
#   Nice and clever.
class ToolTipBase:
    def __init__(self, button):
        self.button = button
        self.tipwindow = None
        self.id = None
        self.x = self.y = 0
        self._id1 = self.button.bind("<Enter>", self.enter)
        self._id2 = self.button.bind("<Leave>", self.leave)
        self._id3 = self.button.bind("<ButtonPress>", self.leave)
        return
    def enter(self, event = None):
        self.schedule()
        return
    def leave(self, event = None):
        self.unschedule()
        self.hidetip()
        return
    def schedule(self):
        self.unschedule()
        self.id = self.button.after(500, self.showtip)
        return
    def unschedule(self):
        id = self.id
        self.id = None
        if id:
            self.button.after_cancel(id)
        return
    def showtip(self):
        if self.tipwindow:
            return
# The tip window must be completely clear of the mouse pointer so offset the
# x and y a little. This is all in a try because I started getting TclErrors
# to the effect that the window no longer existed by the time the geometry and
# deiconify functions were reached after adding the 'keep the tooltip off the
# edge of the display' stuff. I think this additional stuff was adding enough
# time to the whole process that it would get caught trying to bring up a tip
# that was no longer needed as the user quickly moved the pointer around the
# display.
        try:
            self.tipwindow = tw = Toplevel(self.button)
            tw.withdraw()
            tw.wm_overrideredirect(1)
            self.showcontents()
            x = self.button.winfo_pointerx()
            y = self.button.winfo_pointery()
# After much trial and error...keep the tooltip away from the right edge of the
# screen and the bottom of the screen.
            tw.update()
            if x+tw.winfo_reqwidth()+5 > Root.winfo_screenwidth():
                x -= (tw.winfo_reqwidth()+5)
            else:
                x += 5
            if y+tw.winfo_reqheight()+5 > Root.winfo_screenheight():
                y -= (tw.winfo_reqheight()+5)
            else:
                y += 5
            tw.wm_geometry("+%d+%d" % (x, y))
# If you do a tw.lift() along with the deiconify the tooltip "flashes", so I'm
# not doing it and it seems to work OK.
            tw.deiconify()
        except TclError:
            self.hidetip()
        return
    def showcontents(self, Len, text = "Your text here"):
# Break up the incoming message about every Len characters.
        if len(text) > Len:
            Msg = ""
            Count = 0
            for c in text:
                if Count == 0 and c == " ":
                    continue
                if Count > Len and c == " ":
                    Msg += "\n"
                    Count = 0
                    continue
                if c == "\n":
                    Msg += c
                    Count = 0
                    continue
                Count += 1
                Msg += c
            text = Msg
# Override this in derived class.
        Lab = Label(self.tipwindow, text = text, justify = LEFT, \
                bg = Clr["Y"], bd = 1, fg = Clr["B"], relief = SOLID, \
                padx = 3, pady = 2)
        Lab.pack()
        return
    def hidetip(self):
# If it is already gone then just go back.
        try:
            tw = self.tipwindow
            self.tipwindow = None
            if tw:
                tw.destroy()
        except TclError:
            pass
        return
class ToolTip(ToolTipBase):
    def __init__(self, button, Len, text):
        ToolTipBase.__init__(self, button)
        self.Len = Len
        self.text = text
        return
    def showcontents(self):
        ToolTipBase.showcontents(self, self.Len, self.text)
        return
# END: ToolTip




########################
# BEGIN: updateMe(Which)
# LIB:updateMe():2006.112
def updateMe(Which):
    if Which == 0:
        Root.update_idletasks()
        Root.update()
    else:
        Buts["STOP"].update()
    return
# END: updateMe




###################################
# BEGIN: writeFile(Open, Who, What)
# LIB:writeFile():2010.180
#   Open = 0 = close file when finished
#          1 = leave file open when finished (just to save some time when
#              writing a lot of lines in a row)
#   WARNING: Must call setPROGMsgsFile() before coming here or at least set
#            the global variable PROGMsgsFile.
PROGMsgFp = None

def writeFile(Open, Who, What):
    global PROGMsgFp
# FUTUREME - There is only MSG at this time.
    if Who == "MSG":
        if PROGMsgFp == None:
            try:
                PROGMsgFp = open(PROGMsgsDirVar.get()+PROGMsgsFile, "ab")
            except Exception, e:
# We can't use msgLn() or we'll end up right back here, etc. plus this will be
# REAL annoying, because it will get printed every time this gets called.
                MMsg.insert(END, "Error opening messages file\n")
                MMsg.insert(END, "   "+PROGMsgsFile)
                MMsg.insert(END, "   "+str(e))
# Repeat them here for various reasons.
                print("Error opening messages file")
                print("   '"+PROGMsgsFile+"'")
                print("   "+str(e))
        try:
            PROGMsgFp.write(What)
            PROGMsgFp.flush()
        except Exception, e:
            MMsg.insert(END, "Error writing to messages file\n")
            MMsg.insert(END, "   "+PROGMsgsFile)
            MMsg.insert(END, "   "+str(e))
            print("Error writing to messages file")
            print("   '"+PROGMsgsFile+"'")
            print("   "+str(e))
    if Open == 0:
        PROGMsgFp.close()
        PROGMsgFp = None
    return
# END: writeFile




############################
# BEGIN: writePort(DAS, Str)
# FUNC:writePort():2009.238
#   Does the actual writing to the serial port. This was done mostly for the
#   OPTDebugCVar function.
def writePort(DAS, Str):
    if OPTDebugCVar.get() == 1:
        print(">>>>%s"%Str)
    try:
# Get rid of any leftovers. Once was not enough once.
        CmdPort.flushInput()
        CmdPort.flushInput()
        CmdPort.write(Str)
    except Exception, e:
        print("writePort(): .flushInput() or .write() error.")
        print(e)
# KLUDGEWARNING: Linux, FC4 and a laptop with only a Keyspan converter for a
# serial port required this delay for some (probably electrical) reason. The
# commands would be garbled or truncated somehow by the time they got to the
# DASs and then the DASs would not respond. I suspect that might have
# something to do with the port getting closed too quickly after this function
# returns. So rather than stick in delays everywhere else...
    sleep(.1)
    return
# END: writePort




###########################################
# BEGIN: ydhms2Epoch(YYYY, DDD, HH, MM, SS)
# LIB:ydhms2Epoch():2010.242
#   Converts the passed date to seconds since Jan 1, 1970.
#   Should only be used for doing things like converting two times to
#   calculate GMT vs LT differences and other short-term things like that
#   since it doesn't know anything about leap seconds.
def ydhms2Epoch(YYYY, DDD, HH, MM, SS):
    global PROGYEI70
    Epoch = 0
# This trick makes it so a year's Epoch only needs to be calculated once.
    try:
        Epoch = PROGYEI70[YYYY]
    except KeyError:
        for YYY in xrange(1970, YYYY):
            if YYY%4 != 0:
                Epoch += 31536000
            elif YYY%100 != 0 or YYY%400 == 0:
                Epoch += 31622400
            else:
                Epoch += 31536000
        PROGYEI70[YYYY] = Epoch
    Epoch += (DDD-1)*86400
    Epoch += HH*3600
    Epoch += MM*60
    Epoch += SS
    return Epoch
# END: ydhms2Epoch




###########################
# BEGIN: ydoy2md(YYYY, DDD)
# LIB:ydoy2md():2009.103
def ydoy2md(YYYY, DDD):
    if DDD < 1:
        return 0, 0
    if DDD < 32:
        return 1, DDD
    elif DDD < 60:
        return 2, DDD-31
    if YYYY%4 != 0:
        Leap = 0
    elif YYYY%100 != 0 or YYYY%400 == 0:
        Leap = 1
    else:
        Leap = 0
# Check for this special day.
    if Leap == 1 and DDD == 60:
        return 2, 29
# The if statements for Mar-Dec are set up for non-leap years. If it is a
# leap year and the date is going to be Mar-Dec, subtract 1 from the day.
    DDD -= Leap
# March
    if DDD < 91:
        return 3, DDD-59
# April
    if DDD < 121:
        return 4, DDD-90
# May
    if DDD < 152:
        return 5, DDD-120
# June
    if DDD < 182:
        return 6, DDD-151
# July
    if DDD < 213:
        return 7, DDD-181
# August
    if DDD < 244:
        return 8, DDD-212
# September
    if DDD < 274:
        return 9, DDD-243
# October
    if DDD < 305:
        return 10, DDD-273
# November
    if DDD < 335:
        return 11, DDD-304
# December
    if DDD < 366:
        return 12, DDD-334
    return 0, 0
# END: ydoy2md




# =====================================
# BEGIN: ========== COMMANDS ==========
# =====================================


#############################
# BEGIN: about(Parent = Root)
# LIB:about():2010.248
PROGTrans["ABTabout-LE"] = "About"
PROGTrans["ABTabout-LS"] = "Acerca De"
PROGTrans["ABTvers-LE"] = "Version"
PROGTrans["ABTvers-LS"] = unicode("Versi\xf3n", "iso8859-1")
PROGTrans["ABTphone-LE"] = "Phone"
PROGTrans["ABTphone-LS"] = unicode("Tel\xe9fono", "iso8859-1")
PROGTrans["ABTconfig-LE"] = "Configuration"
PROGTrans["ABTconfig-LS"] = unicode("Configuraci\xf3n", "iso8859-1")
PROGTrans["ABTsetup-LE"] = "Setups File"
PROGTrans["ABTsetup-LS"] = "Setups File"
PROGTrans["ABTok-LE"] = "OK"
PROGTrans["ABTok-LS"] = "OK"

def about(Parent = Root):
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    Message = "%s (%s)\n   "%(PROG_LONGNAME, PROG_NAME)
    Message += "%s %s\n"%(PROGTrans['ABTvers'+PROGLang], PROG_VERSION)
    Message += "%s\n"%"PASSCAL Instrument Center"
    Message += "%s\n\n"%"Socorro, New Mexico"
    Message += "%s\n"%"Email: passcal@passcal.nmt.edu"
    Message += "%s: %s\n\n"%(PROGTrans['ABTphone'+PROGLang], "575-835-5070")
    Message += "--- %s ---\n"%PROGTrans['ABTconfig'+PROGLang]
    Message += "%s"%PROGConfiguration
# Some programs don't care about the geometry of the main display.
    try:
        if PROGGeometryVar.get() != "":
            Message += "\n"
            Message += "Geometry: %s"%PROGGeometryVar.get()
    except:
        pass
# Some dont have setup files.
    if PROGSetupsDirVar.get() != "N/A":
        Message += "\n\n"
        Message += "--- %s ---\n"%PROGTrans['ABTsetup'+PROGLang]
        Message += "%s"%(PROGSetupsDirVar.get()+PROG_NAMELC+".set")
    formMYD(Parent, (("("+PROGTrans['ABTok'+PROGLang]+")", LEFT, "ok"), ), \
           "ok", "", PROGTrans['ABTabout'+PROGLang], Message)
    return
# END: about




###############################
# BEGIN: addRemID(ID, e = None)
# FUNC:addRemID():2009.030
#   Handles adding and removing either the passed ID (for adding only) or the
#   value of the ID field entered by the user from the status display.
def addRemID(ID, e = None):
    if ID == "":
        IDFieldVar.set(IDFieldVar.get().strip().upper())
        ID = IDFieldVar.get()
        if check130ID(ID) == False:
            msgLn(0, "R", "Bad DAS ID: %s"%ID, True, 2)
            return
        IDPassed = False
    else:
        IDPassed = True
    if ID == "":
        msgLn(0, "R", "No DAS ID was entered.", True, 2)
        return
# Check to see if the ID is in any of the boxes.
    Ret = formSTATID2Key(ID, "any")
    if Ret != -1:
        formSTATClearID(ID)
        IDFieldVar.set("")
        msgLn(1, "", "%4s: Manually removed."%ID)
    else:
# Probably we're full if anything.
        Ret = formSTATAddID(ID)
        if Ret[0] != 0:
            msgLn(0, Ret[1], Ret[2], Ret[3])
            return
        if IDPassed == False:
            Ent["ID"].focus_set()
            msgLn(0, "", "%4s: Manually added."%ID)
    if IDPassed == False:
        IDFieldVar.set("")
    return
# END: addRemID




######################
# BEGIN: allPortsCmd()
# FUNC:allPortsCmd():2008.012
#   Quickly cycles the serial port on and off 15 times to get the serial
#   controller to enable all of the serial ports
def allPortsCmd():
    buttonControl("ALLPORTS", "Y", 1)
    for i in xrange(0, 15):
        if openCmdPort() == False:
            break
        sleep(0.1)
        closeCmdPort()
        sleep(0.1)
        updateMe(0)
    buttonControl("ALLPORTS", "", 0)
    return
# END: allPortsCmd




#######################
# BEGIN: calCmd(VarSet)
# FUNC:calCmd():2009.315
def calCmd(VarSet):
    global WorkState
    Cmd = ""
    Status, ListOfDASs = isItOKToStart(3)
    if Status == False:
        return
    cleanCALS(VarSet)
    Which = eval("%sWhichRVar"%VarSet).get()
    if isgoodCALS(VarSet, Which) == False:
        return
    WorkState = 100
    WhichButton = ""
    if Which == "STEP":
        WhichButton = "STEPCAL"
    elif Which.startswith("S"):
        WhichButton = "SINECAL"
    else:
        WhichButton = "NOISECAL"
    buttonControl(WhichButton, "G", 1)
    formSTATSetStatus("all", "B")
    Chans = eval("%sChannelsRVar"%VarSet).get()
    Duration = eval("%sDurationVar"%VarSet).get()
    Amplitude = eval("%sAmplitudeVar"%VarSet).get()
    StepInterval = eval("%sStepIntervalVar"%VarSet).get()
    StepWidth = eval("%sStepWidthVar"%VarSet).get()
    Frequency = eval("%sFrequencyRVar"%VarSet).get()
    if openCmdPort() == False:
        buttonControl(WhichButton, "", 0)
        return
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        if DAS != "0000" and Duration == "8":
            Answer = formMYD(Root, (("Send", LEFT, "send"), \
                    ("Stop", LEFT, "stop")), "stop", "", "Next!", \
                    "Send short cal commands to DAS %s?"%DAS)
            if Answer == "stop":
                WorkState = 999
                break
            updateMe(0)
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        if Which == "STEP":
            msgLn(1, "", "%d. %s: Start Step Cal Channels %s... (%s)"% \
                    (Count, DAS, Chans, getGMT(0)))
        elif Which.startswith("S"):
            msgLn(1, "", \
                    "%d. %s: Start Sine Cal (%s) Channels %s... (%s)"% \
                    (Count, DAS, Which, Chans, getGMT(0)))
        else:
            msgLn(1, "", \
                    "%d. %s: Start Noise Cal (%s) Channels %s... (%s)"% \
                    (Count, DAS, Which, Chans, getGMT(0)))
# Things go more smoothly when a reset is done to first turn off any
# calibration command that may already be running.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "C", "   Resetting...")
        Cmd = rt130CmdFormat(DAS, "RS  RS")
        writePort(DAS, Cmd)
# If we are talking to all of the DASs then don't bother reading the response,
# but still delay for a bit to allow the DASs time to finish resetting. The
# amount of time will be from about 4 to about 20 seconds depending on how
# many CF cards need to be checked.
        if DAS == "0000":
            delay(20)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 4)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Reset command response!", True, 3)
                AllOK = False
                WorkState = 999
                continue
# In general we will always break out and stop when something like a DAS starts
# talking out of turn since once something like that starts there's no way to
# stop it, except to just stop and wait.
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# Since we know who we are working with try the IDID command until we get a
# response so we don't wait the full 20 seconds if we don't have to (like will
# be the case when using DAS 0000).
            Cmd = rt130CmdFormat(DAS, "IDID")
            for i in xrange(0, 20):
                writePort(DAS, Cmd)
                Rp = rt130GetRp(1, 1, 0)
                if Rp != "" or WorkState == 999:
                    break
            if WorkState == 999:
                continue
            if i == 20:
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No command response after reset!", True, 3)
                AllOK = False
                continue
# Send the calibration parameters.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "C", "   Sending parameters...")
        Sensor = ""
        if Chans == "123":
            Sensor = "1"
        elif Chans == "456":
            Sensor = "2"
        Cmd = rt130CmdFormat(DAS, "PK"+Sensor+"E  "+padR(Duration, 4)+ \
                padR(Amplitude, 4)+Which+padR(StepInterval, 4)+ \
                padR(StepWidth, 4)+padR(Frequency, 4)+"PK")
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(14)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 10, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No Calibration Parameters command response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# Implement parameters.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "C", "   Implementing...")
        Cmd = rt130CmdFormat(DAS, "PIPI")
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(9)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 10, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Implement Parameters command response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# Send Sensor Calibration command to start
        msgLn(1, "C", "   Starting calibration signal...")
        Cmd = rt130CmdFormat(DAS, "SK"+Sensor+"SSK")
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(10)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 10, 0)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Start Calibration command response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
        formSTATSetStatus(DAS, "G")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
        msgLn(1, "Y", "Some DASs may still be working.")
    stoppedMe(WorkState, DAS)
    buttonControl(WhichButton, "", 0)
    return
# END: calCmd




############################
# BEGIN: centeringVoltsCmd()
# FUNC:centeringVoltsCmd():2009.054
#   Steps through the list of DASs and prints the centering voltages.
def centeringVoltsCmd():
    global WorkState
    Status, ListOfDASs = isItOKToStart(2)
    if Status == False:
        return
    if CV123Var.get() == 0 and CV456Var.get() == 0:
        msgLn(0, "R", "Select something to get the status of.", True, 2)
        return
    WorkState = 100
    buttonControl("CENTVOLTS", "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        buttonControl("CENTVOLTS", "", 0)
        return
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        msgLn(1, "W", "%d. %s: Centering voltages... (%s)"% \
                (Count, DAS, getGMT(0)))
# Auxiliary Data request.
        Cmd = rt130CmdFormat(DAS, "SSAD              SS")
        writePort(DAS, Cmd)
# No Lag. Info request.
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Auxiliary Data command response!", True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
# The request always seems to return voltages for "both" sensors (ch 123 456)
# even though most units only have channels 123 (it would return more if there
# were hardware installed for more than 6 channels -- that's not supported
# here -- just use the value of Sensor Count and add a loop).
        if CV123Var.get() != 0:
            msgLn(1, "", "   Channels 123:  ", False)
            Value = floatt(Rp[52:52+4])
            if Value > -1.5 and Value < 1.5:
                msgLn(1, "G", Rp[52:52+4]+"  ", False)
            else:
                msgLn(1, "Y", Rp[52:52+4]+"  ", False)
            Value = floatt(Rp[56:56+4])
            if Value > -1.5 and Value < 1.5:
                msgLn(1, "G", Rp[56:56+4]+"  ", False)
            else:
                msgLn(1, "Y", Rp[56:56+4]+"  ", False)
            Value = floatt(Rp[60:60+4])
            if Value > -1.5 and Value < 1.5:
                msgLn(1, "G", Rp[60:60+4])
            else:
                msgLn(1, "Y", Rp[60:60+4])
        if CV456Var.get() != 0:
            msgLn(1, "", "   Channels 456:  ", False)
            Value = floatt(Rp[82:82+4])
            if Value > -1.5 and Value < 1.5:
                msgLn(1, "G", Rp[82:82+4]+"  ", False)
            else:
                msgLn(1, "Y", Rp[82:82+4]+"  ", False)
            Value = floatt(Rp[86:86+4])
            if Value > -1.5 and Value < 1.5:
                msgLn(1, "G", Rp[86:86+4]+"  ", False)
            else:
                msgLn(1, "Y", Rp[86:86+4]+"  ", False)
            Value = floatt(Rp[90:90+4])
            if Value > -1.5 and Value < 1.5:
                msgLn(1, "G", Rp[90:90+4])
            else:
                msgLn(1, "Y", Rp[90:90+4])
        formSTATSetStatus(DAS, "G")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
    stoppedMe(WorkState, DAS)
    buttonControl("CENTVOLTS", "", 0)
    return
# END: centeringVoltsCmd




#############################################
# BEGIN: changeDirs(Parent, Which, Mode, Var)
# LIB:changeDirs():2010.173
#   Mode = formMYDF mode value (some callers may not want to allow directory
#          creation, for example).
#      1 = just picking
#      2 = picking and creating
#   Var = if not None the selected directory will be placed there. May not be
#         used in all programs.
#
#   Not all programs will use all items.
def changeDirs(Parent, Which, Mode, Var):
# The caller can pass either.
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    if Which == "select":
# Just use the directory as a starting point.
        Answer = formMYDF(Parent, Mode, "Pick A Directory For All", \
                PROGMsgsDirVar.get(), "")
        if Answer == "":
            return (1, )
        elif Answer == PROGMsgsDirVar.get():
            return (0, "", "All directories unchanged.", 0)
        else:
# Some of these may not exist in a program.
            try:
                PROGDataDirVar.set(Answer)
            except:
                pass
            try:
                PROGMsgsDirVar.set(Answer)
            except:
                pass
            try:
                CLTRDOrigDirVar.set(Answer)
            except:
                pass
            try:
                TCUTCutDirVar.set(Answer)
            except:
                pass
            try:
                PROGWorkDirVar.set(Answer)
            except:
                pass
            return (0, "WB", "All directories changed to\n   %s"%Answer, 0)
    elif Which == "cut":
        Answer = formMYDF(Parent, Mode, "Pick A Cut Directory", \
                TCUTCutDirVar.get(), "")
        if Answer == "":
            return (1, )
        elif Answer == TCUTCutDirVar.get():
            return (0, "", "Cut data directory unchanged.", 0)
        else:
            TCUTCutDirVar.set(Answer)
            return (0, "WB", "Cut data directory changed to\n   %s"%Answer, 0)
    elif Which == "data":
        if Var == None:
            Answer = formMYDF(Parent, Mode, "Pick A Data Directory", \
                    PROGDataDirVar.get(), "")
            if Answer == "":
                return (1, )
            elif Answer == PROGDataDirVar.get():
                return (0, "", "Data directory unchanged.", 0)
            else:
                PROGDataDirVar.set(Answer)
        else:
            Answer = formMYDF(Parent, Mode, "Pick A Data Directory", \
                    Var.get(), "")
            if Answer == "":
                return (1, )
            elif Answer == Var.get():
                return (0, "", "Data directory unchanged.", 0)
            else:
                Var.set(Answer)
        return (0, "WB", "Data directory changed to\n   %s"%Answer, 0)
    elif Which == "msgs":
        Answer = formMYDF(Parent, Mode, "Pick A Messages Directory", \
                PROGMsgsDirVar.get(), "")
        if Answer == "":
            return (1, )
        elif Answer == PROGMsgsDirVar.get():
            return (0, "", "Messages directory unchanged.", 0)
        else:
            PROGMsgsDirVar.set(Answer)
            return (0, "WB", "Messages directory changed to\n   %s"%Answer, 0)
    elif Which == "orig":
        Answer = formMYDF(Parent, Mode, "Pick An Orig Directory", \
                CLTRDOrigDirVar.get(), "")
        if Answer == "":
            return (1, )
        elif Answer == CLTRDOrigDirVar.get():
            return (0, "", "Orig data directory unchanged.", 0)
        else:
            CLTRDOrigDirVar.set(Answer)
            return (0, "WB", "Orig data directory changed to\n   %s"%Answer, 0)
    elif Which == "work":
        Answer = formMYDF(Parent, Mode, "Pick A Work Directory", \
                PROGWorkDirVar.get(), "")
        if Answer == "":
            return (1, )
        elif Answer == PROGWorkDirVar.get():
            return (0, "", "Work directory unchanged.", 0)
        else:
            PROGWorkDirVar.set(Answer)
            return (0, "WB", "Work directory changed to\n   %s"%Answer, 0)
    return
##########################################################
# BEGIN: changeDirsCmd(Parent, Which, Mode, Var, e = None)
# FUNC:changeDirsCmd():2010.174
def changeDirsCmd(Parent, Which, Mode, Var, e = None):
    Ret = changeDirs(Parent, Which, Mode, Var)
    if Ret[0] == 0:
# Some programs may not have a messages area.
        try:
            msgLn(0, Ret[1], Ret[2], True, Ret[3])
        except:
            pass
    return
# END: changeDirs




#######################################
# BEGIN: checkForUpdates(Parent = Root)
# LIB:checkForUpdates():2010.250
#   Finds the new|test<prog>.txt file at the URLs and checks to see if the
#   version in those files match the version of this program.
VERS_DLALLOW = True
VERS_VERSURL = "http://www.passcal.nmt.edu/~bob/passoft/"
VERS_VERSURLTEST = "http://www.passcal.nmt.edu/~bob/passofttest/"
VERS_PARTS = 4
VERS_NAME = 0
VERS_VERS = 1
VERS_USIZ = 2
VERS_ZSIZ = 3

def checkForUpdates(Parent = Root):
    if isinstance(Parent, str):
        Parent = Frm[Parent]
# Otherwise the menu doesn't go away on slow connections while url'ing.
    updateMe(0)
# Get the file that tells us about the current version on the server.
# One line:  PROG; version; original size; compressed size
    try:
        Fp = urlopen(VERS_VERSURL+"new"+PROG_NAMELC+".txt")
        Line = readFileLines(Fp)
        Fp.close()
        Line = Line[0]
# If the file doesn't exist you get something like
#     <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
# How unhandy.
        if Line.find("DOCTYPE") != -1:
            raise IOError
    except (IndexError, IOError):
        Line = ""
    try:
        Fp = urlopen(VERS_VERSURLTEST+"test"+PROG_NAMELC+".txt")
        LineTest = readFileLines(Fp)
        Fp.close()
        LineTest = LineTest[0]
        if LineTest.find("DOCTYPE") != -1:
            raise IOError
    except (IndexError, IOError):
        LineTest = ""
# If we didn't get these then there must have been a problem.
    if Line == "" and LineTest == "":
        formMYD(Parent, (("(OK)", TOP, "ok"), ), "ok", "RW", \
                "It's Probably The Net.", \
        "There was an error obtaining the version information from PASSCAL.", \
                "", 2)
        return
    Parts = map(strip, Line.split(";"))
    Parts += (VERS_PARTS-len(Parts))*[""]
    PartsTest = map(strip, LineTest.split(";"))
    PartsTest += (VERS_PARTS-len(PartsTest))*[""]
# Check the test version and just set a flag to control what we will tell the
# user below.
    TestVersion = False
# If the regular copy is older than the test copy let the user know. If they
# are the same then no need. If the regular copy is newer than the test copy
# then Bob isn't working very hard.
    if PROG_VERSION < PartsTest[VERS_VERS] and \
            Parts[VERS_VERS] < PartsTest[VERS_VERS]:
        TestVersion = True
    if PROG_VERSION < Parts[VERS_VERS]:
# Some programs don't need to be professionally installed, some do.
        if VERS_DLALLOW == True:
            if TestVersion == False:
                Answer = formMYD(Parent, (("Download New Version", TOP, \
                        "dlprod"), ("(Don't)", TOP, "dont"), ), "dont", \
                        "YB", "Oh Oh...", \
                        "This is an old version of %s.\nThe current version generally available is %s."% \
                        (PROG_NAME, Parts[VERS_VERS]), "", 2)
            elif TestVersion == True:
                Answer = formMYD(Parent, \
                        (("Download The New Production Version", TOP, \
                        "dlprod"), ("Download The New Test Version", TOP, \
                        "dltest"), ("(Don't Download Anything)", TOP, \
                        "dont")), "dont", "YB", "How Embarrasing...", \
                        "This is an old version of %s.\nThe version everyone else is probably using is %s. However, the really cool people may be running the test version which is version %s."% \
                        (PROG_NAME, Parts[VERS_VERS], PartsTest[VERS_VERS]), \
                        "", 2)
            if Answer == "dont":
                return
            if Answer == "dlprod":
                Ret = checkForUpdatesDownload(Parent, Answer, Parts)
            elif Answer == "dltest":
                Ret = checkForUpdatesDownload(Parent, Answer, PartsTest)
            if Ret == "quit":
                progQuitter(True)
            return
        elif VERS_DLALLOW == False:
            if TestVersion == False:
                Answer = formMYD(Parent, (("(OK)", TOP, "ok"), ), "ok", \
                        "YB", "Tell Someone.", \
                        "This is an old version of %s.\nThe current version generally available is %s."% \
                        (PROG_NAME, Parts[VERS_VERS]), "", 2)
            elif TestVersion == True:
                Answer = formMYD(Parent, (("(OK)", TOP, "ok"), ), "ok", \
                        "YB", "Tell Someone.", \
                        "This is an old version of %s.\nThe current version generally available is %s and there is also a new test version %s."% \
                        (PROG_NAME, Parts[VERS_VERS], PartsTest[VERS_VERS]), \
                        "", 2)
            return
    elif PROG_VERSION == Parts[VERS_VERS]:
        if TestVersion == False:
            Answer = formMYD(Parent, (("Download Anyway", TOP, "dlprod"), \
                    ("(OK)", TOP, "ok")), "ok", "", "Good To Go.", \
                    "This copy of %s is up to date."%PROG_NAME)
        elif TestVersion == True:
            Answer = formMYD(Parent, (("Download Production Anyway", TOP, \
                    "dlprod"), ("Download Test Version", TOP, "dltest"), \
                    ("(OK)", TOP, "ok")), "ok", "", "Good To Go.", \
                    "This copy of %s is up to date, however there is a newer test version of %s."% \
                    (PROG_NAME, PartsTest[VERS_VERS]))
        if Answer == "ok":
            return
        if Answer == "dlprod":
            Ret = checkForUpdatesDownload(Parent, Answer, Parts)
        elif Answer == "dltest":
            Ret = checkForUpdatesDownload(Parent, Answer, PartsTest)
        if Ret == "quit":
            progQuitter(True)
        return
    elif PROG_VERSION > Parts[VERS_VERS]:
# If they aren't allowed to download the file then don't even tell them about
# any new test version.
        if VERS_DLALLOW == False:
            Answer = formMYD(Parent, (("(OK)", TOP, "ok"), ), "ok", "GB", \
                    "All Right!", \
                    "Congratulations! This is a newer version of %s than is generally available. Everyone else probably still has version %s."% \
                    (PROG_NAME, Parts[VERS_VERS]))
        elif VERS_DLALLOW == True:
            if TestVersion == False:
                Answer = formMYD(Parent, (("Download Older Version", TOP, \
                        "dlprod"), ("(OK)", TOP, "ok"), ), "ok", "GB", \
                        "All Right!", \
                        "Congratulations! This is a newer version of %s than is generally available. Everyone else probably still has version %s. You can download and use the older version if you want."% \
                        (PROG_NAME, Parts[VERS_VERS]))
            elif TestVersion == True:
                Answer = formMYD(Parent, \
                        (("I'm Feeling Lucky Download The Test Version", \
                        TOP, "dltest"), \
                        ("Download The Older Production Version", TOP, \
                        "dlprod"), ("(I'll Keep The Version I Have)", TOP, \
                        "keep")), "keep", "GB", "All Right!", \
                        "Congratulations! This is a newer version of %s than is generally available. Everyone else probably still has version %s. However, there is a newer test version than this one at version %s. You can also download and use the older version if you want."% \
                        (PROG_NAME, Parts[VERS_VERS], PartsTest[VERS_VERS]))
        if Answer == "ok" or Answer == "keep":
            return
        if Answer == "dlprod":
            Ret = checkForUpdatesDownload(Parent, Answer, Parts)
        elif Answer == "dltest":
            Ret = checkForUpdatesDownload(Parent, Answer, PartsTest)
        if Ret == "quit":
            progQuitter(True)
        return
    return
######################################################
# BEGIN: checkForUpdatesDownload(Parent, Which, Parts)
# FUNC:checkForUpdatesDownload():2010.250
def checkForUpdatesDownload(Parent, Which, Parts):
    formMYD(Parent, (), "", "CB", "", "Downloading...")
    ZSize = int(Parts[VERS_ZSIZ])
    try:
        if Which == "dlprod":
            GetFile = "new%s.zip"%PROG_NAMELC
            Fpr = urlopen(VERS_VERSURL+GetFile)
        elif Which == "dltest":
            GetFile = "test%s.zip"%PROG_NAMELC
            Fpr = urlopen(VERS_VERSURLTEST+GetFile)
# SetupsDir may not be the best place to put it, but at least it will be
# consistant and not dependent on where the user was working (like it was).
        Fpw = open(PROGSetupsDirVar.get()+GetFile, "wb")
        DLSize = 0
        while 1:
            Buffer = Fpr.read(20000)
            if len(Buffer) == 0:
                break
            Fpw.write(Buffer)
            DLSize += 20000
            formMYDMsg("Downloading (%d%%)...\n"%(100*DLSize/ZSize))
    except Exception, e:
# They may not exist.
        try:
            Fpr.close()
        except:
            pass
        try:
            Fpw.close()
        except:
            pass
        formMYDReturn("")
        formMYD(Parent, (("(OK)", TOP, "ok"), ), "ok", "MW", "Ooops.", \
                "Error downloading new version.\n\n%s"%e, "", 3)
        return ""
    Fpr.close()
    Fpw.close()
    formMYDReturn("")
    if Which == "dlprod":
        Answer = formMYD(Parent, (("Quit %s"%PROG_NAME, TOP, "quit"), \
                ("Don't Quit", TOP, "cont")), "cont", "GB", "Finished?", \
                "The downloaded program file has been saved as\n\n%s\n\nYou should quit %s using the Quit button below, unzip the downloaded file, test the new program file to make sure it is OK, then rename it %s.py and move it to the proper location.\n\nTAKE NOTE OF WHERE THE FILE HAS BEEN DOWNLOADED TO!"% \
                (PROGSetupsDirVar.get()+GetFile, PROG_NAME, PROG_NAMELC))
    elif Which == "dltest":
        Answer = formMYD(Parent, (("Quit %s"%PROG_NAME, TOP, "quit"), \
                ("Don't Quit", TOP, "cont")), "cont", "GB", "Finished?", \
                "The downloaded test version file has been saved as\n\n%s\n\nYou should quit %s using the Quit button below, unzip the downloaded file, test the new program file to make sure it is OK, then rename it to the proper name and move it to the proper location if you feel lucky. I'd keep a copy of the old version if I were you.\n\nTAKE NOTE OF WHERE THE FILE HAS BEEN DOWNLOADED TO!"% \
                (PROGSetupsDirVar.get()+GetFile, PROG_NAME))
    if Answer == "quit":
        return "quit"
    return ""
# END: checkForUpdates




########################
# BEGIN: checkParmsCmd()
# FUNC:checkParmsCmd():2009.082
def checkParmsCmd():
    if checkParms(False) == True:
        msgLn(0, "G", "Parameters checked. All OK.")
    else:
        msgLn(0, "", "Parameters checked.")
    return
# END: checkParmsCmd




##########################
# BEGIN: cleanCALS(VarSet)
# FUNC:cleanCALS():2008.012
def cleanCALS(VarSet):
    eval("%sDurationVar"%VarSet).set(eval("%sDurationVar"% \
            VarSet).get().strip())
    eval("%sAmplitudeVar"%VarSet).set(eval("%sAmplitudeVar"% \
            VarSet).get().strip())
    eval("%sStepIntervalVar"%VarSet).set(eval("%sStepIntervalVar"% \
            VarSet).get().strip())
    eval("%sStepWidthVar"%VarSet).set(eval("%sStepWidthVar"% \
            VarSet).get().strip())
    return
# END: cleanCALS




###################
# BEGIN: debugCmd()
# FUNC:debugCmd():2008.090
def debugCmd():
    if OPTDebugCVar.get() == 0:
        msgLn(0, "", "Debug mode turned OFF.")
    else:
        msgLn(0, "", "Debug mode turned ON.")
    return
# END: debugCmd




#######################
# BEGIN: enumerateCmd()
# FUNC:enumerateCmd():2009.315
#   Handles more things itself (like update()s) because it's special (basically
#   we don't want the Stop button involved).
def enumerateCmd():
    global WorkState
# This command handles its own button logic. We (visually) don't want the Stop
# button involved since stopping enumeration before finishing will leave the
# communication board in a funny state. We only want people that know what
# they are doing to know about hitting the Enumerate button to stop. This will
# set WorkState in the UI thread and then the code further down will pick up on
# it and stop.
    if WorkState == 200:
        msgLn(0, "Y", "Stopping...")
        buttonBG("ENUM", "Y")
        Buts["ENUM"].update()
        WorkState = 999
        return
# If some other action is running don't start this one.
    Status, ListOfDASs = isItOKToStart(0)
    if Status == False:
        return
    WorkState = 200
    buttonBG("ENUM", "G")
    Buts["ENUM"].update()
    msgLn(1, "W", "Enumerating... (%s)"%getGMT(0))
# Clear out any DASs we had in the list.
    formSTATClearID(0)
    for i in xrange(1, STATTXTOTAL+1):
        if WorkState == 999:
            break
# Open and close the port each time through the loop for the hardware end to
# detect (it toggles the RTS line).
        if openCmdPort() == False:
            break
# Call out to any DAS connected. The comm board will keep it to 1 at a time.
        Cmd = rt130CmdFormat("0000", "IDID")
        writePort("0000", Cmd)
        delay(0.5)
        Rp = CmdPort.readline()
        if Rp == "":
           closeCmdPort()
           formSTATAddID("0000")
# Keep the port closed for a bit to cycle the RTS line for "the box".
           sleep(0.1)
           continue
# Do a little QC on the line. The most common failure will be the user
# forgetting to hit the reset button on "the box" which may make the response
# less than 25 characters (that is about the length of a normal IDID response)
# or the Unit ID portion not a valid hex number.
        if len(Rp) < 26:
            msgLn(0, "R", "Did you forget to hit the reset button?", \
                    True, 2)
            closeCmdPort()
            WorkState = 0
            buttonBG("ENUM", "D")
# We don't need to do an update in places like this since the program will be
# going idle after the return.
            return
        DAS = Rp[2:2+4]
        try:
            ID = int(DAS, 16)
        except ValueError:
            msgLn(0, "R", "Did you forget to hit the reset button?", \
                    True, 2)
            closeCmdPort()
            WorkState = 0
            buttonBG("ENUM", "D")
            return
# Just so we don't "find" other models.
        if check130ID(DAS) == False:
            msgLn(1, "Y", "%s is not an RT130. Skipping it."%DAS)
            closeCmdPort()
            sleep(0.1)
            continue
        else:
            if OPTDebugCVar.get() == 1:
                print("<<<<%s"%Rp)
            formSTATAddID(DAS)
            if OPTGetCPUVerCVar.get() != 0:
                Cmd = rt130CmdFormat(DAS, "SSVS              SS")
                writePort(DAS, Cmd)
                Rp = rt130GetRp(1, 5, 0)
                if Rp == "":
                    msgLn(1, "M", \
                           "No Version Status command response from DAS %s!"% \
                            DAS, True, 3)
                    closeCmdPort()
                    delay(0.1)
                    continue
                if checkRp(DAS, Rp) == False:
                    delay(0.1)
                    closeCmdPort()
                    continue
                msgLn(1, "", "%s: CPU version: "%DAS, False)
                msgLn(1, "G", Rp[32:32+16])
# Keep the port closed for a bit to cycle the RTS line for "the box".
        closeCmdPort()
        sleep(0.1)
# This gets rid of any duplicate entries and 0000 unit IDs and sorts and
# displays the DASs that are left.
    ListOfDASs = formSTATRemoveDups(ListOfDASs)
    stoppedMe(WorkState, "")
    DASs = len(ListOfDASs)
    if DASs == 1:
        msgLn(0, "", "1 DAS found.")
    else:
        msgLn(0, "", "%d DASs found."%DASs)
    DASs = 0
    for DAS in ListOfDASs:
        msgLn(1, "", "  %s"%DAS, False)
        DASs += 1
        if DASs == 5:
            msgLn(1, "", "")
            DASs = 0
    if DASs != 0:
        msgLn(0, "", "")
    WorkState = 0
    buttonBG("ENUM", "D")
    return
# END: enumerateCmd




####################
# BEGIN: eraseMsgs()
# LIB:eraseMsgs():2010.162
def eraseMsgs():
    global PROGMsgsFile
    TheMsgsDir = PROGMsgsDirVar.get()
    Answer = formMYD(Root, (("Start A New Messages File", TOP, "new"), \
            ("Erase Current File Contents", TOP, "erase"), ("(Cancel)", TOP, \
            "cancel")), "cancel", "", "Erase All Evidence Or What?", \
            "Erase the messages section\nAND\nstart a new messages file, or erase the contents of the current messages file\n\n%s\n\nand keep using it (generally the old file should be preserved and not erased)?"% \
            PROGMsgsFile)
    if Answer == "cancel":
        return
    elif Answer == "erase":
        try:
            Fp = open(TheMsgsDir+PROGMsgsFile, "wb")
            Fp.close()
            writeFile(0, "MSG", "== Contents erased "+getGMT(0)+" ==\n")
            msgLn(0, "", "", False, 0, False)
            msgLn(9, "", "Working with messages file\n   %s"%(TheMsgsDir+ \
                    PROGMsgsFile))
            msgLn(9, "", "-----")
        except Exception, e:
            msgLn(1, "M", "Error erasing file\n   %s\n   %s"% \
                    (PROGMsgsFile, e), True, 3)
            return
    elif Answer == "new":
        msgLn(0, "", "", False, 0, False)
        if PROGWhoAmILCVar.get() == "":
            PROGMsgsFile = getGMT(1)[:7]+"-"+PROG_NAMELC+".msg"
        else:
            PROGMsgsFile = PROGWhoAmILCVar.get()+"-"+getGMT(1)[:7]+"-"+ \
                    PROG_NAMELC+".msg"
        msgLn(9, "", "Working with messages file\n   %s"%(TheMsgsDir+ \
                PROGMsgsFile))
        msgLn(9, "", "-----")
        loadPROGMsgs()
    ready()
    return
# END: eraseMsgs




####################
# BEGIN: formatCmd()
# FUNC:formatCmd():2009.238
def formatCmd():
    global WorkState
    Status, ListOfDASs = isItOKToStart(3)
    if Status == False:
        return
    WorkState = 100
    buttonControl("FDISKS", "G", 1)
    formSTATSetStatus("all", "B")
    Which = FDiskVar.get()
    if openCmdPort() == False:
        buttonControl("FDISKS", "", 0)
        return
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        msgLn(1, "C", "%d. %s: Formatting disk %s... (%s)"%(Count, DAS, Which,
                getGMT(0)))
        Cmd = rt130CmdFormat(DAS, "MFD%sMF"%Which)
        writePort(DAS, Cmd)
        if DAS == "0000":
# Just so the user thinks something is really going on.
            delay(3)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Format command response!", True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# Now check periodically until we get a response to the status command
# indicating that the operation is done or failed. We will give up after
# 30*(the delay() time).
            Cmd = rt130CmdFormat(DAS, "MFRQMF")
            Wait = 0
            Finished = False
            while 1:
                if WorkState == 999 or AllOK == False or Finished == True:
                    break
                delay(2)
                if OPTDebugCVar.get() == 1:
                    print(">>>>%s"%Cmd)
                writePort(DAS, Cmd)
                Rp = rt130GetRp(1, 5, 0)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", "   No Media Format command response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
# FF means that it is still working.
                if Rp[14:14+2] != "FF":
# Something went wrong.
                    if Rp[14:14+2] == "01":
                        formSTATSetStatus(DAS, "R")
                        msgLn(1, "R", \
                      "   Invalid format request (there may not be a disk).", \
                                True, 3)
                        AllOK = False
                    if Rp[14:14+2] == "02":
                        formSTATSetStatus(DAS, "M")
                        msgLn(1, "M", "   DAS is busy.", True, 3)
                        AllOK = False
# 00 is done.
                    Finished = True
                    continue
# Timout counter.
                Wait += 1
                if Wait > 30:
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", "   No done response timeout!", True, 3)
                    AllOK = False
                    continue
# Keep the user calm.
                if Wait%10 == 0:
                    msgLn(1, "", "   Working...")
        if WorkState == 999 or AllOK == False:
            continue
        formSTATSetStatus(DAS, "G")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
        msgLn(1, "Y", "   Some DASs may still be working.")
    stoppedMe(WorkState, DAS)
    buttonControl("FDISKS", "", 0)
    return
# END: formatCmd




#################################################
# BEGIN: formCAL(Parent, Months = 3, Show = True)
# LIB:formCAL():2010.135
#   Displays a 3-month calendar with dates and day-of-year numbers.
Frm["CAL"] = None
CALTmModeRVar = StringVar()
CALTmModeRVar.set("lt")
CALDtModeRVar = StringVar()
CALDtModeRVar.set("dates")
CALOffsetVar = StringVar()
PROGSetups += ("CALTmModeRVar", "CALDtModeRVar", "CALOffsetVar")
CALYear = 0
CALMonth = 0
CALText1 = None
CALText2 = None
CALText3 = None
CALMON = ("", "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", \
        "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER")
CALFDOM = (0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
CALMonths = 3

def formCAL(Parent, Months = 3, Show = True):
    global CALText1
    global CALText2
    global CALText3
    global CALMonths
    if showUp("CAL"):
        return
    CALMonths = Months
    LFrm = Frm["CAL"] = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.resizable(0, 0)
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "CAL"))
    if CALTmModeRVar.get() == "gmt":
        LFrm.title("Calendar (GMT)")
    elif CALTmModeRVar.get() == "lt":
        GMTDiff = getLTGMTDiff()
        LFrm.title("Calendar (LT: GMT%+.2f hours)"%(float(GMTDiff)/3600.0))
    elif CALTmModeRVar.get() == "tz":
        CALOffsetVar.set("%+.2f"%floatt(CALOffsetVar.get()))
        LFrm.title("Calendar (TZ: GMT%s hours)"%CALOffsetVar.get())
    LFrm.iconname("Cal")
    Sub = Frame(LFrm)
    if CALMonths == 3:
        CALText1 = Text(Sub, width = 29, height = 11, font = PROGMonoFont, \
                bg = Clr["D"], fg = Clr["B"], relief = SUNKEN, \
                state = DISABLED)
        CALText1.pack(side = LEFT, padx = 7)
    CALText2 = Text(Sub, width = 29, height = 11, font = PROGMonoFont, \
            bg = Clr["W"], fg = Clr["B"], relief = SUNKEN, state = DISABLED)
    CALText2.pack(side = LEFT, padx = 7)
    if CALMonths == 3:
        CALText3 = Text(Sub, width = 29, height = 11, font = PROGMonoFont, \
                bg = Clr["D"], fg = Clr["B"], relief = SUNKEN, \
                state = DISABLED)
        CALText3.pack(side = LEFT, padx = 7)
    Sub.pack(side = TOP, padx = 3, pady = 3)
    if CALYear != 0:
        formCALMove("c")
    else:
        formCALMove("n")
    Sub = Frame(LFrm)
    BButton(Sub, text = "<<", command = Command(formCALMove, \
            "-y")).pack(side = LEFT)
    BButton(Sub, text = "<", command = Command(formCALMove, \
            "-m")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Now", command = Command(formCALMove, \
            "n")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = ">", command = Command(formCALMove, \
            "+m")).pack(side = LEFT)
    BButton(Sub, text = ">>", command = Command(formCALMove, \
            "+y")).pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3, pady = 3)
    Sub = Frame(LFrm)
    SSub = Frame(Sub)
    SSSub = Frame(SSub)
    Rb = Radiobutton(SSSub, text = "GMT", value = "gmt", \
            variable = CALTmModeRVar, command = Command(formCALMove, "c"))
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, "Use what appears to be this computer's GMT time.")
    Rb = Radiobutton(SSSub, text = "LT", value = "lt", \
            variable = CALTmModeRVar, command = Command(formCALMove, "c"))
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, \
          "Use what appears to be this computer's time and time zone setting.")
    SSSub.pack(side = TOP, anchor = "w")
    SSSub = Frame(SSub)
    Rb = Radiobutton(SSSub, text = "TZ:=", value = "tz", \
            variable = CALTmModeRVar, command = Command(formCALMove, "c"))
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, \
            "Enter the time zone offset in decimal hours that the calendar should use, instead of this computer's clock settings (the date will still come from this computer).")
    LEnt = Entry(SSSub, width = 6, textvariable = CALOffsetVar)
    LEnt.pack(side = LEFT)
    LEnt.bind("<Double-Button-1>", Command(formKB, "CAL", "TZ Offset", \
                    CALOffsetVar))
    LEnt.bind("<Return>", Command(formCALMove, "c"))
    LEnt.bind("<KP_Enter>", Command(formCALMove, "c"))
    SSSub.pack(side = TOP, anchor = "w")
    SSub.pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    SSub = Frame(Sub)
    Rb = Radiobutton(SSub, text = "Dates", value = "dates", \
            variable = CALDtModeRVar, command = Command(formCALMove, "c"))
    Rb.pack(side = TOP, anchor = "w")
    ToolTip(Rb, 30, "Show the calendar dates.")
    Rb = Radiobutton(SSub, text = "DOY", value = "doy", \
            variable = CALDtModeRVar, command = Command(formCALMove, "c"))
    Rb.pack(side = TOP, anchor = "w")
    ToolTip(Rb, 30, "Show the day-of-year numbers.")
    SSub.pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Close", fg = Clr["R"], command = Command(closeForm, \
            "CAL")).pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3, pady = 3)
    if Show == True:
        center(Parent, LFrm, "C", "I", True)
    return
####################################
# BEGIN: formCALMove(What, e = None)
# FUNC:formCALMove():2010.120
#   Handles changing the calendar form's display.
def formCALMove(What, e = None):
    global CALYear
    global CALMonth
    global CALText1
    global CALText2
    global CALText3
    Frm["CAL"].focus_set()
    Year = CALYear
    Month = CALMonth
    if What == "-y":
        Year -= 1
    elif What == "-m":
        Month -= 1
    elif What == "n":
        if CALTmModeRVar.get() == "gmt":
            Year, Month, Day = getGMT(4)
        elif CALTmModeRVar.get() == "lt":
            Year, DDD, HH, MM, SS = getGMT(11)
            Month, Day = ydoy2md(Year, DDD)
            GMTDiff = getLTGMTDiff()
            if GMTDiff != 0:
                Year, DDD, HH, MM, SS = dateTimeMath(0, GMTDiff, Year, DDD, \
                        HH, MM, SS)
                Month, Day = ydoy2md(Year, DDD)
        elif CALTmModeRVar.get() == "tz":
            Year, DDD, HH, MM, SS = getGMT(11)
            Month, Day = ydoy2md(Year, DDD)
            CALOffsetVar.set("%+.2f"%floatt(CALOffsetVar.get()))
            GMTDiff = int(floatt(CALOffsetVar.get())*3600.0)
            if GMTDiff != 0:
                Year, DDD, HH, MM, SS = dateTimeMath(0, GMTDiff, Year, DDD, \
                        HH, MM, SS)
                Month, Day = ydoy2md(Year, DDD)
    elif What == "+m":
        Month += 1
    elif What == "+y":
        Year += 1
    elif What == "c":
        if CALTmModeRVar.get() == "gmt":
            Frm["CAL"].title("Calendar (GMT)")
        elif CALTmModeRVar.get() == "lt":
            GMTDiff = getLTGMTDiff()
            Frm["CAL"].title("Calendar (LT: GMT%+.2f hours)"% \
                    (float(GMTDiff)/3600.0))
        elif CALTmModeRVar.get() == "tz":
            CALOffsetVar.set("%+.2f"%floatt(CALOffsetVar.get()))
            GMTDiff = int(floatt(CALOffsetVar.get())*3600.0)
            Frm["CAL"].title("Calendar (TZ: GMT%+.2f hours)"% \
                    (float(GMTDiff)/3600.0))
    if Year < 1971:
        beep(1)
        return
    elif Year > 2050:
        beep(1)
        return
    if Month > 12:
        Year += 1
        Month = 1
    elif Month < 1:
        Year -= 1
        Month = 12
    CALYear = Year
    CALMonth = Month
# Only adjust this back one month if we are showing all three months.
    if CALMonths == 3:
        Month -= 1
    if Month < 1:
        Year -= 1
        Month = 12
    for i in xrange(0, 0+3):
# Skip the first and last months if we are only showing one month.
        if CALMonths == 1 and (i == 0 or i == 2):
            continue
        LTxt = eval("CALText%d"%(i+1))
        LTxt.configure(state = NORMAL)
        LTxt.delete(0.0, END)
        LTxt.tag_delete(*LTxt.tag_names())
        if CALDtModeRVar.get() == "dates":
            DOM1 = 0
        else:
            DOM1 = CALFDOM[Month]
            if (Year%4 == 0 and Year%100 != 0) or Year%400 == 0:
                if Month > 2:
                    DOM1 += 1
        if i == 1:
            LTxt.insert(END, "\n")
            LTxt.insert(END, "%s"%(CALMON[Month]+" "+str(Year)).center(29))
            LTxt.insert(END, "\n\n")
            IdxS = LTxt.index(CURRENT)
            LTxt.tag_config(IdxS, background = Clr["W"], foreground = Clr["R"])
            LTxt.insert(END, " Sun ", IdxS)
            IdxS = LTxt.index(CURRENT)
            LTxt.tag_config(IdxS, background = Clr["W"], foreground = Clr["U"])
            LTxt.insert(END, "Mon Tue Wed Thu Fri", IdxS)
            IdxS = LTxt.index(CURRENT)
            LTxt.tag_config(IdxS, background = Clr["W"], foreground = Clr["R"])
            LTxt.insert(END, " Sat", IdxS)
            LTxt.insert(END, "\n")
        else:
            LTxt.insert(END, "\n")
            LTxt.insert(END, "%s"%(CALMON[Month]+" "+str(Year)).center(29))
            LTxt.insert(END, "\n\n")
            LTxt.insert(END, " Sun Mon Tue Wed Thu Fri Sat")
            LTxt.insert(END, "\n")
        All = monthcalendar(Year, Month)
        if CALTmModeRVar.get() == "gmt":
            NowYear, NowMonth, NowDay = getGMT(4)
        elif CALTmModeRVar.get() == "lt":
            NowYear, DDD, HH, MM, SS = getGMT(11)
            NowMonth, NowDay = ydoy2md(NowYear, DDD)
            GMTDiff = getLTGMTDiff()
            if GMTDiff != 0:
                NowYear, DDD, HH, MM, SS = dateTimeMath(0, GMTDiff, NowYear, \
                        DDD, HH, MM, SS)
                NowMonth, NowDay = ydoy2md(NowYear, DDD)
        elif CALTmModeRVar.get() == "tz":
            NowYear, DDD, HH, MM, SS = getGMT(11)
            NowMonth, NowDay = ydoy2md(NowYear, DDD)
            GMTDiff = int(floatt(CALOffsetVar.get())*3600.0)
            if GMTDiff != 0:
                NowYear, DDD, HH, MM, SS = dateTimeMath(0, GMTDiff, NowYear, \
                        DDD, HH, MM, SS)
                NowMonth, NowDay = ydoy2md(NowYear, DDD)
        TargetDay = DOM1+NowDay
        for Week in All:
            LTxt.insert(END, " ")
            for DD in Week:
                if DD != 0:
                    ThisDay = DOM1+DD
                    if ThisDay == TargetDay and Month == NowMonth and \
                            Year == NowYear:
                        IdxS = LTxt.index(CURRENT)
                        LTxt.tag_config(IdxS, background = Clr["C"], \
                                foreground = Clr["B"])
                        LTxt.insert(END, "%3d"%ThisDay, IdxS)
                        LTxt.insert(END, " ")
                    else:
                        LTxt.insert(END, "%3d "%ThisDay)
                else:
                    LTxt.insert(END, "    ")
            LTxt.insert(END, "\n")
        LTxt.configure(state = DISABLED)
        Month += 1
        if Month > 12:
            Year += 1
            Month = 1
    return
# END: formCAL




####################
# BEGIN: formCSINE()
# FUNC:formCSINE():2009.362
Frm["CSINE"] = None
# Not all of these are used by every cal function. They are just all here to
# make the rest of the cal functions() easier.
CSINEChannelsRVar = StringVar()
CSINEChannelsRVar.set("123")
CSINEDurationVar = StringVar()
CSINEDurationVar.set(8)
CSINEAmplitudeVar = StringVar()
CSINEAmplitudeVar.set("3.00")
CSINEStepIntervalVar = StringVar()
CSINEStepIntervalVar.set("1")
CSINEStepWidthVar = StringVar()
CSINEStepWidthVar.set("1")
CSINEFrequencyRVar = StringVar()
CSINEFrequencyRVar.set("2")
CSINEWhichRVar = StringVar()
CSINEWhichRVar.set("SINE")
PROGSetups += ("CSINEChannelsRVar", "CSINEDurationVar", "CSINEAmplitudeVar", \
        "CSINEStepIntervalVar", "CSINEStepWidthVar", "CSINEFrequencyRVar", \
        "CSINEWhichRVar")

def formCSINE():
    if showUp("CSINE"):
        return
    LFrm = Frm["CSINE"] = Toplevel(Root)
    LFrm.withdraw()
    LFrm.resizable(0, 0)
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "CSINE"))
    LFrm.title("Sine Calibration")
    LFrm.iconname("SineCal")
    Label(LFrm, \
            text = "Not all settings will apply to all\nsine wave calibration signal types.").pack(side = TOP)
    Sub = Frame(LFrm)
    LLab = Label(Sub, text = "Channels:")
    LLab.pack(side = LEFT)
    ToolTip(LLab, 30, "The set of channels the signals should be sent to.")
    Radiobutton(Sub, text = "123", variable = CSINEChannelsRVar, \
            value = "123").pack(side = LEFT)
    Radiobutton(Sub, text = "  456", variable = CSINEChannelsRVar, \
            value = "456").pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3)
    Sub = Frame(LFrm)
    labelEntry(Sub, 11, "Duration (secs):", "", CSINEDurationVar, 5, None, \
            None, Bar = False)
    labelEntry(Sub, 11, "  Signal Amplitude (V):", "", CSINEAmplitudeVar, 5, \
            None, None, Bar = False)
    Sub.pack(side = TOP, pady = 3)
    Sub = Frame(LFrm)
    Label(Sub, text = "Freq:").pack(side = LEFT)
    Radiobutton(Sub, text = "1", variable = CSINEFrequencyRVar, \
            value = "1").pack(side = LEFT)
    Radiobutton(Sub, text = "2", variable = CSINEFrequencyRVar, \
            value = "2").pack(side = LEFT)
    Radiobutton(Sub, text = "4", variable = CSINEFrequencyRVar, \
            value = "4").pack(side = LEFT)
    Radiobutton(Sub, text = "5", variable = CSINEFrequencyRVar, \
            value = "5").pack(side = LEFT)
    Radiobutton(Sub, text = "8", variable = CSINEFrequencyRVar, \
            value = "8").pack(side = LEFT)
    Radiobutton(Sub, text = "10", variable = CSINEFrequencyRVar, \
            value = "10").pack(side = LEFT)
    Radiobutton(Sub, text = "20", variable = CSINEFrequencyRVar, \
            value = "20").pack(side = LEFT)
    Radiobutton(Sub, text = "25", variable = CSINEFrequencyRVar, \
            value = "25").pack(side = LEFT)
    Radiobutton(Sub, text = "40", variable = CSINEFrequencyRVar, \
            value = "40").pack(side = LEFT)
    Radiobutton(Sub, text = "50", variable = CSINEFrequencyRVar, \
            value = "50").pack(side = LEFT)
    Radiobutton(Sub, text = "100", variable = CSINEFrequencyRVar, \
            value = "100").pack(side = LEFT)
    Sub.pack(side = TOP, pady = 3)
    Sub = Frame(LFrm)
    Rb = Radiobutton(Sub, text = "Sine  ", variable = CSINEWhichRVar, \
            value = "SINE")
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, "Generate a sine wave using the parameters above.")
    Rb = Radiobutton(Sub, text = "Sweep SP  ", variable = CSINEWhichRVar, \
            value = "SWSP")
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, \
            "Generate a sine wave for 60secs, sweep 50sec-100Hz, sample rate 1000sps, using the amplitude set above.")
    Rb = Radiobutton(Sub, text = "Sweep LP  ", variable = CSINEWhichRVar, \
            value = "SWLP")
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, \
            "Generate a sine wave for 3000secs, sweep 2500sec-2Hz, sample rate of 20sps, using the amplitude set above.")
    Rb = Radiobutton(Sub, text = "Sweep BB", variable = CSINEWhichRVar, \
            value = "SWBB")
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, \
            "Generate a sine wave for 60secs, sweep 50sec-100Hz, sample rate of 100sps, no output for 300secs, then a sine wave for 3000secs, sweep 2500sec-2Hz, sample rate of 20sps, all using the the amplitude set above.")
    Sub.pack(side = TOP, padx = 3)
    Sub = Frame(LFrm)
    BButton(Sub, text = "Start", command = Command(calCmd, \
            "CSINE")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Close", fg = Clr["R"], \
            command = Command(closeForm, "CSINE")).pack(side = LEFT)
    Sub.pack(side = TOP, pady = 3, padx = 3)
    Msg["CSINE"] = Text(LFrm, font = PROGMsgFont, height = 2, width = 45, \
            wrap = WORD)
    Msg["CSINE"].pack(side = TOP, fill = X)
    center(Root, LFrm, "C", "I", True)
    return
# END: formCSINE




####################
# BEGIN: formCNOIS()
# FUNC:formCNOIS():2009.362
Frm["CNOIS"] = None
# Not all of these are used by every cal function. They are just all here to
# make the rest of the cal functions() easier.
CNOISChannelsRVar = StringVar()
CNOISChannelsRVar.set("123")
CNOISDurationVar = StringVar()
CNOISDurationVar.set(8)
CNOISAmplitudeVar = StringVar()
CNOISAmplitudeVar.set("3.00")
CNOISStepIntervalVar = StringVar()
CNOISStepIntervalVar.set("1")
CNOISStepWidthVar = StringVar()
CNOISStepWidthVar.set("1")
CNOISFrequencyRVar = StringVar()
CNOISFrequencyRVar.set("2")
CNOISWhichRVar = StringVar()
CNOISWhichRVar.set("NOIS")
PROGSetups += ("CNOISChannelsRVar", "CNOISDurationVar", "CNOISAmplitudeVar", \
        "CNOISStepIntervalVar", "CNOISStepWidthVar", "CNOISFrequencyRVar", \
        "CNOISWhichRVar")

def formCNOIS():
    if showUp("CNOIS"):
        return
    LFrm = Frm["CNOIS"] = Toplevel(Root)
    LFrm.withdraw()
    LFrm.resizable(0, 0)
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "CNOIS"))
    LFrm.title("Noise Calibration")
    LFrm.iconname("NoiseCal")
    Label(LFrm, \
            text = "Not all settings will apply to all\nnoise wave calibration signal types.").pack(side = TOP)
    Sub = Frame(LFrm)
    LLab = Label(Sub, text = "Channels:")
    LLab.pack(side = LEFT)
    ToolTip(LLab, 30, "The set of channels the signals should be sent to.")
    Radiobutton(Sub, text = "123", variable = CNOISChannelsRVar, \
            value = "123").pack(side = LEFT)
    Radiobutton(Sub, text = "  456", variable = CNOISChannelsRVar, \
            value = "456").pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3)
    Sub = Frame(LFrm)
    labelEntry(Sub, 11, "Duration (secs):", "", CNOISDurationVar, 5, None, \
            None, Bar = False)
    labelEntry(Sub, 11, "  Signal Amplitude (V):", "", CNOISAmplitudeVar, 5, \
            None, None, Bar = False)
    Sub.pack(side = TOP, pady = 3)
    Sub = Frame(LFrm)
    Rb = Radiobutton(Sub, text = "Noise  ", variable = CNOISWhichRVar, \
            value = "NOIS")
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, "Generate random noise using the parameters set above.")
    Rb = Radiobutton(Sub, text = "Noise SP  ", variable = CNOISWhichRVar, \
            value = "RNSP")
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, \
            "Generate random noise for 60secs, sample rate of 1000sps, using the amplitude set above.")
    Rb = Radiobutton(Sub, text = "Noise LP  ", variable = CNOISWhichRVar, \
            value = "RNLP")
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, \
            "Generate random noise for 300secs, sample rate of 200sps, using the amplitude set above.")
    Rb = Radiobutton(Sub, text = "Noise BB", variable = CNOISWhichRVar, \
            value = "RNBB")
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, \
            "Generate random noise for 3000secs, sample rate of 20sps, using the amplitude set above.")
    Sub.pack(side = TOP, padx = 3)
    Sub = Frame(LFrm)
    BButton(Sub, text = "Start", command = Command(calCmd, \
            "CNOIS")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Close", fg = Clr["R"], \
            command = Command(closeForm, "CNOIS")).pack(side = LEFT)
    Sub.pack(side = TOP, pady = 3, padx = 3)
    Msg["CNOIS"] = Text(LFrm, font = PROGMsgFont, height = 2, width = 45, \
            wrap = WORD)
    Msg["CNOIS"].pack(side = TOP, fill = X)
    center(Root, LFrm, "C", "I", True)
    return
# END: formCNOIS




####################
# BEGIN: formCSTEP()
# FUNC:formCSTEP():2009.362
Frm["CSTEP"] = None
# Not all of these are used by every cal function. They are just all here to
# make the rest of the cal functions() easier.
CSTEPChannelsRVar = StringVar()
CSTEPChannelsRVar.set("123")
CSTEPDurationVar = StringVar()
CSTEPDurationVar.set(8)
CSTEPAmplitudeVar = StringVar()
CSTEPAmplitudeVar.set("3.00")
CSTEPStepIntervalVar = StringVar()
CSTEPStepIntervalVar.set("1")
CSTEPStepWidthVar = StringVar()
CSTEPStepWidthVar.set("1")
CSTEPFrequencyRVar = StringVar()
CSTEPFrequencyRVar.set("2")
CSTEPWhichRVar = StringVar()
CSTEPWhichRVar.set("STEP")
PROGSetups += ("CSTEPChannelsRVar", "CSTEPDurationVar", "CSTEPAmplitudeVar", \
        "CSTEPStepIntervalVar", "CSTEPStepWidthVar", "CSTEPFrequencyRVar", \
        "CSTEPWhichRVar")

def formCSTEP():
    if showUp("CSTEP"):
        return
    LFrm = Frm["CSTEP"] = Toplevel(Root)
    LFrm.withdraw()
    LFrm.resizable(0, 0)
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "CSTEP"))
    LFrm.title("Step Calibration")
    LFrm.iconname("StepCal")
    Sub = Frame(LFrm)
    LLab = Label(Sub, text = "Channels:")
    LLab.pack(side = LEFT)
    ToolTip(LLab, 30, "The set of channels the signals should be sent to.")
    Radiobutton(Sub, text = "123", variable = CSTEPChannelsRVar, \
            value = "123").pack(side = LEFT)
    Radiobutton(Sub, text = "  456", variable = CSTEPChannelsRVar, \
            value = "456").pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3)
    Sub = Frame(LFrm)
    labelEntry(Sub, 11, "Duration (secs):", "", CSTEPDurationVar, 5, None, \
            None, Bar = False)
    labelEntry(Sub, 11, "  Signal Amplitude (V):", "", CSTEPAmplitudeVar, 5, \
            None, None, Bar = False)
    Sub.pack(side = TOP, pady = 3)
    Sub = Frame(LFrm)
    labelEntry(Sub, 11, "Step Interval (secs):", "", CSTEPStepIntervalVar, 5, \
            None, None, Bar = False)
    labelEntry(Sub, 11, "  Step Width (secs):", "", CSTEPStepWidthVar, 5, \
            None, None, Bar = False)
    Sub.pack(side = TOP, pady = 3)
    Sub = Frame(LFrm)
    BButton(Sub, text = "Start", command = Command(calCmd, \
            "CSTEP")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Close", fg = Clr["R"], \
            command = Command(closeForm, "CSTEP")).pack(side = LEFT)
    Sub.pack(side = TOP, pady = 3, padx = 3)
    Msg["CSTEP"] = Text(LFrm, font = PROGMsgFont, height = 2, width = 45, \
            wrap = WORD)
    Msg["CSTEP"].pack(side = TOP, fill = X)
    center(Root, LFrm, "C", "I", True)
    return
# END: formCSTEP




#################
# BEGIN: HELPText
#   The text of the help form.
HELPText = "QUICK START\n\
===========\n\
1. START AND SET UP CHANGEO. Start CHANGEO and if they have not been \
   previously entered or set check the following items:\n\
    1. The initial working directory may need to be set. This\n\
       should be the directory where the messages file should\n\
       be saved to. If this is required a file selection dialog\n\
       box will appear.\n\
    2. ENTER COMMAND PORT DEVICE. Fill in the designator for the\n\
       serial port device if it was not filled in when CHANGEO\n\
       started. For Windows it will be something like COM4, for\n\
       Linux something like /dev/ttyUSB0, and for OSX something\n\
       like /dev/tty.USB0 (it will depend greatly on the driver\n\
       for the serial dongle used).\n\
\n\
2. RESET THE SERIAL LINE CONTROLLER. Press the reset button on the \
serial line controller. All of the blue LEDs should light up.\n\
\n\
3. ENUMERATE. After making the connections between the DASs and the \
serial line controller start enumeration by clicking the Enumerate \
button. If you only want to work with a small number of DASs their \
ID numbers may be entered directly using the ID field below the \
Enumerate button. Type one ID number at a time into this field and \
press the Enter/Return key on the keyboard. NOTE: If you enter the \
ID numbers manually you will have to click the All Ports On button \
afterwards to make the serial line controller ready to communicate \
with all connected DASs.\n\
\n\
4. GET TO WORK. Use CHANGEO's buttons and commands to work with the \
enumerated DASs.\n\
\n\
\n\
SELECTING DASs AND THE BROADCAST MODE\n\
=====================================\n\
Many commands may be sent using the Broadcast Mode where the commands are \
directed to a DAS with the ID number 0000. All listening DASs will carry \
out commands sent in that manner. Some commands cannot be sent in that \
manner but must be directed to a specific DAS like, for example, the \
Versions and Monitor commands (CHANGEO must send the command then wait \
for a response from each DAS).\n\
\n\
If all of the DASs listed in the DAS list are selected, AND a command is \
capable of being sent using the Broadcast Mode, AND the 0000 Pref \
checkbutton is selected, then the command will be sent using the \
broadcast method.\n\
\n\
If the 0000 Pref checkbutton is not selected then CHANGEO will send all \
commands only to the DASs in the DAS list that have been selected.\n\
\n\
If a subset of the DASs listed in the DAS list have been selected all \
commands will be sent to only those DASs no matter what the state of the \
0000 Pref checkbutton.\n\
\n\
Parameters may be received from only one DAS at a time.\n\
\n\
\n\
GENERAL STUFF\n\
=============\n\
1. The first time CHANGEO is started in a user's account it may be \
necessary for the user to direct CHANGEO to an initial working directory. \
This should be the directory where the messages file should be saved.\n\
\n\
2. When started CHANGEO checks to ensure that the Python pySerial \
package has been installed on the control computer. This package must be \
installed before CHANGEO can communicate. No other special packages \
are needed, except for the pywin32 package on Windows systems.\n\
\n\
3. CHANGEO records everything written to the sessages section to the file \
\"<date>-changeo.msg\" in the current work directory. <date> will be the \
YYYYDDD date of when the messages file was created.\n\
\n\
4. Setups are saved and loaded from a file called \"changeo.set\" in the \
current work directory.\n\
\n\
5. The colors of messages are not random:\n\
\n\
    Grey - Just information or statements of fact (e.g. Done.).\n\
\n\
    White - Actions where commands are sent to the DASs that will cause \
the DASs to do something, but that will not change the state of the \
DASs, but whose information will be used in support of another \
command (e.g. Getting data stream x parameters... for the Monitor \
Test is a white message, but the message [getting] Data Stream x... \
when receiving all of the parameters is a grey message.).\n\
\n\
    Cyan - Actions where commands are sent to the DASs that will change \
the state of the DASs (e.g. Sending new values...).\n\
\n\
    Red - Something is wrong and it is probably the user's fault (e.g. No \
sample rates have been set.).\n\
\n\
    Magenta - Something is wrong and it may be the fault of the hardware \
(e.g. No Reset command response!).\n\
\n\
    Yellow - Used for warnings or to draw attention to some abnormal \
condition (e.g. Stopping...).\n\
\n\
    Green - Information requested from and returned by the DASs, or used \
just to make the text more readable.\n\
\n\
6. Some items have \"tooltips\" that can be displayed by placing the mouse \
cursor over their associated label.\n\
\n\
\n\
COMMAND LINE ARGUMENTS\n\
======================\n\
The Command Port device may be supplied on the command line.\n\
\n\
\n\
MENU COMMANDS\n\
=============\n\
FILE MENU\n\
---------\n\
----- Erase Messages -----\n\
Erases all of the messages from the messages section. A dialog box will \
appear and an option will be offered to start a new messages file or \
clear the current file and keep using it.\n\
\n\
----- Search Messages -----\n\
Brings up a form to use to search through the current messages file or \
all files in the current messages directory that end with \".msg\".\n\
\n\
----- List Current Directories -----\n\
Simply lists the various directories and where they are pointing.\n\
\n\
----- Change Messages/Work Directory -----\n\
Brings up a directory selection box and allows the user to navigate to \
a different directory and/or create a new directory.\n\
\n\
----- Change All To... -----\n\
Brings up a directory selection box and allows the user to navigate to \
a different directory and/or create a new directory and set all of the \
directory paths to that directory.\n\
\n\
----- Delete Setups File -----\n\
Sometimes a bad setups file can cause the program to misbehave. This can \
be caused by upgrading the program, but reading the setups file created \
by an earlier version of the program. This function will delete the \
current setups file (which can be found in the About box) and then quit \
the program without saving the current parameters. This will reset \
all parameters to their default values. When the program is restarted \
a dialog box should appear saying that the setups file could not be found. \
If this does not happen the Delete Setups File function may need to be \
run again.\n\
\n\
----- Quit -----\n\
Quits CHANGEO.\n\
\n\
\n\
COMMANDS MENU\n\
-------------\n\
----- Set GPS Control to NORMAL -----\n\
----- Set GPS Control to CONTINUOUS -----\n\
----- Set GPS Control to OFF -----\n\
Sends the command to the selected DASs to change the operating mode of \
the GPS to the selected menu item.\n\
\n\
----- Set DAS Time -----\n\
This gets the GMT time from the control computer and transmits it to the \
DASs. This command can be sent using the Broadcast Mode. Since there is \
a delay in getting the time and sending the time this will not be very \
accurate, but is only intended to be used to get the DAS clock(s) close \
to the correct time.\n\
\n\
\n\
PARAMETERS MENU\n\
---------------\n\
----- Save Parameters As... -----\n\
Saves all of the currently set up DAS parameters to the designated file \
selected or entered in the file dialog box. The routine that quality \
checks the parameters will be called and all problems found with the \
parameters will be printed to the messages section before saving.\n\
\n\
----- Load Parameters... -----\n\
Loads the set of previously saved DAS parameters from the designated file.\n\
\n\
----- Set Ch123-DS1/40sps -----\n\
----- Set Ch123-DS1/250sps -----\n\
----- Set Ch123-DS1/40sps-DS2/1sps -----\n\
----- Set Ch123-DS1/40sps,Ch456-DS2/40sps -----\n\
----- Set Ch123-DS1/250sps,Ch456-DS2/250sps -----\n\
----- Set Ch123-DS1/40sps-DS2/1sps,Ch456-DS3/40sps-DS4/1sps -----\n\
These set the DAS parameters to the specified configurations. These are \
popular configurations for testing in the lab.\n\
\n\
\n\
OPTIONS MENU\n\
------------\n\
----- Get CPU Version On Enumerate -----\n\
Selecting this item will cause CHANGEO to query each DAS for its \
firmware version as it is found during the enumeration process.\n\
\n\
----- Summary Mode -----\n\
This will reduce the amount of information sent to the messages \
section for some commands.\n\
\n\
----- Beep When Done-----\n\
This will cause CHANGEO to beep when a command is done executing. The \
actual sound made is dependent on the control computer's operating \
system.\n\
\n\
----- ddd.ddddd -----\n\
Checking this item will cause CHANGEO to convert the GPS positions \
returned with the DAS Status command from their normal deg:min.mmmm \
format to a decimal degrees format.\n\
\n\
----- Debug Mode -----\n\
Causes CHANGEO to send the command strings sent to the DAS and the \
response strings from the DAS to be printed to the window where CHANGEO \
was started from. Lines with \">>>>\" preceding them are commands and \
lines with \"<<<<\" preceeding them are responses. Obviously, CHANGEO \
must have been started from the command line (or the icon double-clicked \
on in Windows) to have a place to see this output).\n\
\n\
\n\
FORMS MENU\n\
----------\n\
The currently open forms of the program will show up here. Selecting one \
will bring that form to the foreground.\n\
\n\
\n\
HELP MENU\n\
---------\n\
----- Calendar -----\n\
Just a built-in calendar that shows dates or DOY values for three months \
in a row. Of course the control computer's clock must be correct for this \
to show the right date.\n\
\n\
----- Check For Updates -----\n\
If the control computer is connected to the Internet this function will \
contact PASSCAL's website and check the version of the program against \
a list of version numbers. Appropriate dialog boxes will be shown \
depending on the result of the check.\n\
\n\
If the current version is old the Download button may be clicked to \
obtain the new version. The new version will be a zipped file and the \
name of the program will be preceeded by \"new\". Once it has been \
confirmed that the \"new\" program file is OK, it should be renamed \
and placed in the proper location.\n\
\n\
----- Reset Commands -----\n\
If CHANGEO crashes, or if a DAS hangs and causes the program to \
hang this command will reset the program's internal flags and possibly \
allow the problem to be reproduced for troubleshooting. When nothing \
is happening the command will have no effect, but the command should \
not be selected when some other action is in progress.\n\
\n\
\n\
BUTTONS AND FIELDS\n\
==================\n\
----- Enumerate -----\n\
Causes CHANGEO to query up to 15 DASs connected to the serial line \
controller by cycling the serial port open and closed 15 times and \
sending the Identify Unit and Software (ID) command while the port is \
open. Cycling the port causes the RTS line to change state which is \
the signal to the serial line controller to shift to the next serial \
communication line (i.e. the next DAS). After the 15th query all of the \
transmit lines from the DASs are activated by the serial line controller. \
The Reset button on the box must be pressed before enumerating so that \
only one transmit line from the DASs is initially active. Failing to do \
this will cause all of the responses from the DASs to the ID command to \
be transmitted at the same time which will make them unreadable.\n\
\n\
----- 0000 Pref -----\n\
CHANGEO has two general modes for sending commands to the DASs. \
The Broadcast Mode sends commands to a DAS with an ID number 0000. \
Any DAS that is listening will recognize this and execute the sent \
command. The other mode directs the commands to a specific DAS using \
its ID number. In this mode only the DAS with that ID number will \
respond to the command. The other listening DASs will ignore the \
command. Many commands and functions may be sent in the Broadcast \
Mode. Some, such as the Versions and Monitor Test functions, cannot. \
For those and other commands like them CHANGEO must send a command \
then wait for a response from an individual DAS before proceeding. \
For the commands that do support the Broadcast Mode there is the \
0000 Pref checkbutton.\n\
\n\
If all of the DASs in the DAS list have been selected, and the 0000 \
Pref checkbutton is selected, then the commands that support the \
Broadcast Mode will be sent using that mode. If all of the DASs in \
the DAS list have been selected, and the 0000 Pref checkbutton is not \
selected, then all commands will be directed to the individual DASs \
using the ID numbers in the DAS list. If all of the DASs in the DAS \
list have not been selected then CHANGEO will send the all commands \
to the individual DASs that are selected no matter which state the \
0000 Pref checkbutton is in.\n\
\n\
When commands are sent in the Broadcast Mode no checking of any of \
the response values from the DASs is done. It can't be done since \
all of the DASs will be responding at the same time.\n\
\n\
----- Select All -----\n\
This causes all of the DASs listed in the DAS list to be selected.\n\
\n\
----- ID field and Clear IDs button -----\n\
An individual DAS's ID number may be entered into the ID field and \
the Return key pressed. If that DAS is not in the DAS list it will be \
added to the list if there is an empty slot. If that DAS is already \
in the list it will be removed. The Clear List button will clear all \
DASs from the DAS list.\n\
\n\
----- All Ports On -----\n\
This button will open and close the serial port quickly 15 times \
which should cause the serial line controller to activate all of the \
transmit lines to the connected DASs. This must be used if the reset \
button on the serial line controller has been pushed, and some DAS IDs \
have been entered manually.\n\
\n\
-----Command Port field -----\n\
Enter the designation for the serial hardware device that should be \
used by CHANGEO to communicate with the DASs. For Windows this will \
be something like COM1, for Linux systems it will be something like \
/dev/ttyUSB0, and for OSX it will be /dev/<something> (it will depend \
on the driver for the serial dongle connected to the USB port of the \
control computer).\n\
\n\
----- STOP -----\n\
When enabled and red this button allows the user to interrupt a \
function. CHANGEO will decide when the time is appropriate for \
stopping. This is generally before proceeding on to the next DAS \
in a series. Between the time when the button is pressed and when the \
program reaches a stopping point the STOP button will be yellow. \
Caution: Stopping in the middle of a command may leave functions \
running on the DASs or leave the DASs in a funny state.\n\
\n\
----- Get CC Time -----\n\
Writes the current GMT time on the control computer to the messages \
section. This could be used as a time stamp in the messages to record \
when something was started or finished for later use.\n\
\n\
----- Receive Parms -----\n\
This will cause CHANGEO to request all of the programming parameters \
from a selected DAS in the DAS list and set CHANGEO's DAS parameters to \
match. Only one DAS may be selected.\n\
\n\
----- Edit Parms -----\n\
This will bring up a separate window from which all of the DAS \
programming parameters may be edited. The parameters are grouped into \
major groups such as data stream and networking parameters. Use the \
buttons on the new window to select the major group that you want to \
work with. There is no 'cancel' button. When a parameter is changed \
you cannot 'undo' the change except by changing the parameter back to \
its previous value.\n\
\n\
----- Summary -----\n\
Prints to the messages section a text summary of the current parameter \
settings. After the listing the routine that quality checks the \
parameters will be called and any problems found will be listed.\n\
\n\
----- Send Parms -----\n\
Sends the DAS parameters to the selected DASs. This function can be \
performed using the Broadcast Mode. The routine that quality checks \
the parameters will be called before the sending operation. All \
problems will need to be corrected before the parameters will be \
allowed to be sent.\n\
\n\
----- Verify Parms -----\n\
Receives the DAS parameters from each DAS and compares them with the \
parameters currently set in CHANGEO. This can be used to verify \
that a set of parameters just sent to the DASs were received OK.\n\
\n\
----- Parms To Disk -----\n\
Sends the command to the selected DASs to write the currently loaded DAS \
parameters to the CompactFlash card drive(s) installed in the units.\n\
\n\
----- Acq/RAM, Parms, GPS, Disk, Volts, -----\n\
----- DAS Status and Loop Control -----\n\
The DAS Status button will query the DASs and write retrieved status \
information to the messages section. Which of the five associated \
checkbuttons that are checked will control which information is \
requested. The Loop Control radiobuttons will tell CHANGEO to \
loop through and request the selected information every 5, 30 or 60 \
seconds until the Stop button is clicked or the \"Off\" Loop Control \
radiobutton is selected.\n\
\n\
----- \"123\", \"456\" and Centering Volts -----\n\
Requests and displays the current sensor centering voltage readings. \
Use the Mass Center test button to send centering commands to the \
sensor(s). Voltages less than +/-1.5V will be green, greater than that \
will be yellow.\n\
\n\
----- Sensor Cal (not yet available) -----\n\
Allows the user to set up and send sensor calibration commands to the \
DASs.\n\
\n\
----- Memory Test -----\n\
This function will command the selected DASs to start their internal \
RAM test. The test on each DAS will begin about 25 seconds after the \
command is sent and will finish in about 40 seconds after it starts. \
CHANGEO will stop looking for DAS responses after about 1 minute and \
20 seconds after the test is started.\n\
\n\
----- Versions/SNs -----\n\
This function queries each DAS and retrieves the software and hardware \
version information. This function cannot be used in the Broadcast \
Mode since CHANGEO must wait for each DAS to respond.\n\
\n\
----- Versions/SNs to PIS -----\n\
This will perform the same function as the Versions/SNs button described \
above, but then send the results from each DAS to the PASSCAL Inventory \
System (PIS).\n\
\n\
----- 1, 2, and Format Disk -----\n\
Sends the command to the DASs to format the selected CompactFlash \
memory card/disk. This command can be sent using the Broadcast Mode.\n\
\n\
----- Clear RAM -----\n\
Sends the command to the DASs to perform the function that clears the \
DAS RAM. This command can be sent using the Broadcast Mode.\n\
\n\
----- Dump RAM -----\n\
Sends the command to the DASs to perform the function that writes the \
contents of the RAM to the CompactFlash memory card/disk. This \
command can be sent using the Broadcast Mode.\n\
\n\
----- Reset -----\n\
Sends the command to the DASs to perform a normal reset. This command \
can be sent using the Broadcast Mode.\n\
\n\
----- Check, Set and Offset Test -----\n\
Sends a sequence of commands to the DASs to check, or check and set \
the DC offset correction values of the DASs. A set of DAS parameters \
enabling the channels to be checked must be sent to the DASs at some \
point before performing this test. This test cannot be performed using the \
Broadcast Mode since CHANGEO must wait for the offset calculation \
results from each DAS.\n\
\n\
----- 1, 2, 3, 4, 5, 6, and Monitor Test buttons -----\n\
Steps through all of the programmed data streams and channels sending \
the commands necessary to perform a monitor test on each one. The \
1,2,3,4,5,6 checkbuttons may be used to tell CHANGEO to skip the \
unselected channels. A plot will appear for each channel tested. When \
all of the channels for a data stream have been plotted an additional \
plot with all of the channels overlayed will be plotted. Following that \
an overlay plot of the first 2 seconds of data (out of 8 seconds) will \
be displayed with the vertical axis exagerated and with CHANGEO attempting \
to shift the waveforms so that the first amplitude peak of each channel's \
data is lined up with all of the other channels so differences in \
amplitude between the different channels will possibly stand out.\n\
\n\
A set of DAS parameters enabling the channels to be checked must \
be sent to the DASs at some point before performing this test. This \
test cannot be performed using the Broadcast Mode since CHANGEO \
must wait for the monitor results from each DAS. Eight seconds of \
data is collected at a sample rate of 20sps, so the DAS parameters \
sent must set the sample rate to 20sps or more.\n\
\n\
When using the function for a \"stomp test\" the stomping should \
start when the message \"Monitoring channel x...\" appears in the \
messages section.\n\
\n\
----- Start Acq and Stop Acq -----\n\
These send the commands to the DASs to start and stop acquisition. No \
check is made to determine the acquisition state before the command is \
sent. The commands can be sent using the Broadcast Mode.\n\
\n\
----- Set Gain High and Set Gain Low -----\n\
These send the commands to the DASs to immediately change the gain \
state of all of the programmed channels. Acquisition does not need to \
be stopped to use this function. A set of parameters enabling the \
channels to be checked must be sent to the DASs at some point before \
performing this test. These functions cannot be performed using the \
Broadcast Mode since each DAS must be asked which of its channels are \
active before the commands are sent.\n\
\n\
----- Sine Cal/Step Cal/Noise Cal -----\n\
These bring up the forms from which to send the sequence of commands \
needed to cause the DASs to generate the associated calibration signal. \
The parameters used are set on the forms that will appear. To stop a \
function early you can either send a different calibration function or \
Reset the DASs. These commands can be sent using the Broadcast Mode.\n\
\n\
----- 123, 456 and Mass Center -----\n\
This button activates the mass centering pulse which lasts for about 7 \
seconds. The command can be sent using the Broadcast Mode. If the \
Broadcast Mode is not used a prompt will be displayed before proceeding \
to each DAS to allow the user time to move the cables used for checking \
the signal from one DAS to the next. The 123 and 456 buttons determine \
which sensor port the Mass Center function will be performed on.\n\
\n\
\n\
PARAMETER NOTES\n\
===============\n\
NETWORKING PARAMETERS\n\
---------------------\n\
When paramters are sent to the DAS all of the current ones are first \
erased from the unit. Normally the Reftek's erase command does not \
affect the network parameters, but CHANGEO sends extra commands to \
also erase those. If the \"None\" radio button on the Network page of \
the DAS parameters dialog box is selected then no setup parameters for \
either the Ethernet, or the serial port will be sent. If either, or \
\"Both\" ports are selected then setup parameters will always be sent \
for both ports. There is no clear method in the actual parameters of \
selecting which port the user intends to use, but the general feeling \
is that the DAS will always try to communicate over a network using \
the serial port first, and the Ethernet port second. This is why the \
parameters for both will be sent even when only one port is going to \
be used. If the Ethernet port is the intended port to program the \
host address for the serial port will always be set to 0.0.0.0.\n\
\n\
\n\
USING THE RT529A FIRMWARE RECOVERY BOARD\n\
========================================\n\
This board is used to recover the firmware on a DAS. This need is \
usually indicated by the Black Screen Of Death when both LCD screen \
lines turn black when powering up and then stay that way.\n\
1. Remove small nuts and bolts and tack DAS case apart.\n\
2. Remove screws holding the circuit boards in place.\n\
3. Locate the RT506C CPU board. Move the jumper on JP2 from\n\
   pins 1 and 2 to pins 2 and 3.\n\
4. Connect the RT529A board to the stack of circuit boards.\n\
5. Connect the DAS's power port to 12VDC.\n\
6. Watch the LCD on the the DAS to determine when the firmware\n\
   reflash is finished.\n\
7. Disconnect power. Remove the RT529A board. Reset the CPU board\n\
   jumper to pins 1 and 2.\n\
8. Power up the DAS again to see thast the reflashing worked.\n\
   Truobleshoot further if necessary.\n\
9. Replace the long screws holding the circuit boards in place.\n\
   Reassemble the DAS's case.\n\
10. Install the latest firmware from a CF card if the RT529A board\n\
    has an earlier version in its EPROMs.\n\
\n\
\n\
DAS LAB BENCH TESTING CHECKLIST\n\
===============================\n\
1. Connect all DASs and check that they all have the same firmware \
version.\n\
2. Select from the Parameters menu Channels 1-3 (or 1-6), Gain 1, 40sps.\n\
3. Send parameters to DASs.\n\
4. Verify parameters.\n\
5. Run CHANGEO tests:\n\
   a. Connect shorted pigtails and run Offset Test.\n\
   b. Connect signal generator and run Monitor Test.\n\
   c. Connect oscilliscope and run Sine, Step, and Noise tests.\n\
   d. Connect signal box and run Mass Center Test on each DAS.\n\
6. Connect interface cable that connects in disk well of DAS and run \
Mem Fill Test.\n\
   a. Open Hyperterminal.\n\
   b. Enter  [.]\n\
   c. Enter   ?\n\
   d. Enter   M  M  A  C  S\n\
   e. Check to see that RAM is completely filled. Clear RAM.\n\
7. Install disks 1 and 2. Format each.\n\
8. Select parameter set 250sps, Gain 1.\n\
9. Send parameters.\n\
10. Verify parameters.\n\
11. Check that all clocks are locked or have locked.\n\
12. Start acauisition.\n\
13. Set gain high after approximately 3 minutes. Wait until all are \
shown to be set to the new gain setting on CHANGEO.\n\
14. Stop acquisition after about 5-10 minutes from when the last \
DAS's gain went high.\n\
15. Offload, convert and look at data in PQL and LOGPEEK. If OK start \
the overnight test, otherwise troubleshoot.\n\
16. Change signal input to all DASs to 1ppm.\n\
17. Select parameter set 40sps, Gain 1.\n\
18. Send parameters.\n\
19. Verify parameters.\n\
20. Clear RAM.\n\
21. Reset. Start acquisition.\n\
22. Next day, offload, convert and look at data in PQL and LOGPEEK. \
Signoff on good DASs, cables and clocks. Make entries in PIS. \
Troubleshoot any bad DASs and clocks.\n\
\n\
END\n"




#########################
# BEGIN: formHELP(Parent)
# LIB:formHELP():2010.284
#   Put the help contents in global variable HELPText somewhere in the
#   program.
Frm["HELP"] = None
HELPFindLookForVar = StringVar()
HELPFindLastLookForVar = StringVar()
HELPFindLinesVar = StringVar()
HELPFindIndexVar = IntVar()
PROGSetups += ("HELPFindLookForVar", )
HELPHeight = 25
HELPWidth = 80
HELPFont = PROGMonoFont

def formHELP(Parent):
    if Frm["HELP"] != None:
        Frm["HELP"].deiconify()
        Frm["HELP"].lift()
        return
    LFrm = Frm["HELP"] = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "HELP"))
    LFrm.title("Help - %s"%PROG_NAME)
    LFrm.iconname("Help")
    Sub = Frame(LFrm)
    LTxt = Txt["HELP"] = Text(Sub, width = HELPWidth, height = HELPHeight, \
            wrap = WORD, font = HELPFont, relief = SUNKEN)
    LTxt.pack(side = LEFT, expand = YES, fill = BOTH)
    LSb = Scrollbar(Sub, orient = VERTICAL, command = LTxt.yview)
    LSb.pack(side = RIGHT, fill = Y)
    LTxt.configure(yscrollcommand = LSb.set)
    Sub.pack(side = TOP, expand = YES, fill = BOTH)
    Sub = Frame(LFrm)
    labelTip(Sub, "Find:=", LEFT, 30, "[Find]")
    LEnt = Entry(Sub, width = 20, textvariable = HELPFindLookForVar)
    LEnt.pack(side = LEFT)
    LEnt.bind("<Double-Button-1>", Command(formKB, "HELP", "Find", \
            HELPFindLookForVar))
    LEnt.bind("<Return>", Command(formFind, "HELP", "HELP"))
    LEnt.bind("<KP_Enter>", Command(formFind, "HELP", "HELP"))
    BButton(Sub, text = "Find", command = Command(formFind, \
            "HELP", "HELP")).pack(side = LEFT)
    BButton(Sub, text = "Next", command = Command(formFindNext, \
            "HELP", "HELP")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Write To "+PROG_NAMELC+".doc", \
            command = Command(formHELPWrite, LTxt)).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Close", fg = Clr["R"], \
            command = Command(closeForm, "HELP")).pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3, pady = 3)
    Msg["HELP"] = Text(LFrm, font = PROGMsgFont, height = 3, wrap = WORD)
    Msg["HELP"].pack(side = TOP, fill = X)
    LTxt.insert(END, HELPText)
# Clear this so the formFind() routine does the right thing if this form was
# brought up previously.
    HELPFindLinesVar.set("")
    center(Parent, LFrm, "C", "I", True)
    return
#####################################
# BEGIN: formHELPWrite(Who, e = None)
# FUNC:formHELPWrite():2010.177
def formHELPWrite(Who, e = None):
    Filespec = PROGWorkDirVar.get()+PROG_NAMELC+PROG_VERSION+".doc"
    try:
        Fp = open(Filespec, "wb")
    except Exception, e:
        msgLn(0, "M", "Error opening help file\n   %s\n   %s"%(Filespec, e), \
                True, 3)
        return
    Fp.write("Help for %s version %s\n\n"%(PROG_NAME, PROG_VERSION))
    N = 1
    while 1:
        if Who.get("%d.0"%N) == "":
            break
# The lines from the Text field do not come with a \n after each screen line,
# so we'll have to split the lines up ourselves.
        Line = Who.get("%d.0"%N, "%d.0"%(N+1))
        N += 1
        if len(Line) < 65:
            Fp.write(Line)
            continue
        Out = ""
        for c in Line:
            if c == " " and len(Out) > 60:
                Fp.write(Out+"\n")
                Out = ""
            elif c == "\n":
                Fp.write(Out+"\n")
                Out == ""
            else:
                Out += c
    Fp.close()
    setMsg("HELP", "", "Help written to\n   %s"%Filespec)
    return
# END: formHELP




#########################
# BEGIN: formPARMS(Which)
# FUNC:formPARMS():2010.201
Frm["PARMS"] = None
PARMSFormatCodes = ("16", "32", "CO", "C2")
PARMSLastSubPacked = ""

def formPARMS(Which):
    global PARMSLastSubPacked
    if Frm["PARMS"] == None:
        LFrm = Frm["PARMS"] = Toplevel(Root)
        LFrm.withdraw()
        LFrm.title("Edit Parms")
        LFrm.protocol("WM_DELETE_WINDOW", formPARMSClose)
# Selection buttons.
        Sub = Frame(LFrm, bd = 1, relief = GROOVE)
        SSub = Frame(Sub, bd = 3)
        for i in (("Station", "SubSta"), ("Channels", "SubChan"), \
                ("Streams", "SubDS"), ("Aux Data", "SubAux"), \
                ("Auto-center", "SubACent"), ("Disks", "SubDisk"), \
                ("Network", "SubNet"), ("GPS Control", "SubGPS")):
            BButton(SSub, text = i[0], command = Command(formPARMSShowSub, \
                    i[1])).pack(side = TOP, fill = X)
        SSub.pack(side = TOP, fill = X)
        SSub = Frame(Sub, bd = 3)
        BButton(SSub, text = "Check\nParameters", \
                command = checkParmsCmd).pack(side = TOP, fill = X)
        SSub.pack(side = TOP, fill = X)
        SSub = Frame(Sub, bd = 3)
        BButton(SSub, text = "Clear All\nParameters", \
                command = formPARMSClearParmsCmd).pack(side = TOP, fill = X)
        SSub.pack(side = TOP, fill = X)
        SSub = Frame(Sub, bd = 3)
        BButton(SSub, text = "Close", \
                command = formPARMSClose).pack(side = TOP, fill = X)
        SSub.pack(side = TOP, fill = X)
        Sub.pack(side = LEFT, expand = YES, fill = BOTH)
        SubFrame = Frame(LFrm)
# Station parameters.
        Subs["Sta"] = Frame(SubFrame)
        Label(Subs["Sta"], text = "STATION PARAMETERS\n").pack(side = TOP, \
                pady = 3)
        Sub = Frame(Subs["Sta"])
        Label(Sub, text = "Experiment name:").pack(side = LEFT)
        Entry(Sub, textvariable = PExpName, width = 24).pack(side = LEFT)
        Sub.pack(side = TOP, anchor = W, padx = 5)
        Sub = Frame(Subs["Sta"])
        Label(Sub, text = "Experiment comment:").pack(side = LEFT)
        Entry(Sub, textvariable = PExpComment, width = 40).pack(side = LEFT)
        Sub.pack(side = TOP, anchor = W, padx = 5)
# Channel parameters.
        Subs["Chan"] = Frame(SubFrame)
        Label(Subs["Chan"], text = "CHANNEL PARAMETERS").pack(side = TOP, \
                pady = 3)
        for i in xrange(1, 1+6):
            Sub = Frame(Subs["Chan"], bd = 2, relief = GROOVE)
            Label(Sub, text = "Channel %d"%i, bd = 3).pack(side = TOP)
            SSub = Frame(Sub)
            Label(SSub, text = "Gain:").pack(side = LEFT)
            for j in (("Not Used", 0), ("1", 1), ("32", 32)):
                Radiobutton(SSub, text = j[0], value = j[1], \
                        variable = eval("PC%dGain"%i)).pack(side = LEFT, \
                        fill = X)
            SSub.pack(side = TOP, anchor = W)
            SSub = Frame(Sub)
            Label(SSub, text = "Channel Name:").pack(side = LEFT)
            Entry(SSub, textvariable = eval("PC%dName"%i), \
                    width = 10).pack(side = LEFT)
            SSub.pack(side = TOP, anchor = W)
            SSub = Frame(Sub)
            Label(SSub, text = "Comment:").pack(side = LEFT)
            Entry(SSub, textvariable = eval("PC%dComment"%i), \
                    width = 40).pack(side = LEFT)
            SSub.pack(side = TOP, anchor = W)
            Sub.pack(side = TOP, expand = YES, fill = BOTH)
# Data stream parameters.
        Subs["DS"] = Frame(SubFrame)
        Label(Subs["DS"], text = "DATA STREAM PARAMETERS").pack(side = TOP, \
                pady = 3)
        for d in xrange(1, 1+4):
            Subs["DS%d"%d] = Frame(Subs["DS"], bd = 2, relief = GROOVE)
            Sub = Frame(Subs["DS%d"%d])
            SSub = Frame(Sub)
            Label(SSub, text = "Data Stream %d Name:"%d, \
                    bd = 3).pack(side = LEFT)
            Entry(SSub, textvariable = eval("PDS%dName"%d), \
                    width = 16).pack(side = LEFT)
            SSub.pack(side = TOP)
            SSub = Frame(Sub)
            Label(SSub, text = "Trigger Type:").pack(side = LEFT)
            SSS = Frame(SSub)
            SSSS = Frame(SSS)
            for i in (("Not Used", 0), ("CON", 1), ("CRS", 2), ("EVT", 3)):
                Radiobutton(SSSS, text = i[0], value = i[1], \
                        command = Command(formPARMSShowEvent, d), \
                        variable = eval("PDS%dTType"%d)).pack(side = LEFT, \
                        fill = X)
            SSSS.pack(side = TOP)
            SSSS = Frame(SSS)
            for i in (("EXT", 4), ("LEV", 5), ("TIM", 6), ("TML", 7), \
                    ("*VOT", 8)):
                Radiobutton(SSSS, text = i[0], value = i[1], \
                        command = Command(formPARMSShowEvent, d), \
                        variable = eval("PDS%dTType"%d)).pack(side = LEFT, \
                        fill = X)
            SSSS.pack(side = TOP)
            SSS.pack(side = LEFT)
            SSub.pack(side = TOP, anchor = W)
            SSub = Frame(Sub)
            Label(SSub, text = "Data Destination:").pack(side = LEFT)
            Checkbutton(SSub, text = "Disk", \
                    variable = eval("PDS%dDisk"%d)).pack(side = LEFT)
            Checkbutton(SSub, text = "Ethernet", \
                    variable = eval("PDS%dEther"%d)).pack(side = LEFT)
            Checkbutton(SSub, text = "Serial", \
                    variable = eval("PDS%dSerial"%d)).pack(side = LEFT)
            Checkbutton(SSub, text = "RAM", \
                    variable = eval("PDS%dRam"%d)).pack(side = LEFT)
            SSub.pack(side = TOP, anchor = W)
            SSub = Frame(Sub)
            Label(SSub, text = "Included Channels:").pack(side = LEFT)
            for c in xrange(1, 1+6):
                Checkbutton(SSub, text = str(c), \
                        variable = eval("PDS%dChan%d"%(d,c))).pack(side = LEFT)
            SSub.pack(side = TOP, anchor = W)
            SSub = Frame(Sub)
            Label(SSub, text = "Sample Rate (sps):").pack(side = LEFT)
            Entry(SSub, textvariable = eval("PDS%dSampRate"%d), \
                    width = 4).pack(side = LEFT)
            SSub.pack(side = TOP, anchor = W)
            SSub = Frame(Sub)
            Label(SSub, text = "Data Format:").pack(side = LEFT)
            for i in PARMSFormatCodes:
                Radiobutton(SSub, text = i, value = i, \
                        variable = eval("PDS%dFormat"%d)).pack(side = LEFT, \
                        fill = X)
            SSub.pack(side = TOP, anchor = W)
            Sub.pack(side = LEFT)
# Data stream CON trigger.
            Subs["CON%d"%d] = Frame(Subs["DS%d"%d], bd = 1, relief = GROOVE)
            Sub = Frame(Subs["CON%d"%d])
            Label(Sub, text = "Start Time\n(yyyydddhhmmss):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dStart1"%d), \
                    width = 13).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["CON%d"%d])
            Label(Sub, text = "Record Length (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dRl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
# Data stream CRS trigger.
            Subs["CRS%d"%d] = Frame(Subs["DS%d"%d], bd = 1, relief = GROOVE)
            Sub = Frame(Subs["CRS%d"%d])
            Label(Sub, text = "Trigger Stream:").pack(side = LEFT)
            for i in xrange(1, 1+6):
                Radiobutton(Sub, text = "%d"%i, value = i, \
                        variable = eval("PDS%dTStrm"%d)).pack(side = LEFT, \
                        fill = X)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["CRS%d"%d])
            Label(Sub, text = "Pre-trigger Length (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dPretl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["CRS%d"%d])
            Label(Sub, text = "Record Length (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dRl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
# Data stream EVT trigger.
            Subs["EVT%d"%d] = Frame(Subs["DS%d"%d], bd = 1, relief = GROOVE)
            Sub = Frame(Subs["EVT%d"%d])
            Label(Sub, text = "Trigger Channels:").pack(side = LEFT)
            for c in xrange(1, 1+6):
                Checkbutton(Sub, text = str(c), \
                       variable = eval("PDS%dTChan%d"%(d,c))).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["EVT%d"%d])
            Label(Sub, text = "Trigger Window (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dTwin"%d), \
                    width = 8).pack(side = LEFT)
            Label(Sub, text = "  Minimum Channels:").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dMc"%d), \
                    width = 2).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["EVT%d"%d])
            Label(Sub, text = "Record Length (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dRl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["EVT%d"%d])
            Label(Sub, text = "Pre-trigger (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dPretl"%d), \
                    width = 8).pack(side = LEFT)
            Label(Sub, text = "  Post-trigger (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dPostl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["EVT%d"%d])
            Label(Sub, text = "STA (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dSta"%d), \
                    width = 8).pack(side = LEFT)
            Label(Sub, text = "  LTA (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dLta"%d), \
                    width = 8).pack(side = LEFT)
            Label(Sub, text = " LTA Hold:").pack(side = LEFT)
            Radiobutton(Sub, text = "Off", value = 0, \
                    variable = eval("PDS%dHold"%d)).pack(side = LEFT, fill = X)
            Radiobutton(Sub, text = "On", value = 1, \
                    variable = eval("PDS%dHold"%d)).pack(side = LEFT, fill = X)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["EVT%d"%d])
            Label(Sub, text = "Trigger Ratio:").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dTr"%d), \
                    width = 8).pack(side = LEFT)
            Label(Sub, text = "  De-trigger Ratio:").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dDtr"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["EVT%d"%d])
            Label(Sub, text = "LP Frequency (Hz):").pack(side = LEFT)
            for i in (("Off", 0), ("0.0", 1), ("12.0", 2)):
                Radiobutton(Sub, text = i[0], value = i[1], \
                        variable = eval("PDS%dLPFreq"%d)).pack(side = LEFT, \
                        fill = X)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["EVT%d"%d])
            Label(Sub, text = "HP Frequency (Hz):").pack(side = LEFT)
            for i in (("Off", 0), ("0.0", 1), ("0.1", 2), ("2.0", 3)):
                Radiobutton(Sub, text = i[0], value = i[1], \
                        variable = eval("PDS%dHPFreq"%d)).pack(side = LEFT, \
                        fill = X)
            Sub.pack(side = TOP, anchor = W)
# Data stream EXT trigger.
            Subs["EXT%d"%d] = Frame(Subs["DS%d"%d], bd = 1, relief = GROOVE)
            Sub = Frame(Subs["EXT%d"%d])
            Label(Sub, text = "Pre-trigger Length (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dPretl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["EXT%d"%d])
            Label(Sub, text = "Record Length (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dRl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
# Data stream LEV trigger.
            Subs["LEV%d"%d] = Frame(Subs["DS%d"%d], bd = 1, relief = GROOVE)
            Sub = Frame(Subs["LEV%d"%d])
            Label(Sub, \
                    text = "Trigger Level (G/M/%/H/counts):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dTlvl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["LEV%d"%d])
            Label(Sub, text = "LP Frequency (Hz):").pack(side = LEFT)
            for i in (("Off", 0), ("0.0", 1), ("12.0", 2)):
                Radiobutton(Sub, text = i[0], value = i[1], \
                        variable = eval("PDS%dLPFreq"%d)).pack(side = LEFT, \
                        fill = X)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["LEV%d"%d])
            Label(Sub, text = "HP Frequency (Hz):").pack(side = LEFT)
            for i in (("Off", 0), ("0.0", 1), ("0.1", 2), ("2.0", 3)):
                Radiobutton(Sub, text = i[0], value = i[1], \
                        variable = eval("PDS%dHPFreq"%d)).pack(side = LEFT, \
                        fill = X)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["LEV%d"%d])
            Label(Sub, text = "Pre-trigger Length (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dPretl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["LEV%d"%d])
            Label(Sub, text = "Record Length (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dRl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
# Data stream TIM trigger.
            Subs["TIM%d"%d] = Frame(Subs["DS%d"%d], bd = 1, relief = GROOVE)
            Sub = Frame(Subs["TIM%d"%d])
            Label(Sub, text = "Start Time\n(yyyydddhhmmss):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dStart1"%d), \
                    width = 13).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["TIM%d"%d])
            Label(Sub, text = "Repeat Interval\n(ddhhmmss):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dRepInt"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["TIM%d"%d])
            Label(Sub, text = "Number Of Triggers:").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dNumTrig"%d), \
                    width = 4).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["TIM%d"%d])
            Label(Sub, text = "Record Length (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dRl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
# Data stream TML trigger.
            Subs["TML%d"%d] = Frame(Subs["DS%d"%d], bd = 1, relief = GROOVE)
            Sub = Frame(Subs["TML%d"%d])
            Label(Sub, \
                    text = "Start Time 1 (yyyydddhhmmss):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dStart1"%d), \
                    width = 13).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            for i in xrange(2, 1+11, 2):
                Sub = Frame(Subs["TML%d"%d])
                Label(Sub, text = "Time %d:"%i).pack(side = LEFT)
                Entry(Sub, textvariable = eval("PDS%dStart%d"%(d,i)), \
                        width = 13).pack(side = LEFT)
                Label(Sub, text = "  Time %d:"%(i+1)).pack(side = LEFT)
                Entry(Sub, textvariable = eval("PDS%dStart%d"%(d,(i+1))), \
                        width = 13).pack(side = LEFT)
                Sub.pack(side = TOP, anchor = W)
            Sub = Frame(Subs["TML%d"%d])
            Label(Sub, text = "Record Length (sec):").pack(side = LEFT)
            Entry(Sub, textvariable = eval("PDS%dRl"%d), \
                    width = 8).pack(side = LEFT)
            Sub.pack(side = TOP, anchor = W)
            Subs["DS%d"%d].pack(side = TOP, anchor = W)
# Auxiliary data parameters.
        Subs["Aux"] = Frame(SubFrame)
        Label(Subs["Aux"], \
                text = "AUXILIARY DATA PARAMETERS\n" \
                ).pack(side = TOP, pady = 3)
        Sub = Frame(Subs["Aux"])
        SSub = Frame(Sub)
        Label(SSub, text = "Sample Period (sec):").pack(side = LEFT)
        Radiobutton(SSub, text = "Not Used", variable = PAuxSPer, \
                value = "").pack(side = LEFT)
        Radiobutton(SSub, text = "1", variable = PAuxSPer, \
                value = "1").pack(side = LEFT)
        Radiobutton(SSub, text = "10", variable = PAuxSPer, \
                value = "10").pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Marker (2digits):").pack(side = LEFT)
        Entry(SSub, textvariable = PAuxMarker, width = 2).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Data Destination:").pack(side = LEFT)
        Checkbutton(SSub, text = "Disk", variable = PAuxDisk).pack(side = LEFT)
        Checkbutton(SSub, text = "Ethernet", \
                variable = PAuxEther).pack(side = LEFT)
        Checkbutton(SSub, text = "Serial", \
                variable = PAuxSerial).pack(side = LEFT)
        Checkbutton(SSub, text = "RAM", variable = PAuxRam).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Included Channels:").pack(side = LEFT)
        SSSub = Frame(SSub)
        SSSSub = Frame(SSSub)
        for c in xrange(1, 1+8):
            Checkbutton(SSSSub, text = str(c), \
                    variable = eval("PAuxChan%d"%c)).pack(side = LEFT)
        SSSSub.pack(side = TOP, anchor = "w")
        SSSSub = Frame(SSSub)
        for c in xrange(9, 9+8):
            Checkbutton(SSSSub, text = str(c), \
                    variable = eval("PAuxChan%d"%c)).pack(side = LEFT)
        SSSSub.pack(side = TOP, anchor = "w")
        SSSub.pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Record Length (sec):").pack(side = LEFT)
        Entry(SSub, textvariable = PAuxRl, width = 8).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        Sub.pack(side = TOP, anchor = W)
# Auto-centering parameters.
        Subs["ACent"] = Frame(SubFrame)
        Label(Subs["ACent"], text = "AUTO-CENTERING PARAMETERS\n", \
                ).pack(side = TOP, pady = 3)
        Sub = Frame(Subs["ACent"])
        SSub = Frame(Sub)
        Label(SSub, text = "Channel Group:").pack(side = LEFT)
        for i in (("Not used", 0), ("123", 123), ("456", 456)):
            Radiobutton(SSub, text = i[0], value = i[1], \
                    variable = PACGroup).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Enabled:").pack(side = LEFT)
        for i in (("No", 0), ("Yes", 1)):
            Radiobutton(SSub, text = i[0], value = i[1], \
                    variable = PACEnable).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Cycle Time (days):").pack(side = LEFT)
        Entry(SSub, textvariable = PACCycle, width = 2).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Threshold (Volts):").pack(side = LEFT)
        Entry(SSub, textvariable = PACThresh, width = 4).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Attempts Per Cycle:").pack(side = LEFT)
        Entry(SSub, textvariable = PACAttempt, width = 2).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Retry Interval (min):").pack(side = LEFT)
        Entry(SSub, textvariable = PACRetry, width = 2).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Sample Period (sec):").pack(side = LEFT)
        for i in (("10", 10), ("100", 100)):
            Radiobutton(SSub, text = i[0], value = i[1], \
                    variable = PACPeriod).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        Sub.pack(side = TOP, anchor = W)
# Disk parameters.
        Subs["Disk"] = Frame(SubFrame)
        Label(Subs["Disk"], text = "DISK PARAMETERS\n").pack(side = TOP, \
                pady = 3)
        Sub = Frame(Subs["Disk"])
        SSub = Frame(Sub)
        Label(SSub, text = "Disk wrap:").pack(side = LEFT)
        for i in (("Disabled", 0), ("Enabled", 1)):
            Radiobutton(SSub, text = i[0], value = i[1], \
                    variable = PDWrap).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Disk Dump Threshold (%RAM):").pack(side = LEFT)
        Entry(SSub, textvariable = PDThresh, width = 2).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Dump On\nEvent Trailer?:").pack(side = LEFT)
        for i in (("No", 0), ("Yes", 1)):
            Radiobutton(SSub, text = i[0], value = i[1], \
                    variable = PDETDump).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Disk Retry (days):").pack(side = LEFT)
        Entry(SSub, textvariable = PDRetry, width = 1).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        Sub.pack(side = TOP, anchor = W)
# Network parameters.
        Subs["Net"] = Frame(SubFrame)
        Label(Subs["Net"], text = "NETWORK PARAMETERS").pack(side = TOP, \
                pady = 3)
        Sub = Frame(Subs["Net"])
        Label(Sub, text = "Intend To Use\nWhich Port?:").pack(side = LEFT)
        for i in (("None", 0), ("Ethernet", 1), ("SerialPPP", 2), ("Both", 3)):
            Radiobutton(Sub, text = i[0], value = i[1], \
                    variable = PNPort).pack(side = LEFT)
        Sub.pack(side = TOP)
        Sub = Frame(Subs["Net"], bd = 2, relief = GROOVE)
        SSub = Frame(Sub)
        Label(SSub, text = "Ethernet Port").pack(side = LEFT)
        SSub.pack(side = TOP)
        SSub = Frame(Sub)
        Label(SSub, text = "Port Power:").pack(side = LEFT)
        for i in (("Auto", 2), ("Continuous", 1)):
            Radiobutton(SSub, text = i[0], value = i[1], \
                    variable = PNEPortPow).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Line Down Action:").pack(side = LEFT)
        for i in (("Keep data", 1), ("Toss data", 2)):
            Radiobutton(SSub, text = i[0], value = i[1], \
                    variable = PNEKeep).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Toss Delay (min):").pack(side = LEFT)
        Entry(SSub, textvariable = PNETDelay, width = 2).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "IP Address\n(xxx.xxx.xxx.xxx):").pack(side = LEFT)
        Entry(SSub, textvariable = PNEIP1, width = 3).pack(side = LEFT)
        Label(SSub, text = ".").pack(side = LEFT)
        Entry(SSub, textvariable = PNEIP2, width = 3).pack(side = LEFT)
        Label(SSub, text = ".").pack(side = LEFT)
        Entry(SSub, textvariable = PNEIP3, width = 3).pack(side = LEFT)
        Label(SSub, text = ".").pack(side = LEFT)
        Entry(SSub, textvariable = PNEIP4, width = 3).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "IP Fill:").pack(side = LEFT)
        for i in (("Use ID", 1), ("Sequential", 2), ("Use As Entered", 3)):
            Radiobutton(SSub, text = i[0], value = i[1], \
                    variable = PNEFill).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Net Mask:").pack(side = LEFT)
        Entry(SSub, textvariable = PNEMask, width = 15).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Gateway Address:").pack(side = LEFT)
        Entry(SSub, textvariable = PNEGateway, width = 15).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Remote Host Address:").pack(side = LEFT)
        Entry(SSub, textvariable = PNEHost, width = 15).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        Sub.pack(side = TOP, anchor = W, expand = YES, fill = X)
# Ethernet part.
        Sub = Frame(Subs["Net"], bd = 2, relief = GROOVE)
        SSub = Frame(Sub)
        Label(SSub, text = "SerialPPP Port").pack(side = LEFT)
        SSub.pack(side = TOP)
        SSub = Frame(Sub)
        Label(SSub, text = "Line Down Action:").pack(side = LEFT)
        for i in (("Keep Data", 1), ("Toss Data", 2)):
            Radiobutton(SSub, text = i[0], value = i[0], \
                    variable = PNSKeep).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Toss Delay (min):").pack(side = LEFT)
        Entry(SSub, textvariable = PNSTDelay, width = 2).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Mode:").pack(side = LEFT)
        for i in (("Direct", 1), ("AT/Modem", 2), ("Freewave", 3)):
            Radiobutton(SSub, text = i[0], value = i[1], \
                    variable = PNSMode).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Speed:").pack(side = LEFT)
        for i in (("9600", 9600), ("19200", 19200), ("57600", 57600), \
                ("115200", 115200)):
            Radiobutton(SSub, text = i[0], value = i[1], \
                    variable = PNSSpeed).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "IP Address\n(xxx.xxx.xxx.xxx):").pack(side = LEFT)
        Entry(SSub, textvariable = PNSIP1, width = 3).pack(side = LEFT)
        Label(SSub, text = ".").pack(side = LEFT)
        Entry(SSub, textvariable = PNSIP2, width = 3).pack(side = LEFT)
        Label(SSub, text = ".").pack(side = LEFT)
        Entry(SSub, textvariable = PNSIP3, width = 3).pack(side = LEFT)
        Label(SSub, text = ".").pack(side = LEFT)
        Entry(SSub, textvariable = PNSIP4, width = 3).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "IP Fill:").pack(side = LEFT)
        for i in (("Use ID", 1), ("Sequential", 2), ("Use As Entered", 3)):
            Radiobutton(SSub, text = i[0], value = i[1], \
                    variable = PNSFill).pack(side = LEFT, fill = X)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Net Mask:").pack(side = LEFT)
        Entry(SSub, textvariable = PNSMask, width = 15).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Gateway Address:").pack(side = LEFT)
        Entry(SSub, textvariable = PNSGateway, width = 15).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        SSub = Frame(Sub)
        Label(SSub, text = "Remote Host Address:").pack(side = LEFT)
        Entry(SSub, textvariable = PNSHost, width = 15).pack(side = LEFT)
        SSub.pack(side = TOP, anchor = W)
        Sub.pack(side = TOP, anchor = W, expand = YES, fill = X)
        SubFrame.pack(side = LEFT, expand = YES, fill = BOTH)
# GPS control parameters.
        Subs["GPS"] = Frame(SubFrame)
        Label(Subs["GPS"], text = "GPS CONTROL PARAMETERS\n" \
                ).pack(side = TOP, padx = 20, pady = 3)
        Radiobutton(Subs["GPS"], text = "Normal Duty Cycle", \
                variable = PGPSMode, value = "D").pack(side = TOP)
        Radiobutton(Subs["GPS"], text = "Continuous", variable = PGPSMode, \
                value = "C").pack(side = TOP)
        Radiobutton(Subs["GPS"], text = "Off", variable = PGPSMode, \
                value = "O").pack(side = TOP)
        center(Root, LFrm, "NW", "O", True)
    else:
        LFrm = Frm["PARMS"]
# Pick a panel to show.
    if Which != PARMSLastSubPacked:
        Subs["Sta"].pack_forget()
        Subs["Chan"].pack_forget()
        Subs["DS"].pack_forget()
        Subs["Aux"].pack_forget()
        Subs["ACent"].pack_forget()
        Subs["Disk"].pack_forget()
        Subs["Net"].pack_forget()
        Subs["GPS"].pack_forget()
        if Which == "SubSta":
            Subs["Sta"].pack(side = TOP, expand = YES, fill = BOTH)
        elif Which == "SubChan":
            Subs["Chan"].pack(side = TOP, expand = YES, fill = BOTH)
        elif Which == "SubDS":
            Subs["DS"].pack(side = TOP, expand = YES, fill = BOTH)
            formPARMSShowEvents()
        elif Which == "SubAux":
            Subs["Aux"].pack(side = TOP, expand = YES, fill = BOTH)
        elif Which == "SubACent":
            Subs["ACent"].pack(side = TOP, expand = YES, fill = BOTH)
        elif Which == "SubDisk":
            Subs["Disk"].pack(side = TOP, expand = YES, fill = BOTH)
        elif Which == "SubNet":
            Subs["Net"].pack(side = TOP, expand = YES, fill = BOTH)
        elif Which == "SubGPS":
            Subs["GPS"].pack(side = TOP, expand = YES, fill = BOTH)
        PARMSLastSubPacked = Which
        LFrm.lift()
    updateMe(0)
    return
################################
# BEGIN: formPARMSShowSub(Which)
# FUNC:formPARMSShowSub():2009.327
def formPARMSShowSub(Which):
    formPARMS(Which)
    return
############################
# BEGIN: formPARMSShowEdit()
# FUNC:formPARMSShowEdit():2009.327
#   Show commands for parameter frames.
def formPARMSShowEdit():
    if Frm["PARMS"] == None:
        formPARMS("SubSta")
    else:
       Frm["PARMS"].deiconify()
       Frm["PARMS"].lift()
    return
##############################
# BEGIN: formPARMSShowEvents()
# FUNC:formPARMSShowEvents():2009.327
#   Just calls formPARMSShowEvent() if it is safe.
def formPARMSShowEvents():
    if Frm["PARMS"] != None:
        formPARMSShowEvent(1)
        formPARMSShowEvent(2)
        formPARMSShowEvent(3)
        formPARMSShowEvent(4)
    return
##############################
# BEGIN: formPARMSShowEvent(e)
# FUNC:formPARMSShowEvent():2009.327
#   Handles making the right set of event parameters show up when
#   one of the event radiobuttons are pushed.
def formPARMSShowEvent(e):
    Subs["CON%d"%e].pack_forget()
    Subs["CRS%d"%e].pack_forget()
    Subs["EVT%d"%e].pack_forget()
    Subs["EXT%d"%e].pack_forget()
    Subs["LEV%d"%e].pack_forget()
    Subs["TIM%d"%e].pack_forget()
    Subs["TML%d"%e].pack_forget()
    if eval("PDS%dTType"%e).get() == 1:
        Subs["CON%d"%e].pack(side = LEFT, expand = YES, fill = BOTH)
    elif eval("PDS%dTType"%e).get() == 2:
        Subs["CRS%d"%e].pack(side = LEFT, expand = YES, fill = BOTH)
    elif eval("PDS%dTType"%e).get() == 3:
        Subs["EVT%d"%e].pack(side = LEFT, expand = YES, fill = BOTH)
    elif eval("PDS%dTType"%e).get() == 4:
        Subs["EXT%d"%e].pack(side = LEFT, expand = YES, fill = BOTH)
    elif eval("PDS%dTType"%e).get() == 5:
        Subs["LEV%d"%e].pack(side = LEFT, expand = YES, fill = BOTH)
    elif eval("PDS%dTType"%e).get() == 6:
        Subs["TIM%d"%e].pack(side = LEFT, expand = YES, fill = BOTH)
    elif eval("PDS%dTType"%e).get() == 7:
        Subs["TML%d"%e].pack(side = LEFT, expand = YES, fill = BOTH)
    return
#################################
# BEGIN: formPARMSClearParmsCmd()
# FUNC:formPARMSClearParmsCmd():2009.327
def formPARMSClearParmsCmd():
    formPARMSClearParms()
    formPARMSShowEvents()
    msgLn(0, "W", "All parameters cleared.")
    return
##############################
# BEGIN: formPARMSClearParms()
# FUNC:formPARMSClearParms():2009.327
def formPARMSClearParms():
    PExpName.set("")
    PExpComment.set("")
    for c in xrange(1, 1+6):
        eval("PC%dName"%c).set("")
        eval("PC%dGain"%c).set(0)
        eval("PC%dComment"%c).set("")
    for d in xrange(1, 1+4):
        eval("PDS%dName"%d).set("")
        eval("PDS%dDisk"%d).set(0)
        eval("PDS%dEther"%d).set(0)
        eval("PDS%dSerial"%d).set(0)
        eval("PDS%dRam"%d).set(0)
        for c in xrange(1, 1+6):
            eval("PDS%dChan%d"%(d,c)).set(0)
        eval("PDS%dSampRate"%d).set("")
        eval("PDS%dFormat"%d).set("")
        eval("PDS%dTType"%d).set(0)
        for c in xrange(1, 1+6):
            eval("PDS%dTChan%d"%(d,c)).set(0)
        eval("PDS%dMc"%d).set("")
        eval("PDS%dPretl"%d).set("")
        eval("PDS%dRl"%d).set("")
        eval("PDS%dSta"%d).set("")
        eval("PDS%dLta"%d).set("")
        eval("PDS%dHold"%d).set(0)
        eval("PDS%dTr"%d).set("")
        eval("PDS%dTwin"%d).set("")
        eval("PDS%dPostl"%d).set("")
        eval("PDS%dDtr"%d).set("")
        for i in xrange(1, 1+11):
            eval("PDS%dStart%d"%(d,i)).set("")
        eval("PDS%dTStrm"%d).set(0)
        eval("PDS%dTlvl"%d).set("")
        eval("PDS%dLPFreq"%d).set(0)
        eval("PDS%dHPFreq"%d).set(0)
        eval("PDS%dRepInt"%d).set("")
        eval("PDS%dNumTrig"%d).set("")
    PAuxMarker.set("")
    for c in xrange(1, 1+16):
        eval("PAuxChan%d"%c).set(0)
    PAuxDisk.set(0)
    PAuxEther.set(0)
    PAuxSerial.set(0)
    PAuxRam.set(0)
    PAuxSPer.set("")
    PAuxRl.set("")
    PACGroup.set(0)
    PACEnable.set(0)
    PACCycle.set("")
    PACThresh.set("")
    PACAttempt.set("")
    PACRetry.set("")
    PACPeriod.set(0)
    PNPort.set(0)
    PNEPortPow.set(0)
    PNEKeep.set(0)
    PNETDelay.set("")
    for i in xrange(1, 1+4):
        eval("PNEIP%d"%i).set("")
    PNEFill.set(1)
    PNEMask.set("")
    PNEHost.set("")
    PNEGateway.set("")
    PNSKeep.set(0)
    PNSTDelay.set("")
    PNSMode.set(0)
    PNSSpeed.set(0)
    for i in xrange(1, 1+4):
        eval("PNSIP%d"%i).set("")
    PNSFill.set(1)
    PNSMask.set("")
    PNSHost.set("")
    PNSGateway.set("")
    PDETDump.set(0)
    PDRetry.set("")
    PDWrap.set(0)
    PDThresh.set("")
    PGPSMode.set("")
    return
#################################
# BEGIN: formPARMSSetParms(Which)
# FUNC:formPARMSSetParms():2010.249
def formPARMSSetParms(Which):
    formPARMSClearParms()
    if Which == "defaults":
        for c in xrange(1, 1+6):
            eval("PC%dName"%c).set("Channel %d"%c)
        for d in xrange(1, 1+4):
            eval("PDS%dName"%d).set("Stream %d"%d)
            eval("PDS%dMc"%d).set("1")
            eval("PDS%dPretl"%d).set("0.0")
            eval("PDS%dRl"%d).set("3600")
            eval("PDS%dSta"%d).set("0.0")
            eval("PDS%dLta"%d).set("0.1")
            eval("PDS%dTr"%d).set("0.1")
            eval("PDS%dTwin"%d).set("0")
            eval("PDS%dPostl"%d).set("0.0")
            eval("PDS%dDtr"%d).set("0.0")
            eval("PDS%dStart1"%d).set("2004001000000")
            eval("PDS%dTlvl"%d).set("0")
            eval("PDS%dNumTrig"%d).set("0")
        PACCycle.set("10")
        PACThresh.set("1.0")
        PACAttempt.set("1")
        PACRetry.set("5")
        PACPeriod.set(10)
        PDRetry.set("3")
        PDThresh.set("66")
    elif Which == "bench":
        formPARMSSetParms("defaults")
        PExpName.set("Bench")
        PExpComment.set("Ch123-DS1/40sps")
        PC1Gain.set(1)
        PC2Gain.set(1)
        PC3Gain.set(1)
        PDS1Disk.set(1)
        PDS1Chan1.set(1)
        PDS1Chan2.set(1)
        PDS1Chan3.set(1)
        PDS1SampRate.set("40")
        PDS1Format.set("CO")
        PDS1TType.set(1)
        PDS1Start1.set("2004001000000")
        PDS1Rl.set("3600")
        formPARMSShowEvents()
        msgLn(0, "", "Ch123-DS1/40sps parameters set.")
    elif Which == "bench6":
        formPARMSSSetParms("defaults")
        PExpName.set("Bench-6")
        PExpComment.set("Ch123-DS1/40sps, Ch456-DS2/40sps")
        PC1Gain.set(1)
        PC2Gain.set(1)
        PC3Gain.set(1)
        PC4Gain.set(1)
        PC5Gain.set(1)
        PC6Gain.set(1)
        PDS1Disk.set(1)
        PDS1Chan1.set(1)
        PDS1Chan2.set(1)
        PDS1Chan3.set(1)
        PDS1SampRate.set("40")
        PDS1Format.set("CO")
        PDS1TType.set(1)
        PDS1Start1.set("2004001000000")
        PDS1Rl.set("3600")
        PDS2Disk.set(1)
        PDS2Chan4.set(1)
        PDS2Chan5.set(1)
        PDS2Chan6.set(1)
        PDS2SampRate.set("40")
        PDS2Format.set("CO")
        PDS2TType.set(1)
        PDS2Start1.set("2004001000000")
        PDS2Rl.set("3600")
        formPARMSShowEvents()
        msgLn(0, "", "Ch123-DS1/40sps, Ch456-DS2/40sps parameters set.")
    elif Which == "1231250":
        formPARMSSetParms("defaults")
        PExpName.set("Bench2")
        PExpComment.set("Ch123-DS1/250sps")
        PC1Gain.set(1)
        PC2Gain.set(1)
        PC3Gain.set(1)
        PDS1Disk.set(1)
        PDS1Chan1.set(1)
        PDS1Chan2.set(1)
        PDS1Chan3.set(1)
        PDS1SampRate.set("250")
        PDS1Format.set("CO")
        PDS1TType.set(1)
        PDS1Start1.set("2004001000000")
        PDS1Rl.set("3600")
        formPARMSShowEvents()
        msgLn(0, "", "Ch123-DS1/250sps parameters set.")
    elif Which == "12312506":
        formPARMSSetParms("defaults")
        PExpName.set("Bench2-6")
        PExpComment.set("Ch123-DS1/250sps, Ch456-DS2/250sps")
        PC1Gain.set(1)
        PC2Gain.set(1)
        PC3Gain.set(1)
        PC4Gain.set(1)
        PC5Gain.set(1)
        PC6Gain.set(1)
        PDS1Disk.set(1)
        PDS1Chan1.set(1)
        PDS1Chan2.set(1)
        PDS1Chan3.set(1)
        PDS1SampRate.set("250")
        PDS1Format.set("CO")
        PDS1TType.set(1)
        PDS1Start1.set("2004001000000")
        PDS1Rl.set("3600")
        PDS2Disk.set(1)
        PDS2Chan4.set(1)
        PDS2Chan5.set(1)
        PDS2Chan6.set(1)
        PDS2SampRate.set("250")
        PDS2Format.set("CO")
        PDS2TType.set(1)
        PDS2Start1.set("2004001000000")
        PDS2Rl.set("3600")
        formPARMSShowEvents()
        msgLn(0, "", "Ch123-DS1/250sps, Ch456-DS2/250sps parameters set.")
    elif Which == "12314021":
        formPARMSSetParms("defaults")
        PExpName.set("Overnight")
        PExpComment.set("Ch123-DS1/40sps-DS2/1sps")
        PC1Gain.set(1)
        PC2Gain.set(1)
        PC3Gain.set(1)
        PDS1Disk.set(1)
        PDS1Chan1.set(1)
        PDS1Chan2.set(1)
        PDS1Chan3.set(1)
        PDS1SampRate.set("40")
        PDS1Format.set("CO")
        PDS1TType.set(1)
        PDS1Start1.set("2004001000000")
        PDS1Rl.set("3600")
        PDS2Disk.set(1)
        PDS2Chan1.set(1)
        PDS2Chan2.set(1)
        PDS2Chan3.set(1)
        PDS2SampRate.set("1")
        PDS2Format.set("CO")
        PDS2TType.set(1)
        PDS2Start1.set("2004001000000")
        PDS2Rl.set("3600")
        formPARMSShowEvents()
        msgLn(0, "", "Ch123-DS1/40sps-DS2/1sps parameters set.")
    elif Which == "123140216":
        formPARMSSetParms("defaults")
        PExpName.set("Overnight")
        PExpComment.set("Ch123-DS1/40-DS2/1, Ch456-DS1/40-DS2/1")
        PC1Gain.set(1)
        PC2Gain.set(1)
        PC3Gain.set(1)
        PC4Gain.set(1)
        PC5Gain.set(1)
        PC6Gain.set(1)
        PDS1Disk.set(1)
        PDS1Chan1.set(1)
        PDS1Chan2.set(1)
        PDS1Chan3.set(1)
        PDS1SampRate.set("40")
        PDS1Format.set("CO")
        PDS1TType.set(1)
        PDS1Start1.set("2004001000000")
        PDS1Rl.set("3600")
        PDS2Disk.set(1)
        PDS2Chan1.set(1)
        PDS2Chan2.set(1)
        PDS2Chan3.set(1)
        PDS2SampRate.set("1")
        PDS2Format.set("CO")
        PDS2TType.set(1)
        PDS2Start1.set("2004001000000")
        PDS2Rl.set("3600")
        PDS3Disk.set(1)
        PDS3Chan4.set(1)
        PDS3Chan5.set(1)
        PDS3Chan6.set(1)
        PDS3SampRate.set("40")
        PDS3Format.set("CO")
        PDS3TType.set(1)
        PDS3Start1.set("2004001000000")
        PDS3Rl.set("3600")
        PDS4Disk.set(1)
        PDS4Chan4.set(1)
        PDS4Chan5.set(1)
        PDS4Chan6.set(1)
        PDS4SampRate.set("1")
        PDS4Format.set("CO")
        PDS4TType.set(1)
        PDS4Start1.set("2004001000000")
        PDS4Rl.set("3600")
        formPARMSShowEvents()
        msgLn(0, "", \
          "Ch123-DS1/40sps-DS2/1sps, Ch456-DS1/40sps-DS2/1sps parameters set.")
    PGPSMode.set("D")
    return
#########################
# BEGIN: formPARMSClose()
# FUNC:formPARMSClose():2009.327
def formPARMSClose():
    global PARMSLastSubPacked
    if Frm["PARMS"] != None:
        closeForm("PARMS")
        PARMSLastSubPacked = ""
    return
# END: formPARMS




####################
# BEGIN: formSRCHM()
# LIB:formSRCHM():2010.162
Frm["SRCHM"] = None
SRCHMSearchVar = StringVar()
SRCHMEraseCVar = IntVar()
SRCHMEraseCVar.set(1)
SRCHMMsgsDirVar = StringVar()
SRCHMLastFilespecVar = StringVar()
PROGSetups += ("SRCHMSearchVar", "SRCHMEraseCVar", "SRCHMMsgsDirVar", \
        "SRCHMLastFilespecVar")

def formSRCHM():
    if showUp("SRCHM"):
        return
    LFrm = Frm["SRCHM"] = Toplevel(Root)
    LFrm.withdraw()
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "SRCHM"))
    LFrm.title("Search Messages")
    Sub = Frame(LFrm)
    LLb = Label(Sub, text = "Search Messages Directory:", relief = GROOVE, \
            bd = 2)
    LLb.pack(side = LEFT)
    ToolTip(LLb, 30, "Right-click to change the directory.")
    LLb.bind("<Button-3>", Command(popDirFID, "SRCHM", "selfmsgs", \
            SRCHMMsgsDirVar))
    Entry(Sub, width = 1, textvariable = SRCHMMsgsDirVar, state = DISABLED, \
            relief = FLAT, bd = 0, bg = Clr["D"], \
            fg = Clr["B"]).pack(side = LEFT, expand = YES, fill = X)
    Sub.pack(side = TOP, anchor = "w", expand = NO, fill = X, padx = 3)
    Sub = Frame(LFrm)
    labelTip(Sub, "Find:=", LEFT, 40, \
            "[Search Current] The string to search for.")
    LEnt = Ent["SRCHM"] = Entry(Sub, textvariable = SRCHMSearchVar)
    LEnt.pack(side = LEFT, expand = YES, fill = X)
    LEnt.bind("<Double-Button-1>", Command(formKB, "SRCHM", "Find", \
                    SRCHMSearchVar))
    LEnt.bind("<Return>", Command(formSRCHMGo, "current"))
    LEnt.bind("<KP_Enter>", Command(formSRCHMGo, "current"))
    LEnt.focus_set()
    LEnt.icursor(END)
    BButton(Sub, text = "Clear", fg = Clr["U"], \
            command = Command(formSRCHMClear, "msg")).pack(side = LEFT)
    Sub.pack(side = TOP, expand = NO, fill = X, padx = 3)
# Results.
    Sub = Frame(LFrm)
    LTxt = Txt["SRCHM"] = Text(Sub, width = 110, height = 25, wrap = WORD, \
            relief = SUNKEN)
    LTxt.pack(side = LEFT, fill = BOTH, expand = YES)
    LSb = Scrollbar(Sub, orient = VERTICAL, command = LTxt.yview)
    LSb.pack(side = RIGHT, fill = Y)
    LTxt.configure(yscrollcommand = LSb.set)
    Sub.pack(side = TOP, fill = BOTH, expand = YES)
    Sub = Frame(LFrm)
    BButton(Sub, text = "Clear All", fg = Clr["U"], \
            command = Command(formSRCHMClear, "all")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    Cb = Checkbutton(Sub, text = "Erase?", variable = SRCHMEraseCVar)
    Cb.pack(side = LEFT)
    ToolTip(Cb, 30, \
            "Erase the results on the form from a previous search or not?")
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Search Current\nMessages", \
            command = Command(formSRCHMGo, "current")).pack(side = LEFT)
    BButton(Sub, text = "Search All\n.msg Files...", \
            command = Command(formSRCHMGo, "files")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Write Results\nTo File...", \
            command = Command(formWrite, "SRCHM", "SRCHM", "SRCHM", \
            "Write Search Results To...", SRCHMLastFilespecVar, \
            True)).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Close", fg = Clr["R"], \
            command = Command(closeForm, "SRCHM")).pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3, pady = 3)
# Status messages.
    Msg["SRCHM"] = Text(LFrm, font = PROGMsgFont, height = 3, wrap = WORD)
    Msg["SRCHM"].pack(side = TOP, fill = X)
    setMsg("SRCHM", "WB", \
           "Enter what to search for in the field at the top of the window.")
    if SRCHMMsgsDirVar.get() == "" or \
            exists(SRCHMMsgsDirVar.get()) == False:
        SRCHMMsgsDirVar.set(PROGMsgsDirVar.get())
    if SRCHMLastFilespecVar.get() == "" or \
            exists(dirname(SRCHMLastFilespecVar.get())) == False:
        SRCHMLastFilespecVar.set(PROGMsgsDirVar.get()+PROG_NAMELC+"search.txt")
    center(Root, LFrm, "C", "I", True)
    return
##############################
# BEGIN: formSRCHMClear(Which)
# FUNC:formSRCHMClear():2009.311
def formSRCHMClear(Which):
    SRCHMSearchVar.set("")
    if Which == "all":
        LTxt = Txt["SRCHM"]
        LTxt.delete(0.0, END)
        LTxt.tag_delete(*LTxt.tag_names())
        setMsg("SRCHM", "", "")
    Ent["SRCHM"].focus_set()
    Ent["SRCHM"].icursor(END)
    return
#####################################
# BEGIN: formSRCHMGo(Which, e = None)
# FUNC:formSRCHMGo():2009.297
def formSRCHMGo(Which, e = None):
    LTxt = Txt["SRCHM"]
    Frm["SRCHM"].focus_set()
    setMsg("SRCHM", "CB", "Searching...")
# Don't .strip() it so you can search for things like " 2006:"
    What = SRCHMSearchVar.get().lower()
    if SRCHMEraseCVar.get() == 1:
        LTxt.delete(0.0, END)
        LTxt.tag_delete(*LTxt.tag_names())
    Lines = []
    N = 1
    if Which == "current":
        while 1:
            if MMsg.get("%d.0"%N) == "":
                break
            Line = MMsg.get("%d.0"%N, "%d.0"%(N+1)).lower()
            if What in Line:
                Lines.append(MMsg.get("%d.0"%N, "%d.0"%(N+1)))
            N += 1
# Special case. If all of the lines start with "USER:" then we should be able
# to sort them in time order by the second word which should be DDD:HH:MM:SS.
# They should already be in time order, but may not be if several different
# messages files have been concatinated.
        AllUSER = True
        for Line in Lines:
            if Line.startswith("USER:") == False:
                AllUSER = False
                break
        if AllUSER == True:
# I like Python. Since "USER: DDD:HH:MM:SS" is the first thing on each line
# then this should handle everything, except a year boundry, but we won't
# worry about that.
            Lines.sort()
        for Line in Lines:
            LTxt.insert(END, Line)
    elif Which == "files":
        TheMsgsDir = SRCHMMsgsDirVar.get()
        Files = listdir(TheMsgsDir)
# With the way some messages files are named (X-YYYYDDD-prog.msg) this might
# help things come out in chronological order.
        Files.sort()
        Searched = []
        for File in Files:
            if File.endswith(PROG_NAMELC+".msg"):
                Searched.append(File)
                try:
                    Fp = open(TheMsgsDir+File, "r")
                    FLines = readFileLines(Fp)
                    Fp.close()
# Try to shorten the file name that will be shown on each line as much as
# possible.
                    LFile = File[:-len(PROG_NAMELC+".msg")]
                    if LFile.endswith("-"):
                        LFile = LFile[:-1]
                except Exception, e:
                    setMsg("SRSHM", "MW", "Error opening file %s\n   %s"% \
                            (File, e), 3)
                    return
                for Line in FLines:
                    if What in Line.lower():
                        Lines.append("%s (%s)\n"%(Line, LFile))
        AllUSER = True
        for Line in Lines:
            if Line.startswith("USER:") == False:
                AllUSER = False
                break
        if AllUSER == True:
# I like Python. Since "USER: DDD:HH:MM:SS" is the first thing on each line
# then this should handle everything, except a year boundry, but we won't
# worry about that.
            Lines.sort()
        for Line in Lines:
            LTxt.insert(END, Line)
        if len(Searched) != 0:
            if len(Lines) != 0:
                LTxt.insert(END, "\n")
            LTxt.insert(END, "Files searched:\n")
            LTxt.insert(END, "   Dir: %s\n"%TheMsgsDir)
            for File in Searched:
                LTxt.insert(END, "   %s\n"%File)
    if len(Lines) == 1:
        setMsg("SRCHM", "WB", "1 match found.")
    else:
        setMsg("SRCHM", "WB", "%d matches found."%len(Lines))
    return
# END: formSRCHM




####################
# BEGIN: getCCTime()
# FUNC:getCCTime():2008.012
def getCCTime():
    msgLn(0, "", "Current CC time: %s"%getGMT(0))
    return
# END: getCCTime




############################
# BEGIN: gpsControlCmd(Mode)
# FUNC:gpsControlCmd():2009.053
def gpsControlCmd(Mode):
    global WorkState
    Status, ListOfDASs = isItOKToStart(3)
    if Status == False:
        return
    WorkState = 100
# Call with None just to control the Stop button
    buttonControl(None, "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        buttonControl(None, "", 0)
        return
    if Mode == "D":
        StrMode = "NORMAL DUTY CYCLE"
    elif Mode == "C":
        StrMode = "CONTINUOUS"
    elif Mode == "O":
        StrMode = "OFF"
    msgLn(1, "C", "Setting GPS mode to %s..."%StrMode)
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        msgLn(1, "C", "   %d. %s: Setting GPS mode..."%(Count, DAS))
        Cmd = rt130CmdFormat(DAS, "GC%s       GC"%Mode)
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(2)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No GPS Control command response!", True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
        formSTATSetStatus(DAS, "G")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
    stoppedMe(WorkState, DAS)
    buttonControl(None, "", 0)
    return
# END: gpsControlCmd




######################
# BEGIN: listDirs(How)
# LIB:listDirs():2008.200changeo
def listDirs(How):
    msgLn(How, "W", "Current messages directory:\n   %s"%PROGMsgsDirVar.get())
    msgLn(How, "W", "Current work directory:\n   %s"%PROGWorkDirVar.get())
    return
# END: listDirs




#######################
# BEGIN: loadParmsCmd()
# FUNC:loadParmsCmd():2010.162
LastPRMFile = ""

def loadParmsCmd():
    global LastPRMFile
    if LastPRMFile == "":
        LoadFile = formMYDF(Root, 3, "Load Parameters From File...", \
                PROGWorkDirVar.get(), "", "", ".prm")
    else:
        LoadFile = formMYDF(Root, 3, "Load Parameters From File...", \
                dirname(LastPRMFile), basename(LastPRMFile), "", ".prm")
    if LoadFile == "":
        msgLn(0, "", "Parameters not loaded.")
        return
    try:
        Fp = open(LoadFile, "r")
    except Exception,e:
        msgLn(1, "M", "Error opening the saved parameters file", True, 3)
        msgLn(1, "M", "   %s"%LoadFile)
        msgLn(0, "M", "   "+str(e))
        return
    formPARMSClearParms()
    Version = Fp.readline().split(":")[1].strip()
    if Version != PFILE_VERSION:
        msgLn(0, "R", "Parameter file version mismatch!", True, 2)
        Fp.close()
        return
    PExpName.set(Fp.readline().split(":")[1].strip())
    PExpComment.set(Fp.readline().split(":")[1].strip())
    for c in xrange(1, 1+6):
        eval("PC%dName"%c).set(Fp.readline().split(":")[1].strip())
        eval("PC%dGain"%c).set(int(Fp.readline().split(":")[1].strip()))
        eval("PC%dComment"%c).set(Fp.readline().split(":")[1].strip())
    for d in xrange(1, 1+4):
        eval("PDS%dName"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dDisk"%d).set(int(Fp.readline().split(":")[1].strip()))
        eval("PDS%dEther"%d).set(int(Fp.readline().split(":")[1].strip()))
        eval("PDS%dSerial"%d).set(int(Fp.readline().split(":")[1].strip()))
        eval("PDS%dRam"%d).set(int(Fp.readline().split(":")[1].strip()))
        for c in xrange(1, 1+6):
            eval("PDS%dChan%d"% \
                    (d,c)).set(int(Fp.readline().split(":")[1].strip()))
        eval("PDS%dSampRate"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dFormat"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dTType"%d).set(int(Fp.readline().split(":")[1].strip()))
        for c in xrange(1, 1+6):
            eval("PDS%dTChan%d"% \
                    (d,c)).set(int(Fp.readline().split(":")[1].strip()))
        eval("PDS%dMc"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dPretl"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dRl"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dSta"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dLta"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dHold"%d).set(int(Fp.readline().split(":")[1].strip()))
        eval("PDS%dTr"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dTwin"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dPostl"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dDtr"%d).set(Fp.readline().split(":")[1].strip())
        for i in xrange(1, 1+11):
            eval("PDS%dStart%d"% \
                    (d,i)).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dTStrm"%d).set(int(Fp.readline().split(":")[1].strip()))
        eval("PDS%dTlvl"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dLPFreq"%d).set(int(Fp.readline().split(":")[1].strip()))
        eval("PDS%dHPFreq"%d).set(int(Fp.readline().split(":")[1].strip()))
        eval("PDS%dRepInt"%d).set(Fp.readline().split(":")[1].strip())
        eval("PDS%dNumTrig"%d).set(Fp.readline().split(":")[1].strip())
    PAuxMarker.set(Fp.readline().split(":")[1].strip())
    for c in xrange(1, 1+16):
        eval("PAuxChan%d"%c).set(int(Fp.readline().split(":")[1].strip()))
    PAuxDisk.set(int(Fp.readline().split(":")[1].strip()))
    PAuxEther.set(int(Fp.readline().split(":")[1].strip()))
    PAuxSerial.set(int(Fp.readline().split(":")[1].strip()))
    PAuxRam.set(int(Fp.readline().split(":")[1].strip()))
    PAuxSPer.set(Fp.readline().split(":")[1].strip())
    PAuxRl.set(Fp.readline().split(":")[1].strip())
    PACGroup.set(int(Fp.readline().split(":")[1].strip()))
    PACEnable.set(int(Fp.readline().split(":")[1].strip()))
    PACCycle.set(Fp.readline().split(":")[1].strip())
    PACThresh.set(Fp.readline().split(":")[1].strip())
    PACAttempt.set(Fp.readline().split(":")[1].strip())
    PACRetry.set(Fp.readline().split(":")[1].strip())
    PACPeriod.set(int(Fp.readline().split(":")[1].strip()))
    PNPort.set(int(Fp.readline().split(":")[1].strip()))
    PNEPortPow.set(int(Fp.readline().split(":")[1].strip()))
    PNEKeep.set(int(Fp.readline().split(":")[1].strip()))
    PNETDelay.set(Fp.readline().split(":")[1].strip())
    PNEIP1.set(Fp.readline().split(":")[1].strip())
    PNEIP2.set(Fp.readline().split(":")[1].strip())
    PNEIP3.set(Fp.readline().split(":")[1].strip())
    PNEIP4.set(Fp.readline().split(":")[1].strip())
    PNEFill.set(int(Fp.readline().split(":")[1].strip()))
    PNEMask.set(Fp.readline().split(":")[1].strip())
    PNEHost.set(Fp.readline().split(":")[1].strip())
    PNEGateway.set(Fp.readline().split(":")[1].strip())
    PNSKeep.set(int(Fp.readline().split(":")[1].strip()))
    PNSTDelay.set(Fp.readline().split(":")[1].strip())
    PNSMode.set(int(Fp.readline().split(":")[1].strip()))
    PNSSpeed.set(int(Fp.readline().split(":")[1].strip()))
    PNSIP1.set(Fp.readline().split(":")[1].strip())
    PNSIP2.set(Fp.readline().split(":")[1].strip())
    PNSIP3.set(Fp.readline().split(":")[1].strip())
    PNSIP4.set(Fp.readline().split(":")[1].strip())
    PNSFill.set(int(Fp.readline().split(":")[1].strip()))
    PNSMask.set(Fp.readline().split(":")[1].strip())
    PNSHost.set(Fp.readline().split(":")[1].strip())
    PNSGateway.set(Fp.readline().split(":")[1].strip())
    PDWrap.set(int(Fp.readline().split(":")[1].strip()))
    PDThresh.set(Fp.readline().split(":")[1].strip())
    PDETDump.set(int(Fp.readline().split(":")[1].strip()))
    PDRetry.set(Fp.readline().split(":")[1].strip())
    PGPSMode.set(Fp.readline().split(":")[1].strip())
    Fp.close()
    msgLn(1, "W", "Parameters loaded from file:")
    msgLn(0, "", "   "+LoadFile)
# Preserve the used file name for a next time
    LastPRMFile = LoadFile
    return
# END: loadParmsCmd




#########################
# BEGIN: loadPROGSetups()
# LIB:loadPROGSetups():2010.246
#   A standard setups file loader for programs that don't require anything
#   special loaded from the .set file just the PROGSetups items.
def loadPROGSetups():
# The .set file may not be there.
    Setfile = PROGSetupsDirVar.get()+PROG_NAMELC+".set"
    if exists(Setfile) == False:
        return (1, "", "Setups file not found. Was looking for\n   %s"% \
                Setfile, 0)
    try:
        Fp = open(Setfile, "rb")
    except Exception, e:
        return (2, "MW", "Error opening setups file\n   %s\n   %s"% \
                (Setfile, e), 3)
    Found = False
# Just catch anything that might go wrong and blame it on the .set file.
    try:
        while 1:
            Line = Fp.readline()
            if Line.strip() == "":
                break
            if Line.startswith(PROG_NAME+":"):
                Found = True
                continue
            if Found == True:
                Parts = map(strip, Line.split(";", 1))
# This is a lot slower than just using the key that was read in and hoping
# that there is a matching Var, but this way is safer since we will only look
# for Vars that we know exist (PROGSetups).
                for Item in PROGSetups:
                    if Parts[0] == Item:
                        if isinstance(eval(Item), StringVar):
                            eval(Item).set(Parts[1])
                            break
                        elif isinstance(eval(Item), IntVar):
                            eval(Item).set(int(Parts[1]))
                            break
        Fp.close()
        if Found == False:
            return (1, "YB", "No %s setups found in\n   %s"%(PROG_NAME, \
                    Setfile), 2)
        else:
            return (0, "WB", "Setups loaded from\n   %s"%Setfile, 0)
    except Exception, e:
        Fp.close()
        return (2, "MW", \
           "Error loading setups from\n   %s\n   %s\n   Was loading line %s"% \
                (Setfile, e, Line), 3)
#################################
# BEGIN: loadPROGSetupsCmd(Which)
# FUNC:loadPROGSetups():2008.029
def loadPROGSetupsCmd(Which):
    Ret = loadPROGSetups()
    msgLn(Which, Ret[1], Ret[2], True, Ret[3])
    return
#########################
# BEGIN: savePROGSetups()
# FUNC:savePROGSetupsCmd():2010.144
#   A standard setups file saver for programs that don't require anything
#   special saved to the .set file just the PROGSetups items.
def savePROGSetups():
    Setfile = PROGSetupsDirVar.get()+PROG_NAMELC+".set"
    try:
        Fp = open(Setfile, "wb")
    except Exception, e:
        return (2, "MW", "Error opening setups file\n   %s\n   %s"%(Setfile, \
                e), 3)
    try:
        Fp.write("%s: %s\n"%(PROG_NAME, PROG_VERSION))
        for Item in PROGSetups:
            if isinstance(eval(Item), StringVar):
                Fp.write("%s; %s\n"%(Item, eval(Item).get()))
            elif isinstance(eval(Item), IntVar):
                Fp.write("%s; %d\n"%(Item, eval(Item).get()))
        Fp.close()
        return (0, "", "Setups saved to\n   %s"%Setfile, 0)
    except Exception, e:
        Fp.close()
        return (2, "MW", "Error saving setups to\n   %s\n   %s"%(Setfile, \
                e), 3)
########################################
# BEGIN: savePROGSetupsCmd(Speak = True)
# FUNC:savePROGSetupsCmd():2008.195
def savePROGSetupsCmd(Speak = True):
    Ret = savePROGSetups()
    if Speak == True:
        msgLn(0, Ret[1], Ret[2], True, Ret[3])
    return
###########################
# BEGIN: deletePROGSetups()
# FUNC:deletePROGSetups():2010.192
def deletePROGSetups():
    Answer = formMYD(Root, (("Delete And Quit", TOP, "doit"), ("Cancel", \
            TOP, "cancel")), "cancel", "YB", "Be careful.", \
            "This will delete the current setups file and quit the program. This should only be done if the contents of the current setups file is known to be causing the program problems.")
    if Answer == "cancel":
        return
    try:
        remove(PROGSetupsDirVar.get()+PROG_NAMELC+".set")
    except Exception, e:
        formMYD(Root, (("(OK)", TOP, "ok"), ), "ok", "MW", "On No.", \
                "The setups file could not be deleted.\n\n%s"%e)
        return        
    progQuitter(False)
    return
# END: loadPROGSetups




########################
# BEGIN: massCenterCmd()
# FUNC:massCenterCmd():2009.053
def massCenterCmd():
    global WorkState
    Cmd = ""
    Status, ListOfDASs = isItOKToStart(3)
    if Status == False:
        return
    WorkState = 100
    buttonControl("MASSCENT", "G", 1)
    formSTATSetStatus("all", "B")
    Chans = CalChansRVar.get()
    if openCmdPort() == False:
        buttonControl("MASSCENT", "", 0)
        return
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        if DAS != "0000":
            Answer = formMYD(Root, (("Send", LEFT, "send"), \
                    ("Stop", LEFT, "stop")), "stop", "", "Next!", \
                    "Send mass center command to DAS %s?"%DAS)
            if Answer == "stop":
                WorkState = 999
                continue
            updateMe(0)
        formSTATSetStatus(DAS, "C")
        Count += 1
        msgLn(1, "C", "%d. %s: Mass Center Channels %s... (%s)"% \
              (Count, DAS, Chans, getGMT(0)))
        if Chans == "123":
            Cmd = rt130CmdFormat(DAS, "SK1MSK")
        elif Chans == "456":
            Cmd = rt130CmdFormat(DAS, "SK2MSK")
        writePort(DAS, Cmd)
# The command response comes when the pulse ends (~7 sec), so we won't look for
# any response to this command. If the DASs don't get the command the person
# watching the test equipment will notice. Delay a little to make it look like
# something is happening.
        if DAS == "0000":
            delay(2)
        else:
            delay(.5)
        formSTATSetStatus(DAS, "G")
    closeCmdPort()
    if WorkState == 999:
        formSTATSetStatus("working", "Y")
        msgLn(1, "Y", "Some DASs may still be working.")
    stoppedMe(WorkState, DAS)
    buttonControl("MASSCENT", "", 0)
    return
# END: massCenterCmd




########################
# BEGIN: memoryTestCmd()
# FUNC:memoryTestCmd():2010.162
def memoryTestCmd():
    global WorkState
    Status, ListOfDASs = isItOKToStart(2)
    if Status == False:
        return
    Answer = formMYD(Root, (("Continue", LEFT, "cont"), ("Stop", LEFT, \
            "stop")), "stop", "YB", "As Good As Gone.", \
            "Testing the memory will wipe out everything in RAM. Are you sure you want to continue or do you want to stop?")
    if Answer == "stop":
        return
    WorkState = 100
    buttonControl("MEMTEST", "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        buttonControl("MEMTEST", "", 0)
        return
    msgLn(1, "C", "Starting memory test... (%s)"%getGMT(0))
# This is a little different. The LCD panel on a DAS shows that the memory
# test takes about 25 seconds to start after the command is sent, about 40
# seconds to run, and it indicates pass or fail for about 15 seconds after
# that (then, I assume, the reset occurs). The command will be sent by this
# section to all selected DASs without waiting for a response.
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        Cmd = rt130CmdFormat(DAS, "MTRMMT")
        writePort(DAS, Cmd)
# Sending the commands too quickly made it likely that more than one DAS
# would respond at the end of the test at the same time (with 15 DASs). This
# delay helped to make that less likely.
        sleep(.5)
    if WorkState == 999:
        formSTATSetStatus("working", "Y")
        msgLn(1, "Y", "Some DASs may still be testing.")
        msgLn(0, "Y", "Stopped.")
    else:
        if len(ListOfDASs) == 1:
            msgLn(1, "W", "   Start test command sent...")
        else:
            msgLn(1, "W", "   Start test commands sent...")
# Everyone should finish the test by about 1m10s so we'll enter a monitoring
# loop and wait for about 1m30s.
        msgLn(1, "W", "   Monitoring (will stop in 90 seconds or less)...")
        StartTime = getGMT(8)
        while 1:
            if WorkState == 999:
                break
            if len(ListOfDASs) == 0:
                break
            if getGMT(8)-StartTime > 90:
                break
            FoundDASs = []
# I'm not looking for any DAS in particular here I'm just looping through
# here the same number of times as there are DASs remaining to answer.
            for DAS in ListOfDASs:
                if WorkState == 999:
                    break
                Rp = rt130GetRp(0, 1, 0)
                if WorkState == 999:
                    break
                if Rp == "":
                    continue
# If the length is not right it probably means that more than one responded
# at the same time. We'll hear about them at the end of the test.
                if len(Rp) > 32:
                    msgLn(1, "Y", "   Bad response size. Response collision?")
                else:
                    RpDAS = Rp[2:2+4]
# Remove DASs from the list after we have scanned for them all this time
# through.
                    FoundDASs.append(RpDAS)
                    Status = Rp[14:14+2]
                    if Status == "00":
                        formSTATSetStatus(RpDAS, "G")
                        msgLn(1, "G", "   %s: Passed."%RpDAS)
                    elif Status == "01":
                        formSTATSetStatus(RpDAS, "Y")
                        msgLn(1, "Y", "   %s: Invalid request."%RpDAS)
                    elif Status == "03":
                        Addr = Rp[16:16+8]
                        formSTATSetStatus(RpDAS, "R")
                        msgLn(1, "R", "   %s: Failed. Address: %s"%(RpDAS, \
                                Addr))
                    else:
                        formSTATSetStatus(RpDAS, "R")
                        msgLn(1, "R", "   %s: Unknown status: %s"%(RpDAS, \
                                Status))
            for FoundDAS in FoundDASs:
                ListOfDASs.remove(FoundDAS)
    closeCmdPort()
    if WorkState == 999:
        formSTATSetStatus("working", "Y")
        msgLn(1, "Y", "Some DASs may still be working.")
        msgLn(0, "Y", "Stopped.")
    else:
        for DAS in ListOfDASs:
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   %s: No memory test command response!"%DAS)
        msgLn(0, "", "Done.")
        if OPTDoneBeepCVar.get() != 0:
            beep(1)
    buttonControl("MEMTEST", "", 0)
    return
# END: memoryTestCmd




#####################
# BEGIN: monitorCmd()
# FUNC:monitorCmd():2009.315
Frm["MON"] = None
Can["MON"] = None
MONSb = None

def monitorCmd():
    global MONSb
    global WorkState
    Status, ListOfDASs = isItOKToStart(2)
    if Status == False:
        return
    WorkState = 100
    buttonControl("MONITOR", "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        buttonControl("MONITOR", "", 0)
        return
    Count = 0
# Clear out anything from a previous run.
    if Frm["MON"] != None:
        LFrm = Frm["MON"]
        LCan = Can["MON"]
        LCan.delete(ALL)
        LCan.configure(scrollregion = (0, 0, 0, 0))
# The plot window's starting point.
        GY = PROGLabelFontHeight
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        msgLn(1, "", "%d. %s: Monitor testing... (%s)"%(Count, DAS, getGMT(0)))
# Get the parm status to find out which data streams we'll be working on.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "W", "   Getting parameter status...")
        Cmd = rt130CmdFormat(DAS, "SSPR              SS")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Parameter Status request response!", True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        Chans = intt(Rp[32:32+2])
        DSs = intt(Rp[34:34+1])
        DStreams = mrDash(Rp[40+Chans:40+Chans+DSs])
# Check to make sure there even are any data streams programmed.
        if DStreams == "--------":
            formSTATSetStatus(DAS, "R")
            msgLn(1, "R", "   No data streams programmed.", True, 2)
# Just go on to the next DAS.
            continue
        d = 0
# Clear this each data stream. The monitor points will be collected here by
# monitorDo(), so the channels can be plotted in an overlay-type graph
# following all of the channel graphs.
        StreamData = []
# For the overlay plot.
        DSMin = maxint
        DSMax = -maxint
# Get the current stream parameters from the DAS so we know what to check.
        for Check in DStreams:
            if WorkState == 999 or AllOK == False:
                break
            d += 1
# If the position is a dash then go on to the next data stream.
            if Check == "-":
                continue
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "W", "   Getting data stream %d parameters..."%d)
            Cmd = rt130CmdFormat(DAS, "PRPD"+padR(str(d), 2)+"PR")
            writePort(DAS, Cmd)
# No Lag time here since this is a request for info.
            Rp = rt130GetRp(1, 10, 0)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No Data Stream Parameters request response!", \
                        True, 3)
                AllOK = False
                continue
# Stop everything if this routine thinks something is wrong.
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# If we come to a ds that has no channels assigned to it just make a note of it
# and go on to the next data stream.
            if Rp[42:42+6] == "      ":
                msgLn(1, "", "   No channels assigned to data stream %d."%d)
                continue
# Check that the sample rate is high enough for this test, if not go on to
# next data stream.
            SR = Rp[58:58+4].strip()
            if intt(SR) < 20:
                msgLn(1, "Y", \
                        "   Data stream %d sample rate is below 20sps."%d)
                continue
            Chans = Rp[42:42+6]
            for c in xrange(1, 1+6):
                if Chans[(c-1)] == " ":
                    continue
# Only do the channels' whose checkbuttons are selected.
                if eval("Chan%dMonCVar"%c).get() == 0:
                    if OPTSummaryModeCVar.get() == 0:
                        msgLn(1, "", "      Skipping channel %d..."%c)
                    continue
# Do the monitor command and get the data.
                Ret = monitorDo(DAS, d, c, StreamData)
                if WorkState == 999:
                    break
                if Ret[0] != 0:
                    msgLn(1, Ret[1], Ret[2], True, Ret[3])
                    formSTATSetStatus(DAS, Ret[1])
                    AllOK = False
                    break
# Create the window if it has not already been done.
                if Frm["MON"] == None:
                    LFrm = Frm["MON"] = Toplevel(Root)
                    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, \
                            "MON"))
                    LFrm.title("Monitor Test Results")
                    LFrm.iconname("MonTest")
                    Sub = Frame(LFrm, borderwidth = 2, relief = SUNKEN)
                    LCan = Can["MON"] = Canvas(Sub, bg = Clr["B"], bd = 0, \
                            width = 700, height = 500)
                    LCan.pack(side = LEFT, fill = BOTH, expand = YES)
                    MONSb = Scrollbar(Sub, orient = VERTICAL, \
                            command = LCan.yview)
                    MONSb.pack(side = RIGHT, fill = Y, expand = NO)
                    LCan.configure(yscrollcommand = MONSb.set)
                    Sub.pack(side = TOP, fill = BOTH, expand = YES)
# The plot window's starting point.
                    GY = PROGLabelFontHeight
# StreamData: [[DAS, DS, Chan, [data points]], <next channel>...]
                DataPoints = StreamData[len(StreamData)-1][3]
                DMin = min(DataPoints)
# Remember the min/max of all of the channels for the combined plots.
                if DMin < DSMin:
                    DSMin = DMin
                DMax = max(DataPoints)
                if DMax > DSMax:
                    DSMax = DMax
                DRange = getRange(DMin, DMax)
                DMid = DMin+(DRange/2)
                msgLn(1, "", "         Max: ", False)
                msgLn(1, "G", "%s"%fmti(DMax), False)
                msgLn(1, "", "   Min: ", False)
                msgLn(1, "G", "%s"%fmti(DMin))
# The mid point should be somewhere around 0 (that's what the offset test is
# for), so check for that.
                if DMid > -100 and DMid < 100:
                    msgLn(1, "", "         Mid: ", False)
                    msgLn(1, "G", "%s"%fmti(DMid), False)
                    msgLn(1, "", "   Range: ", False)
                    msgLn(1, "G", "%s"%fmti(DRange))
                else:
                    msgLn(1, "", "         Mid: ", False)
                    msgLn(1, "Y", "%s"%fmti(DMid), False)
                    msgLn(1, "", "   Range: ", False)
                    msgLn(1, "G", "%s"%fmti(DRange))
                LCan.create_text(10, GY, fill = "white", anchor = "w", \
  text = "DAS: %s  DS: %d  Ch: %d   Max: %s   Min: %s   Mid: %s   Range: %s"% \
                        (DAS, d, c, fmti(DMin), fmti(DMax), fmti(DMid), \
                        fmti(DRange)))
                GY += PROGLabelFontHeight
                Points = 160
                Y1 = GY+(100-100*.5)
                LCan.create_line(10, Y1, 10+160*4+20, Y1, fill = "blue", \
                        width = 1)
                Cmd = []
                for i in xrange(0, Points-1):
                    X1 = 20+i*4
                    X2 = 20+(i*4)+4
                    if DRange != 0:
                        Y1 = GY+(100-100*(DataPoints[i]-DMin)/DRange)
                        Y2 = GY+(100-100*(DataPoints[i+1]-DMin)/DRange)
                    else:
                        Y1 = GY+50
                        Y2 = GY+50
                    Cmd += X1, Y1, X2, Y2
                LCan.create_line(Cmd, fill = "green", width = 1)
# Adjust the display. There may not be anything on the display so try (which
# at this point would be odd or a bug).
                try:
                    Top = LCan.bbox(ALL)[3]+10
                except TypeError:
                    Top = 10
# The RIGHT value (100) can be anything since there is no horizontal scroll
# bar.
                LCan.configure(scrollregion = (0, 0, 100, Top))
                if MONSb.get()[1] == 1.0:
                    LCan.yview_moveto(1.0)
                updateMe(0)
                GY += 100+PROGLabelFontHeight*1.5
        if WorkState == 999 or AllOK == False:
            continue
# ----- OVERLAYED GRAPHS ----
# If StreamData has more than one graph's data in it...
        if len(StreamData) > 1:
# Plot the first half (80 points) of the returned data from each channel all
# on one plot just as the data came from the DAS (the phases may not match).
            getAColor(0)
            Chan = 0
            for Stream in StreamData:
                Chan += 1
                GColor = getAColor(7)[0]
                LCan.create_text(10, GY, fill = GColor, \
                        text = "DAS: %s  Channel: %d"%(DAS, Chan), \
                        anchor = "w")
                GY += PROGLabelFontHeight
            getAColor(0)
            for Stream in StreamData:
                DataPoints = Stream[3]
                GColor = getAColor(7)[0]
                DMin = DSMin
                DMax = DSMax
                DRange = getRange(DMin, DMax)
                DMid = DMin+(DRange/2)
                Points = 160
                Cmd = []
                for i in xrange(0, Points-1):
                    X1 = 20+i*4
                    X2 = 20+(i*4)+4
                    if DRange != 0:
                        Y1 = GY+(100-100*(DataPoints[i]-DMin)/DRange)
                        Y2 = GY+(100-100*(DataPoints[i+1]-DMin)/DRange)
                    else:
                        Y1 = GY+50
                        Y2 = GY+50
                    Cmd += X1, Y1, X2, Y2
                LCan.create_line(Cmd, fill = GColor, width = 1)
                try:
                    Top = LCan.bbox(ALL)[3]+10
                except TypeError:
                    Top = 10
                LCan.configure(scrollregion = (0, 0, 100, Top))
                if MONSb.get()[1] == 1.0:
                    LCan.yview_moveto(1.0)
                updateMe(0)
            GY += 100+PROGLabelFontHeight*1.5
# ----- ZOOMED-IN ADJUSTED GRAPH -----
# Now go through each channels' points and find the first peak to try and
# plot the channels in phase.
            getAColor(0)
            Chan = 0
            PeakIndexes = {}
            for Stream in StreamData:
                DataPoints = Stream[3]
# This will be the Stream index of the highest point.
                PeakPoint = 0
                LastPoint = DataPoints[0]
# If the data starts off going down the loop below will trigger right away, so
# wait until we've seen the data values start back up before looking for the
# peak using the flag HitBottom.
                HitBottom = False
                for Point in DataPoints[1:]:
                   if Point < LastPoint:
                       if HitBottom == True:
# We've started down.
                           break
                   elif Point > LastPoint and HitBottom == False:
                       HitBottom = True
                   LastPoint = Point
                   PeakPoint += 1
# Just in case the input is some kind of flat line or something (which, from a
# testing point of view, would be kind of silly). This will keep the for i loop
# below from running out of DataPoints.
                   if PeakPoint > 40:
                       break
                Chan += 1
                PeakIndexes[Chan] = PeakPoint
                GColor = getAColor(7)[0]
                LCan.create_text(10, GY, fill = GColor, \
                        text = "DAS: %s  Channel: %d   Peak sample: %d"%(DAS, \
                        Chan, PeakPoint), anchor = "w")
                GY += PROGLabelFontHeight
            getAColor(0)
            Chan = 0
            for Stream in StreamData:
                DataPoints = Stream[3]
                Chan += 1
                DataPoints = DataPoints[PeakIndexes[Chan]:]
                GColor = getAColor(7)[0]
                DMin = DSMin
                DMax = DSMax
                DRange = getRange(DMin, DMax)
                DMid = DMin+(DRange/2)
                Points = 40
                Cmd = []
                for i in xrange(0, Points-1):
                    X1 = 20+i*16
                    X2 = 20+(i*16)+16
                    if DRange != 0:
                        Y1 = GY+(240-240*(DataPoints[i]-DMin)/DRange)
                        Y2 = GY+(240-240*(DataPoints[i+1]-DMin)/DRange)
                    else:
                        Y1 = GY+120
                        Y2 = GY+120
                    Cmd += X1, Y1, X2, Y2
                LCan.create_line(Cmd, fill = GColor, width = 1)
                try:
                    Top = LCan.bbox(ALL)[3]+10
                except TypeError:
                    Top = 10
                LCan.configure(scrollregion = (0, 0, 100, Top))
                if MONSb.get()[1] == 1.0:
                    LCan.yview_moveto(1.0)
                updateMe(0)
            GY += 240+PROGLabelFontHeight*1.5
        formSTATSetStatus(DAS, "G")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
# Use "working" here since DAS no longer points at the DAS that we were working
# on.
        formSTATSetStatus("working", "Y")
# This may just be a normal stop.
        msgLn(1, "Y", "DAS may still be working.")
    stoppedMe(WorkState, "")
    buttonControl("MONITOR", "", 0)
    return
# END: monitorCmd




####################
# BEGIN: offsetCmd()
# FUNC:offsetCmd():2009.315
#   This whole sequence of commands seems to be a bit sensitive to the length
#   of the time delays.
def offsetCmd():
    global WorkState
    Status, ListOfDASs = isItOKToStart(2)
    if Status == False:
        return
# For converting the values.
    Range = pow(2, 32)
    WorkState = 100
    buttonControl("OFFSET", "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        buttonControl("OFFSET", "", 0)
        return
    Action = OffSetRVar.get()
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        if Action == "set":
           msgLn(1, "", "%d. %s: Setting offsets... (%s)"%(Count, DAS, \
                   getGMT(0)))
        else:
           msgLn(1, "", "%d. %s: Checking offsets... (%s)"%(Count, DAS, \
                   getGMT(0)))
        Channels = "      "   # One character for each channel.
# Get the parm status to find out which data streams we'll be working on.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "W", "   Getting parameter status...")
        Cmd = rt130CmdFormat(DAS, "SSPR              SS")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Parameter Status request response!", True, 3)
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        Chans = intt(Rp[32:32+2])
        DSs = intt(Rp[34:34+1])
        DStreams = mrDash(Rp[40+Chans:40+Chans+DSs])
# Check to make sure there even are any data streams programmed.
        if DStreams == "--------":
            formSTATSetStatus(DAS, "R")
            msgLn(1, "R", "   No data streams programmed.", True, 2)
            continue
        d = 0
# Get the current stream parameters from the DAS so we know what to check.
        for Check in DStreams:
            if WorkState == 999 or AllOK == False:
                break
            d += 1
# If the position is a dash then go on to the next data stream.
            if Check == "-":
                continue
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "W", "   Getting data stream %d parameters..."%d)
            Cmd = rt130CmdFormat(DAS, "PRPD"+padR(str(d), 2)+"PR")
            writePort(DAS, Cmd)
# No Lag, info request.
            Rp = rt130GetRp(1, 10, 0)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No Data Stream Parameters request response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# If we come to a ds that has no channels assigned to it just make a note of it
# and go on to the next data stream.
            if Rp[42:42+6] == "      ":
                msgLn(1, "", "   No channels assigned to data stream %d."%d)
                continue
# We don't need to know which channels have been assigned to a DS because the
# returned data will just contain data for each channel that is assigned.
# However, check that the sample rate is high enough for this test.
            SR = Rp[58:58+4].strip()
            if intt(SR) < 20:
                formSTATSetStatus(DAS, "Y")
                msgLn(1, "Y", \
                        "   Data stream %d sample rate is below 20sps."%d)
                continue
# Get the relative offsets and print them before changing anything.
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "W", "   Checking...")
            Cmd = rt130CmdFormat(DAS, "DO"+padR(str(d), 1)+"R"+padR("3", 2)+ \
                    "DO")
            writePort(DAS, Cmd)
            Rp = rt130GetRp(1, 7, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No Data Offset check command response!", True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
            StatColor = "G"
#TESTING            for i in range(0, intt(Rp[14:14+2])):
            for i in xrange(0, intt(Rp[14:14+2])):
                Start = 16+(i*10)
                Value = long(hexInvert(Rp[Start+2:Start+10]), 16)
                if Value > Range/2:
                    Value = Value-Range
                msgLn(1, "", "      Ch"+Rp[Start+1:Start+2]+" diff: ", False)
                if Value > -100 and Value < 100:
                    msgLn(1, "G", str(Value))
                else:
                    msgLn(1, "R", str(Value))
                    StatColor = "R"
# Check to see if we will be continuing or if we are just checking values.
            if Action == "check":
                formSTATSetStatus(DAS, StatColor)
                continue
# Send the command.
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "W", "   Calculating offsets...")
# Have the DAS calculate the absolute value. Let it integrate for 3 seconds.
            Cmd = rt130CmdFormat(DAS, "DO"+padR(str(d), 1)+"A"+padR("3", 2)+ \
                    "DO")
            writePort(DAS, Cmd)
            Rp = rt130GetRp(1, 7, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Data Offset command response!", True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# Begin constructing the command to set the values.
            Settings = []
            Cmd = "SO"+" "+"A"+Rp[14:14+2]
#TESTING            for i in range(0, intt(Rp[14:14+2])):
            for i in xrange(0, intt(Rp[14:14+2])):
                Start = 16+(i*10)
                Cmd = Cmd+Rp[Start:Start+2]+hexInvert(Rp[Start+2:Start+10])
# Keep the new numbers so they can be printed out below.
                Settings.append(long(Rp[Start+2:Start+10], 16))
            Cmd = Cmd+"SO"
            Cmd = rt130CmdFormat(DAS, Cmd)
# Send the new numbers back to the DAS.
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "C", "   Sending new values...")
            writePort(DAS, Cmd)
# We have to give the DAS a bit of extra time after this command to finish up.
            Rp = rt130GetRp(1, 7, 5)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Set Offset command response!", True, 3)
                msgLn(1, "Y", "   Check offsets manually!")
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# Now get the relative offsets for something to print out.
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "W", "   Checking...")
            Cmd = rt130CmdFormat(DAS, "DO"+padR(str(d), 1)+"R"+padR("5", 2)+ \
                    "DO")
            writePort(DAS, Cmd)
            Rp = rt130GetRp(1, 7, 5)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Data Offset check command response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
#TESTING            for i in range(0, intt(Rp[14:14+2])):
            for i in xrange(0, intt(Rp[14:14+2])):
                Start = 16+(i*10)
                Value = long(hexInvert(Rp[Start+2:Start+10]), 16)
                if Value > Range/2:
                    Value = Value-Range
                msgLn(1, "", "      Ch"+Rp[Start+1:Start+2]+" Abs: ", False)
                msgLn(1, "G", str(Settings[i]), False)
                msgLn(1, "", "  Off: ", False)
                msgLn(1, "G", str(pow(2,32)-Settings[i]), False)
                msgLn(1, "", "  Diff: ", False)
                if Value > -100 and Value < 100:
                    msgLn(1, "G", str(Value))
                else:
                    msgLn(1, "R", str(Value))
        if WorkState == 999 or AllOK == False:
            continue
# The check routine has already set the colors.
        if Action == "set":
            formSTATSetStatus(DAS, "G")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
        msgLn(1, "Y", "DAS may still be working.")
    stoppedMe(WorkState, "")
    buttonControl("OFFSET", "", 0)
    return
# END: offsetCmd




#########################
# BEGIN: parmsToDiskCmd()
# FUNC:parmsToDiskCmd():2009.053
def parmsToDiskCmd():
    global WorkState
    Status, ListOfDASs = isItOKToStart(2)
    if Status == False:
        return
    WorkState = 100
    buttonControl("WP", "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        buttonControl("WP", "", 0)
        return
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        msgLn(1, "C", "%d. %s: Writing Parameters to disk... (%s)"%(Count, \
                DAS, getGMT(0)))
        Cmd = rt130CmdFormat(DAS, "WPWP")
        writePort(DAS, Cmd)
# This can take about 10 seconds with 2 disks to return, but we do want to
# wait for each one to get the status of the write(s) (see below).
        Rp = rt130GetRp(1, 20, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Write Parameters command response!", True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
# 2.8.8S just returns WPWP. 2.9.0 returns a 2-byte status about each disk.
        if Rp.find("WPWP") != -1:
            formSTATSetStatus(DAS, "G")
            msgLn(1, "", "   Parameters written.")
        elif Rp.find("WP0") != -1:
            msgLn(1, "", "   Parameters written: D1: ", False)
            if Rp[12:12+2] == "00":
                msgLn(1, "G", "Passed", False)
                RpAllOK = True
            else:
                msgLn(1, "Y", "Failed", False)
                RpAllOK = False
            msgLn(1, "", "  D2: ", False)
            if Rp[14:14+2] == "00":
                msgLn(1, "G", "Passed")
# Don't change RpAllOK here in case it was set to False above.
            else:
                msgLn(1, "Y", "Failed")
                RpAllOK = False
            if RpAllOK == True:
                formSTATSetStatus(DAS, "G")
            else:
                formSTATSetStatus(DAS, "Y")
        else:
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   Unknown response.", True, 3)
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
        msgLn(1, "Y", "DAS may still be working.")
    stoppedMe(WorkState, DAS)
    buttonControl("WP", "", 0)
    return
# END: parmsToDiskCmd




######################
# BEGIN: pref0000Cmd()
# FUNC:pref0000Cmd():2009.314
def pref0000Cmd():
    if OPTPref0000CVar.get() == 0:
        msgLn(0, "", "0000 Preference turned off.")
    else:
        msgLn(0, "", "0000 Preference turned on.")
    return
# END: pref0000Cmd




##########################
# BEGIN: receiveParmsCmd()
# FUNC:receiveParmsCmd():2009.328
def receiveParmsCmd():
    global WorkState
    Status, ListOfDASs = isItOKToStart(1)
    if Status == False:
        return
    WorkState = 100
    buttonControl("RECEIVE", "G", 1)
    formSTATSetStatus("all", "B")
    formPARMSClearParms()
    if openCmdPort() == False:
        buttonControl("RECEIVE", "", 0)
        return
# OK, so maybe someday more than one DAS will be allowed, so we'll do all of
# this inside of a for loop, but only allow ListOfDASs to contain one DAS
# ...maybe we'll print out the parameter summary for each DAS as it is
# received, or something like that.
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        msgLn(1, "", "%d. %s: Receiving parameters... (%s)"%(Count, DAS, \
                getGMT(0)))
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   Station...")
        Cmd = rt130CmdFormat(DAS, "PRPS  PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Station Parameters request response!", \
                    True, 3)
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
# You have to add 4 to the sending offsets of the parameters described in the
# Reftek documentation (i.e. the experiment name is at [14:14+24] when you
# send the station parameters, but at [18:18+24] when receiving).
        PExpName.set(Rp[18:18+24].strip())
        PExpComment.set(Rp[42:42+40].strip())
# Get the current setup of the DAS to figure out which channels and data
# streams to get.
        Cmd = rt130CmdFormat(DAS, "SSPR              SS")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Parameter Status request response!", True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        Chans = intt(Rp[32:32+2])
        DSs = intt(Rp[34:34+1])
        Channels = mrDash(Rp[40:40+Chans])
        DStreams = mrDash(Rp[40+Chans:40+Chans+DSs])
        for c in xrange(1, 1+6):
            if WorkState == 999:
                break
            if Channels[(c-1)] == "-":
                continue
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "", "   Channel %d..."%c)
            Cmd = rt130CmdFormat(DAS, "PRPC%d PR"%c)
            writePort(DAS, Cmd)
            Rp = rt130GetRp(1, 5, 0)
            if WorkState == 999:
                break
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No Channel %d Parameters request response!"%c, \
                        True, 3)
                AllOK = False
                break
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                break
            eval("PC%dName"%c).set(Rp[18:18+10].strip())
            eval("PC%dComment"%c).set(Rp[114:114+40].strip())
# The high gain setting in the DAS may be "100" depending on which program
# was used to program it. CHANGEO uses "32".
            Gain = intt(Rp[86:86+4])
            if Gain == 0 or Gain == 1:
                eval("PC%dGain"%c).set(Gain)
            if Gain == 32 or Gain == 100:
                eval("PC%dGain"%c).set(32)
# Go on to the next DAS if something is wrong.
        if WorkState == 999 or AllOK == False:
            continue
        for d in xrange(1, 1+4):
            if WorkState == 999:
                break
            if DStreams[(d-1)] == "-":
                continue
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "", "   Data stream %d..."%d)
            Cmd = rt130CmdFormat(DAS, "PRPD%d PR"%d)
            writePort(DAS, Cmd)
            Rp = rt130GetRp(1, 5, 0)
            if WorkState == 999:
                break
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No DS%d Parameters request response!"%d, True, 3)
                AllOK = False
                break
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                break
            eval("PDS%dName"%d).set(Rp[18:18+16].strip())
            if Rp[34:34+1] != " ":
                eval("PDS%dRam"%d).set(1)
            if Rp[35:35+1] != " ":
                eval("PDS%dDisk"%d).set(1)
            if Rp[36:36+1] != " ":
                eval("PDS%dEther"%d).set(1)
            if Rp[37:37+1] != " ":
                eval("PDS%dSerial"%d).set(1)
            for c in xrange(1, 1+6):
                if Rp[41+c:41+c+1] != " ":
                    eval("PDS%dChan%d"%(d,c)).set(1)
            eval("PDS%dSampRate"%d).set(Rp[58:58+4].strip())
            eval("PDS%dFormat"%d).set(Rp[62:62+2].strip())
            if Rp[64:64+4].strip() == "CON":
                eval("PDS%dTType"%d).set(1)
                eval("PDS%dRl"%d).set(Rp[68:68+8].strip())
                eval("PDS%dStart1"%d).set(Rp[76:76+14].strip())
            elif Rp[64:64+4].strip() == "CRS":
                eval("PDS%dTType"%d).set(2)
                eval("PDS%dTStrm"%d).set(intt(Rp[68:68+2]))
                eval("PDS%dPretl"%d).set(Rp[70:70+8].strip())
                eval("PDS%dRl"%d).set(Rp[78:78+8].strip())
            elif Rp[64:64+4].strip() == "EVT":
                eval("PDS%dTType"%d).set(3)
                for c in xrange(1, 1+6):
                    if Rp[67+c:67+c+1] != " ":
                        eval("PDS%dTChan%d"%(d,c)).set(1)
                eval("PDS%dMc"%d).set(Rp[84:84+2].strip())
                eval("PDS%dTwin"%d).set(Rp[86:86+8].strip())
                eval("PDS%dPretl"%d).set(Rp[94:94+8].strip())
                eval("PDS%dPostl"%d).set(Rp[102:102+8].strip())
                eval("PDS%dRl"%d).set(Rp[110:110+8].strip())
                eval("PDS%dSta"%d).set(Rp[126:126+8].strip())
                eval("PDS%dLta"%d).set(Rp[134:134+8].strip())
                eval("PDS%dTr"%d).set(Rp[150:150+8].strip())
                eval("PDS%dDtr"%d).set(Rp[158:158+8].strip())
                Holding = Rp[166:166+4].strip()
                if Holding == "OFF":
                    eval("PDS%dHold"%d).set(0)
                elif Holding == "ON":
                    eval("PDS%dHold"%d).set(1)
                Pass = Rp[170:170+4].strip()
                if Pass == "OFF":
                    eval("PDS%dLPFreq"%d).set(0)
                elif Pass == "0":
                    eval("PDS%dLPFreq"%d).set(1)
                elif Pass == "12":
                    eval("PDS%dLPFreq"%d).set(2)
                Pass = Rp[174:174+4].strip()
                if Pass == "OFF":
                    eval("PDS%dHPFreq"%d).set(0)
                elif Pass == "0":
                    eval("PDS%dHPFreq"%d).set(1)
                elif Pass == "0.1":
                    eval("PDS%dHPFreq"%d).set(2)
                elif Pass == "12":
                    eval("PDS%dHPFreq"%d).set(3)
            elif Rp[64:64+4].strip() == "EXT":
                eval("PDS%dTType"%d).set(4)
                eval("PDS%dPretl"%d).set(Rp[68:68+8].strip())
                eval("PDS%dRl"%d).set(Rp[76:76+8].strip())
            elif Rp[64:64+4].strip() == "LEV":
                eval("PDS%dTType"%d).set(5)
                eval("PDS%dTlvl"%d).set(Rp[68:68+8].strip())
                eval("PDS%dPretl"%d).set(Rp[76:76+8].strip())
                eval("PDS%dRl"%d).set(Rp[84:84+8].strip())
                Pass = Rp[92:92+4].strip()
                if Pass == "OFF":
                    eval("PDS%dLPFreq"%d).set(0)
                elif Pass == "0":
                    eval("PDS%dLPFreq"%d).set(1)
                elif Pass == "12":
                    eval("PDS%dLPFreq"%d).set(2)
                Pass = Rp[96:96+4].strip()
                if Pass == "OFF":
                    eval("PDS%dHPFreq"%d).set(0)
                elif Pass == "0":
                    eval("PDS%dHPFreq"%d).set(1)
                elif Pass == "0.1":
                    eval("PDS%dHPFreq"%d).set(2)
                elif Pass == "12":
                    eval("PDS%dHPFreq"%d).set(3)
            elif Rp[64:64+4].strip() == "TIM":
                eval("PDS%dTType"%d).set(6)
                eval("PDS%dStart1"%d).set(Rp[68:68+14].strip())
                eval("PDS%dRepInt"%d).set(Rp[82:82+8].strip())
                eval("PDS%dNumTrig"%d).set(Rp[90:90+4].strip())
                eval("PDS%dRl"%d).set(Rp[102:102+8].strip())
            elif Rp[64:64+4].strip() == "TML":
                eval("PDS%dTType"%d).set(7)
                for i in xrange(1, 1+11):
                    eval("PDS%dStart%d"%(d,i)).set \
                                (Rp[54+(i*14):54+(i*14)+14].strip())
                eval("PDS%dRl"%d).set(Rp[102:102+8].strip())
            elif Rp[64:64+4].strip() == "VOT":
                eval("PDS%dTType"%d).set(8)
        if WorkState == 999 or AllOK == False:
            continue
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   Auxiliary data...")
        Cmd = rt130CmdFormat(DAS, "PRPA  PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", \
                    "   No Auxiliary Data Parameters request response!", \
                    True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        PAuxMarker.set(Rp[16:16+2].strip())
# Channels are offset 18-33 (16 channels).
        for i in xrange(1, 1+16):
            if Rp[17+i:17+i+1] != " ":
                eval("PAuxChan%d"%i).set(1)
        PAuxSPer.set(Rp[34:34+8].strip())
        PAuxRl.set(Rp[44:44+8].strip())
        if Rp[52:52+1] != " ":
            PAuxRam.set(1)
        if Rp[53:53+1] != " ":
            PAuxDisk.set(1)
        if Rp[54:54+1] != " ":
            PAuxEther.set(1)
        if Rp[55:55+1] != " ":
            PAuxSerial.set(1)
# FINISHME - add Differential Control stuff for PA.
# These are a bit weird. Ask for both, but only use the one whose parameters
# are not blank (blanked by the 'erase parameters' command when the parameters
# were sent).
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   Auto-centering...")
        Cmd = rt130CmdFormat(DAS, "PRPQ1 PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", \
                    "   No Auto-centering Parameters request response!", \
                    True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
# Just look at a portion of the parameter space.
        if Rp[15:15+10].strip() == "":
# Our DASs only have two places to physically connect sensors, so we only have
# to check "sensors" 1 and 2. Since 1 didn't yield anything...
            Cmd = rt130CmdFormat(DAS, "PRPQ2 PR")
            writePort(DAS, Cmd)
            Rp = rt130GetRp(1, 15, 0)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No Auto-centering Parameters request response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# By this point we have all of the parameters we'll ever have.
        if Rp[15:15+10].strip() != "":
            if Rp[16:16+1] == "1":
                PACGroup.set(123)
            elif Rp[16:16+1] == "2":
                PACGroup.set(456)
            if Rp[17:17+1] == " ":
                PACEnable.set(0)
            elif Rp[17:17+1] == "Y":
                PACEnable.set(1)
            PACPeriod.set(intt(Rp[18:18+4]))
            PACCycle.set(Rp[22:22+2].strip())
            PACThresh.set(Rp[24:24+4].strip())
            PACAttempt.set(Rp[28:28+2].strip())
            PACRetry.set(Rp[30:30+2].strip())
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   Disks...")
        Cmd = rt130CmdFormat(DAS, "PRPZ  PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Disk Parameters request response!", True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        PDThresh.set(Rp[22:22+2].strip())
        if Rp[28:28+1] == "N":
            PDWrap.set(0)
        else:
            PDWrap.set(1)
        PDRetry.set(Rp[32:32+2].strip())
        if Rp[20:20+1] == "Y":
            PDETDump.set(1)
        else:
            PDETDump.set(0)
# PN1 is for the Ethernet parameters and PN2 is for the serial port parameters
# so we will need to ask for both. How to set PNPort to reflect which one
# the user wants to use remains a mystery, except to generate some warning
# messages when the parameters are summary'ed or sent to the DAS. If the
# parameters were sent with CHANGEO the port not in use may not have an IP
# address set. We'll check for that down below.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   Network...")
        Cmd = rt130CmdFormat(DAS, "PRPN1 PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Network Parameters request response!", \
                    True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
# Get what should be the IP address, check to see if there are any "."
# (as in 1.2.3.4), if not create an IP (0.0.0.0) then split it up into the
# individual tuples and .set() the vars.
        RawIP = Rp[18:18+15].replace(" ", "")
        try:
            RawIP.index(".")
        except ValueError:
            RawIP = "0.0.0.0"
        IPTups = RawIP.split(".")
        for i in xrange(1, 1+4):
            eval("PNEIP%d"%i).set(IPTups[(i-1)].strip())
# Since we are getting the parameters from one DAS set this.
        PNEFill.set(3)
        if Rp[33:33+1] == "P":
            PNEPortPow.set(1)
        elif Rp[33:33+1] == "T":
            PNEPortPow.set(2)
# Just so checking the parameters won't squawk when all zeros for everything
# are received from a completely wiped DAS.
        else:
            PNEPortPow.set(2)
        PNEMask.set(Rp[34:34+16].replace(" ", ""))
        PNEHost.set(Rp[50:50+16].replace(" ", ""))
        PNEGateway.set(Rp[66:66+16].replace(" ", ""))
        PNETDelay.set(Rp[90:90+2].strip())
        if Rp[82:82+1] == "K":
            PNEKeep.set(1)
        elif Rp[82:82+1] == "T":
            PNEKeep.set(2)
# Make this assumption since the allowed delay for tossing is 2-99 mins.
        elif PNSTDelay.get() == "0":
            PNSKeep.set(1)
# Serial port parms.
        Cmd = rt130CmdFormat(DAS, "PRPN2 PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Network Parameters request response!", \
                    True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
# Work on the IP address.
        RawIP = Rp[18:18+15].replace(" ", "")
        try:
            RawIP.index(".")
        except ValueError:
            RawIP = "0.0.0.0"
        IPTups = RawIP.split(".")
        for i in xrange(1, 1+4):
            eval("PNSIP%d"%i).set(IPTups[(i-1)].strip())
# Since we are getting the parameters from one DAS set this.
        PNSFill.set(3)
        PNSMask.set(Rp[34:34+16].replace(" ", ""))
        PNSHost.set(Rp[50:50+16].replace(" ", ""))
        PNSGateway.set(Rp[66:66+16].replace(" ", ""))
        PNSTDelay.set(Rp[90:90+2].strip())
        if Rp[82:82+1] == "K":
            PNSKeep.set(1)
        elif Rp[82:82+1] == "T":
            PNSKeep.set(2)
# Make this assumption since the allowed delay for tossing is 2-99 mins.
        elif PNSTDelay.get() == "0":
            PNSKeep.set(1)
        Mode = Rp[83:83+1]
        if Mode == "D":
            PNSMode.set(1)
        elif Mode == "A":
            PNSMode.set(2)
        elif Mode == "F":
            PNSMode.set(3)
        else:
            PNSMode.set(1)
        PNSSpeed.set(intt(Rp[84:84+6]))
# Try to determine what to set PNPort to by just looking at the first tuple
# If blanks are sent to a DAS for the IP address, then the DAS is reset,
# older versions of the firmware will return 000.000.000.000, while newer
# versions will return 0.0.0.0.  If the first tuple of both addresses is 0 or
# 000 we'll guess that the addresses are not real and set the intened port to
# "none".  If you don't do a reset the DASs will return just blanks for the
# IP addresses.
        if (PNEIP1.get() == "" and PNSIP1.get() == "") or \
                (PNEIP1.get() == "0" and PNSIP1.get() == "0") or \
                (PNEIP1.get() == "000" and PNSIP1.get() == "000"):
            PNPort.set(0)
        elif PNEIP1.get() != "" and PNSIP1.get() == "":
            PNPort.set(1)
        elif PNEIP1.get() == "" and PNSIP1.get() != "":
            PNPort.set(2)
        elif PNEIP1.get() != "" and \
                (PNSIP1.get() == "0" and PNSIP2.get() == "0" and \
                PNSIP3.get() == "0" and PNSIP4.get() == "0"):
            PNPort.set(1)
        else:
            PNPort.set(0)
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   GPS control...")
            Cmd = rt130CmdFormat(DAS, "SSXC              SS")
            writePort(DAS, Cmd)
            Rp = rt130GetRp(1, 5, 0)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No External Clock Status command response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
            PGPSMode.set(Rp[85:85+1])
        formSTATSetStatus(DAS, "G")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
    stoppedMe(WorkState, "")
# Just in case the parms window is up.
    formPRAMSShowEvents()
    buttonControl("RECEIVE", "", 0)
    return
# END: receiveParmsCmd




#######################
# BEGIN: remAllDASCmd()
# FUNC:remAllDASCmd():2009.026
def remAllDASCmd():
# If some other action is running don't start this one.
    if isItOKToStart(0) == False:
        return
# Clear out all DASs we had in the list.
    formSTATClearID("0")
    return
# END: remAllDASCmd




#######################
# BEGIN: resetProgCmd()
# FUNC:resetProgCmd():2008.012
#   Resets the color of all of the buttons and clears WorkState (via
#   buttonControl) after something has gone wrong. Maybe.
def resetProgCmd():
    Keys = Buts.keys()
    for Key in Keys:
        buttonControl(Key, "", 0)
    closeCmdPort()
    msgLn(0, "R", "Reset commands.")
    return
# END: resetProgCmd




#######################
# BEGIN: saveParmsCmd()
# FUNC:saveParmsCmd():2010.322
def saveParmsCmd():
    global LastPRMFile
    if LastPRMFile == "":
        SaveFile = formMYDF(Root, 3, "Save Parameters To FIle...", \
                PROGWorkDirVar.get(), "", "", ".prm")
    else:
        SaveFile = formMYDF(Root, 3, "Save Parameters To File...", \
                dirname(LastPRMFile), basename(LastPRMFile), "", ".prm")
    if SaveFile == "":
        msgLn(0, "", "Parameters not saved.")
        return
    try:
        Fp = open(SaveFile, "w")
    except Exception, e:
        msgLn(1, "M", "Error opening the parameter file", True, 3)
        msgLn(1, "M", "   %s"%SaveFile)
        msgLn(0, "M", "   "+str(e))
        return
# Let the user know what problems are being saved
    checkParms(False)
    Fp.write("Version: %s\n"%PFILE_VERSION)
    Fp.write("ExpName: %s\n"%PExpName.get())
    Fp.write("ExpComment: %s\n"%PExpComment.get())
    for c in xrange(1, 1+6):
        Fp.write("C%dName: %s\n"%(c, eval("PC%dName"%c).get()))
        Fp.write("C%dGain: %d\n"%(c, eval("PC%dGain"%c).get()))
        Fp.write("C%dComment: %s\n"%(c, eval("PC%dComment"%c).get()))
    for d in xrange(1, 1+4):
        Fp.write("DS%dName: %s\n"%(d, eval("PDS%dName"%d).get()))
        Fp.write("DS%dDisk: %d\n"%(d, eval("PDS%dDisk"%d).get()))
        Fp.write("DS%dEther: %d\n"%(d, eval("PDS%dEther"%d).get()))
        Fp.write("DS%dSerial: %d\n"%(d, eval("PDS%dSerial"%d).get()))
        Fp.write("DS%dRam: %d\n"%(d, eval("PDS%dRam"%d).get()))
        for c in xrange(1, 1+6):
            Fp.write("DS%dChan%d: %d\n"% \
                    (d, c, eval("PDS%dChan%d"%(d,c)).get()))
        Fp.write("DS%dSampRate: %s\n"%(d, eval("PDS%dSampRate"%d).get()))
        Fp.write("DS%dFormat: %s\n"%(d, eval("PDS%dFormat"%d).get()))
        Fp.write("DS%dTType: %d\n"%(d, eval("PDS%dTType"%d).get()))
        for c in xrange(1, 1+6):
            Fp.write("DS%dTChan%d: %d\n"% \
                    (d, c, eval("PDS%dTChan%d"%(d,c)).get()))
        Fp.write("DS%dMc: %s\n"%(d, eval("PDS%dMc"%d).get()))
        Fp.write("DS%dPreTrigLen: %s\n"%(d, eval("PDS%dPretl"%d).get()))
        Fp.write("DS%dRecLen: %s\n"%(d, eval("PDS%dRl"%d).get()))
        Fp.write("DS%dSTA: %s\n"%(d, eval("PDS%dSta"%d).get()))
        Fp.write("DS%dLTA: %s\n"%(d, eval("PDS%dLta"%d).get()))
        Fp.write("DS%dLTAHold: %d\n"%(d, eval("PDS%dHold"%d).get()))
        Fp.write("DS%dTrigRatio: %s\n"%(d, eval("PDS%dTr"%d).get()))
        Fp.write("DS%dTrigWin: %s\n"%(d, eval("PDS%dTwin"%d).get()))
        Fp.write("DS%dPostTrigLen: %s\n"%(d, eval("PDS%dPostl"%d).get()))
        Fp.write("DS%dDeTrigRatio: %s\n"%(d, eval("PDS%dDtr"%d).get()))
        for i in xrange(1, 1+11):
            Fp.write("DS%dStart%d: %s\n"% \
                    (d, i, eval("PDS%dStart%d"%(d,i)).get()))
        Fp.write("DS%dTrigStrm: %d\n"%(d, eval("PDS%dTStrm"%d).get()))
        Fp.write("DS%dTrigLevel: %s\n"%(d, eval("PDS%dTlvl"%d).get()))
        Fp.write("DS%dLPFreq: %d\n"%(d, eval("PDS%dLPFreq"%d).get()))
        Fp.write("DS%dHPFreq: %d\n"%(d, eval("PDS%dHPFreq"%d).get()))
        Fp.write("DS%dRepeatInt: %s\n"%(d, eval("PDS%dRepInt"%d).get()))
        Fp.write("DS%dNumTrig: %s\n"%(d, eval("PDS%dNumTrig"%d).get()))
    Fp.write("AuxMark: %s\n"%PAuxMarker.get())
    for c in xrange(1, 1+16):
        Fp.write("AuxChan%d: %d\n"%(c, eval("PAuxChan%d"%c).get()))
    Fp.write("AuxDisk: %d\n"%PAuxDisk.get())
    Fp.write("AuxEthernet: %d\n"%PAuxEther.get())
    Fp.write("AuxSerial: %d\n"%PAuxSerial.get())
    Fp.write("AuxRAM: %d\n"%PAuxRam.get())
    Fp.write("AuxFreq: %s\n"%PAuxSPer.get())
    Fp.write("AuxRecLen: %s\n"%PAuxRl.get())
    Fp.write("ACGroup: %d\n"%PACGroup.get())
    Fp.write("ACEnable: %d\n"%PACEnable.get())
    Fp.write("ACCycle: %s\n"%PACCycle.get())
    Fp.write("ACThreshold: %s\n"%PACThresh.get())
    Fp.write("ACAttempt: %s\n"%PACAttempt.get())
    Fp.write("ACRetry: %s\n"%PACRetry.get())
    Fp.write("ACPeriod: %d\n"%PACPeriod.get())
    Fp.write("NPort: %d\n"%PNPort.get())
    Fp.write("NPortPower: %d\n"%PNEPortPow.get())
    Fp.write("NEthernetKeep: %d\n"%PNEKeep.get())
    Fp.write("NEthernetTossDelay: %s\n"%PNETDelay.get())
    Fp.write("NEthernetIP1:%s\n"%PNEIP1.get())
    Fp.write("NEthernetIP2:%s\n"%PNEIP2.get())
    Fp.write("NEthernetIP3:%s\n"%PNEIP3.get())
    Fp.write("NEthernetIP4:%s\n"%PNEIP4.get())
    Fp.write("NEthernetFill: %d\n"%PNEFill.get())
    Fp.write("NEthernetMask: %s\n"%PNEMask.get())
    Fp.write("NEthernetHost: %s\n"%PNEHost.get())
    Fp.write("NEhternetGateway: %s\n"%PNEGateway.get())
    Fp.write("NSerialKeep: %d\n"%PNSKeep.get())
    Fp.write("NSerialTossDelay: %s\n"%PNSTDelay.get())
    Fp.write("NSerialMode: %d\n"%PNSMode.get())
    Fp.write("NSerialSpeed: %d\n"%PNSSpeed.get())
    Fp.write("NSerialIP1: %s\n"%PNSIP1.get())
    Fp.write("NSerialIP2: %s\n"%PNSIP2.get())
    Fp.write("NSerialIP3: %s\n"%PNSIP3.get())
    Fp.write("NSerialIP4: %s\n"%PNSIP4.get())
    Fp.write("NSerialFill: %d\n"%PNSFill.get())
    Fp.write("NSerialMask: %s\n"%PNSMask.get())
    Fp.write("NSerialHost: %s\n"%PNSHost.get())
    Fp.write("NSerialGateway: %s\n"%PNSGateway.get())
    Fp.write("DWrap: %d\n"%PDWrap.get())
    Fp.write("DDumpThreshold: %s\n"%PDThresh.get())
    Fp.write("DEventTrailerDump: %d\n"%PDETDump.get())
    Fp.write("DRetry: %s\n"%PDRetry.get())
    Fp.write("GPSMode: %s\n"%PGPSMode.get())
    Fp.close()
    msgLn(1, "W", "Parameters saved to file:")
    msgLn(0, "", "   "+SaveFile)
# Preserve the used file name for a next time
    LastPRMFile = SaveFile
    return
# END: saveParmsCmd




########################
# BEGIN: sendParmsCmd()
# FUNC:sendParmsCmd():2009.315
#   Does the actual work of sending the parameters to the DASs.
def sendParmsCmd():
    global WorkState
    if checkParms(True) == False:
        return
    Status, ListOfDASs = isItOKToStart(3)
    if Status == False:
        return
    WorkState = 100
    buttonControl("SEND", "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        buttonControl("SEND", "", 0)
        return
# For use in setting IP addresses.
    DASCount = -1
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        msgLn(1, "", "%d. %s: Programming... (%s)"%(Count, DAS, getGMT(0)))
        DASCount += 1
# Stop acquisition. Send the command, wait for a response.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "C", "   Stopping acquisition...")
        Cmd = rt130CmdFormat(DAS, "AQH 0000AQ")
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(3)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Stop Acquisition command response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# Erase parameters.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "C", "   Erasing parameters...")
        Cmd = rt130CmdFormat(DAS, "PEPE")
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(3)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Erase Parameters command response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# The network parameters do not get erased when the erase parameters command
# is sent (above), so we'll do that here.
        Cmd = rt130CmdFormat(DAS, "PN1 "+padR("", 76)+"PN")
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(3)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                      "   No Network Ethernet Parameters clearing response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
        Cmd = rt130CmdFormat(DAS, "PN2 "+padR("", 76)+"PN")
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(3)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No Network Serial Parameters clearing response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# Station parameters.
        if len(PExpName.get()) != 0 or len(PExpComment.get()) != 0:
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "C", "   Station...")
            Cmd = rt130CmdFormat(DAS, "PS"+ \
                    padR("", 2)+ \
                    padR(PExpName.get(), 24)+ \
                    padR(PExpComment.get(), 40)+ \
                    padR("", 4)+padR("", 24)+padR("", 40)+"PS")
            writePort(DAS, Cmd)
            if DAS == "0000":
                delay(3)
                if WorkState == 999:
                    continue
            else:
                Rp = rt130GetRp(1, 5, 2)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", \
                            "   No Station Parameters command response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
# Channel parameters.
        for c in xrange(1, 1+6):
            if sendChanParms(DAS, c, eval("PC%dName"%c), eval("PC%dGain"%c), \
                    eval("PC%dComment"%c)) == False:
                break
        if WorkState == 999:
            continue
# Data stream parameters.
        for d in xrange(1, 1+4):
            if sendDSParms(DAS, d) == False:
                break
        if WorkState == 999:
            continue
# Auxiliary data parameters.
# Only send these if the sampling frequency has been set.
        if PAuxSPer.get() != 0:
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "C", "   Auxiliary data...")
            Chans = ""
            for c in xrange(1, 1+16):
                if eval("PAuxChan%d"%c).get() != 0:
                    Chans = Chans+"Y"
                else:
                    Chans = Chans+" "
            Dest = ""
            for s in ("Ram", "Disk", "Ether", "Serial"):
                if eval("PAux%s"%s).get() != 0:
                    Dest = Dest+"Y"
                else:
                    Dest = Dest+" "
# FINISHME - add Differential Control stuff.
            Cmd = rt130CmdFormat(DAS, "PA"+padR(PAuxMarker.get(), 2)+ \
                    padR(Chans, 16)+padR(PAuxSPer.get(), 8)+"16"+ \
                    padR(PAuxRl.get(), 8)+Dest+padR("", 12)+"PA")
            writePort(DAS, Cmd)
            if DAS == "0000":
                delay(3)
                if WorkState == 999:
                    continue
            else:
                Rp = rt130GetRp(1, 5, 2)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", \
                            "   No Auxiliary Parameters command response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "Y")
                    AllOK = False
                    WorkState = 999
                    continue
# Auto-centering parameters.
# Only send these if the channel group has been set to something.
        if PACGroup.get() != 0:
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "C", "   Auto-centering...")
            if PACGroup.get() == 123:
               Group = "1"
            elif PACGroup.get() == 456:
               Group = "2"
            if PACEnable.get() == 0:
               Enable = " "
            elif PACEnable.get() == 1:
               Enable = "Y"
            Cmd = rt130CmdFormat(DAS, "PQ"+Group+Enable+ \
                    padR(str(PACPeriod.get()), 4)+ \
                    padR(PACCycle.get(), 2)+ \
                    padR(PACThresh.get(), 4)+ \
                    padR(PACAttempt.get(), 2)+ \
                    padR(PACRetry.get(), 2)+"PQ")
            writePort(DAS, Cmd)
            if DAS == "0000":
                delay(3)
                if WorkState == 999:
                    continue
            else:
                Rp = rt130GetRp(1, 5, 2)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", \
                         "   No Auto-centering Parameters command response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
# Disk parameters.
# Always send these.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "C", "   Disk...")
        if PDETDump.get() == 0:
            Dump = "N"
        else:
            Dump = "Y"
        if PDWrap.get() == 0:
            Wrap = "N"
        else:
            Wrap = "Y"
        Cmd = rt130CmdFormat(DAS, "PZ"+"    "+Dump+" "+ \
                padR(PDThresh.get(), 2)+"    "+Wrap+"   "+ \
                padR(PDRetry.get(), 1)+padR("", 11)+"PZ")
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(3)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Disk Parameters command response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# Network parameters - we will send whatever the user has entered for both
# sets of parameters no matter which we intend to use with the exception of
# setting the serial host to 0.0.0.0 when we know that it is intended to use
# the Ethernet port.
# If we are not going to use either one then just leave the parameters erased.
        if PNPort.get() != 0:
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "C", "   Ethernet Network...")
            if DAS == "0000":
# For lack of anything else.
                IPaddr = "192.168.1.1"
            else:
                IPaddr = makeIP(PNEFill.get(), DAS, 16, DASCount, \
                       PNEIP1.get(), PNEIP2.get(), PNEIP3.get(), PNEIP4.get())
            Power = " "
            if PNEPortPow.get() == 1:
                Power = "P"
            elif PNEPortPow.get() == 2:
                Power = "T"
            KeepToss = " "
            if PNEKeep.get() == 1:
                KeepToss = "K"
            elif PNEKeep.get() == 2:
                KeepToss = "T"
            Mode = " "
            Cmd = rt130CmdFormat(DAS, "PN"+padR("1", 2)+padR(IPaddr, 15)+ \
                    Power+padR(PNEMask.get(), 16)+ \
                    padR(PNEHost.get(), 16)+ \
                    padR(PNEGateway.get(), 16)+ \
                    KeepToss+Mode+padR("", 6)+ \
                    padR("%s"%PNETDelay.get(), 2)+"  "+"PN")
            writePort(DAS, Cmd)
            if DAS == "0000":
                delay(3)
                if WorkState == 999:
                    continue
            else:
                Rp = rt130GetRp(1, 5, 2)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", \
                       "   No Network Ethernet Parameters command response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
# Let the user know what the Ethernet network address was set to.
            if PNPort.get() == 1 or PNPort.get() == 3:
                msgLn(1, "", "   Ethernet IP address set to: "+IPaddr)
# Set all of the serial port stuff to whatever the user has entered.
            if OPTSummaryModeCVar.get() == 0:
                msgLn(1, "C", "   Serial Network...")
            if DAS == "0000":
# For lack of anything else.
                IPaddr = "192.168.1.1"
            else:
                IPaddr = makeIP(PNSFill.get(), DAS, 16, DASCount, \
                       PNSIP1.get(), PNSIP2.get(), PNSIP3.get(), PNSIP4.get())
            KeepToss = " "
            if PNSKeep.get() == 1:
                KeepToss = "K"
            elif PNSKeep.get() == 2:
                KeepToss = "T"
            Mode = " "
            if PNSMode.get() == 1:
                Mode = "D"
            elif PNSMode.get() == 2:
                Mode = "A"
            elif PNSMode.get() == 3:
                Mode = "F"
# If we intend to use just the Ethernet port set this which is about the only
# thing I can see that determines exactly which port is intended.
            if PNPort.get() == 1:
                PNSHost.set("0.0.0.0")
            Cmd = rt130CmdFormat(DAS, "PN"+padR("2", 2)+padR(IPaddr, 15)+ \
                    " "+padR(PNSMask.get(), 16)+ \
                    padR(PNSHost.get(), 16)+ \
                    padR(PNSGateway.get(), 16)+ \
                    KeepToss+Mode+padR("%d"%PNSSpeed.get(), 6)+
                    padR("%s"%PNSTDelay.get(), 2)+"  "+"PN")
            writePort(DAS, Cmd)
            if DAS == "0000":
                delay(3)
                if WorkState == 999:
                    continue
            else:
                Rp = rt130GetRp(1, 5, 2)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", \
                         "   No Network Serial Parameters command response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
# Let the user know what the network address was set to.
            if PNPort.get() == 2 or PNPort.get() == 3:
                msgLn(1, "", "   Serial IP address set to: "+IPaddr)
# GPS operaing mode.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "C", "   GPS op mode...")
        Mode = PGPSMode.get()
# Just in case since it's kinda important.
        if Mode != "N" and Mode != "D" and Mode != "O":
            Mode = "N"
        Cmd = rt130CmdFormat(DAS, "GC%s       GC"%Mode)
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(2)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No GPS Control command response!", True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# Implement the parameters.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "C", "   Implementing...")
        Cmd = rt130CmdFormat(DAS, "PIPI")
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(3)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Implement Parameters command response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# Set all of them or one of them green if we made it all of the way to here.
        formSTATSetStatus(DAS, "G")
    closeCmdPort()
# This will either set the one we were working on or all of them yellow.
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
    stoppedMe(WorkState, DAS)
    buttonControl("SEND", "", 0)
    return
# END: sendParmsCmd




###################################
# BEGIN: sendToPIS(PISData, Prefix)
# LIB:sendToPIS():2010.135
#   Handles the low-level communications with the Incoming.py server program
#   on the database machine.
def sendToPIS(PISData, Prefix):
    CSock = socket(AF_INET, SOCK_STREAM)
    try:
        CSock.connect(("piss.passcal.nmt.edu", 15142))
    except Exception, e:
        return (2, "MW", \
                "%sError connecting to server.\n%sData not sent.\n%s%s"% \
                (Prefix, Prefix, Prefix, str(e)), 3)
    CSock.sendall(PISData+" <ETX>")
# Wait for the response..
    InLine = ""
    In = ""
# WARNIING FINISHME - This won't really work without setting .settimeout, but
# I couldn't get a socket timeout to work with .recv if the server crashed.
# Maybe it is a bug in Python?
    Trys = 0
    while 1:
        if OPTDebugCVar.get() != 0:
            print("Trying to recv %d"%Trys)
        In = CSock.recv(2048)
        InLine += In
        if InLine.endswith("<ACK>"):
            break
        Trys += 1
        if Trys > 4:
            break
    CSock.close()
    if OPTDebugCVar.get() != 0:
        print("Recv: %s"%InLine)
    if InLine.endswith("<ACK>"):
# Return what should be the tuple part of InLine.
        return eval(InLine[:-5])
    elif InLine[:-5].strip() == "":
        return (2, "MW", Prefix+"Connection refused.", 3)
    else:
        return (2, "MW", Prefix+"Data transmission error.", 3)
# END: sendToPIS




##########################
# BEGIN: setGainCmd(Which)
# FUNC:setGainCmd():2009.315
def setGainCmd(Which):
    global WorkState
    Status, ListOfDASs = isItOKToStart(2)
    if Status == False:
        return
    WorkState = 100
    if Which == "high":
        buttonControl("SGAINHIGH", "G", 1)
    elif Which == "low":
        buttonControl("SGAINLOW", "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        if Which == "high":
            buttonControl("SGAINHIGH", "", 0)
        elif Which == "low":
            buttonControl("SGAINLOW", "", 0)
        return
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        msgLn(1, "", "%d. %s: Setting gain %s... (%s)"% \
                (Count, DAS, Which, getGMT(0)))
# Get the current setup of the DAS to figure out which channels to set
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "W", "   Getting parameter status...")
        Cmd = rt130CmdFormat(DAS, "SSPR              SS")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Parameter Status request response!", True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        Chans = intt(Rp[32:32+2])
        Channels = mrDash(Rp[40:40+Chans])
        ChanNum = 0
        for Chan in Channels:
            if WorkState == 999 or AllOK == False:
                break
            ChanNum += 1
            if Chan != "-":
                if OPTSummaryModeCVar.get() == 0:
                    msgLn(1, "C", "   Setting channel "+str(ChanNum))
                if Which == "high":
                    Cmd = rt130CmdFormat(DAS, "IG"+padR(str(ChanNum), 2)+ \
                                        padR("100", 4)+"IG")
                elif Which == "low":
                    Cmd = rt130CmdFormat(DAS, "IG"+padR(str(Chan), 2)+ \
                                        padR("1", 4)+"IG")
                writePort(DAS, Cmd)
                Rp = rt130GetRp(1, 5, 2)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", "   No Immediate Gain request response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
        if WorkState == 999 or AllOK == False:
            continue
        formSTATSetStatus(DAS, "G")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
    stoppedMe(WorkState, "")
    if Which == "high":
        buttonControl("SGAINHIGH", "", 0)
    elif Which == "low":
        buttonControl("SGAINLOW", "", 0)
    return
# END: setGainCmd




#####################
# BEGIN: setTimeCmd()
# FUNC:setTimeCmd():2010.162
def setTimeCmd():
    global WorkState
    Status, ListOfDASs = isItOKToStart(3)
    if Status == False:
        return
    WorkState = 100
# Call with None just to control the Stop button.
    buttonControl(None, "G", 1)
    formSTATSetStatus("all", "B")
    MYDAnswerVar.set("")
    Answer = formMYD(Root, (("Input25", TOP, "input"), \
            ("Use Input Above", TOP, "input"), ("Use CC Time", TOP, "pc"), \
            ("Cancel", TOP, "cancel")), "cancel", "", "Which One?", \
"Enter a time (YYYY:DDD:HH:MM:SS format) in the field below and click the Use Input Above button, or click the Use CC Time button to set the time using the current control computer time.")
    if Answer == "cancel":
        msgLn(0, "", "Nothing done.")
        buttonControl(None, "", 0)
        return
    elif Answer != "pc":
        TheTime = Answer.strip()
        if len(TheTime) != 17:
            msgLn(0, "R", "Bad input time: %s"%TheTime, True, 2)
            buttonControl(None, "", 0)
            return
        GMT = TheTime
        msgLn(1, "G", "Using time: %s"%GMT)
    else:
        GMT = getGMT(0)
        msgLn(1, "G", "Current CC time: %s"%GMT)
    if openCmdPort() == False:
        buttonControl(None, "", 0)
        return
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        msgLn(1, "C", "   %d. %s: Setting time..."%(Count, DAS))
# Get the time from the CC for each DAS and send it. Wait for a response
        if Answer == "pc":
            GMT = getGMT(0)
        Cmd = rt130CmdFormat(DAS, "TS%sM00TS"%GMT)
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(3)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 2)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", "   No Time Set command response!", True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
    stoppedMe(WorkState, DAS)
    buttonControl(None, "", 0)
    return
# END: setTimeCmd




##############################
# BEGIN: startSimpleCmd(Which)
# FUNC:startSimpleCmd():2010.162
def startSimpleCmd(Which):
    global WorkState
    Cmd = ""
    Status, ListOfDASs = isItOKToStart(3)
    if Status == False:
        return
    if Which == "CLEARRAM":
        Answer = formMYD(Root, (("Continue", LEFT, "cont"), ("Stop", LEFT, \
                "stop")), "stop", "YB", "As Good As Gone.", \
                "Clearing RAM will wipe out everything in RAM. Are you sure you want to continue or do you want to stop?")
        if Answer == "stop":
            return
    if Which == "RESET":
        Answer = formMYD(Root, (("Continue", LEFT, "cont"), ("Stop", LEFT, \
                "stop")), "stop", "YB", "Think.", \
                "Resetting may stop acquisition and disturb any test in progress. Are you sure you want to continue or do you want to stop?")
        if Answer == "stop":
            return
    WorkState = 100
    buttonControl(Which, "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        buttonControl(Which, "", 0)
        return
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
# Send the command and wait for a response.
        Count += 1
        if Which == "STARTACQ":
            msgLn(1, "C", "%d. %s: Starting acquisition... (%s)"% \
                    (Count, DAS, getGMT(0)))
            Cmd = rt130CmdFormat(DAS, "AQS 0000AQ")
        elif Which == "STOPACQ":
            msgLn(1, "C", "%d. %s: Stopping acquisition... (%s)"% \
                    (Count, DAS, getGMT(0)))
            Cmd = rt130CmdFormat(DAS, "AQH 0000AQ")
        elif Which == "CLEARRAM":
            msgLn(1, "C", "%d. %s: Clearing RAM... (%s)"% \
                    (Count, DAS, getGMT(0)))
            Cmd = rt130CmdFormat(DAS, "MFRMMF")
        elif Which == "DUMPRAM":
            msgLn(1, "C", "%d. %s: Dumping RAM... (%s)"% \
                    (Count, DAS, getGMT(0)))
            Cmd = rt130CmdFormat(DAS, "FD  FD")
        elif Which == "RESET":
            msgLn(1, "C", "%d. %s: Resetting... (%s)"% \
                    (Count, DAS, getGMT(0)))
            Cmd = rt130CmdFormat(DAS, "RS  RS")
        writePort(DAS, Cmd)
        if DAS == "0000":
            delay(3)
            if WorkState == 999:
                continue
        else:
            Rp = rt130GetRp(1, 5, 3)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                if Which == "START":
                    msgLn(1, "M", "   No Start Acq command response!", True, 3)
                elif Which == "STOP":
                    msgLn(1, "M", "   No Stop Acq command response!", True, 3)
                elif Which == "CLEARRAM":
                    msgLn(1, "M", "   No Clear RAM command response!", True, 3)
                elif Which == "DUMPRAM":
                    msgLn(1, "M", "   No Dump RAM command response!", True, 3)
                elif Which == "RESET":
                    msgLn(1, "M", "   No Reset command response!", True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
        formSTATSetStatus(DAS, "G")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
    stoppedMe(WorkState, DAS)
    buttonControl(Which, "", 0)
    return
# END: startSimpleCmd




####################
# BEGIN: statusCmd()
# FUNC:statusCmd():2009.315
#   Steps through the list of DASs and prints the selected status items.
def statusCmd():
    global WorkState
    Status, ListOfDASs = isItOKToStart(2)
    if Status == False:
        return
    if RAMStatCVar.get() == 0 and ParmsStatCVar.get() == 0 and \
            GPSStatVar.get() == 0 and DStatVar.get() == 0 and \
            VStatVar.get() == 0:
        msgLn(0, "R", "Select something to get the status of.", True, 2)
        return
    WorkState = 100
    buttonControl("STATUS", "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        buttonControl("STATUS", "", 0)
        return
    while(1):
        Count = 0
        for DAS in ListOfDASs:
            if WorkState == 999:
                break
# Since you can select what to check for on the fly...
            if RAMStatCVar.get() == 0 and ParmsStatCVar.get() == 0 and \
                    GPSStatVar.get() == 0 and DStatVar.get() == 0 and \
                    VStatVar.get() == 0:
                msgLn(1, "R", "Nothing is selected to get the status of.", \
                        True, 2)
                continue
            formSTATSetStatus(DAS, "C")
            AllOK = True
            Count += 1
            msgLn(1, "W", "%d. %s: DAS Status... (%s)"% \
                    (Count, DAS, getGMT(0)))
            DASTimeDone = False
# Acquisition Status request.
            if RAMStatCVar.get() == 1:
                Cmd = rt130CmdFormat(DAS, "SSAQ              SS")
                writePort(DAS, Cmd)
# No Lag. It's just an info request.
                Rp = rt130GetRp(1, 5, 0)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", \
                            "   No Acquisition Status command response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
                DASTime = Rp[14:14+18]
                AcqState = ""
                if Rp[32:32+1] == "Y":
                    AcqState = "START "
                else:
                    AcqState = "STOP "
                if Rp[33:33+1] == "Y":
                    AcqState = AcqState+"ON"
                else:
                   AcqState = AcqState+"OFF"
                Events = Rp[34:34+6].strip()
                RAMUsed = Rp[48:48+6].strip()
                RAMTotal = Rp[42:42+6].strip()
                if DASTimeDone == False:
                    msgLn(1, "", "   DAS Time: ", False)
                    msgLn(1, "G", DASTime)
                    DASTimeDone = True
                msgLn(1, "", "   Acq state: ", False)
                if AcqState == "START ON":
                    msgLn(1, "G", AcqState, False)
                elif AcqState == "STOP ON":
                    msgLn(1, "Y", AcqState, False)
                else:
                    msgLn(1, "R", AcqState, False)
                msgLn(1, "", "    Events: ", False)
                msgLn(1, "G", Events)
                msgLn(1, "", "   RAM Used: ", False)
                msgLn(1, "G", RAMUsed+" of "+RAMTotal+" KB")
# Parameters status (summary).
            if ParmsStatCVar.get() == 1:
                Cmd = rt130CmdFormat(DAS, "SSPR              SS")
                writePort(DAS, Cmd)
                Rp = rt130GetRp(1, 5, 0)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", \
                            "   No Parameter Status request response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
                DASTime = Rp[14:14+18]
                Chans = intt(Rp[32:32+2])
                DSs = intt(Rp[34:34+1])
                Channels = mrDash(Rp[40:40+Chans])
                DStreams = mrDash(Rp[40+Chans:40+Chans+DSs])
                if DASTimeDone == False:
                    msgLn(1, "", "   DAS Time: ", False)
                    msgLn(1, "G", DASTime)
                    DASTimeDone = True
                msgLn(1, "", "   Parms: Chs: ", False)
                if Channels == "------":
                    msgLn(1, "Y", Channels, False)
                else:
                    msgLn(1, "G", Channels, False)
                msgLn(1, "", "    DSs: ", False)
                if DStreams == "--------":
                    msgLn(1, "Y", DStreams)
                else:
                    msgLn(1, "G", DStreams)
# Xternal clock status
            if GPSStatVar.get() == 1:
                Cmd = rt130CmdFormat(DAS, "SSXC              SS")
                writePort(DAS, Cmd)
                Rp = rt130GetRp(1, 5, 0)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", \
                            "   No External Clock Status command response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
                DASTime = Rp[14:14+18]
                TSLL = Rp[32:32+8].strip()
                LockStatus = Rp[51:51+1]
                if Rp[84:84+1] == "Y":
                    GPSState = "ON"
                else:
                    GPSState = "SLEEP"
                LLPhase = Rp[40:40+11].strip()
                SVTracked = Rp[52:52+2].strip()
                if OPTPosDddd.get() == 1:
                    Latitude = deciDeg(Rp[54:54+12].replace(" ", ""))
                    Longitude = deciDeg(Rp[66:66+12])
                else:
                    Latitude = Rp[54:54+12].replace(" ", "")
                    Longitude = Rp[66:66+12]
                Elevation = Rp[78:78+6]
                GPSOpMode = Rp[85:85+1]
                if DASTimeDone == False:
                    msgLn(1, "", "   DAS Time: ", False)
                    msgLn(1, "G", DASTime)
                    DASTimeDone = True
                msgLn(1, "", "   GPS State: ", False)
                if GPSState == "ON":
                    msgLn(1, "G", GPSState, False)
                elif GPSState == "SLEEP":
                    msgLn(1, "Y", GPSState, False)
                else:
                    msgLn(1, "R", GPSState, False)
                msgLn(1, "", "  Lock: ", False)
                if LockStatus == "L":
                    msgLn(1, "G", LockStatus, False)
                else:
                    msgLn(1, "Y", LockStatus, False)
                msgLn(1, "", "  SV: ", False)
                if intt(SVTracked) < 4:
                    msgLn(1, "Y", "%s"%SVTracked, False)
                else:
                    msgLn(1, "G", "%s"%SVTracked, False)
                msgLn(1, "", "  TSLL: ", False)
                if TSLL < "00:00:25":
                    msgLn(1, "G", TSLL)
                else:
                    msgLn(1, "Y", TSLL)
                msgLn(1, "", "   Phase: ", False)
                if intt(LLPhase) > -10 and intt(LLPhase) < 10:
                    msgLn(1, "G", "%s"%LLPhase)
                else:
                    msgLn(1, "Y", "%s"%LLPhase)
                msgLn(1, "", "   Lat: ", False)
                if Latitude == "N00.00000" or Latitude == "N00:00.0000":
                    msgLn(1, "Y", Latitude, False)
                else:
                    msgLn(1, "G", Latitude, False)
                msgLn(1, "", "  Long: ", False)
                if Longitude == "E000.00000" or Longitude == "E000:00.0000":
                    msgLn(1, "Y", Longitude, False)
                else:
                    msgLn(1, "G", Longitude, False)
                msgLn(1, "", "  Elev: ", False)
                msgLn(1, "G", Elevation)
                msgLn(1, "", "   GPS Op Mode: ", False)
                if GPSOpMode == "D":
                    msgLn(1, "G", "Normal Duty Cycle")
                elif GPSOpMode == "C":
                    msgLn(1, "Y", "Continuous")
                elif GPSOpMode == "O":
                    msgLn(1, "R", "Off")
                else:
                    msgLn(1, "M", "Unknown")
# Get the status of the disk drives
            if DStatVar.get() == 1:
                Cmd = rt130CmdFormat(DAS, "SSDK              SS")
                writePort(DAS, Cmd)
                Rp = rt130GetRp(1, 5, 0)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", "   No Disk Status command response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
                DASTime = Rp[14:14+18]
                D1Used = Rp[38:38+6].strip()
                D1Total = Rp[32:32+6].strip()
                D2Used = Rp[56:56+6].strip()
                D2Total = Rp[50:50+6].strip()
                if Rp[68:68+1] == "1":
                    D1Curr = "*"
                    D2Curr = " "
                else:
                    D1Curr = " "
                    D2Curr = "*"
                if DASTimeDone == False:
                    msgLn(1, "", "   DAS Time: ", False)
                    msgLn(1, "G", DASTime)
                    DASTimeDone = True
                if D1Total != "0":
                    msgLn(1, "", "   Disk 1: ", False)
                    msgLn(1, "G", D1Curr+D1Used+" of "+D1Total+" MB")
                else:
                    msgLn(1, "", "   Disk 1: ", False)
                    msgLn(1, "Y", D1Curr+"Not installed")
                if D2Total != "0":
                    msgLn(1, "", "   Disk 2: ", False)
                    msgLn(1, "G", D2Curr+D2Used+" of "+D2Total+" MB")
                else:
                    msgLn(1, "", "   Disk 2: ", False)
                    msgLn(1, "Y", D2Curr+"Not installed")
# Unit Status (voltages)
            if VStatVar.get() == 1:
                Cmd = rt130CmdFormat(DAS, "SSUS              SS")
                writePort(DAS, Cmd)
                Rp = rt130GetRp(1, 5, 0)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", "   No Unit Status command response!", \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
                DASTime = Rp[14:14+18]
                InVolts = Rp[32:32+4].strip()
                BUVolts = Rp[36:36+4].strip()
                Temp = Rp[40:40+6].strip()
                if DASTimeDone == False:
                    msgLn(1, "", "   DAS Time: ", False)
                    msgLn(1, "G", DASTime)
                    DASTimeDone = True
                msgLn(1, "", "   Input: ", False)
                if floatt(InVolts) > 10.0:
                    msgLn(1, "G", InVolts+"V", False)
                else:
                    msgLn(1, "R", InVolts+"V", False)
                msgLn(1, "", "    B/U: ", False)
                if floatt(BUVolts) > 2.6:
                    msgLn(1, "G", BUVolts+"V", False)
                else:
                    msgLn(1, "R", BUVolts+"V", False)
                msgLn(1, "", "    Temp: ", False)
                if floatt(Temp) > 30.0:
                    msgLn(1, "R", Temp+"C")
                elif floatt(Temp) > 10.0:
                    msgLn(1, "G", Temp+"C")
                else:
                    msgLn(1, "C", Temp+"C")
            formSTATSetStatus(DAS, "G")
        if LoopRVar.get() == "off":
            break
        else:
            loopDelay()
# loopDelay may have returned early because of one of these.
            if WorkState == 999 or LoopRVar.get() == "off":
                break
            msgLn(1, "", "")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
    stoppedMe(WorkState, "")
    buttonControl("STATUS", "", 0)
    return
# END: statusCmd




#####################
# BEGIN: stopAction()
# FUNC:stopAction():2008.040
def stopAction():
    global WorkState
    if WorkState == 999:
        msgLn(1, "Y", "Patience is a virtue...")
    elif WorkState != 0:
        msgLn(1, "Y", "Stopping...")
        buttonBG("STOP", "Y")
        WorkState = 999
    return
# END: stopAction




#####################
# BEGIN: sumModeCmd()
# FUNC:sumModeCmd():2003.315
def sumModeCmd():
    if OPTSummaryModeCVar.get() == 0:
        msgLn(0, "", "Summary mode turned OFF.")
    else:
        msgLn(0, "", "Summary mode turned ON.")
    return
# END: sumModeCmd




#####################
# BEGIN: summaryCmd()
# FUNC:summaryCmd():2009.063
#   Prints a summary of the current set of parameters.
def summaryCmd():
    if isItOKToStart(0) == False:
        return
    msgLn(1, "", "")
    msgLn(1, "W", "Parameter summary... (%s)"%getGMT(0))
    if PExpName.get() != "" or PExpComment.get() != "":
        msgLn(1, "W", "==== Station Parameters ====")
        if PExpName.get() != "":
            msgLn(1, "", "   Experiment Name: %s"%PExpName.get())
        if PExpComment.get() != "":
            msgLn(1, "", "Experiment Comment: %s"%PExpComment.get())
    msgLn(1, "", "")
    if PC1Gain.get() != 0 or PC2Gain.get() != 0 or PC3Gain.get() != 0 or \
            PC4Gain.get() != 0 or PC5Gain.get() != 0 or PC6Gain.get() != 0:
        msgLn(1, "W", "==== Channel Parameters ====")
        for c in xrange(1, 1+6):
            if eval("PC%dGain"%c).get() != 0:
                msgLn(1, "W", "----- Ch%d -----"%c)
                msgLn(1, "", "   Name: %s"%eval("PC%dName"%c).get())
                msgLn(1, "", "   Gain: %d"%eval("PC%dGain"%c).get())
                if eval("PC%dComment"%c).get() != "":
                    msgLn(1, "", "Comment: %s"%eval("PC%dComment"%c).get())
        msgLn(1, "", "")
    if PDS1TType.get() != 0 or PDS2TType.get() != 0 or PDS3TType.get() or \
            PDS4TType.get() != 0:
        msgLn(1, "W", "==== Data Stream Parameters ====")
        for d in xrange(1, 1+4):
# If no trigger type is set go to the next data stream
            if eval("PDS%dTType"%d).get() == 0:
                continue
            msgLn(1, "W", "----- DS%d -----"%d)
            msgLn(1, "", "Stream name: %s"%eval("PDS%dName"%d).get())
            msgLn(1, "", "   Channels: ", False)
            for c in xrange(1, 1+6):
                if eval("PDS%dChan%d"%(d,c)).get() != 0:
                    msgLn(1, "", "%d "%c, False)
            msgLn(1, "", "")
            msgLn(1, "", "Sample rate: %s"%eval("PDS%dSampRate"%d).get())
            msgLn(1, "", "Data format: ", False)
            if eval("PDS%dFormat"%d).get() == "":
                msgLn(1, "", "Not set")
            else:
                msgLn(1, "", eval("PDS%dFormat"%d).get())
            msgLn(1, "", "Destination: ", False)
            if eval("PDS%dDisk"%d).get() != 0:
                msgLn(1, "", "Disk ", False)
            if eval("PDS%dEther"%d).get() != 0:
                msgLn(1, "", "Ethernet ", False)
            if eval("PDS%dSerial"%d).get() != 0:
                msgLn(1, "", "Serial ", False)
            if eval("PDS%dRam"%d).get() != 0:
                msgLn(1, "", "RAM", False)
            msgLn(1, "", "")
# Print the stuff for the selected trigger type
# CON
            if eval("PDS%dTType"%d).get() == 1:
                msgLn(1, "", "    Trigger type: CON")
                msgLn(1, "", "      Start time: %s"% \
                        eval("PDS%dStart1"%d).get())
                msgLn(1, "", "   Record length: %s"%eval("PDS%dRl"%d).get())
# CRS
            elif eval("PDS%dTType"%d).get() == 2:
                msgLn(1, "", "         Trigger type: CRS")
                msgLn(1, "", "       Trigger stream: %d"% \
                        eval("PDS%dTStrm"%d).get())
                msgLn(1, "", "   Pre-trigger length: %s"% \
                        eval("PDS%dPretl"%d).get())
                msgLn(1, "", "        Record length: %s"% \
                        eval("PDS%dRl"%d).get())
# EVT
            elif eval("PDS%dTType"%d).get() == 3:
                msgLn(1, "", "          Trigger type: EVT")
                msgLn(1, "", "      Trigger channels: ", False)
                for c in xrange(1, 1+6):
                    if eval("PDS%dTChan%d"%(d,c)).get() != 0:
                        msgLn(1, "", "%d "%c, False)
                msgLn(1, "", "")
                msgLn(1, "", "        Trigger window: %s"% \
                        eval("PDS%dTwin"%d).get())
                msgLn(1, "", "      Minimum channels: %s"% \
                        eval("PDS%dMc"%d).get())
                msgLn(1, "", "    Pre-trigger length: %s"% \
                        eval("PDS%dPretl"%d).get())
                msgLn(1, "", "         Record length: %s"% \
                        eval("PDS%dRl"%d).get())
                msgLn(1, "", "   Post-trigger length: %s"% \
                        eval("PDS%dPostl"%d).get())
                msgLn(1, "", "    Short-term average: %s"% \
                        eval("PDS%dSta"%d).get())
                msgLn(1, "", "     Long-term average: %s"% \
                        eval("PDS%dLta"%d).get())
                msgLn(1, "", "         Trigger ratio: %s"% \
                        eval("PDS%dTr"%d).get())
                msgLn(1, "", "      De-trigger ratio: %s"% \
                        eval("PDS%dDtr"%d).get())
                if eval("PDS%dHold"%d).get() == 0:
                    Holding = "OFF"
                else:
                    Holding = "ON"
                msgLn(1, "", "              LTA hold: %s"%Holding)
# EXT
            elif eval("PDS%dTType"%d).get() == 4:
                msgLn(1, "", "         Trigger type: EXT")
                msgLn(1, "", "   Pre-trigger length: %s"% \
                        eval("PDS%dPretl"%d).get())
                msgLn(1, "", "        Record length: %s"% \
                        eval("PDS%dRl"%d).get())
# LEV
            elif eval("PDS%dTType"%d).get() == 5:
                msgLn(1, "", "         Trigger type: LEV")
                msgLn(1, "", "        Trigger level: %s"% \
                        eval("PDS%dTlvl"%d).get())
                msgLn(1, "", "         LP frequency: ", False)
                if eval("PDS%dLPFreq"%d).get() == 0:
                    msgLn(1, "", "Off")
                elif eval("PDS%dLPFreq"%d).get() == 1:
                    msgLn(1, "", "0.0")
                elif eval("PDS%dLPFreq"%d).get() == 2:
                    msgLn(1, "", "12.0")
                msgLn(1, "", "         HP frequency: ", False)
                if eval("PDS%dHPFreq"%d).get() == 0:
                    msgLn(1, "", "Off")
                elif eval("PDS%dHPFreq"%d).get() == 1:
                    msgLn(1, "", "0.0")
                elif eval("PDS%dHPFreq"%d).get() == 2:
                    msgLn(1, "", "0.1")
                elif eval("PDS%dHPFreq"%d).get() == 3:
                    msgLn(1, "", "2.0")
                msgLn(1, "", "   Pre-trigger length: %s"% \
                        eval("PDS%dPretl"%d).get())
                msgLn(1, "", "        Record length: %s"% \
                        eval("PDS%dRl"%d).get())
# TIM
            elif eval("PDS%dTType"%d).get() == 6:
                msgLn(1, "", "         Trigger type: TIM")
                msgLn(1, "", "           Start time: %s"% \
                        eval("PDS%dStart1"%d).get())
                msgLn(1, "", "      Repeat interval: %s"% \
                        eval("PDS%dRepInt"%d).get())
                msgLn(1, "", "   Number of triggers: %s"% \
                        eval("PDS%dNumTrig"%d).get())
                msgLn(1, "", "        Record length: %s"% \
                        eval("PDS%dRl"%d).get())
# TML
            elif eval("PDS%dTType"%d).get() == 7:
                msgLn(1, "", "    Trigger type: TML")
                for i in xrange(1, 1+11):
                    msgLn(1, "", "      Start time: %s"% \
                            eval("PDS%dStart%d"%(d,i)).get())
                msgLn(1, "", "   Record length: %s"%eval("PDS%dRl"%d).get())
# VOT - not yet
            elif eval("PDS%dTType"%d).get() == 8:
                pass
        msgLn(1, "", "")
    if PAuxSPer.get() != "":
        msgLn(1, "W", "==== Auxiliary Data Parameters ====")
        msgLn(1, "", "           Marker: %s"%PAuxMarker.get())
        msgLn(1, "", "    Sample period: %s"%PAuxSPer.get())
        msgLn(1, "", " Data destination: ", False)
        if PAuxDisk.get() != 0:
            msgLn(1, "", "Disk ", False)
        if PAuxEther.get() != 0:
            msgLn(1, "", "Ethernet ", False)
        if PAuxSerial.get() != 0:
            msgLn(1, "", "Serial ", False)
        if PAuxRam.get() != 0:
            msgLn(1, "", "RAM", False)
        msgLn(1, "", "")
        msgLn(1, "", "Included channels: ", False)
        for c in xrange(1, 1+16):
            if eval("PAuxChan%d"%c).get() != 0:
                msgLn(1, "", "%d "%c, False)
        msgLn(1, "", "")
        msgLn(1, "", "    Record length: %s"%PAuxRl.get())
        msgLn(1, "", "")
    if PACGroup.get() != 0:
        msgLn(1, "W", "==== Auto-centering Parameters ====")
        msgLn(1, "", " Channel group: %d"%PACGroup.get())
        if PACEnable.get() == 0:
            Enable = "No"
        else:
            Enable = "Yes"
        msgLn(1, "", "       Enabled: %s"%Enable)
        msgLn(1, "", "    Cycle time: %s"%PACCycle.get())
        msgLn(1, "", "     Threshold: %s"%PACThresh.get())
        msgLn(1, "", "Attempts/cycle: %s"%PACAttempt.get())
        msgLn(1, "", "Retry interval: %s"%PACRetry.get())
        msgLn(1, "", " Sample period: %d"%PACPeriod.get())
        msgLn(1, "", "")
    msgLn(1, "W", "==== Disk Parameters ====")
    msgLn(1, "", "     Disk wrap: ", False)
    if PDWrap.get() == 0:
        msgLn(1, "", "Disabled")
    else:
        msgLn(1, "", "Enabled")
    msgLn(1, "", "Dump threshold: %s%%"%PDThresh.get())
    msgLn(1, "", "    Dump on ET: ", False)
    if PDETDump.get() == 0:
        msgLn(1, "", "No")
    else:
        msgLn(1, "", "Yes")
    msgLn(1, "", "    Disk retry: %s"%PDRetry.get())
    msgLn(1, "", "")
    if PNPort.get() != 0:
        msgLn(1, "W", "==== Network Parameters ====")
        if PNPort.get() == 1 or PNPort.get() == 3:
            msgLn(1, "W", "----- Ethernet -----")
            msgLn(1, "", "       Port power: ", False)
            if PNEPortPow.get() == 0:
                msgLn(1, "", "Not set")
            elif PNEPortPow.get() == 1:
                msgLn(1, "", "Continuous")
            elif PNEPortPow.get() == 2:
                msgLn(1, "", "Auto")
            msgLn(1, "", " Line down action: ", False)
            if PNEKeep.get() == 0:
                msgLn(1, "", "Not set")
            elif PNEKeep.get() == 1:
                msgLn(1, "", "Keep data")
            elif PNEKeep.get() == 2:
                msgLn(1, "", "Toss data")
            if PNEKeep.get() == 2:
                msgLn(1, "", "       Toss delay: %s"%PNETDelay.get())
# Make up the IP address
            IP = ""
            for i in xrange(1, 1+4):
                if eval("PNEIP%d"%i).get().strip() == "":
                    IP = IP+"___."
                else:
                    IP = IP+eval("PNEIP%d"%i).get().strip()+"."
            msgLn(1, "", "  IP address: %s"%IP[:len(IP)-1])
            if PNEFill.get() == 1:
                Fill = "Use DAS ID"
            elif PNEFill.get() == 2:
                Fill = "Sequential"
            elif PNEFill.get() == 3:
                Fill = "Use as entered"
            msgLn(1, "", "     IP fill: %s"%Fill)
            msgLn(1, "", "    Net mask: %s"%PNEMask.get())
            msgLn(1, "", "     Gateway: %s"%PNEGateway.get())
            msgLn(1, "", "Host address: %s"%PNEHost.get())
        if PNPort.get() == 2 or PNPort.get() == 3:
            msgLn(1, "W", "----- Serial -----")
            msgLn(1, "", " Line down action: ", False)
            if PNSKeep.get() == 0:
                msgLn(1, "", "Not set")
            elif PNSKeep.get() == 1:
                msgLn(1, "", "Keep data")
            elif PNSKeep.get() == 2:
                msgLn(1, "", "Toss data")
            if PNSKeep.get() == 2:
                msgLn(1, "", "       Toss delay: %s"%PNSTDelay.get())
            msgLn(1, "", " Serial port mode: ", False)
            if PNSMode.get() == 0:
                msgLn(1, "", "Not set")
            elif PNSMode.get() == 1:
                msgLn(1, "", "Direct")
            elif PNSMode.get() == 2:
                msgLn(1, "", "AT/Modem")
            elif PNSMode.get() == 3:
                msgLn(1, "", "Freewave")
            msgLn(1, "", "Serial port speed: %d"%PNSSpeed.get())
            IP = ""
            for i in xrange(1, 1+4):
                if eval("PNSIP%d"%i).get().strip() == "":
                    IP = IP+"___."
                else:
                    IP = IP+eval("PNSIP%d"%i).get().strip()+"."
            msgLn(1, "", "  IP address: %s"%IP[:len(IP)-1])
            Fill = ""
            if PNSFill.get() == 1:
                Fill = "Use DAS ID"
            elif PNSFill.get() == 2:
                Fill = "Sequential"
            elif PNSFill.get() == 2:
                Fill = "Use as entered"
            msgLn(1, "", "     IP fill: %s"%Fill)
            msgLn(1, "", "    Net mask: %s"%PNSMask.get())
            msgLn(1, "", "     Gateway: %s"%PNSGateway.get())
            msgLn(1, "", "Host address: %s"%PNSHost.get())
        msgLn(0, "", "")
    msgLn(1, "W", "==== GPS Control Parameters ====")
    msgLn(1, "", "     GPS Mode: ", False)
    if PGPSMode.get() == "D":
        msgLn(1, "", "Normal Duty Cycle")
    elif PGPSMode.get() == "C":
        msgLn(1, "Y", "Continuous")
    elif PGPSMode.get() == "O":
        msgLn(1, "R", "Off")
    else:
        msgLn(1, "M", "Unknown")
    msgLn(1, "", "")
    checkParms(False)
    return
# END: summaryCmd




#########################
# BEGIN: verifyParmsCmd()
# FUNC:verifyParmsCmd():2009.315
#   Steps through the list of DASs, receives the parameters, and checks key
#   parameter items to make sure they match the current set of parameters
#   in the program.
def verifyParmsCmd():
    global WorkState
    Status, ListOfDASs = isItOKToStart(2)
    if Status == False:
        return
    WorkState = 100
    buttonControl("VERIFY", "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        buttonControl("VERIFY", "", 0)
        return
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        ParmAllOK = True
        Count += 1
        msgLn(1, "W", "%d. %s: Verifying parameters... (%s)"%(Count, DAS, \
                getGMT(0)))
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   Station...")
        Cmd = rt130CmdFormat(DAS, "PRPS  PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Station Parameters request response!", \
                    True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
# You have to add 4 to the sending offsets of the parameters described in the
# Reftek documentation (i.e. the experiment name is at [14:14+24] when you
# send the station parameters, but at [18:18+24] when receiving).
        msgLn(1, "", "     Experiment name: %s"%Rp[18:18+24].strip())
        if PExpName.get() != Rp[18:18+24].strip():
            msgLn(1, "Y", "      Experiment name does not match.")
            ParmAllOK = False
        if PExpComment.get() != Rp[42:42+40].strip():
            msgLn(1, "Y", "      Experiment comment does not match.")
            ParmAllOK = False
# Get the current setup of the DAS to figure out which channels and data
# streams to get.
        Cmd = rt130CmdFormat(DAS, "SSPR              SS")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Parameter Status request response!", True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        Chans = intt(Rp[32:32+2])
        DSs = intt(Rp[34:34+1])
        Channels = mrDash(Rp[40:40+Chans])
        DStreams = mrDash(Rp[40+Chans:40+Chans+DSs])
# Check to see that the number of channels and data streams set up in CHANGEO
# match the number of channels and data streams set up in the DAS.
        CChans = 0
        DChans = 0
        CDSs = 0
        DDSs = 0
        for c in xrange(1, 1+6):
            if eval("PC%dGain"%c).get() != 0:
                CChans += 1
            if Channels[(c-1)] != "-":
                DChans += 1
        if CChans != DChans:
            msgLn(1, "Y", "   Number of active channels does not match.")
            ParmAllOK = False
        for d in xrange(1, 1+4):
            if eval("PDS%dTType"%d).get() != 0:
                CDSs += 1
            if DStreams[(d-1)] != "-":
                DDSs += 1
        if CDSs != DDSs:
            msgLn(1, "Y", "   Number of active data streams does not match.")
            ParmAllOK = False
        for c in xrange(1, 1+6):
            if WorkState == 999 or AllOK == False:
                break
            if Channels[(c-1)] != "-":
                if OPTSummaryModeCVar.get() == 0:
                    msgLn(1, "", "   Channel %d..."%c)
            Cmd = rt130CmdFormat(DAS, "PRPC%d PR"%c)
            writePort(DAS, Cmd)
            Rp = rt130GetRp(1, 5, 0)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No Channel %d Parameters request response!"%c, \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# If this is blank then there are no parameters for this channel.
            if Rp[16:16+2] == "  ":
                continue
            if eval("PC%dName"%c).get() != Rp[18:18+10].strip():
                msgLn(1, "Y", "      Name does not match.")
                ParmAllOK = False
            if eval("PC%dComment"%c).get() != Rp[114:114+40].strip():
                msgLn(1, "Y", "      Comment does not match.")
                ParmAllOK = False
            if eval("PC%dGain"%c).get() != intt(Rp[86:86+4]):
                msgLn(1, "Y", "      Gain setting does not match.")
                ParmAllOK = False
        if WorkState == 999 or AllOK == False:
            continue
        for d in xrange(1, 1+4):
            if WorkState == 999 or AllOK == False:
                break
            if DStreams[(d-1)] != "-":
                if OPTSummaryModeCVar.get() == 0:
                    msgLn(1, "", "   Data stream %d..."%d)
                Cmd = rt130CmdFormat(DAS, "PRPD%d PR"%d)
                writePort(DAS, Cmd)
                Rp = rt130GetRp(1, 5, 0)
                if WorkState == 999:
                    continue
                if Rp == "":
                    formSTATSetStatus(DAS, "M")
                    msgLn(1, "M", \
                            "   No DS%d Parameters request response!"%d, \
                            True, 3)
                    AllOK = False
                    continue
                if checkRp(DAS, Rp) == False:
                    formSTATSetStatus(DAS, "M")
                    AllOK = False
                    WorkState = 999
                    continue
# If this is blank then there are no parameters for this stream.
                if Rp[16:16+2] == "  ":
                    continue
                if eval("PDS%dName"%d).get() != Rp[18:18+16].strip():
                    msgLn(1, "Y", "      Name does not match.")
                    ParmAllOK = False
                if (Rp[34:34+1] != " " and eval("PDS%dRam"%d).get() == 0) or \
                        (Rp[34:34+1] == " " and \
                        eval("PDS%dRam"%d).get() != 0) or \
                        (Rp[35:35+1] != " " and \
                        eval("PDS%dDisk"%d).get() == 0) or \
                        (Rp[35:35+1] == " " and \
                        eval("PDS%dDisk"%d).get() != 0) or \
                        (Rp[36:36+1] != " " and \
                        eval("PDS%dEther"%d).get() == 0) or \
                        (Rp[36:36+1] == " " and \
                        eval("PDS%dEther"%d).get() != 0) or \
                        (Rp[37:37+1] != " " and \
                        eval("PDS%dSerial"%d).get() == 0) or \
                        (Rp[37:37+1] == " " and \
                        eval("PDS%dSerial"%d).get() != 0):
                    msgLn(1, "Y", "      Data destination does not match.")
                    ParmAllOK = False
                for c in xrange(1, 1+6):
                    if (Rp[41+c:41+c+1] != " " and \
                            eval("PDS%dChan%d"%(d,c)).get() == 0) or \
                            (Rp[41+c:41+c+1] == " " and \
                            eval("PDS%dChan%d"%(d,c)).get() != 0):
                        msgLn(1, "Y", \
                               "      Included channel settings do not match.")
                        ParmAllOK = False
                        break
                if eval("PDS%dSampRate"%d).get() != Rp[58:58+4].strip():
                    msgLn(1, "Y", "      Sample rate does not match.")
                    ParmAllOK = False
                if Rp[62:62+2] != eval("PDS%dFormat"%d).get():
                    msgLn(1, "Y", "      Data format setting does not match.")
                    ParmAllOK = False
                if Rp[64:64+4].strip() == "CON":
                    if eval("PDS%dTType"%d).get() != 1:
                        msgLn(1, "Y", \
                                "      Trigger type setting does not match.")
                        ParmAllOK = False
                    else:
                        if eval("PDS%dStart1"%d).get() != Rp[76:76+14].strip():
                            msgLn(1, "Y", "      Start time does not match.")
                            ParmAllOK = False
                        if eval("PDS%dRl"%d).get() != Rp[68:68+8].strip():
                            msgLn(1, "Y", \
                                    "      Record length does not match.")
                            ParmAllOK = False
                elif Rp[64:64+4].strip() == "CRS":
                    if eval("PDS%dTType"%d).get() != 2:
                        msgLn(1, "Y", "      Trigger type does not match.")
                        ParmAllOK = False
                    else:
                        if eval("PDS%dTStrm"%d).get() != intt(Rp[68:68+2]):
                            msgLn(1, "Y", \
                                "      Trigger stream setting does not match.")
                            ParmAllOK = False
                        if eval("PDS%dPretl"%d).get() != Rp[70:70+8].strip():
                            msgLn(1, "Y", \
                                    "      Pre-trigger length does not match.")
                            ParmAllOK = False
                        if eval("PDS%dRl"%d).get() != Rp[78:78+8].strip():
                            msgLn(1, "Y", \
                                    "      Record length does not match.")
                            ParmAllOK = False
                elif Rp[64:64+4].strip() == "EVT":
                    if eval("PDS%dTType"%d).get() != 3:
                        msgLn(1, "Y", "      Trigger type does not match.")
                        ParmAllOK = False
                    else:
                        for c in xrange(1, 1+6):
                            if (Rp[67+c:67+c+1] != " " and \
                                    eval("PDS%dTChan%d"%(d,c)).get() == 0) or \
                                    (Rp[67+c:67+c+1] == " " and \
                                    eval("PDS%dTChan%d"%(d,c)).get() != 0):
                                msgLn(1, "Y", \
                                "      Trigger channel settings do not match.")
                                ParmAllOK = False
                                break
                        if eval("PDS%dTwin"%d).get() != Rp[86:86+8].strip():
                            msgLn(1, "Y", \
                                  "      Trigger window value does not match.")
                            ParmAllOK = False
                        if eval("PDS%dMc"%d).get() != Rp[84:84+2].strip():
                            msgLn(1, "Y", \
                            "      Minimum number of channels does not match.")
                            ParmAllOK = False
                        if eval("PDS%dRl"%d).get() != Rp[110:110+8].strip():
                            msgLn(1, "Y", \
                                    "      Record length does not match.")
                            ParmAllOK = False
                        if eval("PDS%dPretl"%d).get() != Rp[94:94+8].strip():
                            msgLn(1, "Y", \
                                    "      Pre-trigger length does not match.")
                            ParmAllOK = False
                        if eval("PDS%dPostl"%d).get() != Rp[102:102+8].strip():
                            msgLn(1, "Y", \
                                   "      Post-trigger length does not match.")
                            ParmAllOK = False
                        if eval("PDS%dSta"%d).get() != Rp[126:126+8].strip():
                            msgLn(1, "Y", "      STA length does not match.")
                            ParmAllOK = False
                        if eval("PDS%dLta"%d).get() != Rp[134:134+8].strip():
                            msgLn(1, "Y", "      LTA length does not match.")
                            ParmAllOK = False
                        Holding = Rp[166:166+4].strip()
                        if (Holding == "OFF" and \
                                eval("PDS%dHold"%d).get() != 0) or \
                                (Holding == "ON" and \
                                eval("PDS%dHold"%d).get() != 1):
                            msgLn(1, "Y", \
                                    "      LTA hold setting does not match.")
                            ParmAllOK = False
                        if eval("PDS%dTr"%d).get() != Rp[150:150+8].strip():
                            msgLn(1, "Y", \
                                    "      Trigger ratio does not match.")
                            ParmAllOK = False
                        if eval("PDS%dDtr"%d).get() != Rp[158:158+8].strip():
                            msgLn(1, "Y", \
                                    "      De-trigger ratio does not match.")
                        Pass = Rp[170:170+4].strip()
                        if (Pass == "OFF" and \
                                eval("PDS%dLPFreq"%d).get() != 0) or \
                                (Pass == "0" and \
                                eval("PDS%dLPFreq"%d).get() != 1) or \
                                (Pass == "12" and \
                                eval("PDS%dLPFreq"%d).get() != 2):
                            msgLn(1, "Y", \
                               "      Low pass filter setting does not match.")
                            ParmAllOK = False
                        Pass = Rp[174:174+4].strip()
                        if (Pass == "OFF" and \
                                eval("PDS%dHPFreq"%d).get() != 0) or \
                                (Pass == "0" and \
                                eval("PDS%dHPFreq"%d).get() != 1) or \
                                (Pass == "0.1" and \
                                eval("PDS%dHPFreq"%d).get() != 2) or \
                                (Pass == "12" and \
                                eval("PDS%dHPFreq"%d).get() != 3):
                            msgLn(1, "Y", \
                              "      High pass filter setting does not match.")
                            ParmAllOK = False
                elif Rp[64:64+4].strip() == "EXT":
                    if eval("PDS%dTType"%d).get() != 4:
                        msgLn(1, "Y", "      Trigger type does not match.")
                        ParmAllOK = False
                    else:
                        if eval("PDS%dPretl"%d).get() != Rp[68:68+8].strip():
                            msgLn(1, "Y", \
                                    "      Pre-trigger length does not match.")
                            ParmAllOK = False
                        if eval("PDS%dRl"%d).get() != Rp[76:76+8].strip():
                            msgLn(1, "Y", \
                                    "      Record length does not match.")
                            ParmAllOK = False
                elif Rp[64:64+4].strip() == "LEV":
                    if eval("PDS%dTType"%d).get() != 5:
                        msgLn(1, "Y", "      Trigger type does not match.")
                        ParmAllOK = False
                    else:
                        if eval("PDS%dTlvl"%d).get() != Rp[68:68+8].strip():
                            msgLn(1, "Y", \
                                    "      Trigger level does not match.")
                            ParmAllOK = False
                        Pass = Rp[92:92+4].strip()
                        if (Pass == "OFF" and \
                                eval("PDS%dLPFreq"%d).get() != 0) or \
                                (Pass == "0" and \
                                eval("PDS%dLPFreq"%d).get() != 1) or \
                                (Pass == "12" and \
                                eval("PDS%dLPFreq"%d).get() != 2):
                            msgLn(1, "Y", \
                               "      Low pass filter setting does not match.")
                            ParmAllOK = False
                        Pass = Rp[96:96+4].strip()
                        if (Pass == "OFF" and \
                                eval("PDS%dHPFreq"%d).get() != 0) or \
                                (Pass == "0" and \
                                eval("PDS%dHPFreq"%d).get() != 1) or \
                                (Pass == "0.1" and \
                                eval("PDS%dHPFreq"%d).get() != 2) or \
                                (Pass == "12" and \
                                eval("PDS%dHPFreq"%d).get() != 3):
                            msgLn(1, "Y",
                              "      High pass filter setting does not match.")
                            ParmAllOK = False
                        if eval("PDS%dPretl"%d).get() != Rp[76:76+8].strip():
                            msgLn(1, "Y", \
                                    "      Pre-trigger length does not match.")
                            ParmAllOK = False
                        if eval("PDS%dRl"%d).get() != Rp[84:84+8].strip():
                            msgLn(1, "Y", \
                                    "      Record length does not match.")
                            ParmAllOK = False
                elif Rp[64:64+4].strip() == "TIM":
                    if eval("PDS%dTType"%d).get() != 6:
                        msgLn(1, "Y", "      Trigger type does not match.")
                        ParmAllOK = False
                    else:
                        if eval("PDS%dStart1"%d).get() != Rp[68:68+14].strip():
                            msgLn(1, "Y", "      Start time does not match.")
                            ParmAllOK = False
                        if eval("PDS%dRepInt"%d).get() != Rp[82:82+8].strip():
                            msgLn(1, "Y", \
                                    "      Repeat interval does not match.")
                            ParmAllOK = False
                        if eval("PDS%dNumTrig"%d).get() != Rp[90:90+4].strip():
                            msgLn(1, "Y", \
                                    "      Number of triggers does not match.")
                            ParmAllOK = False
                        if eval("PDS%dRl"%d).get() != Rp[102:102+8].strip():
                            msgLn(1, "Y", \
                                    "      Record length does not match.")
                            ParmAllOK = False
                elif Rp[64:64+4].strip() == "TML":
                    if eval("PDS%dTType"%d).get() != 7:
                        msgLn(1, "Y", "      Trigger type does not match.")
                        ParmAllOK = False
                    else:
                        for i in xrange(1, 1+12):
                            if eval("PDS%dStart%d"%(d,i)).get() != \
                                    Rp[54+(i*14):54+(i*14)+14].strip():
                                msgLn(1, "Y", \
                                       "      Start time %d does not match."%i)
                                ParmAllOK = False
                                break
                        if eval("PDS%dRl"%d).get() != Rp[102:102+8].strip():
                            msgLn(1, "Y", \
                                    "      Record length does not match.")
                            ParmAllOK = False
                elif Rp[64:64+4].strip() == "VOT":
                    msgLn(1, "R", \
                            "VOT trigger type not currently supported.", \
                            True, 2)
                    ParmAllOK = False
        if WorkState == 999 or AllOK == False:
            continue
# Auxiliary data.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   Auxiliary data...")
        Cmd = rt130CmdFormat(DAS, "PRPA  PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", \
                    "   No Auxiliary Data Parameters request response!", \
                    True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        if PAuxSPer.get() != Rp[34:34+8].strip():
            msgLn(1, "Y", "      Sample period setting does not match.")
            ParmAllOK = False
        if PAuxMarker.get() != Rp[16:16+2].strip():
            msgLn(1, "Y", "      Marker value does not match.")
            ParmAllOK = False
        if (Rp[52:52+1] != " " and PAuxRam.get() == 0) or \
                (Rp[52:52+1] == " " and PAuxRam.get() != 0) or \
                (Rp[53:53+1] != " " and PAuxDisk.get() == 0) or \
                (Rp[53:53+1] == " " and PAuxDisk.get() != 0) or \
                (Rp[54:54+1] != " " and PAuxEther.get() == 0) or \
                (Rp[54:54+1] == " " and PAuxEther.get() != 0) or \
                (Rp[55:55+1] != " " and PAuxSerial.get() == 0) or \
                (Rp[55:55+1] == " " and PAuxSerial.get() != 0):
            msgLn(1, "Y", "      Data destination setting not match.")
            ParmAllOK = False
# First channel offset is 18.
        for c in xrange(1, 1+16):
            if (Rp[17+c:17+c+1] != " " and \
                    eval("PAuxChan%d"%c).get() == 0) or \
                    (Rp[17+c:17+c+1] == " " and \
                    eval("PAuxChan%d"%c).get() != 0):
                msgLn(1, "Y", "      Included channel settings do not match.")
                ParmAllOK = False
                break
        if PAuxRl.get() != Rp[44:44+8].strip():
            msgLn(1, "Y", \
                  "      Record length does not match.")
            ParmAllOK = False
# FINISHME - Add Differential Control stuff here.
# Auto-centering parameters.
# These are a bit weird. Ask for both, but only use the one whose parameters
# are not blank (blanked by the 'erase parameters' command sent when the
# parameters were sent).
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   Auto-centering...")
        Cmd = rt130CmdFormat(DAS, "PRPQ1 PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", \
                    "   No Auto-centering Parameters request response!", \
                    True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
# Just look at a portion of the parameter space to if it is blank or not.
        if Rp[15:15+10].strip() == "":
# Our DASs only have two places to physically connect sensors, so we only have
# to check "sensors" 1 and 2. Since 1 (the above if) didn't yield anything...
            Cmd = rt130CmdFormat(DAS, "PRPQ2 PR")
            writePort(DAS, Cmd)
            Rp = rt130GetRp(1, 15, 0)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No Auto-centering Parameters request response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
# By this point we have all of the parameters we'll ever have. If everything
# is still blank then we don't need to check anything.
        if Rp[15:15+10].strip() != "":
            if (Rp[16:16+1] == "1" and PACGroup.get() != 123) or \
                    (Rp[16:16+1] == "2" and PACGroup.get() != 456):
                msgLn(1, "Y", "      Channel group setting does not match.")
                ParmAllOK = False
            if (Rp[17:17+1] == " " and PACEnable.get() != 0) or \
                    (Rp[17:17+1] == "Y" and PACEnable.get() != 1):
                msgLn(1, "Y", "      Enabled setting does not match.")
                ParmAllOK = False
            if PACCycle.get() != Rp[22:22+2].strip():
                msgLn(1, "Y", "      Cycle time does not match.")
                ParmAllOK = False
            if PACThresh.get() != Rp[24:24+4].strip():
                msgLn(1, "Y", "      Threshold does not match.")
                ParmAllOK = False
            if PACAttempt.get() != Rp[28:28+2].strip():
                msgLn(1, "Y", "      Attempts per cycle does not match.")
                ParmAllOK = False
            if PACRetry.get() != Rp[30:30+2].strip():
                msgLn(1, "Y", "      Retry interval does not match.")
                ParmAllOK = False
            if PACPeriod.get() != intt(Rp[18:18+4]):
                msgLn(1, "Y", "      Sample period setting does not match.")
                ParmAllOK = False
# Disk parameters.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   Disks...")
        Cmd = rt130CmdFormat(DAS, "PRPZ  PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Disk Parameters request response!", True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        if (Rp[28:28+1] == "N" and PDWrap.get() != 0) or \
                (Rp[28:28+1] != "N" and PDWrap.get() != 1):
            msgLn(1, "Y", "      Disk wrap setting does not match.")
            ParmAllOK = False
        if PDThresh.get() != Rp[22:22+2].strip():
            msgLn(1, "Y", "      Dump threshold does not match.")
            ParmAllOK = False
        if (Rp[20:20+1] == "Y" and PDETDump.get() != 1) or \
                (Rp[20:20+1] != "Y" and PDETDump.get() == 1):
            msgLn(1, "Y", "      Dump on ET setting does not match.")
            ParmAllOK = False
        if PDRetry.get() != Rp[32:32+2].strip():
            msgLn(1, "Y", "      Retry value does not match.")
            ParmAllOK = False
# Network parameters.
# PN1 is for the Ethernet parameters and PN2 is for the serial port parameters
# so we will need to ask for both. How to set PNPort to reflect which one
# the DAS is setup to use remains a mystery, except to generate some warning
# messages when the parameters are summary'ed or sent to the DAS. If the
# parameters were sent with CHANGEO the port not in use should not have an IP
# address set. We'll check for that down below.
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   Network...")
        Cmd = rt130CmdFormat(DAS, "PRPN1 PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", \
                    "   No Ethernet Network Parameters request response!", \
                    True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        if (Rp[33:33+1] == "P" and PNEPortPow.get() != 1) or \
                (Rp[33:33+1] == "T" and PNEPortPow.get() != 2) or \
                (Rp[33:33+1] == " " and PNEPortPow.get() != 0):
            msgLn(1, "Y", "      Port power setting does not match.")
            ParmAllOK = False
        if (Rp[82:82+1] == "K" and PNEKeep.get() != 1) or \
                (Rp[82:82+1] == "T" and PNEKeep.get() != 2):
            msgLn(1, "Y", "      Line down action setting does not match.")
            ParmAllOK = False
        if PNETDelay.get() != Rp[90:90+2].strip():
            msgLn(1, "Y", "      Ethernet toss delay does not match.")
            ParmAllOK = False
# The IP addresses do not get checked since they may have all been programmed
# differently by CHANGEO.
#        if PNEIP.get() != Rp[18:18+15].strip():
#            msgLn(1, "Y", "      Ethernet IP address does not match.")
#            ParmAllOK = False
        if PNEMask.get() != Rp[34:34+16].strip():
            msgLn(1, "Y", "      Ethernet mask does not match.")
            ParmAllOK = False
        if PNEGateway.get() != Rp[66:66+16].strip():
            msgLn(1, "Y", "      Ethernet gateway address does not match.")
            ParmAllOK = False
        if PNEHost.get() != Rp[50:50+16].strip():
            msgLn(1, "Y", "      Ethernet remote host address does not match.")
            ParmAllOK = False
# Serial port parms.
        Cmd = rt130CmdFormat(DAS, "PRPN2 PR")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", \
                    "   No serial Network Parameters request response!", \
                    True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        if (Rp[82:82+1] == "K" and PNSKeep.get() != 1) or \
                (Rp[82:82+1] == "T" and PNSKeep.get() != 2):
            msgLn(1, "Y", "      Serial keep/toss setting does not match.")
            ParmAllOK = False
        if PNSTDelay.get() != Rp[90:90+2].strip():
            msgLn(1, "Y", "      Serial toss delay does not match.")
            ParmAllOK = False
        if (Rp[83:83+1] == "D" and PNSMode.get() != 1) or \
                (Rp[83:83+1] == "A" and PNSMode.get() != 2) or \
                (Rp[83:83+1] == "F" and PNSMode.get() != 3):
            msgLn(1, "Y", "      Serial line mode setting does not match.")
            ParmAllOK = False
        if PNSSpeed.get() != intt(Rp[84:84+6]):
            msgLn(1, "Y", "      Serial port speed setting does not match.")
            ParmAllOK = False
# See above
#        if PNSIP.get() != Rp[18:18+15].strip():
#            msgLn(1, "Y", "      Serial IP address does not match.")
#            ParmAllOK = False
        if PNSMask.get() != Rp[34:34+16].strip():
            msgLn(1, "Y", "      Serial mask does not match.")
            ParmAllOK = False
        if PNSGateway.get() != Rp[66:66+16].strip():
            msgLn(1, "Y", "      Serial gateway address does not match.")
            ParmAllOK = False
        if PNSHost.get() != Rp[50:50+16].strip():
            msgLn(1, "Y", "      Serial remote host address does not match.")
            ParmAllOK = False
        if OPTSummaryModeCVar.get() == 0:
            msgLn(1, "", "   External clock...")
            Cmd = rt130CmdFormat(DAS, "SSXC              SS")
            writePort(DAS, Cmd)
            Rp = rt130GetRp(1, 5, 0)
            if WorkState == 999:
                continue
            if Rp == "":
                formSTATSetStatus(DAS, "M")
                msgLn(1, "M", \
                        "   No External Clock Status command response!", \
                        True, 3)
                AllOK = False
                continue
            if checkRp(DAS, Rp) == False:
                formSTATSetStatus(DAS, "M")
                AllOK = False
                WorkState = 999
                continue
            GPSOpMode = Rp[85:85+1]
            if PGPSMode.get() != GPSOpMode:
                msgLn(1, "Y", "      GPS operating mode does not match.")
                ParmAllOK = False
        if ParmAllOK == True:
            formSTATSetStatus(DAS, "G")
            msgLn(1, "", "   All parameters OK.")
        else:
            formSTATSetStatus(DAS, "Y")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
    stoppedMe(WorkState, "")
    buttonControl("VERIFY", "", 0)
    return
# END: verifyParmsCmd




##########################
# BEGIN: versionsCmd(Send)
# FUNC:versionsCmd():2010.133
#   Steps through the list of DASs and prints the version numbers.
def versionsCmd(Send):
    global WorkState
    Status, ListOfDASs = isItOKToStart(2)
    if Status == False:
        return
    WorkState = 100
    if Send == "pis":
        buttonControl("PISVERSIONS", "G", 1)
    elif Send == "nopis":
        buttonControl("VERSIONS", "G", 1)
    formSTATSetStatus("all", "B")
    if openCmdPort() == False:
        if Send == "pis":
            buttonControl("PISVERSIONS", "G", 1)
        elif Send == "nopis":
            buttonControl("VERSIONS", "G", 1)
        return
    Count = 0
    for DAS in ListOfDASs:
        if WorkState == 999:
            break
        formSTATSetStatus(DAS, "C")
        AllOK = True
        Count += 1
        msgLn(1, "W", "%d. %s: Versions... (%s)"%(Count, DAS, \
                getGMT(0)))
# Do this to get the RAM size.
        Cmd = rt130CmdFormat(DAS, "SSAQ              SS")
        writePort(DAS, Cmd)
# No Lag. Info request.
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Acquisition Status command response!", \
                    True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        RAM = Rp[42:42+6].strip().upper()
        msgLn(1, "", "   RAM size: ", False)
        msgLn(1, "G", RAM)
# Board versions.
        Cmd = rt130CmdFormat(DAS, "SSVS              SS")
        writePort(DAS, Cmd)
        Rp = rt130GetRp(1, 5, 0)
        if WorkState == 999:
            continue
        if Rp == "":
            formSTATSetStatus(DAS, "M")
            msgLn(1, "M", "   No Version Status command response!", True, 3)
            AllOK = False
            continue
        if checkRp(DAS, Rp) == False:
            formSTATSetStatus(DAS, "M")
            AllOK = False
            WorkState = 999
            continue
        CPU = Rp[32:32+16].strip().upper()
        msgLn(1, "", "   CPU version: ", False)
        msgLn(1, "G", CPU)
# Build this list of information as we go for sending to the PIS database.
        if Send == "pis":
            PISData = "CHANGEO\" DATE=NOW\" DASID=%s\" "%DAS
            PISData += "VERRAMSIZE=%s\" VERCPUFW=%s\" "%(RAM, CPU)
# There may be more than one ATD board in a unit.
        CountATD = 0
# Step through all of the boards that may be in the unit.
#TESTING        for i in range(0, intt(Rp[48:48+2])):
        for i in xrange(0, intt(Rp[48:48+2])):
            Start = 50+(i*20)
            Board = Rp[Start+5:Start+5+3].upper()
            if Board == "ATD":
                CountATD += 1
                Board += "%d"%CountATD
            Board += " "+Rp[Start:Start+4].strip().upper()
            BoardSq = Board.replace(" ", "")
# Some of the versions and stuff have been things like "A 8" so squish them to
# make everyone's life easier.
            Rev = Rp[Start+4:Start+4+1].upper().replace(" ", "")
            SN = Rp[Start+8:Start+8+4].upper().replace(" ", "")
            FPGAMin = Rp[Start+16:Start+16+1].upper().replace(" ", "")
            FPGAVer = Rp[Start+17:Start+17+3].upper().replace(" ", "")
# The LID board does not have an FPGA.
            if Board[:3] == "LID":
                msgLn(1, "", "   "+"%-10s"%(Board+":")+" Rev: ", False)
                msgLn(1, "G", "%1s"%Rev, False)
                msgLn(1, "", "  SN: ", False)
                msgLn(1, "G", "%-4s"%SN)
                if Send == "pis":
                    PISData += "VER130%sREV=%s\" VER130%sSN=%s\" "%(BoardSq, \
                            Rev, BoardSq, SN)
            else:
                msgLn(1, "", "   "+"%-10s"%(Board+":")+" Rev: ", False)
                msgLn(1, "G", "%1s"%Rev, False)
                msgLn(1, "", "  SN: ", False)
                msgLn(1, "G", "%-4s"%SN, False)
                msgLn(1, "", "   FPGAVer: ", False)
                msgLn(1, "G", "%1s"%FPGAVer, False)
                msgLn(1, "", "  Min: ", False)
                msgLn(1, "G", "%-3s"%FPGAMin)
                if Send == "pis":
                    PISData += \
                            "VER130%sREV=%s\" VER130%sSN=%s\" VER130%sFPGAVER=%s\" VER130%sFPGAMIN=%s\" "% \
                            (BoardSq, Rev, BoardSq, SN, BoardSq, FPGAVer, \
                            BoardSq, FPGAMin)
        if Send == "pis":
            Ret = sendToPIS(PISData, "   ")
            if Ret[0] == 0 or Ret[0] == 1:
                msgLn(0, Ret[1], Ret[2], True, Ret[3])
                formSTATSetStatus(DAS, Ret[1])
            elif Ret[0] == 2:
                msgLn(0, Ret[1], Ret[2], True, Ret[3])
                formSTATSetStatus(DAS, Ret[1])
                msgLn(0, Ret[1], "   Stopping...")
                AllOK = False
                WorkState = 999
                continue
        else:
            formSTATSetStatus(DAS, "G")
    closeCmdPort()
    if WorkState == 999 and AllOK == True:
        formSTATSetStatus("working", "Y")
    stoppedMe(WorkState, "")
    if Send == "pis":
        buttonControl("PISVERSIONS", "", 0)
    else:
        buttonControl("VERSIONS", "", 0)
    return
# END: versionsCmd




# ==================================
# BEGIN: ========== SETUP ==========
# ==================================


######################
# BEGIN: menuMake(Win)
# FUNC:menuMake():2010.201
MENUMenus = {}

def menuMake(Win):
    global MENUMenus
    MENUMenus.clear()
    Top = Menu(Win)
    Win.configure(menu = Top)
    Fi = Menu(Top, tearoff = 0)
    MENUMenus["File"] = Fi
    Top.add_cascade(label = "File", menu = Fi, font = PROGCascadeFont)
    Fi.add_command(label = "Erase Messages", command = eraseMsgs)
    Fi.add_command(label = "Search Messages", command = formSRCHM)
    Fi.add_separator()
    Fi.add_command(label = "List Current Directories", \
            command = Command(listDirs, 1))
    Fi.add_command(label = "Change Messages Directory...", \
            command = Command(changeDirsCmd, Root, "msgs", 2, None))
    Fi.add_command(label = "Change Work Directory...", \
            command = Command(changeDirsCmd, Root, "work", 2, None))
    Fi.add_command(label = "Change All To...", \
            command = Command(changeDirsCmd, Root, "select", 2, None))
    Fi.add_separator()
    Fi.add_command(label = "Delete Setups File", command = deletePROGSetups)
    Fi.add_separator()
    Fi.add_command(label = "Quit", command = Command(progQuitter, True))
    Co = Menu(Top, tearoff = 0)
    MENUMenus["Commands"] = Co
    Top.add_cascade(label = "Commands", menu = Co, font = PROGCascadeFont)
    Co.add_command(label = "Set GPS Control to NORMAL", \
            command = Command(gpsControlCmd, "D"))
    Co.add_command(label = "Set GPS Control to CONTINUOUS", \
            command = Command(gpsControlCmd, "C"))
    Co.add_command(label = "Set GPS Control to OFF", \
            command = Command(gpsControlCmd, "O"))
    Co.add_separator()
    Co.add_command(label = "Set DAS Time", command = setTimeCmd)
    Pr = Menu(Top, tearoff = 0)
    MENUMenus["Parameters"] = Pr
    Top.add_cascade(label = "Parameters", menu = Pr, font = PROGCascadeFont)
    Pr.add_command(label = "Save Parameters As...", command = saveParmsCmd)
    Pr.add_command(label = "Load Parameters...", command = loadParmsCmd)
    Pr.add_separator()
    Pr.add_command(label = "Set Ch123-DS1/40sps", \
            command = Command(formPARMSSetParms, "bench"))
    Pr.add_command(label = "Set Ch123-DS1/250sps", \
            command = Command(formPARMSSetParms, "1231250"))
    Pr.add_command(label = "Set Ch123-DS1/40sps-DS2/1sps", \
            command = Command(formPARMSSetParms, "12314021"))
    Pr.add_separator()
    Pr.add_command(label = "Set Ch123-DS1/40sps,Ch456-DS2/40sps", \
            command = Command(formPARMSSetParms, "bench6"))
    Pr.add_command(label = "Set Ch123-DS1/250sps,Ch456-DS2/250sps", \
            command = Command(formPARMSSetParms, "12312506"))
    Pr.add_command( \
            label = "Set Ch123-DS1/40sps-DS2/1sps,Ch456-DS3/40sps-DS4/1sps", \
            command = Command(formPARMSSetParms, "123140216"))
    Op = Menu(Top, tearoff = 0)
    MENUMenus["Options"] = Op
    Top.add_cascade(label = "Options", menu = Op, font = PROGCascadeFont)
    Op.add_checkbutton(label = "Get CPU Version On Enumerate", \
            variable = OPTGetCPUVerCVar)
    Op.add_separator()
    Op.add_checkbutton(label = "Summary Mode", variable = OPTSummaryModeCVar, \
            command = sumModeCmd)
    Op.add_checkbutton(label = "Beep When Done", variable = OPTDoneBeepCVar)
    Op.add_checkbutton(label = "ddd.ddddd", variable = OPTPosDddd)
    Op.add_checkbutton(label = "Debug Mode", variable = OPTDebugCVar, \
            command = debugCmd)
    Fo = Menu(Top, tearoff = 0, postcommand = menuMakeForms)
    MENUMenus["Forms"] = Fo
    Top.add_cascade(label = "Forms", menu = Fo, font = PROGCascadeFont)
    Hp = Menu(Top, tearoff = 0)
    MENUMenus["Help"] = Hp
    Top.add_cascade(label = "Help", menu = Hp, font = PROGCascadeFont)
    Hp.add_command(label = "Help", command = Command(formHELP, Root))
    Hp.add_command(label = "Calendar", command = Command(formCAL, Root))
    Hp.add_command(label = "Check For Updates", command = checkForUpdates)
    Hp.add_command(label = "About", command = about)
    Hp.add_separator()
    Hp.add_command(label = "Reset Commands", foreground = Clr["R"], \
            command = resetProgCmd)
    return
###############################################
# BEGIN: menuMakeSet(MenuText, ItemText, State)
# FUNC:menuMakeSet():2010.201
def menuMakeSet(MenuText, ItemText, State):
    Found = False
    try:
        Menu = MENUMenus[MenuText]
        for Item in range(Menu.index("end")+1):
            Type = Menu.type(Item)
            if Type in ("tearoff", "separator"):
                continue
            if Menu.entrycget(Item, "label") == ItemText:
                Found = True
                Menu.entryconfigure(Item, state = State)
                break
# Just in case. This should never go off if I've done my job.
    except:
        print("menuMakeSet: %s, %s\a"%(MenuText, ItemText))
    return
################################
# BEGIN: menuMakeForms(e = None)
# FUNC:menuMakeForms():2010.249
def menuMakeForms(e = None):
    FMenu = MENUMenus["Forms"]
    FMenu.delete(0, END)
# Build the list of forms so they can be sorted alphabetically.
    Forms = []
    for Frmm in Frm.keys():
        try:
            if Frm[Frmm] != None:
                Forms.append([Frm[Frmm].title(), Frmm])
        except TclError:
            print Frmm
            closeForm(Frmm)
    if len(Forms) == 0:
        FMenu.add_command(label = "No Forms Are Open")
    else:
        Forms.sort()
        for Title, Frmm in Forms:
            FMenu.add_command(label = Title, command = Command(showUp, Frmm))
        FMenu.add_separator()
        FMenu.add_command(label = "Close All Forms", command = closeFormAll)
    return
# END: menuMake




######################
# BEGIN: setPROGVars()
# FUNC:setPROGVars():2009.328
def setPROGVars():
    OPTGetCPUVerCVar.set(0)
    IDFieldVar.set("")
    FDiskVar.set(1)
    OffSetRVar.set("set")
    for i in xrange(1, 1+6):
        eval("Chan%dMonCVar"%i).set(1)
    CalChansRVar.set("123")
    RAMStatCVar.set(1)
    ParmsStatCVar.set(1)
    GPSStatVar.set(1)
    DStatVar.set(1)
    VStatVar.set(1)
    CV123Var.set(1)
    CV456Var.set(0)
    OPTPref0000CVar.set(1)
    OPTSummaryModeCVar.set(0)
    OPTDoneBeepCVar.set(0)
    OPTPosDddd.set(0)
    OPTDebugCVar.set(0)
    return
# END: setPROGVars




###############
# BEGIN: main()
# FUNC:main():2010.159
Root.title(PROG_NAME+" - "+PROG_VERSION)
Root.protocol("WM_DELETE_WINDOW", Command(progQuitter, True))
Root.resizable(0, 0)
PROGMsgsDirVar = StringVar()
PROGWorkDirVar = StringVar()
CmdPortVar = StringVar()
PROGSetups += ("PROGMsgsDirVar", "PROGWorkDirVar", "CmdPortVar")
WorkState = 0
MSGLNAlwaysScroll = False
CmdPort = None
# A global place to keep button references.
Buts = {}
# Trigger parameter frames.
Subs = {}
# Entry fields.
Ent = {}
# Parameter variables.
PExpName = StringVar()
PExpComment = StringVar()
PC1Name = StringVar()
PC2Name = StringVar()
PC3Name = StringVar()
PC4Name = StringVar()
PC5Name = StringVar()
PC6Name = StringVar()
PC1Gain = IntVar()
PC2Gain = IntVar()
PC3Gain = IntVar()
PC4Gain = IntVar()
PC5Gain = IntVar()
PC6Gain = IntVar()
PC1Comment = StringVar()
PC2Comment = StringVar()
PC3Comment = StringVar()
PC4Comment = StringVar()
PC5Comment = StringVar()
PC6Comment = StringVar()
PDS1Name = StringVar()
PDS1Disk = IntVar()
PDS1Ether = IntVar()
PDS1Serial = IntVar()
PDS1Ram = IntVar()
PDS1Chan1 = IntVar()
PDS1Chan2 = IntVar()
PDS1Chan3 = IntVar()
PDS1Chan4 = IntVar()
PDS1Chan5 = IntVar()
PDS1Chan6 = IntVar()
PDS1SampRate = StringVar()
PDS1Format = StringVar()
PDS1TType = IntVar()
PDS1TChan1 = IntVar()
PDS1TChan2 = IntVar()
PDS1TChan3 = IntVar()
PDS1TChan4 = IntVar()
PDS1TChan5 = IntVar()
PDS1TChan6 = IntVar()
PDS1Mc = StringVar()
PDS1Pretl = StringVar()
PDS1Rl = StringVar()
PDS1Sta = StringVar()
PDS1Lta = StringVar()
PDS1Hold = IntVar()
PDS1Tr = StringVar()
PDS1Twin = StringVar()
PDS1Postl = StringVar()
PDS1Dtr = StringVar()
PDS1Start1 = StringVar()
PDS1Start2 = StringVar()
PDS1Start3 = StringVar()
PDS1Start4 = StringVar()
PDS1Start5 = StringVar()
PDS1Start6 = StringVar()
PDS1Start7 = StringVar()
PDS1Start8 = StringVar()
PDS1Start9 = StringVar()
PDS1Start10 = StringVar()
PDS1Start11 = StringVar()
PDS1TStrm = IntVar()
PDS1Tlvl = StringVar()
PDS1LPFreq = IntVar()
PDS1HPFreq = IntVar()
PDS1RepInt = StringVar()
PDS1NumTrig = StringVar()
PDS2Name = StringVar()
PDS2Disk = IntVar()
PDS2Ether = IntVar()
PDS2Serial = IntVar()
PDS2Ram = IntVar()
PDS2Chan1 = IntVar()
PDS2Chan2 = IntVar()
PDS2Chan3 = IntVar()
PDS2Chan4 = IntVar()
PDS2Chan5 = IntVar()
PDS2Chan6 = IntVar()
PDS2SampRate = StringVar()
PDS2Format = StringVar()
PDS2TType = IntVar()
PDS2TChan1 = IntVar()
PDS2TChan2 = IntVar()
PDS2TChan3 = IntVar()
PDS2TChan4 = IntVar()
PDS2TChan5 = IntVar()
PDS2TChan6 = IntVar()
PDS2Mc = StringVar()
PDS2Pretl = StringVar()
PDS2Rl = StringVar()
PDS2Sta = StringVar()
PDS2Lta = StringVar()
PDS2Hold = IntVar()
PDS2Tr = StringVar()
PDS2Twin = StringVar()
PDS2Postl = StringVar()
PDS2Dtr = StringVar()
PDS2Start1 = StringVar()
PDS2Start2 = StringVar()
PDS2Start3 = StringVar()
PDS2Start4 = StringVar()
PDS2Start5 = StringVar()
PDS2Start6 = StringVar()
PDS2Start7 = StringVar()
PDS2Start8 = StringVar()
PDS2Start9 = StringVar()
PDS2Start10 = StringVar()
PDS2Start11 = StringVar()
PDS2TStrm = IntVar()
PDS2Tlvl = StringVar()
PDS2LPFreq = IntVar()
PDS2HPFreq = IntVar()
PDS2RepInt = StringVar()
PDS2NumTrig = StringVar()
PDS3Name = StringVar()
PDS3Disk = IntVar()
PDS3Ether = IntVar()
PDS3Serial = IntVar()
PDS3Ram = IntVar()
PDS3Chan1 = IntVar()
PDS3Chan2 = IntVar()
PDS3Chan3 = IntVar()
PDS3Chan4 = IntVar()
PDS3Chan5 = IntVar()
PDS3Chan6 = IntVar()
PDS3SampRate = StringVar()
PDS3Format = StringVar()
PDS3TType = IntVar()
PDS3TChan1 = IntVar()
PDS3TChan2 = IntVar()
PDS3TChan3 = IntVar()
PDS3TChan4 = IntVar()
PDS3TChan5 = IntVar()
PDS3TChan6 = IntVar()
PDS3Mc = StringVar()
PDS3Pretl = StringVar()
PDS3Rl = StringVar()
PDS3Sta = StringVar()
PDS3Lta = StringVar()
PDS3Hold = IntVar()
PDS3Tr = StringVar()
PDS3Twin = StringVar()
PDS3Postl = StringVar()
PDS3Dtr = StringVar()
PDS3Start1 = StringVar()
PDS3Start2 = StringVar()
PDS3Start3 = StringVar()
PDS3Start4 = StringVar()
PDS3Start5 = StringVar()
PDS3Start6 = StringVar()
PDS3Start7 = StringVar()
PDS3Start8 = StringVar()
PDS3Start9 = StringVar()
PDS3Start10 = StringVar()
PDS3Start11 = StringVar()
PDS3TStrm = IntVar()
PDS3Tlvl = StringVar()
PDS3LPFreq = IntVar()
PDS3HPFreq = IntVar()
PDS3RepInt = StringVar()
PDS3NumTrig = StringVar()
PDS4Name = StringVar()
PDS4Disk = IntVar()
PDS4Ether = IntVar()
PDS4Serial = IntVar()
PDS4Ram = IntVar()
PDS4Chan1 = IntVar()
PDS4Chan2 = IntVar()
PDS4Chan3 = IntVar()
PDS4Chan4 = IntVar()
PDS4Chan5 = IntVar()
PDS4Chan6 = IntVar()
PDS4SampRate = StringVar()
PDS4Format = StringVar()
PDS4TType = IntVar()
PDS4TChan1 = IntVar()
PDS4TChan2 = IntVar()
PDS4TChan3 = IntVar()
PDS4TChan4 = IntVar()
PDS4TChan5 = IntVar()
PDS4TChan6 = IntVar()
PDS4Mc = StringVar()
PDS4Pretl = StringVar()
PDS4Rl = StringVar()
PDS4Sta = StringVar()
PDS4Lta = StringVar()
PDS4Hold = IntVar()
PDS4Tr = StringVar()
PDS4Twin = StringVar()
PDS4Postl = StringVar()
PDS4Dtr = StringVar()
PDS4Start1 = StringVar()
PDS4Start2 = StringVar()
PDS4Start3 = StringVar()
PDS4Start4 = StringVar()
PDS4Start5 = StringVar()
PDS4Start6 = StringVar()
PDS4Start7 = StringVar()
PDS4Start8 = StringVar()
PDS4Start9 = StringVar()
PDS4Start10 = StringVar()
PDS4Start11 = StringVar()
PDS4TStrm = IntVar()
PDS4Tlvl = StringVar()
PDS4LPFreq = IntVar()
PDS4HPFreq = IntVar()
PDS4RepInt = StringVar()
PDS4NumTrig = StringVar()
PAuxMarker = StringVar()
PAuxChan1 = IntVar()
PAuxChan2 = IntVar()
PAuxChan3 = IntVar()
PAuxChan4 = IntVar()
PAuxChan5 = IntVar()
PAuxChan6 = IntVar()
PAuxChan7 = IntVar()
PAuxChan8 = IntVar()
PAuxChan9 = IntVar()
PAuxChan10 = IntVar()
PAuxChan11 = IntVar()
PAuxChan12 = IntVar()
PAuxChan13 = IntVar()
PAuxChan14 = IntVar()
PAuxChan15 = IntVar()
PAuxChan16 = IntVar()
PAuxDisk = IntVar()
PAuxEther = IntVar()
PAuxSerial = IntVar()
PAuxRam = IntVar()
PAuxSPer = StringVar()
PAuxRl = StringVar()
PACGroup = IntVar()
PACEnable = IntVar()
PACCycle = StringVar()
PACThresh = StringVar()
PACAttempt = StringVar()
PACRetry = StringVar()
PACPeriod = IntVar()
PNPort = IntVar()
PNEPortPow = IntVar()
PNEKeep = IntVar()
PNETDelay = StringVar()
PNEIP1 = StringVar()
PNEIP2 = StringVar()
PNEIP3 = StringVar()
PNEIP4 = StringVar()
PNEFill = IntVar()
PNEMask = StringVar()
PNEHost = StringVar()
PNEGateway = StringVar()
PNSKeep = IntVar()
PNSTDelay = StringVar()
PNSIP = StringVar()
PNSIP1 = StringVar()
PNSIP2 = StringVar()
PNSIP3 = StringVar()
PNSIP4 = StringVar()
PNSFill = IntVar()
PNSMask = StringVar()
PNSHost = StringVar()
PNSGateway = StringVar()
PNSMode = IntVar()
PNSSpeed = IntVar()
PDETDump = IntVar()
PDRetry = StringVar()
PDWrap = IntVar()
PDThresh = StringVar()
PGPSMode = StringVar()
PROGSetups += ("PExpName", "PExpComment", "PC1Name", "PC2Name", "PC3Name", \
        "PC4Name", "PC5Name", "PC6Name", "PC1Gain", "PC2Gain", "PC3Gain", \
        "PC4Gain", "PC5Gain", "PC6Gain", "PC1Comment", "PC2Comment", \
        "PC3Comment", "PC4Comment", "PC5Comment", "PC6Comment", "PDS1Name", \
        "PDS1Disk", "PDS1Ether", "PDS1Serial", "PDS1Ram", "PDS1Chan1", \
        "PDS1Chan2", "PDS1Chan3", "PDS1Chan4", "PDS1Chan5", "PDS1Chan6", \
        "PDS1SampRate", "PDS1Format", "PDS1TType", "PDS1TChan1", \
        "PDS1TChan2", "PDS1TChan3", "PDS1TChan4", "PDS1TChan5", "PDS1TChan6", \
        "PDS1Mc", "PDS1Pretl", "PDS1Rl", "PDS1Sta", "PDS1Lta", "PDS1Hold", \
        "PDS1Tr", "PDS1Twin", "PDS1Postl", "PDS1Dtr", "PDS1Start1", \
        "PDS1Start2", "PDS1Start3", "PDS1Start4", "PDS1Start5", "PDS1Start6", \
        "PDS1Start7", "PDS1Start8", "PDS1Start9", "PDS1Start10", \
        "PDS1Start11", "PDS1TStrm", "PDS1Tlvl", "PDS1LPFreq", "PDS1HPFreq", \
        "PDS1RepInt", "PDS1NumTrig", "PDS2Name", "PDS2Disk", "PDS2Ether", \
        "PDS2Serial", "PDS2Ram", "PDS2Chan1", "PDS2Chan2", "PDS2Chan3", \
        "PDS2Chan4", "PDS2Chan5", "PDS2Chan6", "PDS2SampRate", "PDS2Format", \
        "PDS2TType", "PDS2TChan1", "PDS2TChan2", "PDS2TChan3", "PDS2TChan4", \
        "PDS2TChan5", "PDS2TChan6", "PDS2Mc", "PDS2Pretl", "PDS2Rl", \
        "PDS2Sta", "PDS2Lta", "PDS2Hold", "PDS2Tr", "PDS2Twin", "PDS2Postl", \
        "PDS2Dtr", "PDS2Start1", "PDS2Start2", "PDS2Start3", "PDS2Start4", \
        "PDS2Start5", "PDS2Start6", "PDS2Start7", "PDS2Start8", "PDS2Start9", \
        "PDS2Start10", "PDS2Start11", "PDS2TStrm", "PDS2Tlvl", "PDS2LPFreq", \
        "PDS2HPFreq", "PDS2RepInt", "PDS2NumTrig", "PDS3Name", "PDS3Disk", \
        "PDS3Ether", "PDS3Serial", "PDS3Ram", "PDS3Chan1", "PDS3Chan2", \
        "PDS3Chan3", "PDS3Chan4", "PDS3Chan5", "PDS3Chan6", "PDS3SampRate", \
        "PDS3Format", "PDS3TType", "PDS3TChan1", "PDS3TChan2", "PDS3TChan3", \
        "PDS3TChan4", "PDS3TChan5", "PDS3TChan6", "PDS3Mc", "PDS3Pretl", \
        "PDS3Rl", "PDS3Sta", "PDS3Lta", "PDS3Hold", "PDS3Tr", "PDS3Twin", \
        "PDS3Postl", "PDS3Dtr", "PDS3Start1", "PDS3Start2", "PDS3Start3", \
        "PDS3Start4", "PDS3Start5", "PDS3Start6", "PDS3Start7", "PDS3Start8", \
        "PDS3Start9", "PDS3Start10", "PDS3Start11", "PDS3TStrm", "PDS3Tlvl", \
        "PDS3LPFreq", "PDS3HPFreq", "PDS3RepInt", "PDS3NumTrig", "PDS4Name", \
        "PDS4Disk", "PDS4Ether", "PDS4Serial", "PDS4Ram", "PDS4Chan1", \
        "PDS4Chan2", "PDS4Chan3", "PDS4Chan4", "PDS4Chan5", "PDS4Chan6", \
        "PDS4SampRate", "PDS4Format", "PDS4TType", "PDS4TChan1", \
        "PDS4TChan2", "PDS4TChan3", "PDS4TChan4", "PDS4TChan5", "PDS4TChan6", \
        "PDS4Mc", "PDS4Pretl", "PDS4Rl", "PDS4Sta", "PDS4Lta", "PDS4Hold", \
        "PDS4Tr", "PDS4Twin", "PDS4Postl", "PDS4Dtr", "PDS4Start1", \
        "PDS4Start2", "PDS4Start3", "PDS4Start4", "PDS4Start5", \
        "PDS4Start6", "PDS4Start7", "PDS4Start8", "PDS4Start9", \
        "PDS4Start10", "PDS4Start11", "PDS4TStrm", "PDS4Tlvl", "PDS4LPFreq", \
        "PDS4HPFreq", "PDS4RepInt", "PDS4NumTrig", "PAuxMarker", "PAuxChan1", \
        "PAuxChan2", "PAuxChan3", "PAuxChan4", "PAuxChan5", "PAuxChan6", \
        "PAuxChan7", "PAuxChan8", "PAuxChan9", "PAuxChan10", "PAuxChan11", \
        "PAuxChan12", "PAuxChan13", "PAuxChan14", "PAuxChan15", "PAuxChan16", \
        "PAuxDisk", "PAuxEther", "PAuxSerial", "PAuxRam", "PAuxSPer", \
        "PAuxRl", "PACGroup", "PACEnable", "PACCycle", "PACThresh", \
        "PACAttempt", "PACRetry", "PACPeriod", "PNPort", "PNEPortPow", \
        "PNEKeep", "PNETDelay", "PNEIP1", "PNEIP2", "PNEIP3", "PNEIP4", \
        "PNEFill", "PNEMask", "PNEHost", "PNEGateway", "PNSKeep", \
        "PNSTDelay", "PNSIP", "PNSIP1", "PNSIP2", "PNSIP3", "PNSIP4", \
        "PNSFill", "PNSMask", "PNSHost", "PNSGateway", "PNSMode", "PNSSpeed", \
        "PDETDump", "PDRetry", "PDWrap", "PDThresh", "PGPSMode")
formPARMSClearParms()
formPARMSSetParms("defaults")
# Main screen and menu checkbutton and radiobutton variables.
OPTGetCPUVerCVar = IntVar()
IDFieldVar = StringVar()
FDiskVar = IntVar()
OffSetRVar = StringVar()
Chan1MonCVar = IntVar()
Chan2MonCVar = IntVar()
Chan3MonCVar = IntVar()
Chan4MonCVar = IntVar()
Chan5MonCVar = IntVar()
Chan6MonCVar = IntVar()
ChanMonRVar = StringVar()
CalChansRVar = StringVar()
RAMStatCVar = IntVar()
ParmsStatCVar = IntVar()
GPSStatVar = IntVar()
DStatVar = IntVar()
VStatVar = IntVar()
CV123Var = IntVar()
CV456Var = IntVar()
OPTPref0000CVar = IntVar()
OPTSummaryModeCVar = IntVar()
OPTDoneBeepCVar = IntVar()
OPTPosDddd = IntVar()
OPTDebugCVar = IntVar()
LoopRVar = StringVar()
LoopRVar.set("off")
PROGSetups += ("OPTGetCPUVerCVar", "IDFieldVar", "FDiskVar", "OffSetRVar", \
        "Chan1MonCVar", "Chan2MonCVar", "Chan3MonCVar", "Chan4MonCVar", \
        "Chan5MonCVar", "Chan6MonCVar", "ChanMonRVar", "CalChansRVar", \
        "RAMStatCVar", "ParmsStatCVar", "GPSStatVar", "DStatVar", "VStatVar", \
        "CV123Var", "CV456Var", "OPTPref0000CVar", "OPTSummaryModeCVar", \
        "OPTDoneBeepCVar", "OPTPosDddd", "OPTDebugCVar", "LoopRVar")
setPROGVars()
menuMake(Root)
SubRoot = Frame(Root)
# ----- Enum panel -----
SubP = Frame(SubRoot, bd = 1, relief = GROOVE)
Sub = Frame(SubP, bd = 3)
Buts["ENUM"] = BButton(Sub, text = "Enumerate", command = enumerateCmd)
Buts["ENUM"].pack(side = TOP, fill = X)
Cb = Checkbutton(Sub, text = "0000 Pref", variable = OPTPref0000CVar, \
            command = pref0000Cmd)
Cb.pack(side = TOP)
ToolTip(Cb, 35, \
        "Checking this tell CHANGEO to broadcast commands to all DASs at the same time when possible.")
SSub = Frame(Sub)
formSTAT(SSub)
SSub.pack(side = TOP, fill = BOTH, expand = YES, pady = 2)
BButton(Sub, text = "Select All", \
        command = formSTATSelectAll).pack(side = TOP, fill = X)
SSub = Frame(Sub)
Lab = Label(SSub, text = "ID:=")
Lab.pack(side = LEFT)
ToolTip(Lab, 30, \
        "[Add/Remove] Enter the ID number of the DAS to add or remove from the DAS list. If the DAS is already in the list it will be removed. If it is not in the list it will be added.")
LEnt = Ent["ID"] = Entry(SSub, width = 6, textvariable = IDFieldVar)
LEnt.pack(side = LEFT, pady = 3)
LEnt.bind("<Return>", Command(addRemID, ""))
LEnt.bind("<KP_Enter>", Command(addRemID, ""))
SSub.pack(side = TOP)
BButton(Sub, text = "Clear IDs", command = remAllDASCmd, \
        fg = Clr["U"]).pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Sub = Frame(SubP, bd = 3)
Buts["ALLPORTS"] = BButton(Sub, text = "All Ports On", command = allPortsCmd)
Buts["ALLPORTS"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
CmdPortLab = labelTip(Sub, "Command Port:", TOP, 30, \
        "Device designation for the command serial port. For example:\nWindows: COM4\nLinux: /dev/ttyUSB0\nOSX: /dev/tty.USB<something>")
if PROGSystem == "dar" or PROGSystem == "lin" or PROGSystem == "sun":
    CmdPortLab.bind("<Button-3>", Command(popDirDevice, CmdPortVar, \
            "Command Port"))
Entry(Sub, textvariable = CmdPortVar, width = 16).pack(side = TOP, fill = X, \
        pady = 3)
Sub.pack(side = TOP, fill = X)
SubP.pack(side = LEFT, expand = YES, fill = BOTH)
# ----- Parms panel -----
SubP = Frame(SubRoot, bd = 1, relief = GROOVE)
Sub = Frame(SubP, bd = 3)
Buts["STOP"] = BButton(Sub, text = "Stop", command = stopAction, \
        state = DISABLED)
Buts["STOP"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
Buts["CCGET"] = BButton(Sub, text = "Get CC Time", command = getCCTime)
Buts["CCGET"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
Buts["RECEIVE"] = BButton(Sub, text = "Receive Parms", \
        command = receiveParmsCmd)
Buts["RECEIVE"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
BButton(Sub, text = "Edit Parms", \
        command = formPARMSShowEdit).pack(side = TOP, fill = X)
BButton(Sub, text = "Summary", command = summaryCmd).pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Sub = Frame(SubP, bd = 3)
Buts["SEND"] = BButton(Sub, text = "Send Parms", command = sendParmsCmd)
Buts["SEND"].pack(side = TOP, fill = X)
Buts["VERIFY"] = BButton(Sub, text = "Verify Parms", \
        command = verifyParmsCmd)
Buts["VERIFY"].pack(side = TOP, fill = X)
Buts["WP"] = BButton(Sub, text = "Parms To Disk", command = parmsToDiskCmd)
Buts["WP"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
SSub = Frame(Sub)
Checkbutton(SSub, text = "Acq/RAM", variable = RAMStatCVar).pack(side = TOP)
SSub.pack(side = TOP)
SSub = Frame(Sub)
Checkbutton(SSub, text = "Parms", variable = ParmsStatCVar).pack(side = LEFT)
Checkbutton(SSub, text = "GPS", variable = GPSStatVar).pack(side = LEFT)
SSub.pack(side = TOP)
SSub = Frame(Sub)
Checkbutton(SSub, text = "Disk", variable = DStatVar).pack(side = LEFT)
Checkbutton(SSub, text = "Volts", variable = VStatVar).pack(side = LEFT)
SSub.pack(side = TOP)
Buts["STATUS"] = BButton(Sub, text = "DAS Status", command = statusCmd)
Buts["STATUS"].pack(side = TOP, fill = X)
Lab = Label(Sub, text = "Loop Control")
Lab.pack(side = TOP)
ToolTip(Lab, 30, "Controls how often the DAS Status command(s) are repeated.")
SSub = Frame(Sub)
Radiobutton(SSub, text = "Off", variable = LoopRVar, \
        value = "off").pack(side = LEFT)
Radiobutton(SSub, text = "5s", variable = LoopRVar, \
        value = "5").pack(side = LEFT)
SSub.pack(side = TOP)
SSub = Frame(Sub)
Radiobutton(SSub, text = "30s", variable = LoopRVar, \
        value = "30").pack(side = LEFT)
Radiobutton(SSub, text = "60s", variable = LoopRVar, \
        value = "60").pack(side = LEFT)
SSub.pack(side = TOP)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
SSub = Frame(Sub)
Checkbutton(SSub, text = "123", variable = CV123Var).pack(side = LEFT)
Checkbutton(SSub, text = "456", variable = CV456Var).pack(side = LEFT)
SSub.pack(side = TOP)
Buts["CENTVOLTS"] = BButton(Sub, text = "Centering Volts", \
        command = centeringVoltsCmd)
Buts["CENTVOLTS"].pack(side = TOP, fill = X)
Buts["SENSCAL"] = BButton(Sub, text = "Sensor Cal", command = Command(notYet, \
        Root))
Buts["SENSCAL"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
Buts["MEMTEST"] = BButton(Sub, text = "Memory Test", command = memoryTestCmd)
Buts["MEMTEST"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
Buts["VERSIONS"] = BButton(Sub, text = "Versions/SNs", \
        command = Command(versionsCmd, "nopis"))
Buts["VERSIONS"].pack(side = TOP, fill = X)
Buts["PISVERSIONS"] = BButton(Sub, text = "Versions/SNs\nto PIS", \
        command = Command(versionsCmd, "pis"))
Buts["PISVERSIONS"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
SubP.pack(side = LEFT, expand = YES, fill = BOTH)
# ----- Commands panel -----
SubP = Frame(SubRoot, bd = 1, relief = GROOVE)
Sub = Frame(SubP, bd = 3)
SSub = Frame(Sub)
Lab = Label(SSub, text = "Disk:")
Lab.pack(side = LEFT)
ToolTip(Lab, 30, "Select which disk slot to attempt to format.")
Radiobutton(SSub, text = "1", value = 1, \
        variable = FDiskVar).pack(side = LEFT)
Radiobutton(SSub, text = "2", value = 2, \
        variable = FDiskVar).pack(side = LEFT)
SSub.pack(side = TOP)
Buts["FDISKS"] = BButton(Sub, text = "Format Disk", command = formatCmd)
Buts["FDISKS"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Buts["CLEARRAM"] = BButton(Sub, text = "Clear RAM", \
        command = Command(startSimpleCmd, "CLEARRAM"))
Buts["CLEARRAM"].pack(side = TOP, fill = X)
Buts["DUMPRAM"] = BButton(Sub, text = "Dump RAM", \
        command = Command(startSimpleCmd, "DUMPRAM"))
Buts["DUMPRAM"].pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
Buts["RESET"] = BButton(Sub, text = "Reset", \
        command = Command(startSimpleCmd, "RESET"))
Buts["RESET"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
SSub = Frame(Sub)
Radiobutton(SSub, text = "Check", value = "check", \
        variable = OffSetRVar).pack(side = LEFT)
Radiobutton(SSub, text = "Set", value = "set", \
        variable = OffSetRVar).pack(side = LEFT)
SSub.pack(side = TOP)
Buts["OFFSET"] = BButton(Sub, text = "Offset Test", command = offsetCmd)
Buts["OFFSET"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
Lab = Label(Sub, text = "Channels")
Lab.pack(side = TOP)
ToolTip(Lab, 30, \
        "Select the channels a monitor test should be performed on (if the RT130(s) have been suitably programmed).")
SSub = Frame(Sub)
Checkbutton(SSub, text = "1", variable = Chan1MonCVar).pack(side = LEFT)
Checkbutton(SSub, text = "2", variable = Chan2MonCVar).pack(side = LEFT)
Checkbutton(SSub, text = "3", variable = Chan3MonCVar).pack(side = LEFT)
SSub.pack(side = TOP)
SSub = Frame(Sub)
Checkbutton(SSub, text = "4", variable = Chan4MonCVar).pack(side = LEFT)
Checkbutton(SSub, text = "5", variable = Chan5MonCVar).pack(side = LEFT)
Checkbutton(SSub, text = "6", variable = Chan6MonCVar).pack(side = LEFT)
SSub.pack(side = TOP)
Buts["MONITOR"] = BButton(Sub, text = "Monitor Test", command = monitorCmd)
Buts["MONITOR"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
Buts["STARTACQ"] = BButton(Sub, text = "Start Acq", \
        command = Command(startSimpleCmd, "STARTACQ"))
Buts["STARTACQ"].pack(side = TOP, fill = X)
Buts["STOPACQ"] = BButton(Sub, text = "Stop Acq", \
        command = Command(startSimpleCmd, "STOPACQ"))
Buts["STOPACQ"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
Buts["SGAINHIGH"] = BButton(Sub, text = "Set Gain High", \
        command = Command(setGainCmd, "high"))
Buts["SGAINHIGH"].pack(side = TOP, fill = X)
Buts["SGAINLOW"] = BButton(Sub, text = "Set Gain Low", \
        command = Command(setGainCmd, "low"))
Buts["SGAINLOW"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Frame(SubP, height = 2, bd = 1, relief = GROOVE).pack(side = TOP, fill = BOTH)
Sub = Frame(SubP, bd = 3)
SSub.pack(side = TOP)
Buts["SINECAL"] = BButton(Sub, text = "Sine Cal", command = formCSINE)
Buts["SINECAL"].pack(side = TOP, fill = X)
Buts["STEPCAL"] = BButton(Sub, text = "Step Cal", command = formCSTEP)
Buts["STEPCAL"].pack(side = TOP, fill = X)
Buts["NOISECAL"] = BButton(Sub, text = "Noise Cal", command = formCNOIS)
Buts["NOISECAL"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
Sub = Frame(SubP, bd = 3)
SSub = Frame(Sub)
Radiobutton(SSub, text = "123", value = "123", \
        variable = CalChansRVar).pack(side = LEFT)
Radiobutton(SSub, text = "456", value = "456", \
        variable = CalChansRVar).pack(side = LEFT)
SSub.pack(side = TOP)
Buts["MASSCENT"] = BButton(Sub, text = "Mass Center", command = massCenterCmd)
Buts["MASSCENT"].pack(side = TOP, fill = X)
Sub.pack(side = TOP, fill = X)
SubP.pack(side = LEFT, expand = YES, fill = BOTH)
# ----- Messages panel -----
Sub = Frame(SubRoot, bd = 1, relief = GROOVE)
Label(Sub, text = "Messages").pack(side = TOP)
SSub = Frame(Sub)
labelTip(SSub, "Msg:=", LEFT, 40, \
        "[Enter] Enter the message to write to the messages section followed by the Return key.")
LEnt = Ent["MM"] = Entry(SSub, textvariable = PROGMessageEntryVar)
LEnt.pack(side = LEFT, expand = YES, fill = X)
LEnt.bind("<Return>", messageEntry)
LEnt.bind("<KP_Enter>", messageEntry)
LEnt.bind("<Double-Button-1>", Command(formKB, Root, "Msg", \
        PROGMessageEntryVar))
BButton(SSub, text = "Clear", fg = Clr["U"], \
        command = messageEntryClear).pack(side = LEFT)
SSub.pack(side = TOP, fill = X, padx = 3, pady = 3)
MMsg = Text(Sub, width = 65, height = 0, wrap = WORD, bg = Clr["B"], \
        fg = "lightgrey")
MMsg.pack(side = LEFT, expand = YES, fill = BOTH)
MMVSb = Scrollbar(Sub, orient = VERTICAL, command = MMsg.yview)
MMVSb.pack(side = RIGHT, fill = Y)
MMsg.configure(yscrollcommand = MMVSb.set)
Sub.pack(side = LEFT, expand = YES, fill = BOTH)
SubRoot.pack(side = TOP)
msgLn(0, "", "", False, 0, False)
center(None, Root, "C", "I", True)
# Begin startup sequence.
Ret = getPROGStarted()
if Ret[0] == 1:
    formMYD(Root, (("(OK)", TOP, "ok"), ), "ok", Ret[1], "Really?", Ret[2])
elif Ret[0] == 2:
    formMYD(Root, (("(OK)", TOP, "ok"), ), "ok", Ret[1], "Oh Oh.", Ret[2])
# Something is wrong so don't save the setups.
    progQuitter(False)
# How things get set up differ depending on if the user has told the program
# that they are running it from the command line. In that case take a chance
# and get the Msgs and Work dirs from the getcwd() command.
if PROGCLRunning == 0:
# Set these to something sensible if they were not loaded by the setups file,
# but if all of them are blank then this may be the first running of the
# program in this account. In that case ask if the user wants to set them
# to something else.
    if PROGMsgsDirVar.get() == "" and PROGWorkDirVar.get() == "":
        Ret = getPROGStartDir(0)
        if Ret != "":
            PROGMsgsDirVar.set(Ret)
            PROGWorkDirVar.set(Ret)
# Some of these may never be true, but are here just in case.
    if PROGMsgsDirVar.get() == "":
        PROGMsgsDirVar.set(PROGSetupsDirVar.get())
    if PROGWorkDirVar.get() == "":
        PROGWorkDirVar.set(PROGMsgsDirVar.get())
elif PROGCLRunning == 1:
    CWD = getCWD()
    PROGMsgsDirVar.set(CWD)
    PROGWorkDirVar.set(CWD)
# Place this at the beginning of the messages section just for troubleshooting
# purposes, but not in the messages since they have not been loaded yet.
msgLn(9, "", "Setups directory\n   %s"%PROGSetupsDirVar.get())
setPROGMsgsFile()
msgLn(9, "", "-----")
loadPROGMsgs()
listDirs(9)
ready()
# Let the user enter the port on the command line like /dev/ttyUSB0. If there
# is none then look for a previously saved setup file. This will only work on
# OSs like Linux.
if CLAPort != "":
    if exists(CLAPort):
        CmdPortVar.set(CLAPort)
    else:
        msgLn(1, "R", "Supplied serial port device not found:", True, 2)
        msgLn(0, "", "   \"%s\""%CLAPort)
# Try to load the serial package.
try:
    from serial import Serial, EIGHTBITS, PARITY_NONE, STOPBITS_ONE
except ImportError, e:
    formMYD(Root, (("(OK)", LEFT, "ok"), ), "ok", "RW", "Welcome.", \
            "The serial interface package (pySerial) is having trouble.\n\n%s\n\nThis will need to be corrected before %s will be capable of doing anything very useful.\nHave a nice day!"% \
            (e, PROG_NAME), "", 2)
if PROGSystem != "dar" and PROGSystem != "lin" and PROGSystem != "win":
    formMYD(Root, (("(OK)", LEFT, "ok"), ), "ok", "YB", "Surprise!", \
            "There is only full support for Apple OSX, Linux and Windows at this time.\n\nThis system identifies itself as \"%s\"."% \
            PROGSystem, "", 2)
Root.mainloop()
# END: main
