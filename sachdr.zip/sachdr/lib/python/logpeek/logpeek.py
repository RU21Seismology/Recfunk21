#! /usr/bin/env picpython
# BEGIN PROGRAM: LOGPEEK
# Started: 2001.040
# By: Bob Greschke

from sys import argv, exit, platform
PROGSystem = platform[:3].lower()
PROG_NAME = "LOGPEEK"
PROG_NAMELC = "logpeek"
PROG_LONGNAME = "RT130 Log File and Data Peeker"
PROG_VERSION = "2011.081"
PROG_VERSURL = "http://www.passcal.nmt.edu/~bob/versions.htm"

# This will stay "" if there is no passed path/filename supplied on the command
# line.
CLAFile = ""
PROGLang = "-LE"
# If set it tells the program that the user is running it from the command
# line which affects how the initial paths are set.
PROGCLRunning = 0
# If 1 the program will ignore the saved main display geometry information.
PROGIgnoreGeometry = 0
# Allow selecting multiple files or not?
PROGMultiMode = False
for Arg in argv[1:]:
    if Arg == "-#":
        print PROG_VERSION
        exit()
    elif Arg == "-LE":
        PROGLang = "-LE"
    elif Arg == "-LS":
        PROGLang = "-LS"
    elif Arg == "-c":
        PROGCLRunning = 1
    elif Arg == "-g":
        PROGIgnoreGeometry = 1
    elif Arg == "-m":
        PROGMultiMode = True
    else:
# If it is none of the above then treat the argument as a path/filename.
        CLAFile = Arg

# Check for this.
from sys import version_info
if version_info[0] != 2:
    print "%s only runs on Python 2."%PROG_NAME
    exit()
# For putting Python 3 support in.
PYVERSION = version_info[0]

# Where all of the translations will be kept.
PROGTrans = {}

from Tkinter import *
from calendar import monthcalendar, setfirstweekday
from fnmatch import fnmatch
import Image, ImageDraw, ImageTk
from math import cos, sqrt
from os import access, environ, getcwd, listdir, makedirs, renames, sep, \
        walk, W_OK
from os.path import abspath, basename, dirname, exists, getsize, isdir, isfile
# PROFILE
#import profile
from string import *
from sys import maxint
from time import gmtime, sleep, localtime, strftime, time
from tkFont import Font
from urllib import urlopen
from warnings import filterwarnings
from zipfile import is_zipfile, ZipFile
# For older versions of Python.
try:
    True
except NameError:
    True = 0 == 0
    False = not True

filterwarnings("ignore")
setfirstweekday(6)

# This is way up here so StringVars and IntVars can be declared throughout the
# code.
Root = Tk()
Root.withdraw()

# For the program's forms, Text fields, buttons...
But = {}
Can = {}
Ent = {}
Frm = {}
Msg = {}
Txt = {}
Var = {}
Sb = {}

#####################
# BEGIN: option_add()
# LIB:option_add():2010.252
#   Fonts: a constant nagging problem, though less now. I've stopped trying
#   to micromanage them and mostly let the user suffer with what the system
#   decides to use.
PROGScreenWidth = Root.winfo_screenwidth()
PROGScreenHeight = Root.winfo_screenheight()
PROGConfiguration = ""
if PROGSystem == "dar":
    PROGProportionalFont = "(system's choice)"
    PROGFixedFont = "Fixed"
# A "new" version of PASSCAL Tkinter sets this to 1.
    Root.option_add("*Button*borderWidth", "2")
    Root.option_add("*Text*font", (PROGFixedFont, -14, ""))
    PROGKBFont = (PROGFixedFont, -12, "bold")
    PROGConfiguration = "Darwin %dx%d\nProportional font: %s\nFixed font: %s"% \
            (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
            PROGFixedFont)
elif PROGSystem == "lin":
    PROGProportionalFont = "Helvetica"
    PROGFixedFont = "Courier"
# This is for LUNCH-sized displays (and VMWare on a 13" MacBook Pro).
    if PROGScreenHeight < 800:
        Root.option_add("*Button*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Checkbutton*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Radiobutton*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Entry*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Label*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Text*font", (PROGFixedFont, -11, ""))
        PROGKBFont = (PROGFixedFont, -11, "")
        PROGConfiguration = "Linux (<800) %dx%d\nProportional font: %s\nFixed font: %s"% \
                (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
                PROGFixedFont)
# This is for VMWare on a 13" MacBook, full screen. Open up a few things to
# makeit easier on the eyes.
    elif PROGScreenHeight == 800:
        Root.option_add("*Button*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Checkbutton*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Radiobutton*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Entry*font", (PROGProportionalFont, -12, ""))
        Root.option_add("*Label*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Text*font", (PROGFixedFont, -12, ""))
        PROGKBFont = (PROGFixedFont, -11, "")
        PROGConfiguration = "Linux (=800) %dx%d\nProportional font: %s\nFixed font: %s"% \
                (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
                PROGFixedFont)
    else:
        Root.option_add("*Button*font", (PROGProportionalFont, -12, ""))
        Root.option_add("*Checkbutton*font", (PROGProportionalFont, -12, ""))
        Root.option_add("*Radiobutton*font", (PROGProportionalFont, -11, ""))
        Root.option_add("*Entry*font", (PROGProportionalFont, -12, ""))
        Root.option_add("*Label*font", (PROGProportionalFont, -12, ""))
        Root.option_add("*Text*font", (PROGFixedFont, -12, ""))
        PROGKBFont = (PROGFixedFont, -12, "bold")
        PROGConfiguration = "Linux %dx%d\nProportional font: %s\nFixed font: %s"% \
                (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
                PROGFixedFont)
elif PROGSystem == "sun":
    PROGProportionalFont = "(system's choice)"
    PROGFixedFont = "Courier"
    Root.option_add("*Text*font", (PROGFixedFont, -12, ""))
    PROGKBFont = (PROGFixedFont, -12, "bold")
    PROGConfiguration = "Sun %dx%d\nProportional font: %s\nFixed font: %s"% \
            (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
            PROGFixedFont)
elif PROGSystem == "win":
    PROGProportionalFont = "(system's choice)"
    PROGFixedFont = "Courier New"
    Root.option_add("*Text*font", (PROGFixedFont, 9, ""))
    PROGKBFont = (PROGFixedFont, 9, "bold")
    PROGConfiguration = "Windows %dx%d\nProportional font: %s\nFixed font: %s"% \
            (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
            PROGFixedFont)
else:
    PROGProportionalFont = "(system's choice)"
    PROGFixedFont = "Courier"
    Root.option_add("*Text*font", (PROGFixedFont, 10, ""))
    PROGKBFont = (PROGFixedFont, 10, "bold")
    PROGConfiguration = "Other %dx%d\nProportional font: %s\nFixed font: %s"% \
            (PROGScreenWidth, PROGScreenHeight, PROGProportionalFont, \
            PROGFixedFont)
# This will help on some systems, and have no effect on others.
Root.option_add("*Menu*font", Button().cget("font"))
PROGCascadeFont = Menu().cget("font")
# For things that might not get pack()'ed and have to have their fonts set.
PROGCheckbuttonFont = Checkbutton().cget("font")
# Sometimes the fonts in the picker go crazy so set this.
PROGMYDFFont = Entry().cget("font")
# Depending on the Tkinter version or how it was compiled the scroll bars can
# be pretty narrow.
if Scrollbar().cget("width") < "15":
    Root.option_add("*Scrollbar*width", "15")
# PIL on OSX doesn't handle "green" correctly, so use RGB for everything.
# B = black, C = cyan, G = green, M = magenta, R = red, O = orange, W = white
# Y = yellow, E = light gray, A = gray, K = dark gray, U = blue, N = dark green
# S = dark red, y = light yellow, D = default widget color.
# Orange should be #FF7F00, but #DD5F00 is easier to see on a white background
# and it still looks OK on a black background.
Clr = {"B":"#000000", "C":"#00FFFF", "G":"#00FF00", "M":"#FF00FF", \
        "R":"#FF0000", "O":"#FF7F00", "W":"#FFFFFF", "Y":"#FFFF00", \
        "E":"#DFDFDF", "A":"#8F8F8F", "K":"#3F3F3F", "U":"#0000FF", \
        "N":"#007F00", "S":"#7F0000", "y":"#7F7F00", "D":Root.cget("bg")}
Root.option_add("*Button*takeFocus", "0")
Root.option_add("*Checkbutton*anchor", "w")
Root.option_add("*Checkbutton*takeFocus", "0")
Root.option_add("*Entry*background", Clr["W"])
Root.option_add("*Entry*foreground", Clr["B"])
Root.option_add("*Entry*highlightThickness", "2")
Root.option_add("*Entry*insertWidth", "3")
Root.option_add("*Entry*highlightColor", Clr["B"])
Root.option_add("*Entry*disabledBackground", Clr["D"])
Root.option_add("*Entry*disabledForeground", Clr["B"])
Root.option_add("*Listbox*background", Clr["W"])
Root.option_add("*Listbox*foreground", Clr["B"])
Root.option_add("*Listbox*selectBackground", Clr["G"])
Root.option_add("*Listbox*selectForeground", Clr["B"])
Root.option_add("*Listbox*takeFocus", "0")
Root.option_add("*Listbox*exportSelection", "0")
Root.option_add("*Radiobutton*takeFocus", "0")
Root.option_add("*Scrollbar*takeFocus", "0")
Root.option_add("*Text*background", Clr["W"])
Root.option_add("*Text*foreground", Clr["B"])
Root.option_add("*Text*takeFocus", "0")
Root.option_add("*Text*highlightThickness", "0")
Root.option_add("*Text*insertWidth", "0")
Root.option_add("*Text*width", "0")
Root.option_add("*Text*padX", "3")
Root.option_add("*Text*padY", "3")
PROGMonoFont = Text().cget("font")
# Message fields don't need to be the fixed width Text() font.
PROGMsgFont = Label().cget("font")
# For Canvas stuff.
PROGLabelFont = Label().cget("font")
PROGLabelFontFont = Font(font = PROGLabelFont)
PROGLabelFontHeight = PROGLabelFontFont.metrics("ascent")+ \
        PROGLabelFontFont.metrics("descent")
# To control the color of the buttons better in X-Windows programs.
Root.option_add("*Button*activeBackground", Clr["D"])
Root.option_add("*Checkbutton*activeBackground", Clr["D"])
Root.option_add("*Radiobutton*activeBackground", Clr["D"])
# END: option_add

PROGSetups = ()

# Colors for everything. They get assigned as soon as we know what color mode
# we are in (color or b&w).
DClr = {"ACQStart":"", "ACQStartBG":"", "ACQStop":"", "ACQStopBG":"", \
        "MFCAN":"", "GPSCanvas":"", "ClockTime":"", "DCDIFF":"", \
        "DCDIFFBG":"", "DEFS":"", "DEFSBG":"", "DISCREP":"", "DISCREPBG":"", \
        "DRSET":"", "DRSETBG":"", "DUMPOn":"", "DUMPOnBG":"", "DUMPOff":"", \
        "DUMPOffBG":"", "ERROR":"", "ERRORBG":"", "EVT":"", "EVTBG":"", \
        "GPSOff":"", "GPSOffBG":"", "GPSOn":"", "GPSOnBG":"", "GPSLK":"", \
        "GPSLKBG":"", "ICPE":"", "ICPEBG":"", "Image":"", "JERK":"", \
        "JERKBG":"", "Label":"", "MaxMinL":"", "MRC":"", "MRCBG":"", \
        "NETDown":"", "NETDownBG":"", "NETUp":"", "NETUpBG":"", "Plot":"", \
        "PWRUP":"", "PWRUPBG":"", "CLKPWR":"", "CLKPWRBG":"", "RESET":"", \
        "RESETBG":"", "SOH":"", "SOHBG":"", "TEMP":"", "TEMPBG":"", \
        "TMJMPPos":"", "TMJMPPosBG":"", "TMJMPNeg":"", "TMJMPNegBG":"", \
        "VOLT":"", "VOLTBG":"", "BKUP":"", "BKUPBG":"", "BKUPG":"", \
        "BKUPGBG":"", "BKUPB":"", "BKUPBBG":"", "BKUPU":"", "BKUPUBG":"", \
        "MPP":"", "MPG":"", "MPB":"", "MPU":"", "MPH":"", "WARN":"", \
        "WARNBG":""}
PROGColorModeRVar = StringVar()
PROGColorModeRVar.set("B")
PROGGeometryVar = StringVar()
PROGSetups += ("PROGColorModeRVar", "PROGGeometryVar")

#########################
# BEGIN: lunchFunctions()
# LIB:lunchFunctions():2011.081logpeek
# These deployment and TSP file layouts are in here to serve as a guide for
# writing shot event lines from exportTT() and don't really get used.  The
# whole lunchFunctions() library collection of routines are not included or
# used...so be careful. The header is just here so potential changes are
# caught when the routines are changed elsewhere.
DEPSHOT_STAG = 0    # SHOT;
DEPSHOT_STID = 1    # Shot point name/ID
DEPSHOT_ARRY = 2    # Array/Sub-array designation
DEPSHOT_IDID = 3    # Shot ID
DEPSHOT_LATI = 4    # Latitude (NDD.ddd)
DEPSHOT_LONG = 5    # Longitude (EDDD.ddd)
DEPSHOT_ELEV = 6    # Elevation (m)
DEPSHOT_TIME = 7    # Shot time (YYYY:DDD:HH:MM:SS.sss)
DEPSHOT_PRET = 8    # Pre-trigger length (secs)
DEPSHOT_POST = 9    # Post-trigger length (secs)
DEPSHOT_RADI = 10   # Radius of receivers to include (km.mmm)
DEPSHOT_SAMP = 11   # Sample rate to use (sps)
DEPSHOT_DPTH = 12   # Depth of shot (m)
DEPSHOT_SIZE = 13   # Size of shot (kg)
DEPSHOT_RVEL = 14   # Radial velocity to use for gather
DEPSHOT_COMM = 15   # Comments
DEPSHOT_SOUR = 16   # Position source ("SURVEY", "LUNCH", "HANDHELD", etc.)

# Layout of the TSP shot file.
TSPSHOTFIELDS = 7   # YYYY,DDD,HH,MM...
TSPSHOT_REQU = 6    # Azimuth is optional
TSPSHOT_TSPY = 0    # Year
TSPSHOT_TSPD = 1    # DDD
TSPSHOT_TSPH = 2    # Hour
TSPSHOT_TSPM = 3    # Min
TSPSHOT_TSPS = 4    # Sec
TSPSHOT_IDID = 5    # Shot FFID
TSPSHOT_POST = 6    # Shot length to cut
TSPSHOT_TSAZ = 7    # Azimuth

# For the <something>2Epoch-type library functions.
PROGYEF70 = {}
PROGYEI70 = {}
PROGYEF84 = {}
PROGYEI84 = {}




# ==============================================
# BEGIN: ========== PROGRAM FUNCTIONS ==========
# ==============================================


#############################
# BEGIN: about(Parent = Root)
# LIB:about():2010.248
PROGTrans["ABTabout-LE"] = "About"
PROGTrans["ABTabout-LS"] = "Acerca De"
PROGTrans["ABTvers-LE"] = "Version"
PROGTrans["ABTvers-LS"] = unicode("Versi\xf3n", "iso8859-1")
PROGTrans["ABTphone-LE"] = "Phone"
PROGTrans["ABTphone-LS"] = unicode("Tel\xe9fono", "iso8859-1")
PROGTrans["ABTconfig-LE"] = "Configuration"
PROGTrans["ABTconfig-LS"] = unicode("Configuraci\xf3n", "iso8859-1")
PROGTrans["ABTsetup-LE"] = "Setups File"
PROGTrans["ABTsetup-LS"] = "Setups File"
PROGTrans["ABTok-LE"] = "OK"
PROGTrans["ABTok-LS"] = "OK"

def about(Parent = Root):
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    Message = "%s (%s)\n   "%(PROG_LONGNAME, PROG_NAME)
    Message += "%s %s\n"%(PROGTrans['ABTvers'+PROGLang], PROG_VERSION)
    Message += "%s\n"%"PASSCAL Instrument Center"
    Message += "%s\n\n"%"Socorro, New Mexico"
    Message += "%s\n"%"Email: passcal@passcal.nmt.edu"
    Message += "%s: %s\n\n"%(PROGTrans['ABTphone'+PROGLang], "575-835-5070")
    Message += "--- %s ---\n"%PROGTrans['ABTconfig'+PROGLang]
    Message += "%s"%PROGConfiguration
# Some programs don't care about the geometry of the main display.
    try:
        if PROGGeometryVar.get() != "":
            Message += "\n"
            Message += "Geometry: %s"%PROGGeometryVar.get()
    except:
        pass
# Some dont have setup files.
    if PROGSetupsDirVar.get() != "N/A":
        Message += "\n\n"
        Message += "--- %s ---\n"%PROGTrans['ABTsetup'+PROGLang]
        Message += "%s"%(PROGSetupsDirVar.get()+PROG_NAMELC+".set")
    formMYD(Parent, (("("+PROGTrans['ABTok'+PROGLang]+")", LEFT, "ok"), ), \
           "ok", "", PROGTrans['ABTabout'+PROGLang], Message)
    return
# END: about




##############################
# BEGIN: class BButton(Button)
# LIB:BButton():2009.238
class BButton(Button):
    def __init__(self, master = None, **kw):
        if PROGSystem == "win" and "text" in kw:
            if kw["text"].find("\n") == -1:
                kw["text"] = " "+kw["text"]+" "
            else:
# Add " " to each end of each line so all lines get centered.
                parts = kw["text"].split("\n")
                ntext = ""
                for part in parts:
                    ntext += " "+part+" \n"
                kw["text"] = ntext[:-1]
# Some systems have the button change color when rolled over.
        if "bg" in kw:
            kw["activebackground"] = kw["bg"]
        if "fg" in kw:
            kw["activeforeground"] = kw["fg"]
        Button.__init__(self, master, **kw)
# END: BButton




#######################
# BEGIN: bcd2Int(InStr)
# LIB:bcd2Int():2008.300
#   Converts the passed 1 or 2-byte BCD string into an integer by looking up
#   the vlaues (AND'ing and >>'ing slow things down).
#   There's no error checking to keep it fast so don't pass it things like
#   an "empty" string.
#   Since it is global just using BCDTable in-place in the code and not calling
#   bcd2Int() makes things even faster.
BCDTable = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 0, 0, 0, 0, 0, 10, 11, 12, 13, \
        14, 15, 16, 17, 18, 19, 0, 0, 0, 0, 0, 0, 20, 21, 22, 23, 24, 25, 26, \
        27, 28, 29, 0, 0, 0, 0, 0, 0, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, \
        0, 0, 0, 0, 0, 0, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 0, 0, 0, 0, \
        0, 0, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 0, 0, 0, 0, 0, 0, 60, \
        61, 62, 63, 64, 65, 66, 67, 68, 69, 0, 0, 0, 0, 0, 0, 70, 71, 72, 73, \
        74, 75, 76, 77, 78, 79, 0, 0, 0, 0, 0, 0, 80, 81, 82, 83, 84, 85, 86, \
        87, 88, 89, 0, 0, 0, 0, 0, 0, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, \
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0)

def bcd2Int(InStr):
    if len(InStr) == 1:
        return BCDTable[ord(InStr)]
    else:
        return (BCDTable[ord(InStr[0])]*100)+(BCDTable[ord(InStr[1])])
# END: bcd2Int




################################
# BEGIN: beep(Howmany, e = None)
# LIB:beep():2010.256
PROGNoBeepingCRVar = IntVar()
PROGSetups += ("PROGNoBeepingCRVar", )

def beep(Howmany, e = None):
    if PROGNoBeepingCRVar.get() == 0:
        for i in xrange(0, Howmany):
            Root.bell()
            if i < Howmany-1:
                updateMe(0)
                sleep(.15)
    return
# END: beep




##########################
# BEGIN: busyCursor(OnOff)
# FUNC:busyCursor():2009.057
DefCursor = Root.cget("cursor")

def busyCursor(OnOff):
    if OnOff == 0:
        TheCursor = DefCursor
    else:
        TheCursor = "watch"
    Root.config(cursor = TheCursor)
    for Fram in Frm.values():
        if Fram != None:
            Fram.config(cursor = TheCursor)
    updateMe(0)
    return
# END: busyCursor




#############################################
# BEGIN: buttonBG(Butt, Colr, State = NORMAL)
# LIB:buttonBG():2009.287
def buttonBG(Butt, Colr, State = NORMAL):
# Try since this may get called without the button even existing.
    try:
        if isinstance(Butt, str):
# Set both items to keep the button from changing colors on *NIXs when the
# mouse rolls over. Also only use the first character of the passed value so
# we can pass bg/fg color pairs (I don't think this will ever actually happen).
            Buts[Butt].configure(bg = Clr[Colr[0]], \
                    activebackground = Clr[Colr[0]], state = State)
        else:
            Butt.configure(bg = Clr[Colr[0]], \
                    activebackground = Clr[Colr[0]], state = State)
        updateMe(0)
    except:
        pass
    return
# END: buttonBG




#######################################################
# BEGIN: canText(Can, Cx, Cy, Color, Str, Anchor = "w")
# LIB:canText():2010.181
#   Used to print text to a canvas such that the color of individual words
#   in a line can be changed. Use 0 for Cx to tell the routine to place this
#   Str at the end of the last Str passed.
CANTEXTLastX = 0

def canText(Can, Cx, Cy, Color, Str, Anchor = "w"):
    global CANTEXTLastX
    if Cx == 0:
        Cx = CANTEXTLastX
    if isinstance(Color, str):
        ID = Can.create_text(Cx, Cy, text = Str, fill = Clr[Color[0]], \
                font = PROGLabelFont, anchor = Anchor)
# This may be an input from getAColor().
    elif isinstance(Color, tuple):
        ID = Can.create_text(Cx, Cy, text = Str, fill = Color[0], \
                font = PROGLabelFont, anchor = Anchor)
    else:
        ID = Can.create_text(Cx, Cy, text = Str, fill = "white", \
                font = PROGLabelFont, anchor = Anchor)
    L, T, R, B = Can.bbox(ID)
# -1: I don't know if this is a Tkinter bug or if it just happened to be
# specific to the font I was using or what.
    CANTEXTLastX = R-1
    return ID
# END: canText




###############################################################################
# BEGIN: center(Parent, TheFrame, Where, InOut, Show, CenterX = 0, CenterY = 0)
# LIB:center():2009.326
#   Where tells the function where in relation to the Parent TheFrame should
#   show up.  Use the diagram below to figure out where things will end up.
#
#      +---------------+
#      | NW    N    NE |
#      |               |
#      | W     C     E |
#      |               |
#      | SW    S    SE |
#      +---------------+
#
#   Set Parent to None to use the whole display as the parent.
#   Set InOut to "I" or "O" to control if TheFrame shows "I"nside or "O"outside
#   the Parent (does not apply if the Parent is None).
#
#   CenterX and CenterY not equal to zero overrides everything.
#
def center(Parent, TheFrame, Where, InOut, Show, CenterX = 0, CenterY = 0):
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    if isinstance(TheFrame, str):
        TheFrame = Frm[TheFrame]
# Kiosk mode. Just take over the whole screen. Doesn't check for, but only
# works for Root.
    if Where == "K":
        Root.geometry("%dx%d+0+0"%(Root.winfo_screenwidth(), \
                Root.winfo_screenheight()-30))
        Root.lift()
        Root.deiconify()
        updateMe(0)
        return
# So all of the dimensions get updated.
    updateMe(0)
    FW = TheFrame.winfo_reqwidth()
    if TheFrame == Root:
# Different systems have to be compensated for a little because of differences
# in the reported heights (mostly title and menu bar heights).
        if PROGSystem == "dar" or PROGSystem == "win":
            FH = TheFrame.winfo_reqheight()
        else:
            FH = TheFrame.winfo_reqheight()+50
    else:
        FH = TheFrame.winfo_reqheight()
# Find the center of the Parent.
    if CenterX == 0 and CenterY == 0:
        if Parent == None:
            PX = 0
            PY = 0
            PW = Root.winfo_screenwidth()
            PH = Root.winfo_screenheight()
# A PW of >1920 (the width of a 24" iMac) probably means the user has two
# monitors. Tkinter just gets fed the total width and the smallest display's
# height, so just set the size to 1024x768 and then let the user resize and
# reposition as needed. It's what they get for being so lucky.
            if PW > 1920:
                PW = 1024
                PH = 768
            CenterX = PW/2
            CenterY = PH/2-25
        elif Parent == Root:
            PX = Parent.winfo_x()
            PW = Parent.winfo_width()
            CenterX = PX+PW/2
# Macs, Linux and Suns think the top of the Root window is below the title
# and menu bars.  Windows thinks the top of the window is the top of the
# window, so adjust the window heights accordingly to try and cover that up.
            if PROGSystem == "win":
                PY = Parent.winfo_y()
                PH = Parent.winfo_height()
            else:
                PY = Parent.winfo_y()-50
                PH = Parent.winfo_height()+50
            CenterY = PY+PH/2
        else:
            PX = Parent.winfo_x()
            PW = Parent.winfo_width()
            CenterX = PX+PW/2
            PY = Parent.winfo_y()
            PH = Parent.winfo_height()
            CenterY = PY+PH/2
# Can't put forms outside the whole display.
        if Parent == None or InOut == "I":
            InOut = 1
        else:
            InOut = -1
        if Where == "C":
            TheFrame.geometry("+%i+%i"%(CenterX-FW/2, CenterY-FH/2))
        elif Where == "N":
            TheFrame.geometry("+%i+%i"%(CenterX-FW/2, PY+(50*InOut)))
        elif Where == "NE":
            TheFrame.geometry("+%i+%i"%(PX+PW-FW-(50*InOut), PY+(50*InOut)))
        elif Where == "E":
            TheFrame.geometry("+%i+%i"%(PX+PW-FW-(50*InOut), \
                    CenterY-TheFrame.winfo_reqheight()/2))
        elif Where == "SE":
            TheFrame.geometry("+%i+%i"%(PX+PW-FW-(50*InOut), \
                    PY+PH-FH-(50*InOut)))
        elif Where == "S":
            TheFrame.geometry("+%i+%i"%(CenterX-TheFrame.winfo_reqwidth()/2, \
                    PY+PH-FH-(50*InOut)))
        elif Where == "SW":
            TheFrame.geometry("+%i+%i"%(PX+(50*InOut), PY+PH-FH-(50*InOut)))
        elif Where == "W":
            TheFrame.geometry("+%i+%i"%(PX+(50*InOut), \
                    CenterY-TheFrame.winfo_reqheight()/2))
        elif Where == "NW":
            TheFrame.geometry("+%i+%i"%(PX+(50*InOut), PY+(50*InOut)))
    else:
        TheFrame.geometry("+%i+%i"%(CenterX-FW/2, CenterY-FH/2))
    if Show == True:
        TheFrame.lift()
        TheFrame.deiconify()
    updateMe(0)
    return
# END: center




#############################################
# BEGIN: changeDirs(Parent, Which, Mode, Var)
# LIB:changeDirs():2010.173
#   Mode = formMYDF mode value (some callers may not want to allow directory
#          creation, for example).
#      1 = just picking
#      2 = picking and creating
#   Var = if not None the selected directory will be placed there. May not be
#         used in all programs.
#
#   Not all programs will use all items.
def changeDirs(Parent, Which, Mode, Var):
# The caller can pass either.
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    if Which == "select":
# Just use the directory as a starting point.
        Answer = formMYDF(Parent, Mode, "Pick A Directory For All", \
                PROGMsgsDirVar.get(), "")
        if Answer == "":
            return (1, )
        elif Answer == PROGMsgsDirVar.get():
            return (0, "", "All directories unchanged.", 0)
        else:
# Some of these may not exist in a program.
            try:
                PROGDataDirVar.set(Answer)
            except:
                pass
            try:
                PROGMsgsDirVar.set(Answer)
            except:
                pass
            try:
                CLTRDOrigDirVar.set(Answer)
            except:
                pass
            try:
                TCUTCutDirVar.set(Answer)
            except:
                pass
            try:
                PROGWorkDirVar.set(Answer)
            except:
                pass
            return (0, "WB", "All directories changed to\n   %s"%Answer, 0)
    elif Which == "cut":
        Answer = formMYDF(Parent, Mode, "Pick A Cut Directory", \
                TCUTCutDirVar.get(), "")
        if Answer == "":
            return (1, )
        elif Answer == TCUTCutDirVar.get():
            return (0, "", "Cut data directory unchanged.", 0)
        else:
            TCUTCutDirVar.set(Answer)
            return (0, "WB", "Cut data directory changed to\n   %s"%Answer, 0)
    elif Which == "data":
        if Var == None:
            Answer = formMYDF(Parent, Mode, "Pick A Data Directory", \
                    PROGDataDirVar.get(), "")
            if Answer == "":
                return (1, )
            elif Answer == PROGDataDirVar.get():
                return (0, "", "Data directory unchanged.", 0)
            else:
                PROGDataDirVar.set(Answer)
        else:
            Answer = formMYDF(Parent, Mode, "Pick A Data Directory", \
                    Var.get(), "")
            if Answer == "":
                return (1, )
            elif Answer == Var.get():
                return (0, "", "Data directory unchanged.", 0)
            else:
                Var.set(Answer)
        return (0, "WB", "Data directory changed to\n   %s"%Answer, 0)
    elif Which == "msgs":
        Answer = formMYDF(Parent, Mode, "Pick A Messages Directory", \
                PROGMsgsDirVar.get(), "")
        if Answer == "":
            return (1, )
        elif Answer == PROGMsgsDirVar.get():
            return (0, "", "Messages directory unchanged.", 0)
        else:
            PROGMsgsDirVar.set(Answer)
            return (0, "WB", "Messages directory changed to\n   %s"%Answer, 0)
    elif Which == "orig":
        Answer = formMYDF(Parent, Mode, "Pick An Orig Directory", \
                CLTRDOrigDirVar.get(), "")
        if Answer == "":
            return (1, )
        elif Answer == CLTRDOrigDirVar.get():
            return (0, "", "Orig data directory unchanged.", 0)
        else:
            CLTRDOrigDirVar.set(Answer)
            return (0, "WB", "Orig data directory changed to\n   %s"%Answer, 0)
    elif Which == "work":
        Answer = formMYDF(Parent, Mode, "Pick A Work Directory", \
                PROGWorkDirVar.get(), "")
        if Answer == "":
            return (1, )
        elif Answer == PROGWorkDirVar.get():
            return (0, "", "Work directory unchanged.", 0)
        else:
            PROGWorkDirVar.set(Answer)
            return (0, "WB", "Work directory changed to\n   %s"%Answer, 0)
    return
##########################################################
# BEGIN: changeDirsCmd(Parent, Which, Mode, Var, e = None)
# FUNC:changeDirsCmd():2010.174
def changeDirsCmd(Parent, Which, Mode, Var, e = None):
    Ret = changeDirs(Parent, Which, Mode, Var)
    if Ret[0] == 0:
# Some programs may not have a messages area.
        try:
            msgLn(0, Ret[1], Ret[2], True, Ret[3])
        except:
            pass
    return
# END: changeDirs




##################################################
# BEGIN: compFs(DirVar, FileVar, VarSet, e = None)
# LIB:compFs():2010.227
#   Attempts to complete the directory or file name in an Entry field using
#   the Tab key.
#   - If DirVar is set to a field's StringVar and FileVar is None then the
#     routine only looks for directories.
#   - If DirVar and FileVar are set to StringVars then it works to find a
#     complete fliespec, but getting the path and filenames from different
#     fields.
#   - If DirVar is None and FileVar is set to a StringVar then it trys to
#     complete path and filenames.
#
#   Call comFsSetup() after the Entry field has been created.
def compFs(DirVar, FileVar, VarSet, e = None):
    if VarSet != None:
        setMsg(VarSet, "", "")
# ---- Caller only wants directories.
    if DirVar != None and FileVar == None:
        Dir = dirname(DirVar.get())
# This is a slight gotchya. If the field is empty that might mean that the user
# means "/" should be the starting point. If it is they will have to enter the
# / since if we are on Windows I'd have no idea what the default should be.
        if len(Dir) == 0:
            beep(2)
            return
        if Dir.endswith(sep) == False:
            Dir += sep
# Now get what must be a partial directory name, treat it as a file name, but
# then only allow the result of everything to be a directory.
        PartialFile = basename(DirVar.get())
        if len(PartialFile) == 0:
            beep(2)
            return
        PartialFile += "*"
        Files = listdir(Dir)
        Matched = []
        for File in Files:
            if fnmatch(File, PartialFile):
                Matched.append(File)
        if len(Matched) == 0:
            beep(2)
            return
        elif len(Matched) == 1:
            Dir = Dir+Matched[0]
# If whatever matched is not a directory then just beep and return, otherwise
# make it look like a directory and put it into the field.
            if isdir(Dir) == False:
                beep(2)
                return
            if Dir.endswith(sep) == False:
                Dir += sep
            DirVar.set(Dir)
            e.widget.icursor(END)
            return
        else:
# Get the max number of characters that matched and put the partial directory
# path into the Var. If Dir+PartialDir is really the directory the user wants
# they will have to add the sep themselves since with multiple matches I won't
# know what to do. Consider DIR DIR2 DIR3 with a maxMatch() return of DIR. The
# directory DIR would always be selected and set as the path which may not be
# what the user wanted. Now this could cause trouble downstream since I'm
# leaving a path in the field without a trailing sep (everything tries to
# avoid doing that), so the caller will have to worry about that.
            PartialDir = maxMatch(Matched)
            DirVar.set(Dir+PartialDir)
            e.widget.icursor(END)
            beep(1)
            return
    else:
# ---- Find a file, but the filespec is in one field.
        if DirVar == None and FileVar != None:
            Dir = dirname(FileVar.get())
            Which = 1
# ---- Find a file, but path and file are in separate fields.
        elif DirVar != None and FileVar != None:
            Dir = dirname(DirVar.get())
            Which = 2
        if len(Dir) == 0:
            beep(2)
            return
        if Dir.endswith(sep) == False:
            Dir += sep
        PartialFile = basename(FileVar.get())
        if len(PartialFile) == 0:
            beep(2)
            return
# Match anything to what the user has entered for the file name.
        PartialFile += "*"
        Files = listdir(Dir)
        Matched = []
        for File in Files:
            if fnmatch(File, PartialFile):
                Matched.append(File)
        if len(Matched) == 0:
            beep(2)
            return
        elif len(Matched) == 1:
            File = Matched[0]
            Filespec = Dir+File
# We can stick a directory name in a single field, but the user will have to
# change the directory field if they are separate (it may be that the user
# is not allowed to change the directory field value and I don't want to
# violate that, plus that could be really confusing for everyone when we have
# multiple matches).
            if isdir(Filespec):
                if Which == 1:
                    if Filespec.endswith(sep) == False:
                        Filespec += sep
                    FileVar.set(Filespec)
                    e.widget.icursor(END)
                    return
                elif Which == 2:
                    beep(2)
                    return
            if Which == 1:
                FileVar.set(Filespec)
            elif Which == 2:
                FileVar.set(File)
            e.widget.icursor(END)
            return
        else:
            PartialFile = maxMatch(Matched)
            if Which == 1:
                FileVar.set(Dir+PartialFile)
            elif Which == 2:
                FileVar.set(PartialFile)
            e.widget.icursor(END)
            beep(1)
            return
##############################################################
# BEGIN: compFsSetup(LFrm, LEnt, DirVar, FileVar, VarSet = "")
# FUNC:compFsSetup():2010.255
#   Just sets up the bind's for the passed Entry field. See compFs() for the
#   DirVar and FileVar explainations.
def compFsSetup(LFrm, LEnt, DirVar, FileVar, VarSet):
    LEnt.bind("<FocusIn>", Command(compFsTabOff, LFrm))
    LEnt.bind("<FocusOut>", Command(compFsTabOn, LFrm))
    LEnt.bind("<Key-Tab>", Command(compFs, DirVar, FileVar, VarSet))
    return
#####################################
# BEGIN: compFsTabOff(LFrm, e = None)
# FUNC:compFsTabOff():2010.225
def compFsTabOff(LFrm, e = None):
    LFrm.bind("<Key-Tab>", nullCall)
    return
###################################
# BEGIN: compFsTabOn(LFrm, e = None)
# FUNC:compFsTabOn():2010.225
def compFsTabOn(LFrm, e = None):
    LFrm.unbind("<Key-Tab>")
    return
# END: compFs




####################################
# BEGIN: convertDate(ToFormat, Date)
# LIB:convertDate():2010.195
#   Takes in a Date in the YYYYMMMDD, YYYY:DDD or YYYY-MM-DD format and
#   converts it to the format specified in ToFormat.
#       "YYYYMMMDD" or "YYYY:DDD" or "YYYY-MM-DD"
#   A ToFormat of "yd" = returns the integers YYYY, DDD
#   If it can't figure out what to do with the date it just returns the passed
#   Date as is in (1, Date).
def convertDate(ToFormat, Date):
    Date = Date.strip()
    if len(Date) == 0:
        if ToFormat == "yd":
            return (1, 0, 0)
        else:
            return (1, Date)
# "Must" be YYYY:DDD.
    if Date.find(":") != -1:
        Parts = Date.split(":")
        if len(Parts) == 2:
            try:
                YYYY = int(Parts[0])
                DDD = int(Parts[1])
            except:
                if ToFormat == "yd":
                    return (1, 0, 0)
                else:
                    return (1, Date)
            if YYYY < 1000 or YYYY > 9999:
                if ToFormat == "yd":
                    return (1, 0, 0)
                else:
                    return (1, Date)
            Leap = isLeap(YYYY)
            if DDD < 1 or DDD > 356+Leap:
                if ToFormat == "yd":
                    return (1, 0, 0)
                else:
                    return (1, Date)
            if ToFormat == "yd":
                return (0, YYYY, DDD)
            elif ToFormat == "YYYYMMMDD":
                MM, DD = ydoy2md(YYYY, DDD)
                return (0, "%d%s%02d"%(YYYY, m2MMM(MM), DD))
            elif ToFormat == "YYYY-MM-DD":
                MM, DD = ydoy2md(YYYY, DDD)
                return (0, "%d-%02d-%02d"%(YYYY, MM, DD))
            elif ToFormat == "YYYY:DDD":
                return (0, "%d:%03d"%(YYYY, DDD))
        else:
            if ToFormat == "yd":
                return (1, 0, 0)
            else:
                return (1, Date)
# "Must" be YYYY-MM-DD.
    elif Date.find("-") != -1:
        Parts = Date.split("-")
        if len(Parts) == 3:
            YYYY = intt(Parts[0])
            if YYYY < 1 or YYYY > 9999:
                if ToFormat == "yd":
                    return (1, 0, 0)
                else:
                    return (1, Date)
            MM = intt(Parts[1])
            if MM < 1 or MM > 12:
                if ToFormat == "yd":
                    return (1, 0, 0)
                else:
                    return (1, Date)
            DD = intt(Parts[2])
            if DD < 1 or DD > 31:
                if ToFormat == "yd":
                    return (1, 0, 0)
                else:
                    return (1, Date)
            if ToFormat == "yd":
                return (0, YYYY, ymd2doy(YYYY, MM, DD))
            elif ToFormat == "YYYYMMMDD":
                return (0, "%d%s%02d"%(YYYY, m2MMM(MM), DD))
            elif ToFormat == "YYYY-MM-DD":
                return (0, "%d-%02d-%02d"%(YYYY, MM, DD))
            elif ToFormat == "YYYY:DDD":
                return (0, "%d:%03d"%(YYYY, ymd2doy(YYYY, MM, DD)))
        else:
            if ToFormat == "yd":
                return (1, 0, 0)
            else:
                return (1, Date)
# "Must" be YYYYMMMDD.
    else:
        YYYY = intt(Date)
        if YYYY < 1 or YYYY > 9999:
            if ToFormat == "yd":
                return (1, 0, 0)
            else:
                return (1, Date)
        MMM = Date[4:4+3]
        MM = MMM2m(MMM)
        if MM < 1 or MM > 12:
            if ToFormat == "yd":
                return (1, 0, 0)
            else:
                return (1, Date)
        DD = intt(Date[7:])
        if DD < 1 or DD > 31:
            if ToFormat == "yd":
                return (1, 0, 0)
            else:
                return (1, Date)
        if ToFormat == "yd":
            return (0, YYYY, ymd2doy(YYYY, MM, DD))
        elif ToFormat == "YYYYMMMDD":
            return (0, "%d%s%02d"%(YYYY, m2MMM(MM), DD))
        elif ToFormat == "YYYY-MM-DD":
            return (0, "%d-%02d-%02d"%(YYYY, MM, DD))
        elif ToFormat == "YYYY:DDD":
            return (0, "%d:%03d"%(YYYY, ymd2doy(YYYY, MM, DD)))
    return (1, Date)
# END: convertDate




###########################
# BEGIN: changeDateFormat()
# FUNC:changeDateFormat():2010.246
#   Makes sure that the format of any data in the from/to fields matches the
#   format selected in the Options menu.
def changeDateFormat():
    updateMe(0)
    Format = OPTDateFormatRVar.get()
    for Fld in ("From", "To"):
        eval("%sDateVar"%Fld).set(eval("%sDateVar"%Fld).get().strip().upper())
        if eval("%sDateVar"%Fld).get() != "":
            Ret = convertDate(Format, eval("%sDateVar"%Fld).get())
            if Ret[0] != 0:
                setMsg("MM", "%s field value bad."%Fld, 2)
                return False
            eval("%sDateVar"%Fld).set(Ret[1])
# For the time range form formRTIME.
    for Fld in ("From", "To"):
        eval("RTIME%sVar"%Fld).set(eval("RTIME%sVar"% \
                Fld).get().strip().upper())
        if eval("RTIME%sVar"%Fld).get() != "":
            Ret = convertDate(Format, eval("RTIME%sVar"%Fld).get())
            if Ret[0] != 0:
                setMsg("RTIME", "%s field value bad."%Fld, 2)
                return False
            eval("RTIME%sVar"%Fld).set(Ret[1])
    return True
# END: changeDateFormat




#######################################
# BEGIN: checkForUpdates(Parent = Root)
# LIB:checkForUpdates():2010.250
#   Finds the new|test<prog>.txt file at the URLs and checks to see if the
#   version in those files match the version of this program.
VERS_DLALLOW = True
VERS_VERSURL = "http://www.passcal.nmt.edu/~bob/passoft/"
VERS_VERSURLTEST = "http://www.passcal.nmt.edu/~bob/passofttest/"
VERS_PARTS = 4
VERS_NAME = 0
VERS_VERS = 1
VERS_USIZ = 2
VERS_ZSIZ = 3

def checkForUpdates(Parent = Root):
    if isinstance(Parent, str):
        Parent = Frm[Parent]
# Otherwise the menu doesn't go away on slow connections while url'ing.
    updateMe(0)
# Get the file that tells us about the current version on the server.
# One line:  PROG; version; original size; compressed size
    try:
        Fp = urlopen(VERS_VERSURL+"new"+PROG_NAMELC+".txt")
        Line = readFileLines(Fp)
        Fp.close()
        Line = Line[0]
# If the file doesn't exist you get something like
#     <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
# How unhandy.
        if Line.find("DOCTYPE") != -1:
            raise IOError
    except (IndexError, IOError):
        Line = ""
    try:
        Fp = urlopen(VERS_VERSURLTEST+"test"+PROG_NAMELC+".txt")
        LineTest = readFileLines(Fp)
        Fp.close()
        LineTest = LineTest[0]
        if LineTest.find("DOCTYPE") != -1:
            raise IOError
    except (IndexError, IOError):
        LineTest = ""
# If we didn't get these then there must have been a problem.
    if Line == "" and LineTest == "":
        formMYD(Parent, (("(OK)", TOP, "ok"), ), "ok", "RW", \
                "It's Probably The Net.", \
        "There was an error obtaining the version information from PASSCAL.", \
                "", 2)
        return
    Parts = map(strip, Line.split(";"))
    Parts += (VERS_PARTS-len(Parts))*[""]
    PartsTest = map(strip, LineTest.split(";"))
    PartsTest += (VERS_PARTS-len(PartsTest))*[""]
# Check the test version and just set a flag to control what we will tell the
# user below.
    TestVersion = False
# If the regular copy is older than the test copy let the user know. If they
# are the same then no need. If the regular copy is newer than the test copy
# then Bob isn't working very hard.
    if PROG_VERSION < PartsTest[VERS_VERS] and \
            Parts[VERS_VERS] < PartsTest[VERS_VERS]:
        TestVersion = True
    if PROG_VERSION < Parts[VERS_VERS]:
# Some programs don't need to be professionally installed, some do.
        if VERS_DLALLOW == True:
            if TestVersion == False:
                Answer = formMYD(Parent, (("Download New Version", TOP, \
                        "dlprod"), ("(Don't)", TOP, "dont"), ), "dont", \
                        "YB", "Oh Oh...", \
                        "This is an old version of %s.\nThe current version generally available is %s."% \
                        (PROG_NAME, Parts[VERS_VERS]), "", 2)
            elif TestVersion == True:
                Answer = formMYD(Parent, \
                        (("Download The New Production Version", TOP, \
                        "dlprod"), ("Download The New Test Version", TOP, \
                        "dltest"), ("(Don't Download Anything)", TOP, \
                        "dont")), "dont", "YB", "How Embarrasing...", \
                        "This is an old version of %s.\nThe version everyone else is probably using is %s. However, the really cool people may be running the test version which is version %s."% \
                        (PROG_NAME, Parts[VERS_VERS], PartsTest[VERS_VERS]), \
                        "", 2)
            if Answer == "dont":
                return
            if Answer == "dlprod":
                Ret = checkForUpdatesDownload(Parent, Answer, Parts)
            elif Answer == "dltest":
                Ret = checkForUpdatesDownload(Parent, Answer, PartsTest)
            if Ret == "quit":
                progQuitter(True)
            return
        elif VERS_DLALLOW == False:
            if TestVersion == False:
                Answer = formMYD(Parent, (("(OK)", TOP, "ok"), ), "ok", \
                        "YB", "Tell Someone.", \
                        "This is an old version of %s.\nThe current version generally available is %s."% \
                        (PROG_NAME, Parts[VERS_VERS]), "", 2)
            elif TestVersion == True:
                Answer = formMYD(Parent, (("(OK)", TOP, "ok"), ), "ok", \
                        "YB", "Tell Someone.", \
                        "This is an old version of %s.\nThe current version generally available is %s and there is also a new test version %s."% \
                        (PROG_NAME, Parts[VERS_VERS], PartsTest[VERS_VERS]), \
                        "", 2)
            return
    elif PROG_VERSION == Parts[VERS_VERS]:
        if TestVersion == False:
            Answer = formMYD(Parent, (("Download Anyway", TOP, "dlprod"), \
                    ("(OK)", TOP, "ok")), "ok", "", "Good To Go.", \
                    "This copy of %s is up to date."%PROG_NAME)
        elif TestVersion == True:
            Answer = formMYD(Parent, (("Download Production Anyway", TOP, \
                    "dlprod"), ("Download Test Version", TOP, "dltest"), \
                    ("(OK)", TOP, "ok")), "ok", "", "Good To Go.", \
                    "This copy of %s is up to date, however there is a newer test version of %s."% \
                    (PROG_NAME, PartsTest[VERS_VERS]))
        if Answer == "ok":
            return
        if Answer == "dlprod":
            Ret = checkForUpdatesDownload(Parent, Answer, Parts)
        elif Answer == "dltest":
            Ret = checkForUpdatesDownload(Parent, Answer, PartsTest)
        if Ret == "quit":
            progQuitter(True)
        return
    elif PROG_VERSION > Parts[VERS_VERS]:
# If they aren't allowed to download the file then don't even tell them about
# any new test version.
        if VERS_DLALLOW == False:
            Answer = formMYD(Parent, (("(OK)", TOP, "ok"), ), "ok", "GB", \
                    "All Right!", \
                    "Congratulations! This is a newer version of %s than is generally available. Everyone else probably still has version %s."% \
                    (PROG_NAME, Parts[VERS_VERS]))
        elif VERS_DLALLOW == True:
            if TestVersion == False:
                Answer = formMYD(Parent, (("Download Older Version", TOP, \
                        "dlprod"), ("(OK)", TOP, "ok"), ), "ok", "GB", \
                        "All Right!", \
                        "Congratulations! This is a newer version of %s than is generally available. Everyone else probably still has version %s. You can download and use the older version if you want."% \
                        (PROG_NAME, Parts[VERS_VERS]))
            elif TestVersion == True:
                Answer = formMYD(Parent, \
                        (("I'm Feeling Lucky Download The Test Version", \
                        TOP, "dltest"), \
                        ("Download The Older Production Version", TOP, \
                        "dlprod"), ("(I'll Keep The Version I Have)", TOP, \
                        "keep")), "keep", "GB", "All Right!", \
                        "Congratulations! This is a newer version of %s than is generally available. Everyone else probably still has version %s. However, there is a newer test version than this one at version %s. You can also download and use the older version if you want."% \
                        (PROG_NAME, Parts[VERS_VERS], PartsTest[VERS_VERS]))
        if Answer == "ok" or Answer == "keep":
            return
        if Answer == "dlprod":
            Ret = checkForUpdatesDownload(Parent, Answer, Parts)
        elif Answer == "dltest":
            Ret = checkForUpdatesDownload(Parent, Answer, PartsTest)
        if Ret == "quit":
            progQuitter(True)
        return
    return
######################################################
# BEGIN: checkForUpdatesDownload(Parent, Which, Parts)
# FUNC:checkForUpdatesDownload():2010.250
def checkForUpdatesDownload(Parent, Which, Parts):
    formMYD(Parent, (), "", "CB", "", "Downloading...")
    ZSize = int(Parts[VERS_ZSIZ])
    try:
        if Which == "dlprod":
            GetFile = "new%s.zip"%PROG_NAMELC
            Fpr = urlopen(VERS_VERSURL+GetFile)
        elif Which == "dltest":
            GetFile = "test%s.zip"%PROG_NAMELC
            Fpr = urlopen(VERS_VERSURLTEST+GetFile)
# SetupsDir may not be the best place to put it, but at least it will be
# consistant and not dependent on where the user was working (like it was).
        Fpw = open(PROGSetupsDirVar.get()+GetFile, "wb")
        DLSize = 0
        while 1:
            Buffer = Fpr.read(20000)
            if len(Buffer) == 0:
                break
            Fpw.write(Buffer)
            DLSize += 20000
            formMYDMsg("Downloading (%d%%)...\n"%(100*DLSize/ZSize))
    except Exception, e:
# They may not exist.
        try:
            Fpr.close()
        except:
            pass
        try:
            Fpw.close()
        except:
            pass
        formMYDReturn("")
        formMYD(Parent, (("(OK)", TOP, "ok"), ), "ok", "MW", "Ooops.", \
                "Error downloading new version.\n\n%s"%e, "", 3)
        return ""
    Fpr.close()
    Fpw.close()
    formMYDReturn("")
    if Which == "dlprod":
        Answer = formMYD(Parent, (("Quit %s"%PROG_NAME, TOP, "quit"), \
                ("Don't Quit", TOP, "cont")), "cont", "GB", "Finished?", \
                "The downloaded program file has been saved as\n\n%s\n\nYou should quit %s using the Quit button below, unzip the downloaded file, test the new program file to make sure it is OK, then rename it %s.py and move it to the proper location.\n\nTAKE NOTE OF WHERE THE FILE HAS BEEN DOWNLOADED TO!"% \
                (PROGSetupsDirVar.get()+GetFile, PROG_NAME, PROG_NAMELC))
    elif Which == "dltest":
        Answer = formMYD(Parent, (("Quit %s"%PROG_NAME, TOP, "quit"), \
                ("Don't Quit", TOP, "cont")), "cont", "GB", "Finished?", \
                "The downloaded test version file has been saved as\n\n%s\n\nYou should quit %s using the Quit button below, unzip the downloaded file, test the new program file to make sure it is OK, then rename it to the proper name and move it to the proper location if you feel lucky. I'd keep a copy of the old version if I were you.\n\nTAKE NOTE OF WHERE THE FILE HAS BEEN DOWNLOADED TO!"% \
                (PROGSetupsDirVar.get()+GetFile, PROG_NAME))
    if Answer == "quit":
        return "quit"
    return ""
# END: checkForUpdates




#################################
# BEGIN: closeForm(Who, e = None)
# LIB:closeForm():2010.204
#   Handles closing a form.
def closeForm(Who, e = None):
# In case it is a "busy" form that takes a long time to close.
    updateMe(0)
# The form may not exist or Frm[Who] may be pointing to a "lost" form, so try.
    try:
        if Frm[Who] == None:
            return
        Frm[Who].destroy()
    except:
        pass
    try:
        Frm[Who] = None
    except:
        pass
    return
###############################
# BEGIN: closeFormAll(e = None)
# FUNC:closeFormAll():2010.255
#   Goes through all of the forms and shuts them down.
def closeFormAll(e = None):
    for Frmm in Frm.keys():
# Try to call a formXControl() function. Some may have them and some may not.
        try:
            Ret = eval("form%sControl"%Frmm)("close")
# Simple forms that may just still have stuff running return 1 and a message.
# More complex forms may take care of everything themselves and return 2.
            if Ret[0] == 1:
                showUp(Frmm)
                formMYD(Frmm, (("(OK)", TOP, "ok"), ), "ok", Ret[1], "Oops!", \
                        Ret[2])
                break
            elif Ret[0] == 2:
                break
        except:
            closeForm(Frmm)
    return
# END: closeForm




######################
# BEGIN: class Command
# LIB:Command():2006.112
#   Pass arguments to functions from button presses and menu selections! Nice!
#   In your declaration:  ...command = Command(func, args,...)
#   Also use in bind() statements
#       x.bind("<****>", Command(func, args...))
class Command:
    def __init__(self, func, *args, **kw):
        self.func = func
        self.args = args
        self.kw = kw
    def __call__(self, *args, **kw):
        args = self.args+args
        kw.update(self.kw)
        apply(self.func, args, kw)
# END: Command




##############################################################
# BEGIN: dateTimeMath(DeltaDD, DeltaSS, YYYY, DDD, HH, MM, SS)
# LIB:dateTimeMath():2009.102
#   Adds or subtracts (depending on the sign of DeltaDD/DeltaSS) the requested
#   amount of time to/from the passed date.  Returns a tuple with the results:
#           (YYYY, DDD, HH, MM, SS)
#   Only does whole days or seconds.
def dateTimeMath(DeltaDD, DeltaSS, YYYY, DDD, HH, MM, SS):
    DeltaDD = int(DeltaDD)
    DeltaSS = int(DeltaSS)
    if DeltaDD != 0:
        if DeltaDD > 0:
            Forward = 1
        else:
            Forward = 0
        while 1:
# Speed limit the change to keep things simpler.
            if DeltaDD < -365 or DeltaDD > 365:
                if Forward == 1:
                    DDD += 365
                    DeltaDD -= 365
                else:
                    DDD -= 365
                    DeltaDD += 365
            else:
                DDD += DeltaDD
                DeltaDD = 0
            Leap = isLeap(YYYY)
            if DDD < 1 or DDD > 365+Leap:
                if Forward == 1:
                    DDD -= 365+Leap
                    YYYY += 1
                else:
                    YYYY -= 1
                    Leap = isLeap(YYYY)
                    DDD += 365+Leap
            if DeltaDD == 0:
                break
    if DeltaSS != 0:
        if DeltaSS > 0:
            Forward = 1
        else:
            Forward = 0
        while 1:
# Again, just to keep the code reasonable.
            if DeltaSS < -59 or DeltaSS > 59:
                if Forward == 1:
                    SS += 59
                    DeltaSS -= 59
                else:
                    SS -= 59
                    DeltaSS += 59
            else:
                SS += DeltaSS
                DeltaSS = 0
            if SS < 0 or SS > 59:
                if Forward == 1:
                    SS -= 60
                    MM += 1
                    if MM > 59:
                        MM = 0
                        HH += 1
                        if HH > 23:
                            HH = 0
                            DDD += 1
                            if DDD > 365:
                                Leap = isLeap(YYYY)
                                if DDD > 365+Leap:
                                    YYYY += 1
                                    DDD = 1
                else:
                    SS += 60
                    MM -= 1
                    if MM < 0:
                        MM = 59
                        HH -= 1
                        if HH < 0:
                            HH = 23
                            DDD -= 1
                            if DDD < 1:
                                YYYY -= 1
                                if isLeap(YYYY) == 1:
                                    DDD = 366
                                else:
                                    DDD = 365
            if DeltaSS == 0:
                 break
    return (YYYY, DDD, HH, MM, SS)
# END: dateTimeMath




#########################
# BEGIN: dhms2DHMS(InStr)
# LIB:dhms2DHMS():2008.283
def dhms2DHMS(InStr):
    Len = len(InStr)
    InStr = InStr.strip()
    if InStr == "":
        return "00:00:00:00"
    if Len == 6:
        return "%s:%s:%s"%(InStr[:2], InStr[2:4], InStr[4:6])
    else:
        return "%s:%s:%s:%s"%(InStr[:2], InStr[2:4], InStr[4:6], InStr[6:8])
# END: dhms2DHMS




###################
# BEGIN: eatBATMP()
# FUNC:eatBATMP():2010.310
def eatBATMP():
    global TheYear
    global TheLastDOY
    global TimeMax
    global InParts
# 72A's:
# Ex: 186:14:33:58 BATTERY VOLTAGE = 13.6V, TEMPERATURE = 26C
# RT130:
# Ex: 186:14:33:58 BATTERY VOLTAGE = 13.6V, TEMPERATURE = 26C, BACKUP = 3.3V
    InParts = InLine.split()
    ThisDOY = InIntt()
    if ThisDOY == 1 and (TheLastDOY == 365 or TheLastDOY == 366):
        TheYear += 1
    TheLastDOY = ThisDOY
    Time = str2Epoch(TheYear, InParts[0])
    if Time > TimeMax:
        TimeMax = Time
    Volts = floatt(InParts[4])
    Temp = floatt(InParts[7])
    if RTModel == "RT130":
        BkupV = floatt(InParts[10])
    else:
        BkupV = 0.0
    return (Time, Volts, Temp, BkupV)
# END: eatBATMP




##################
# BEGIN: eatCPUV()
# FUNC:eatCPUV():2011.080
def eatCPUV():
    global TheCPUVers
    global InParts
# The version line changes every week, so if there is no . in what we have
# then we must not have the right thing.
# Possiblities so far:
#    341:22:05:41 CPU SOFTWARE V03.00H  (72A and older 130 FW)
#    341:22:05:41 REF TEK 130  (no version number at all)
#    341:22:05:41 Ref Tek 130  2.8.8S (2007:163)
#    341:22:05:41 CPU SOFTWARE V 3.0.0 (2009:152)
    if TheCPUVers.find(".") == -1:
        InParts = InLine.split()
        if InParts[1].startswith("CPU"):
            TheCPUVers = " ".join(InParts[3:])
        elif InParts[1].startswith("R"):
# There may not be any version info in this line (REF TEK 130...then nothing)
# but accessing non-existant InParts doesn't matter. TheCPUVers will just be
# "".
            TheCPUVers = " ".join(InParts[4:])
    return
# END: eatCPUV




####################
# BEGIN: eatDCDIFF()
# FUNC:eatDCDIFF():2008.360
def eatDCDIFF():
    global TheYear
    global TheLastDOY
    global TimeMax
    global InParts
# Ex: 245:07:41:45 DSP CLOCK DIFFERENCE: 0 SECS AND -989 MSECS
    InParts = InLine.split()
    ThisDOY = InIntt()
    if ThisDOY == 1 and (TheLastDOY == 365 or TheLastDOY == 366):
        TheYear += 1
    TheLastDOY = ThisDOY
    Time = str2Epoch(TheYear, InParts[0])
    if Time > TimeMax:
        TimeMax = Time
    Secs = floatt(InParts[4])
    MSecs = floatt(InParts[-2])
    Total = abs(Secs)*1000.0+abs(MSecs)
    if Secs < 0.0 or MSecs < 0.0:
        Total *= -1.0
    return (Time, Total)
# END: eatDCDIFF




##################
# BEGIN: eatDEFS()
# FUNC:eatDEFS():2008.360
def eatDEFS():
    global InParts
# Ex: Station Channel Definition   01:330:19:24:42:978    ST: 7095
# Ex: Data Stream Definition   01:330:19:24:42:978    ST: 7095
# Ex: Calibration Definition   01:330:19:24:42:978    ST: 7095
    InParts = InLine.split()
    if InParts[0] == "STATION":
        Year = intt(InParts[3])
        DateTime = InParts[3][3:]
    elif InParts[0] == "DATA":
        Year = intt(InParts[3])
        DateTime = InParts[3][3:]
    elif InParts[0] == "CALIBRATION":
        Year = intt(InParts[2])
        DateTime = InParts[2][3:]
    else:
        print "eatDEFS error"
        return
    if Year < 70:
        Year += 2000
    else:
        Year += 1900
    Time = str2Epoch(Year, DateTime);
# These will not be allowed to set TimeMin since the RT130's save multiple
# copies of the parameters in the log files (one per day), but they all have
# the date/timestamp of the first time the parameters were written (unless
# a new copy is written because the parameters were changed, of course).
    return Time
# END: eatDEFS




#################
# BEGIN: eatEVT()
# FUNC:eatEVT():2008.325
def eatEVT():
    global TimeMin
    global TimeMax
    global InParts
    InParts = InLine.split()
# Ex: DAS: 0108 EV: 2632 DS: 2 FST = 2001:253:15:13:59:768 TT = 2001:253:15:13:59:768 NS: 144005 SPS: 40 ETO: 0
# Use the Trigger Time (TT = ).
    Time = str2Epoch(None, InParts[11]);
# If the TT time is something like 0000:000:00:00:00:000, which some program
# generated for the TT time when an event ended badly, then str2Epoch will
# return a bad value. Too bad for the user if an event actually triggers at
# 1970:001:00:00:00, because that one will be missed.
    if Time > 0:
        if Time < TimeMin:
            TimeMin = Time
        if Time > TimeMax:
            TimeMax = Time
# Last item is data stream.
    return (Time, intt(InParts[5]))
# END: eatEVT




##################
# BEGIN: eatGPOS()
# FUNC:eatGPOS():2008.361
def eatGPOS():
    global InParts
# Ex: 253:22:41:25 GPS: POSITION: N43:44:17.12 W096:37:25.27 +00456M
    InParts = InLine.split()
# Lat, Long, Elev.
    return (str2Dddd(InParts[3]), str2Dddd(InParts[4]), floatt(InParts[5]))
# END: eatGPOS




##################
# BEGIN: eatGPSV()
# FUNC:eatGPSV():2008.360
def eatGPSV():
    global TheGPSvers
    global InParts
# Ex: 159:15:41:05 GPS: V03.30    (17JAN2000)
    if TheGPSvers == "":
        InParts = InLine.split()
        TheGPSvers = (InParts[2]+" "+InParts[3]).strip()
    return
# END: eatGPSV




##################
# BEGIN: eatICPE()
# FUNC:eatICPE():2008.361
def eatICPE():
    global TheYear
    global TheLastDOY
    global TimeMax
    global InParts
# Ex: 253:19:41:42 INTERNAL CLOCK PHASE ERROR OF 4823 USECONDS
    InParts = InLine.split()
# Compare ThisDOY with LastDOY.  If LastDOY was 365 or 366 and this one is
# 1 then we must be processing lines from the SOH packet that midnight occured
# in the middle of.  It MUST be the next year, right??
    ThisDOY = InIntt()
    if ThisDOY == 1 and (TheLastDOY == 365 or TheLastDOY == 366):
        TheYear += 1
    TheLastDOY = ThisDOY
    Time = str2Epoch(TheYear, InParts[0])
    if Time > TimeMax:
        TimeMax = Time
# We always want to return the error in milliseconds.
    Error = floatt(InParts[-2])
    if InParts[-1].startswith("USEC"):
        Error /= 1000.0
    elif InParts[-1].startswith("SEC"):
        Error *= 1000.0
    return (Time, Error)
# END: eatICPE




####################
# BEGIN: eatSIMPLE()
# FUNC:eatSIMPLE():2008.361
def eatSIMPLE():
    global TheYear
    global TheLastDOY
    global TimeMax
# Ex: 186:20:46:41 EXTERNAL CLOCK IS UNLOCKED
# Ex: 186:21:41:35 EXTERNAL CLOCK IS LOCKED
    ThisDOY = InIntt()
    if ThisDOY == 1 and (TheLastDOY == 365 or TheLastDOY == 366):
        TheYear += 1
    TheLastDOY = ThisDOY
# The second item is the DateTime.
    Time = str2Epoch(TheYear, InLine.split(" ", 1)[0])
    if Time > TimeMax:
        TimeMax = Time
    return Time
# END: eatSIMPLE




#################
# BEGIN: eatSOH()
# FUNC:eatSOH():2010.172
#   The SOH time can be either
#       YYYY:DDD:HH:MM:SS(plus .TTT or :TTT) or
#       YY:DDD:HH:MM:SS(plus .TTT or :TTT)
def eatSOH():
    global TheYear
    global TheLastDOY
    global TimeMin
    global TimeMax
    global TheUnitID
    global InParts
# Ex: State of Health  01:251:09:41:35:656   ST: 0108
    InParts = InLine.split()
# InParts[3] == DateTime
# Set TheYear to this lines year since it is the only place where we can get
# it from.
    TheYear = intt(InParts[3])
    if TheYear < 100:
        if TheYear < 70:
            TheYear += 2000
        else:
            TheYear += 1900
# These log lines set TheYear (above) and TheLastDOY, because we "trust" them.
        TheLastDOY = intt(InParts[3][3:])
        Time = str2Epoch(TheYear, InParts[3][3:])
    else:
        TheLastDOY = intt(InParts[3][5:])
        Time = str2Epoch(None, InParts[3])
# The start time of the file will be set by the earliest SOH message.
    if Time < TimeMin:
        TimeMin = Time
    if Time > TimeMax:
        TimeMax = Time
    if TheUnitID == "":
        TheUnitID = InParts[5].strip()
    return Time
# END: eatSOH




###################
# BEGIN: eatTMJMP()
# FUNC:eatTMJMP():2008.361
def eatTMJMP():
    global InParts
# Ex: Time jump: R182.01/06.182.00.46.02.9139.1 obs 00:57:22.800  corr +2680 ms
    InParts = InLine.split()
# Get the start time of the block with the jump.
    Starts = InParts[2].split("/")
# An older version of ref2mseed made lines like:
#    Time jump: DAS9065/R182.01/06.182.00.46.02.9139.1... so watch for it.
    if len(Starts) == 2:
        Start = Starts[1].split(".")
    else:
        Start = Starts[2].split(".")
# Year.
    YYYY = int(Start[0])
    if YYYY < 70:
        YYYY += 2000
    else:
        YYYY += 1900
    DDD = int(Start[1])
# Since the time of the jump doesn't have any idea of year/doy we'll just
# assume that the year and doy are the same as the event start time.  This,
# of course will possibly be wrong 1/24th and 1/365th of the time.
    Time = str2Epoch(None, "%d:%03d:%02d:%02d:%02d"%(YYYY, DDD, \
            int(Start[2]), int(Start[3]), int(Start[4])))
# Now get the time the jump was observed.
    Obed = InParts[4].split(":")
    OTime = str2Epoch(None, "%d:%03d:%02d:%02d:%02d"% \
            (YYYY, DDD, int(Obed[0]), int(Obed[1]), float(Obed[2])))
# OTime+"Jsec".
    JTime = OTime+float(InParts[6])/1000.0
# the last item is channel number.
    return (OTime, JTime, int(Start[6]))
# END: eatTMJMP




#########################
# BEGIN: epoch2Str(Epoch, Ret = "s")
# LIB:epoch2Str():2010.248
def epoch2Str(Epoch, Ret = "s"):
    YYYY = 1970
    while 1:
        if YYYY%4 != 0:
            if Epoch >= 31536000:
                Epoch -= 31536000
            else:
                break
        elif YYYY%100 != 0 or YYYY%400 == 0:
            if Epoch >= 31622400:
                Epoch -= 31622400
            else:
                break
        else:
            if Epoch >= 31536000:
                Epoch -= 31536000
            else:
                break
        YYYY += 1
    DDD = 1
    while Epoch >= 86400:
        Epoch -= 86400
        DDD += 1
    HH = 0
    while Epoch >= 3600:
        Epoch -= 3600
        HH += 1
    MM = 0
    while Epoch >= 60:
        Epoch -= 60
        MM += 1
    if Ret == "s":
        return "%d:%03d:%02d:%02d:%02d"%(YYYY, DDD, HH, MM, Epoch)
    elif Ret == "y":
        return YYYY, DDD, HH, MM, Epoch
# END: epoch2Str




########################
# BEGIN: exportTT(Which)
# FUNC:exportTT():2011.081
#   Goes through the currenty loaded log messages and extracts the event
#   trigger times from the ET lines and exports them to a selected file in the
#   Which format:
#   Which = "tsp" = UTEP's TSP shot file format
#   Which = "depl" = RAWMEET's deployment file line format
#   Which = "depb" = RAWMEET's deployment file block format -- key/value pairs
#   Which = "ymdhms":
#      YYYY:DDD:HH:MM:SS.sss
#   All data streams are extracted and listed separately.
ExportTTFilespecVar = StringVar()
PROGSetups += ("ExportTTFilespecVar", )

def exportTT(Which):
    if len(LOGLines) == 0:
        setMsg("MF", "RW", "No SOH lines have been loaded.", 2)
        return
    Datas = []
    for Line in LOGLines:
        if Line.startswith("DAS: "):
            Parts = Line.split()
            Datas.append([Parts[5], Parts[3], Parts[11]])
    if len(Datas) == 0:
        setMsg("MF", "RW", "No event trigger times found in SOH messages.", \
                2)
        return
    if ExportTTFilespecVar.get() == "" or \
            exists(dirname(ExportTTFilespecVar.get())) == False:
        ExportTTFilespecVar.set(PROGDataDirVar.get()+"events.dat")
    Filespec = formMYDF(Root, 0, "Pick Or Enter An Output File", \
            dirname(ExportTTFilespecVar.get()), \
            basename(ExportTTFilespecVar.get()))
    if Filespec == "":
        setMsg("MF", "", "Nothing done.")
        return
    try:
        Fp = open(Filespec, "w")
    except Exception, e:
        setMsg("MF", "MW", "Error opening file %s\n   %e"%(Filespec, e), 3)
        return
    Datas.sort()
    CurrDS = 0
    LineCount = 0
# Data = [DS, Event, TT]
    for Data in Datas:
        if Data[0] != CurrDS:
            if CurrDS != 0:
                Fp.write("\n")
            Fp.write("# Events from data stream %s\n"%Data[0])
            CurrDS = Data[0]
        Parts = Data[2].split(":")
        Parts += (6-len(Parts))*["???"]
        if Which == "depl":
            Fp.write("SHOT;_STA_;<ARRY>;_ID_;<LATI>;<LONG>;<ELEV>;%s:%s:%s:%s:%s.%s;<PRET>;<POST>;<RADI>;<SAMP>;<DPTH>;<SIZE>;<RVEL>;<COMM>;LOGPEEK  # Evt %s\n"% \
                    (Parts[0], Parts[1], Parts[2], Parts[3], Parts[4], \
                    Parts[5], Data[1]))
        elif Which == "depb":
# We only know two things, so that's all we have to put in a block format.
            Fp.write("SHOT\n")
            Fp.write("   TIME=%s:%s:%s:%s:%s.%s\n"%(Parts[0], Parts[1], \
                    Parts[2], Parts[3], Parts[4], Parts[5]))
            Fp.write("   SOUR=LOGPEEK # Evt %s\n"%Data[1])
        elif Which == "tsp":
            Fp.write("%s, %s, %s, %s, %s.%s, _ID_, _LEN_, 0  # Evt %s\n"% \
                    (Parts[0], Parts[1], Parts[2], Parts[3], Parts[4], \
                    Parts[5], Data[1]))
        elif Which == "ydhms":
            Fp.write("%s:%s:%s:%s:%s.%s  # Evt %s\n"%(Parts[0], Parts[1], \
                    Parts[2], Parts[3], Parts[4], Parts[5], Data[1]))
        LineCount += 1
    Fp.close()
    ExportTTFilespecVar.set(Filespec)
    if LineCount == 1:
        setMsg("MF", "", "1 line written to\n   %s"%Filespec)
    else:
        setMsg("MF", "", "%d lines written to\n   %s"%(LineCount, Filespec))
    return
# END: exportTT




###############################
# BEGIN: fileSelected(e = None)
# FUNC:fileSelected():2011.080
#   Does the job of reading and digesting the selected file(s) or directory.
Frm["LOG"] = None
Txt["LOG"] = None
LOGFindLookForVar = StringVar()
LOGFindLastLookForVar = StringVar()
LOGFindLinesVar = StringVar()
LOGFindIndexVar = IntVar()
PROGSetups += ("LOGFindLookForVar", )
Frm["ERR"] = None
Txt["ERR"] = None
Frm["RAW"] = None
Frm["TPS"] = None
# Can["MF"] gets defined when the program starts, but these don't until the
# raw data displays come up.
Can["RAW"] = None
Can["TPS"] = None
LOGLines = []
RawData = {}

def fileSelected(e = None):
    global LOGLines
    global ACQ
    global ACQxy
    global NET
    global NETxy
    global DUMP
    global DUMPxy
    global TEMP
    global TEMPxy
    global VOLT
    global VOLTxy
    global BKUP
    global BKUPxy
    global MP1
    global MP1xy
    global MP2
    global MP2xy
    global MP3
    global MP3xy
    global MP4
    global MP4xy
    global MP5
    global MP5xy
    global MP6
    global MP6xy
    global DCDIFF
    global DCDIFFxy
    global RESET
    global RESETxy
    global GPSLK
    global GPSLKxy
    global TMJMP
    global TMJMPxy
    global EVT
    global EVTxy
    global GPS
    global GPSxy
    global GPOSd
    global GPOSr
    global GPOSe
    global ICPE
    global ICPExy
    global JERK
    global JERKxy
    global DRSETxy
    global PWRUP
    global PWRUPxy
    global CLKPWR
    global CLKPWRxy
    global DEFS
    global DEFSxy
    global MRC
    global MRCxy
    global SOH
    global SOHxy
    global DISCREP
    global DISCREPxy
    global ERROR
    global ERRORxy
    global WARN
    global WARNxy
    global FStart
    global FEnd
    global CurMainStart
    global CurMainEnd
    global RTModel
    global MainFilename
    global MainFilespec
    global TimeMin
    global TimeMax
    global TheUnitID
    global TheCPUVers
    global TheGPSvers
    global TheLastDOY
    global TheYear
    global InLine
    global TheEarliestDate
    global TheLatestDate
    global StartEndRecord
# Clear the screen off and sets things up for plotting.
    plotMFClear("all")
    plotRAWClear()
    plotTPSClear()
# Get rid of any data from a previous raw data file reading.
    RawData.clear()
# Get the file from the Listbox or from the command line.
    if CLAFile == "":
# Always check the directory entry.
        PROGDataDirVar.set(PROGDataDirVar.get().strip())
        if PROGDataDirVar.get().endswith(sep) == False:
            PROGDataDirVar.set(PROGDataDirVar.get()+sep)
# Just a good place to always keep these in sync.
        PROGMsgsDirVar.set(PROGDataDirVar.get())
        PROGWorkDirVar.set(PROGDataDirVar.get())
# Indexes will always be 1 number if PROGMultiMode if False, or 1 or more if
# it is True.
        try:
            Indexes = MFFiles.curselection()
            Selected = []
            for I in Indexes:
                File = MFFiles.get(I)
                if File == "":
                    continue
# The entry will probably be something like "Filename (x bytes or lines)" so
# just get the Filename.
                Parts = File.split()
                Selected.append(Parts[0])
            if len(Selected) == 0:
                setMsg("MF", "RW", "You need to select a file name.", 2)
                return
        except TclError, e:
            beep(1)
            return
    else:
        Selected = [basename(CLAFile)]
# Take whatever the basename of the first file is, add .ps to it and set it as
# the default .ps file name.
    LastMFPSFilespecVar.set(PROGDataDirVar.get()+basename(Selected[0])+ \
            "-main.ps")
    LastRAWPSFilespecVar.set(PROGDataDirVar.get()+basename(Selected[0])+ \
            "-raw.ps")
    LastTPSPSFilespecVar.set(PROGDataDirVar.get()+basename(Selected[0])+ \
            "-tps.ps")
# See if the user wants to restrict the time range.
    FromDateVar.set(FromDateVar.get().strip())
    ToDateVar.set(ToDateVar.get().strip())
# The defaults.
    FromDate = 0
    ToDate = maxint
    if FromDateVar.get() == "" and ToDateVar.get() == "":
        UseDates = False
    else:
        for F in ("From", "To"):
            if eval("%sDateVar"%F).get() != "":
                Ret = convertDate("yd", eval("%sDateVar"%F).get())
                if Ret[0] != 0:
                    setMsg("MM", "RW", "%s field value bad."%F, 2)
                    return
                if F == "From":
# From 00:00.
                    FromDate = ydhms2Epoch(int(Ret[1]), int(Ret[2]), 0, 0, 0)
                elif F == "To":
# To 00:00 the following day (then > and < will be used in the comparisons).
# ydhms2Epoch() won't mind just adding the 1 day even if DDD is the last day
# of the year.
                    ToDate = ydhms2Epoch(int(Ret[1]), int(Ret[2])+1, 0, 0, 0)
                UseDates = True
# Get the rest of these setup items.
    IncNonSOH = OPTIncNonSOHCVar.get()
# Tells the extractors if the mass positions need to be processed.
    IncDS9 = 0
    if DGrf["MP123"].get() == 1 or DGrf["MP456"].get() == 1:
        IncDS9 = 1
# If the user intends to plot the raw data get a List of the data streams
# selected.
    DSs = []
    for i in xrange(1, 1+PROG_DSS):
        if eval("Stream%dVar"%i).get() == 1:
           DSs.append(i)
# If they are going to spend all that time reading through the raw data then
# shouldn't they want to plot it?
    if IncNonSOH == 1 and (len(DSs) > 0 or IncDS9 == 1) and  \
            OPTPlotRAWCVar.get() == 0 and OPTPlotTPSCVar.get() == 0:
        Answer = formMYD(Root, (("You're Right. Stop.", TOP, "stop"), \
                ("Continue Anyway", TOP, "cont")), "stop", "YB", "Really?", 
                "You have the Include Non-SOH items checkbutton selected and some of the Mass Position and/or DS checkbuttons selected, but you have neither the RAW nor the TPS checkbutton selected. That's a bit of a waste of time reading raw data then not plotting it.")
        if Answer == "stop":
            setMsg("MF", "", "Nothing done.")
            return
# A couple more checks.
    if IncNonSOH == 1 and len(DSs) == 0 and OPTPlotRAWCVar.get() == 1:
        Answer = formMYD(Root, (("You're Right. Stop.", TOP, "stop"), \
                ("Continue Anyway", TOP, "cont")), "stop", "YB", "Really?", 
                "You have the RAW display checkbutton selected, but no DS checkbuttons selected. Not much raw data will get plotted that way.")
        if Answer == "stop":
            setMsg("MF", "", "Nothing done.")
            return
    if IncNonSOH == 1 and len(DSs) == 0 and OPTPlotTPSCVar.get() == 1:
        Answer = formMYD(Root, (("You're Right. Stop.", TOP, "stop"), \
                ("Continue Anyway", TOP, "cont")), "stop", "YB", "Really?", 
                "You have the TPS display checkbutton selected, but no DS checkbuttons selected. Not much raw data will get plotted that way.")
        if Answer == "stop":
            setMsg("MF", "", "Nothing done.")
            return
# Ready to roll.
    progControl("go")
    setMsg("MF", "CB", "Working...")
# Create the window that will contain all of the lines of the file.
    if Frm["LOG"] == None:
        LFrm = Frm["LOG"] = Toplevel(Root)
        LFrm.withdraw()
        LFrm.protocol("WM_DELETE_WINDOW", Command(beep, 1))
        Sub = Frame(LFrm)
# Since the log lines do not need to be a fixed-width font then just make the
# font the Msg font.
        LTxt = Txt["LOG"] = Text(Sub, bg = Clr["B"], cursor = "", \
                fg = Clr["W"], font = PROGMsgFont, height = 30, width = 90, \
                relief = SUNKEN, wrap = NONE)
        LTxt.pack(side = LEFT, expand = YES, fill = BOTH)
        LSb = Scrollbar(Sub, orient = VERTICAL, command = LTxt.yview)
        LSb.pack(side = RIGHT, fill = Y)
        LTxt.configure(yscrollcommand = LSb.set)
        Sub.pack(side = TOP, expand = YES, fill = BOTH)
        Sub = Frame(LFrm)
        labelTip(Sub, "Find:=", LEFT, 30, "[Find]")
        LEnt = Entry(Sub, width = 20, textvariable = LOGFindLookForVar)
        LEnt.pack(side = LEFT)
        LEnt.bind("<Double-Button-1>", Command(formKB, "LOG", "Find", \
                LOGFindLookForVar))
        LEnt.bind("<Return>", Command(formFind, "LOG", "LOG"))
        LEnt.bind("<KP_Enter>", Command(formFind, "LOG", "LOG"))
        BButton(Sub, text = "Find", command = Command(formFind, "LOG", \
                "LOG")).pack(side = LEFT)
        BButton(Sub, text = "Next", command = Command(formFindNext, \
                "LOG", "LOG")).pack(side = LEFT)
        Label(Sub, text = " ").pack(side = LEFT)
        BButton(Sub, text = "Write To File...", command = Command(formWrite, \
                "LOG", "LOG", "LOG", "Pick Or Enter An Output File...", \
                LOGLastFilespecVar, True)).pack(side = TOP)
        Sub.pack(side = TOP, padx = 3, pady = 3)
        Msg["LOG"] = Text(LFrm, cursor = "", font = PROGMsgFont, height = 3, \
                wrap = WORD)
        Msg["LOG"].pack(side = TOP, fill = X)
        center(Root, "LOG", "NW", "O", False)
    else:
        LFrm = Frm["LOG"]
# All of the "good" lines will be .insert()'ed, garbled lines will be
# txLn()'ed in red, and 'skipped' lines will be txLn()'ed in yellow.
        LTxt = Txt["LOG"]
    LFrm.title("SOH Messages")
    del LOGLines[:]
# Where the data for the lines of interest will be kept.
    del ACQ[:]
    del ACQxy[:]
    del BKUP[:]
    del BKUPxy[:]
    del CLKPWR[:]
    del CLKPWRxy[:]
    del DEFS[:]
    del DEFSxy[:]
    del DCDIFF[:]
    del DCDIFFxy[:]
    del DISCREP[:]
    del DISCREPxy[:]
    del DUMP[:]
    del DUMPxy[:]
    del ERROR[:]
    del ERRORxy[:]
    del EVT[:]
    del EVTxy[:]
    del GPOSd[:]
    del GPOSr[:]
    del GPOSe[:]
    del GPS[:]
    del GPSxy[:]
    del GPSLK[:]
    del GPSLKxy[:]
    del ICPE[:]
    del ICPExy[:]
    del JERK[:]
    del JERKxy[:]
    del MP1[:]
    del MP1xy[:]
    del MP2[:]
    del MP2xy[:]
    del MP3[:]
    del MP3xy[:]
    del MP4[:]
    del MP4xy[:]
    del MP5[:]
    del MP5xy[:]
    del MP6[:]
    del MP6xy[:]
    del MRC[:]
    del MRCxy[:]
    del NET[:]
    del NETxy[:]
    del PWRUP[:]
    del PWRUPxy[:]
    del RESET[:]
    del RESETxy[:]
    del SOH[:]
    del SOHxy[:]
    del TEMP[:]
    del TEMPxy[:]
    del TMJMP[:]
    del TMJMPxy[:]
    del VOLT[:]
    del VOLTxy[:]
    del WARN[:]
    del WARNxy[:]
# ===== MAIN LOOP =====
# Now that everything is ready to go start looping through the files.
    for MainFilename in Selected:
        LogFile = False
        MainFilenameLC = MainFilename.lower()
# Build the long source file name.
        MainFilespec = "%s%s"%(PROGDataDirVar.get(), MainFilename)
# Get all of the SOH lines into LOGLines no matter what the source.
# ---- .log source ----
        if MainFilenameLC.endswith(".log"):
            try:
                setMsg("MF", "CB", "Reading "+MainFilespec+"...")
                Fp = open(MainFilespec, "rb")
                LOGLinesOrig = readFileLines(Fp)
                Fp.close()
# Verify that the file lines look a bit like what we are expecting, and then
# strip off the Antelope junk and then continue.
                if OPTQLogCVar.get() == 1:
                    setMsg("MF", "CB", "Checking qlog file information...")
                    FoundSOH = False
                    if len(LOGLinesOrig) > 1000:
                        MaxLines = 1000
                    else:
                        MaxLines = len(LOGLinesOrig)
# If there are none of these I can't use the file (no matter where it came
# from).
                    for Index in xrange(0, MaxLines):
                        if LOGLinesOrig[Index].startswith("State of Health") != -1:
                            FoundSOH = True
                            break
                    if FoundSOH == False:
                        setMsg("MF", "YB", \
                                "No 'State of Health' message lines found.", 2)
                        setInfoMsg("See status message.")
                        progControl("stopped")
                        return
# Now check to see if the SOH timestamp is in the correct place. I think there
# is a difference between real time SOH messages (which will probably fail the
# test above) and sucked-into-antelope ref2mseed log files.
                    FoundTS = False
                    for Index in xrange(0, MaxLines):
                        Parts = LOGLinesOrig[Index].split()
                        if len(Parts) > 5:
                            if rtnPattern(Parts[5]) == "000:00:00:00":
# Get the starting point of the timestamp since the stuff Antelope adds may
# vary in length.
                                FoundTSIndex = \
                                        LOGLinesOrig[Index].index(Parts[5])
                                FoundTS = True
                                break
                    if FoundTS == False:
                        setMsg("MF", "MW", \
                                "Could not find SOH timestamp in 6th word of SOH messages. Is Options|Read qlog-ref2mseed Output Files selected when it shouldn't be?", \
                                3)
                        setInfoMsg("See status message.")
                        progControl("stopped")
                        return
                    for Line in LOGLinesOrig:
                        LOGLines += Line[FoundTSIndex:],
                else:
                    for Line in LOGLinesOrig:
                        LOGLines += Line,
            except Exception, e:
                setMsg("MF", "MW", e, 3)
                setInfoMsg("See status message.")
                progControl("stopped")
                return
            LogFile = True
# ---- .ref source ----
        elif MainFilenameLC.endswith(".ref"):
            Ret = rt72130ExtractRefData(PROGDataDirVar.get(), MainFilename, \
                    "", PROGStopBut, PROGRunning, "MF", IncNonSOH, DSs, \
                    IncDS9, FromDate, ToDate)
            if Ret[0] != 0:
                setMsg("MF", Ret[1], Ret[2], Ret[3])
                setInfoMsg("See status message.")
                progControl("stopped")
                return
            LOGLines.append("%s:  Version Number  %s  File: %s"%(PROG_NAMELC, \
                    PROG_VERSION, MainFilename))
            LOGLines += Ret[1]
# ---- .zip source ----
# Look for these before the .cf files since the .find(".cf") will go off if
# the file is really a .cf.zip file.
        elif MainFilenameLC.endswith(".zip"):
            Ret = rt130ExtractZCFData(PROGDataDirVar.get(), MainFilename, \
                    PROGStopBut, PROGRunning, "MF", IncNonSOH, DSs, IncDS9, \
                    FromDate, ToDate)
            if Ret[0] != 0:
                setMsg("MF", Ret[1], Ret[2], Ret[3])
                setInfoMsg("See status message.")
                progControl("stopped")
                return
            LOGLines.append("%s:  Version Number  %s  File: %s"%(PROG_NAMELC, \
                    PROG_VERSION, MainFilename))
            LOGLines += Ret[1]
# ---- Unzipped CFC source ----
        elif MainFilenameLC.find(".cf") != -1:
# The MainFilename will be Cf.cf/DAS, so split those and build the right things
# to pass. More than one DAS will be allowed in each .cf directory, but only
# the one selected by the user will be handled.
            Dir = PROGDataDirVar.get()+MainFilename.split(sep)[0]+sep
            try:
                DAS = MainFilename.split(sep)[1]
            except:
                DAS = ""
            Ret = rt130ExtractUCFData(Dir, DAS, PROGStopBut, PROGRunning, \
                    "MF", IncNonSOH, DSs, IncDS9, FromDate, ToDate)
            if Ret[0] != 0:
                setMsg("MF", Ret[1], Ret[2], Ret[3])
                setInfoMsg("See status message.")
                progControl("stopped")
                return
            LOGLines.append("%s:  Version Number  %s  File: %s"%(PROG_NAMELC, \
                    PROG_VERSION, MainFilename))
            LOGLines += Ret[1]
# ---- RT130 DAS ID ----
# The MainFilename is just the DAS ID. The directory to read is the one we are
# currently pointing to (PROGDataDirVar). Pass them together to fool the
# extraction function into thinking this is just a .cf "file" like above.
        elif len(MainFilename) == 4 and isHex(MainFilename):
            Ret = rt130ExtractUCFData(PROGDataDirVar.get(), MainFilename, \
                    PROGStopBut, PROGRunning, "MF", IncNonSOH, DSs, IncDS9, \
                    FromDate, ToDate)
            if Ret[0] != 0:
                setMsg("MF", Ret[1], Ret[2], Ret[3])
                setInfoMsg("See status message.")
                progControl("stopped")
                return
            LOGLines.append("%s:  Version Number  %s  File: %s"%(PROG_NAMELC, \
                    PROG_VERSION, MainFilename))
            LOGLines += Ret[1]
    LFrm.title("SOH Messages - %s"%MainFilename)
    setMsg("MF", "CB", "Processing read information...")
# We will skip lines until a "State of Health" line is found.
    Skip = True
# Stick the word "Skipped" in the SOH messages before the beginning of each
# chunk of skipped stuff section so that can be searched for.
# I don't want the first lines of the log lines to be "Skipped", because
# everything up to the first "SOH" line gets skipped, so set this to -1 until
# things get rolling then it will be set to True and False as needed.
    FirstSkip = -1
    TimingProblems = False
    Skipped = 0
    Warnings = 0
    Errors = 0
# This is faster than doing the .get()
    OPTIgTEC = OPTIgTECVar.get()
    LastTime = -float(maxint)
    TimeMin = float(maxint)
    TimeMax = -float(maxint)
    TheUnitID = ""
    TheCPUVers = ""
    TheGPSvers = ""
    TheLastDOY = 0
    TheYear = 1970
    InLine = ""
    TotalLines = len(LOGLines)
    Lines = 0
    for InLine in LOGLines:
# Keep the user entertained.
        if Lines%5000 == 0 and Lines != 0:
            setInfoMsg("Working...\nLines: %d of %d\nSkipped: %d"%(Lines, \
                    TotalLines, Skipped))
# Gives the Stop Reading button a chance to be used.
            PROGStopBut.update()
            if PROGRunning.get() == 0:
                break
# Boy, I hate to spend the CPU cycles doing this, but...
# Any line with "bad" characters will not be processed at all.
        if isprintableInLine() == False:
            if FirstSkip == True:
                txLn("LOG", "", "Skipped")
                Lines += 1
                FirstSkip = False
            txLn("LOG", "R", InLine)
            Lines += 1
            Skipped += 1
            if Skipped%50000 == 0:
                Answer = formMYD(Root, (("No, Stop", LEFT, "stop"), \
                        ("Yes, Continue", LEFT, "cont")), "cont", "YB", \
                        "What's Wrong With This File?", \
                        "%d lines have been skipped so far. Are you sure this is a valid information source file?"% \
                        Skipped)
                if Answer == "stop":
                    setInfoMsg("See status message.")
                    setMsg("MF", "YB", "Stopped.", 2)
                    progControl("stopped")
                    return
            continue
# SOH lines will be used to get the year of the data, and will be used to
# set a flag that will determine if anything will be processed or not:
#   - Nothing will be processed until one of these lines are found
#   - If the time in any line jumps backwards (enough) then no lines will be
#     processed until a 'good' SOH line is found whose time is later than
#     the last time the loop remembers, UNLESS OPTIgTEC != 0 then all lines
#     will be processed no matter how messed up the times are.
# If the first SOH line is really screwed up (like with a large year value)
# then the file may not even be able to be processed without turning on the
# Ignore Timing Errors option.
        if InLine.startswith("State of Health"):
            Time = eatSOH()
            if Time >= LastTime or OPTIgTEC == 1:
                LTxt.insert(END, "%s\n"%InLine)
                Lines += 1
                SOH.append((Lines, Time))
                LastTime = Time
                Skip = False
                FirstSkip = True
                continue
            else:
                if OPTIgTEC == 0:
                    Skip = True
# Event lines are not mixed into the SOH messages in the right place in time
# depending on the information source, so they can get skipped when we are in
# the process of skipping regular SOH messages. Treat them special (basically
# always plot them). This looks for FST, but eatEVT() actually reads the TT
# time. FST seemed like a better choice for fewer false finds.
        elif InLine.find("FST =") != -1:
            Info = eatEVT()
            Lines += 1
            EVT.append((Lines, Info[0], Info[1]))
            LTxt.insert(END, "%s\n"%InLine)
            continue
# LPMP lines are special and always at the end of the message lines in a .log
# file.
        if Skip == False or InLine.startswith("LPMP"):
            LTxt.insert(END, "%s\n"%InLine)
            Lines += 1
        else:
            if FirstSkip == True:
                LTxt.insert(END, "Skipped\n")
                Lines += 1
                FirstSkip = False
# This may or may not be true, but it's the best we can do.
                TimingProblems = True
            txLn("LOG", "Y", InLine)
            Lines += 1
            Skipped += 1
            if Skipped%50000 == 0:
                Answer = formMYD(Root, (("No, Stop", LEFT, "stop"), \
                        ("Yes, Continue", LEFT, "cont")), "cont", "YB", \
                        "What's Wrong With This File?", \
                        "%d lines have been skipped so far. Are you sure this is a valid information source file?"% \
                        Skipped)
                if Answer == "stop":
                    setInfoMsg("See status message.")
                    setMsg("MF", "YB", "Stopped.", 2)
                    progControl("stopped")
                    return
            continue
# Now that InLine has been written to where ever it needs to be displayed upper
# it so we are immune to Reftek's grammer changes.
        InLine = InLine.upper()
# 72, 130.
        if InLine.find("INTERNAL CLOCK PHASE ERROR") != -1:
            Info = eatICPE()
            ICPE.append((Lines, Info[0], Info[1]))
# 72, 130.
        elif InLine.find("EXTERNAL CLOCK IS UNLOCKED") != -1:
            GPSLK.append((Lines, eatSIMPLE(), 0))
# 72, 130.
        elif InLine.find("EXTERNAL CLOCK IS LOCKED") != -1:
            GPSLK.append((Lines, eatSIMPLE(), 1))
# 72, 130.
        elif InLine.find("POSSIBLE DISCREPANCY") != -1:
            DISCREP.append((Lines, eatSIMPLE(), 1))
# 72, 130.
        elif InLine.find("GPS: POSITION") != -1:
            Info = eatGPOS()
            GPOSd.append(Info[0])
            GPOSr.append(Info[1])
            GPOSe.append(Info[2])
# 130 - started somewhere around v2.3.1.
        elif InLine.find("EXTERNAL CLOCK POWER IS TURNED ON") != -1:
            GPS.append((Lines, eatSIMPLE(), 1))
# 130 - started somewhere around v2.3.1.
        elif InLine.find("EXTERNAL CLOCK POWER IS TURNED OFF") != -1:
            GPS.append((Lines, eatSIMPLE(), 0))
# 130-before v2.3.1 to 3.2.2.
        elif InLine.find("EXTERNAL CLOCK WAKEUP") != -1:
            GPS.append((Lines, eatSIMPLE(), 1))
# 130-before v2.3.1 to 3.2.2.
        elif InLine.find("EXTERNAL CLOCK SLEEP") != -1:
            GPS.append((Lines, eatSIMPLE(), 0))
# 72.
        elif InLine.find("GPS: POWER IS TURNED ON") != -1:
            GPS.append((Lines, eatSIMPLE(), 1))
# 72.
        elif InLine.find("GPS: POWER IS TURNED OFF") != -1:
            GPS.append((Lines, eatSIMPLE(), 0))
# 72.
        elif InLine.find("GPS: V") != -1:
            eatGPSV()
# 72, 130.
        elif InLine.find("BATTERY VOLTAGE") != -1:
            Info = eatBATMP()
            VOLT.append((Lines, Info[0], Info[1]))
            TEMP.append((Lines, Info[0], Info[2]))
            if Info[3] == 3.3:
                BKUP.append((Lines, Info[0], Info[3], 1))
            elif Info[3] >= 3.0:
                BKUP.append((Lines, Info[0], Info[3], 2))
            else:
                BKUP.append((Lines, Info[0], Info[3], 3))
# 72, 130.
        elif InLine.find("ERROR:") != -1:
# These lines are generated by programs like ref2segy and do not have any time
# associated with them so just use whatever time was last in Time.
            ERROR.append((Lines, Time, 1))
            Errors += 1
# 72, 130.
        elif InLine.find("WARNING") != -1:
            if rtnPattern(InLine[:12]) == "000:00:00:00":
                WARN.append((Lines, eatSIMPLE(), 1))
            else:
# Just use whatever time was last in Time.
                WARN.append((Lines, Time, 1))
            Warnings += 1
# 72, 130.
        elif InLine.find("AUTO DUMP CALLED") != -1:
            DUMP.append((Lines, eatSIMPLE(), 1))
# 72, 130.
        elif InLine.find("AUTO DUMP COMPLETE") != -1:
            DUMP.append((Lines, eatSIMPLE(), 0))
# 72, 130.
        elif InLine.find("DSP CLOCK SET") != -1:
            JERK.append((Lines, eatSIMPLE(), 1))
# 72, 130.
        elif InLine.find("DSP CLOCK DIFFERENCE") != -1:
            Info = eatDCDIFF()
            DCDIFF.append((Lines, Info[0], Info[1]))
# 72, 130.
        elif InLine.find("TIME JERK") != -1 and InLine.find("OCCURRED") != -1:
            JERK.append((Lines, eatSIMPLE(), 0))
# 130.
        elif InLine.find("JERK") != -1:
            JERK.append((Lines, eatSIMPLE(), 0))
# 72, 130.
        elif InLine.find("ACQUISITION STARTED") != -1:
            ACQ.append((Lines, eatSIMPLE(), 1))
# 72, 130.
        elif InLine.find("ACQUISITION STOPPED") != -1:
            ACQ.append((Lines, eatSIMPLE(), 0))
# 72, 130.
# 2010-Uppering InLine started here. Version 3.0.0 went to all uppercase msgs.
        elif InLine.find("NETWORK LAYER IS UP") != -1:
            NET.append((Lines, eatSIMPLE(), 1))
# 72, 130.
        elif InLine.find("NETWORK LAYER IS DOWN") != -1:
            NET.append((Lines, eatSIMPLE(), 0))
# 72, 130.
        elif InLine.find("STATION CHANNEL DEFINITION") != -1:
            DEFS.append((Lines, eatDEFS()))
# 72?, 130.
        elif InLine.find("MASS RE-CENTER") != -1:
            MRC.append((Lines, eatSIMPLE()))
# FINISHME - mass position kludge stuff. Will need another one of these to read
# whatever Reftek puts in.
# 130.
# The lines are: LPMP YYYY:DDD:HH:MM:SS Chan Value ColorCode
        elif InLine.startswith("LPMP"):
            Parts = InLine.split()
            Epoch = YDHMST2Epoch(Parts[1])
            Chan = intt(Parts[2])
            Value = floatt(Parts[3])
            ColorCode = intt(Parts[4])
            eval("MP%d"%Chan).append((Epoch, Value, ColorCode))
# 72?, 130 - system reset command.
        elif InLine.find("SYSTEM RESET") != -1:
            RESET.append((Lines, eatSIMPLE()))
        elif InLine.find("SYSTEM POWERUP") != -1:
            PWRUP.append((Lines, eatSIMPLE()))
# The firmware version info can be in either of these two lines depending on
# the model and the version of firmware (it changed several times on RT130s).
        elif InLine.find("REF TEK") != -1:
            PWRUP.append((Lines, eatCPUV()))
        elif InLine.find("CPU SOFTWARE") != -1:
            PWRUP.append((Lines, eatCPUV()))
        elif InLine.find("EXTERNAL CLOCK CYCLE") != -1:
            CLKPWR.append((Lines, eatSIMPLE(), 1))
# 130.
        elif InLine.find("AUTO DUMP FAILED") != -1:
            ERROR.append((Lines, eatSIMPLE(), 1))
# FINISHME - 2010SEP07
# This whole mass position thing is really kludgy, but here goes...
# If the mass positions were extracted from the binary data then len(MPx) will
# not be 0. In that case add strange lines to the end of the regular log lines
# that will not get plotted in the usual way, but will get plotted if the
# user saves the log lines to a .log file and sends it in to PIC. Once Reftek
# starts putting the mass positions into the regular SOH messages then LOGPEEK
# will be changed to start plotting them, instead.
# Now if a .log file was read then there may or may not be any mass positions
# (yes if Reftek puts them in, no if not), so don't add them again (MPx will
# contain the info taken from them and not from the DS9 packets).
    if LogFile == False and OPTAddMPMsgsCVar.get() == 1:
        for i in xrange(1, 7):
            MPData = eval("MP%d"%i)
            if len(MPData) > 0:
                for Point in MPData:
                    LTxt.insert(END, "LPMP %s %d %.1f %d\n"%( \
                            epoch2Str(Point[0]), i, Point[1], Point[2]))
    if PROGRunning.get() == 0:
        setMsg("MF", "YB", "Reading stopped.", 2)
        setInfoMsg("")
        progControl("stopped")
        return
# Get the max time range of the graphs, and the other info if we finished the
# file.
    FStart = TimeMin
    CurMainStart = FStart
    FEnd = TimeMax
    CurMainEnd = FEnd
# The Unit's ID (DAS ID) will control the plotting.
# The RT130's have hex serial numbers in the range 9000-FFFF.
    if TheUnitID >= "9000" and TheUnitID <= "FFFF":
        RTModel = "RT130"
    else:
        RTModel = "72A"
# Clear out any previously saved time ranges.
    del StartEndRecord[:]
    setMinMax()
# If there are no SOH messages then there isn't anything to plot.
    if len(SOH) == 0:
        if UseDates == False:
            setMsg("MF", "YB", "No SOH messages found.", 2)
        else:
            setMsg("MF", "YB", \
                    "No SOH messages found. Could be the date range.", 2)
        setInfoMsg("File: "+MainFilename)
    else:
# Fill in the Info box with info about the file.
        if OPTDateFormatRVar.get() == "YYYY:DDD":
            FS = epoch2Str(FStart)
            FE = epoch2Str(FEnd)
        elif OPTDateFormatRVar.get() == "YYYYMMMDD":
            FS = ydhms2ymdhms(epoch2Str(FStart))
            FE = ydhms2ymdhms(epoch2Str(FEnd))
        elif OPTDateFormatRVar.get() == "YYYY-MM-DD":
            FS = ydhms2ymdhmsDash(epoch2Str(FStart))
            FE = ydhms2ymdhmsDash(epoch2Str(FEnd))
        elif OPTDateFormatRVar.get() == "":
            FS = str(FStart)
            FE = str(FEnd)
        if RTModel == "72A":
            setInfoMsg("File: "+MainFilename+
                    "\nDAS: "+TheUnitID+
                    "\nCPU: "+TheCPUVers+
                    "\nGPS: "+TheGPSvers+
                    "\n\nSOH lines: "+str(Lines)+
                    "\nErrors: "+str(Errors)+
                    "\nWarnings: "+str(Warnings)+
                    "\nLines skipped: "+str(Skipped)+
                    "\nFile start: "+FS+ \
                    "\nFile end: "+FE)
        elif RTModel == "RT130":
            setInfoMsg("File: "+MainFilename+
                    "\nDAS: "+TheUnitID+
                    "\nCPU: "+TheCPUVers+
                    "\n\nSOH lines: "+str(Lines)+
                    "\nERROR lines: "+str(Errors)+
                    "\nWARNING lines: "+str(Warnings)+
                    "\nLines skipped: "+str(Skipped)+
                    "\nFile start: "+FS+
                    "\nFile end: "+FE)
        Frm["LOG"].deiconify()
        if DGrf["ERR"].get() == 1:
# Build the file name of a possible .err file.
            EFilename = MainFilespec[:-4]+".err"
# Try to open the file. If we can't we'll just assume it doesn't exist.
            if exists(EFilename):
# Once there was an 89MB .err file!
                Answer = "all"
                if getsize(EFilename) > 1000000:
                    Answer = formMYD(Root, (("All", LEFT, "all"), \
                            ("10,000", LEFT, "10000"), ("None", LEFT, \
                            "none")), "none", "YB", "Wow!", \
                            "The .err file is %d bytes long. Do you want to read the whole thing, only about the first 10,000 lines, or none of it?"% \
                            getsize(EFilename))
                if Answer == "all" or Answer == "10000":
                    setMsg("MF", "CB", "Reading "+EFilename+"...")
                    if Answer == "all":
                        Fp = open(EFilename, "rb")
                        InLines = readFileLines(Fp)
                        Fp.close()
                    elif Answer == "10000":
                        Fp = open(EFilename, "rb")
                        InLines = readFileLines(Fp, 10000*80)
                        Fp.close()
# Create the window that will contain all of the lines of the file.
                    if Frm["ERR"] != None:
                        Frm["ERR"].deiconify()
                        Frm["ERR"].lift()
                    else:
                        LFrm = Frm["ERR"] = Toplevel(Root)
                        LFrm.withdraw()
                        LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, \
                                "ERR"))
                        LFrm.title("Error File Lines - %s"%MainFilename)
                        Sub = Frame(LFrm)
                        Txt["ERR"] = Text(Sub, bg = Clr["B"], cursor = "", \
                                fg = Clr["W"], font = PROGMsgFont, \
                                height = 15, relief = SUNKEN, width = 80, \
                                wrap = NONE)
                        Txt["ERR"].pack(side = LEFT, fill = BOTH, \
                                expand = YES)
                        Scroll = Scrollbar(Sub, orient = VERTICAL, \
                                command = Txt["ERR"].yview)
                        Scroll.pack(side = RIGHT, fill = Y)
                        Txt["ERR"].configure(yscrollcommand = Scroll.set)
                        Sub.pack(side = TOP, expand = YES, fill = BOTH)
# Read through the lines and find the lines of interest.
                        Lines = 0
                        for InLine in InLines:
                            Lines += 1
                            Txt["ERR"].insert(END, "%s\n"%InLine)
                            InLine = InLine.upper()
                            if InLine.find("TIME JUMP:") != -1:
                                Info = eatTMJMP()
# Lines, Observed time, Corrected time, Channel.
                                TMJMP.append((Lines, Info[0], Info[1], \
                                        Info[2]))
                        center(Root, "ERR", "N", "O", True)
# Make the calls to draw all of the plots. Keep the message from plotMF()
# until we are finished with the raw plots.
        Msge = plotMF(None)
        plotRAW()
        plotTPS()
        if TimingProblems == False:
            setMsg("MF", "WB", Msge)
        else:
            Msge += "\nPossible timing problems."
            setMsg("MF", "YB", Msge)
    progControl("stopped")
    return
# END: fileSelected




###################
# BEGIN: floatt(In)
# FUNC:floatt():2007.037
# (No .strip() check. Skips over " " in In)
#    Handles all of the annoying shortfalls of the float() function (vs C).
#    Does not handle scientific notation numbers.
def floatt(In):
    Number = ""
    for c in In:
        if c.isdigit() or c == ".":
            Number += c
        elif (c == "-" or c == "+") and Number == "":
            Number += c
        elif c == " " or c == ",":
            continue
        else:
            break
    try:
        return float(Number)
    except ValueError:
        return 0.0
# END: floatt




####################
# BEGIN: fmti(Value)
# LIB:fmti():2010.138
#   Just couldn't rely on the system to do this, although this won't handle
#   European-style numbers.
def fmti(Value):
    Value = int(Value)
    if Value > -1000 and Value < 1000:
        return str(Value)
    Value = str(Value)
    NewValue = ""
# There'll never be a + sign.
    if Value[0] == "-":
        Offset = 1
    else:
        Offset = 0
    CountDigits = 0
    for i in xrange(len(Value)-1, -1+Offset, -1):
        NewValue = Value[i]+NewValue
        CountDigits += 1
        if CountDigits == 3 and i != 0:
            NewValue = ","+NewValue
            CountDigits = 0
    if Offset != 0:
        if NewValue.startswith(","):
            NewValue = NewValue[1:]
        NewValue = Value[0]+NewValue
    return NewValue
# END: fmti




#################################################
# BEGIN: formCAL(Parent, Months = 3, Show = True)
# LIB:formCAL():2010.135
#   Displays a 3-month calendar with dates and day-of-year numbers.
Frm["CAL"] = None
CALTmModeRVar = StringVar()
CALTmModeRVar.set("lt")
CALDtModeRVar = StringVar()
CALDtModeRVar.set("dates")
CALOffsetVar = StringVar()
PROGSetups += ("CALTmModeRVar", "CALDtModeRVar", "CALOffsetVar")
CALYear = 0
CALMonth = 0
CALText1 = None
CALText2 = None
CALText3 = None
CALMON = ("", "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", \
        "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER")
CALFDOM = (0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
CALMonths = 3

def formCAL(Parent, Months = 3, Show = True):
    global CALText1
    global CALText2
    global CALText3
    global CALMonths
    if showUp("CAL"):
        return
    CALMonths = Months
    LFrm = Frm["CAL"] = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.resizable(0, 0)
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "CAL"))
    if CALTmModeRVar.get() == "gmt":
        LFrm.title("Calendar (GMT)")
    elif CALTmModeRVar.get() == "lt":
        GMTDiff = getLTGMTDiff()
        LFrm.title("Calendar (LT: GMT%+.2f hours)"%(float(GMTDiff)/3600.0))
    elif CALTmModeRVar.get() == "tz":
        CALOffsetVar.set("%+.2f"%floatt(CALOffsetVar.get()))
        LFrm.title("Calendar (TZ: GMT%s hours)"%CALOffsetVar.get())
    LFrm.iconname("Cal")
    Sub = Frame(LFrm)
    if CALMonths == 3:
        CALText1 = Text(Sub, width = 29, height = 11, font = PROGMonoFont, \
                bg = Clr["D"], fg = Clr["B"], relief = SUNKEN, \
                state = DISABLED)
        CALText1.pack(side = LEFT, padx = 7)
    CALText2 = Text(Sub, width = 29, height = 11, font = PROGMonoFont, \
            bg = Clr["W"], fg = Clr["B"], relief = SUNKEN, state = DISABLED)
    CALText2.pack(side = LEFT, padx = 7)
    if CALMonths == 3:
        CALText3 = Text(Sub, width = 29, height = 11, font = PROGMonoFont, \
                bg = Clr["D"], fg = Clr["B"], relief = SUNKEN, \
                state = DISABLED)
        CALText3.pack(side = LEFT, padx = 7)
    Sub.pack(side = TOP, padx = 3, pady = 3)
    if CALYear != 0:
        formCALMove("c")
    else:
        formCALMove("n")
    Sub = Frame(LFrm)
    BButton(Sub, text = "<<", command = Command(formCALMove, \
            "-y")).pack(side = LEFT)
    BButton(Sub, text = "<", command = Command(formCALMove, \
            "-m")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Now", command = Command(formCALMove, \
            "n")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = ">", command = Command(formCALMove, \
            "+m")).pack(side = LEFT)
    BButton(Sub, text = ">>", command = Command(formCALMove, \
            "+y")).pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3, pady = 3)
    Sub = Frame(LFrm)
    SSub = Frame(Sub)
    SSSub = Frame(SSub)
    Rb = Radiobutton(SSSub, text = "GMT", value = "gmt", \
            variable = CALTmModeRVar, command = Command(formCALMove, "c"))
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, "Use what appears to be this computer's GMT time.")
    Rb = Radiobutton(SSSub, text = "LT", value = "lt", \
            variable = CALTmModeRVar, command = Command(formCALMove, "c"))
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, \
          "Use what appears to be this computer's time and time zone setting.")
    SSSub.pack(side = TOP, anchor = "w")
    SSSub = Frame(SSub)
    Rb = Radiobutton(SSSub, text = "TZ:=", value = "tz", \
            variable = CALTmModeRVar, command = Command(formCALMove, "c"))
    Rb.pack(side = LEFT)
    ToolTip(Rb, 30, \
            "Enter the time zone offset in decimal hours that the calendar should use, instead of this computer's clock settings (the date will still come from this computer).")
    LEnt = Entry(SSSub, width = 6, textvariable = CALOffsetVar)
    LEnt.pack(side = LEFT)
    LEnt.bind("<Double-Button-1>", Command(formKB, "CAL", "TZ Offset", \
                    CALOffsetVar))
    LEnt.bind("<Return>", Command(formCALMove, "c"))
    LEnt.bind("<KP_Enter>", Command(formCALMove, "c"))
    SSSub.pack(side = TOP, anchor = "w")
    SSub.pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    SSub = Frame(Sub)
    Rb = Radiobutton(SSub, text = "Dates", value = "dates", \
            variable = CALDtModeRVar, command = Command(formCALMove, "c"))
    Rb.pack(side = TOP, anchor = "w")
    ToolTip(Rb, 30, "Show the calendar dates.")
    Rb = Radiobutton(SSub, text = "DOY", value = "doy", \
            variable = CALDtModeRVar, command = Command(formCALMove, "c"))
    Rb.pack(side = TOP, anchor = "w")
    ToolTip(Rb, 30, "Show the day-of-year numbers.")
    SSub.pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Close", fg = Clr["R"], command = Command(closeForm, \
            "CAL")).pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3, pady = 3)
    if Show == True:
        center(Parent, LFrm, "C", "I", True)
    return
####################################
# BEGIN: formCALMove(What, e = None)
# FUNC:formCALMove():2010.120
#   Handles changing the calendar form's display.
def formCALMove(What, e = None):
    global CALYear
    global CALMonth
    global CALText1
    global CALText2
    global CALText3
    Frm["CAL"].focus_set()
    Year = CALYear
    Month = CALMonth
    if What == "-y":
        Year -= 1
    elif What == "-m":
        Month -= 1
    elif What == "n":
        if CALTmModeRVar.get() == "gmt":
            Year, Month, Day = getGMT(4)
        elif CALTmModeRVar.get() == "lt":
            Year, DDD, HH, MM, SS = getGMT(11)
            Month, Day = ydoy2md(Year, DDD)
            GMTDiff = getLTGMTDiff()
            if GMTDiff != 0:
                Year, DDD, HH, MM, SS = dateTimeMath(0, GMTDiff, Year, DDD, \
                        HH, MM, SS)
                Month, Day = ydoy2md(Year, DDD)
        elif CALTmModeRVar.get() == "tz":
            Year, DDD, HH, MM, SS = getGMT(11)
            Month, Day = ydoy2md(Year, DDD)
            CALOffsetVar.set("%+.2f"%floatt(CALOffsetVar.get()))
            GMTDiff = int(floatt(CALOffsetVar.get())*3600.0)
            if GMTDiff != 0:
                Year, DDD, HH, MM, SS = dateTimeMath(0, GMTDiff, Year, DDD, \
                        HH, MM, SS)
                Month, Day = ydoy2md(Year, DDD)
    elif What == "+m":
        Month += 1
    elif What == "+y":
        Year += 1
    elif What == "c":
        if CALTmModeRVar.get() == "gmt":
            Frm["CAL"].title("Calendar (GMT)")
        elif CALTmModeRVar.get() == "lt":
            GMTDiff = getLTGMTDiff()
            Frm["CAL"].title("Calendar (LT: GMT%+.2f hours)"% \
                    (float(GMTDiff)/3600.0))
        elif CALTmModeRVar.get() == "tz":
            CALOffsetVar.set("%+.2f"%floatt(CALOffsetVar.get()))
            GMTDiff = int(floatt(CALOffsetVar.get())*3600.0)
            Frm["CAL"].title("Calendar (TZ: GMT%+.2f hours)"% \
                    (float(GMTDiff)/3600.0))
    if Year < 1971:
        beep(1)
        return
    elif Year > 2050:
        beep(1)
        return
    if Month > 12:
        Year += 1
        Month = 1
    elif Month < 1:
        Year -= 1
        Month = 12
    CALYear = Year
    CALMonth = Month
# Only adjust this back one month if we are showing all three months.
    if CALMonths == 3:
        Month -= 1
    if Month < 1:
        Year -= 1
        Month = 12
    for i in xrange(0, 0+3):
# Skip the first and last months if we are only showing one month.
        if CALMonths == 1 and (i == 0 or i == 2):
            continue
        LTxt = eval("CALText%d"%(i+1))
        LTxt.configure(state = NORMAL)
        LTxt.delete(0.0, END)
        LTxt.tag_delete(*LTxt.tag_names())
        if CALDtModeRVar.get() == "dates":
            DOM1 = 0
        else:
            DOM1 = CALFDOM[Month]
            if (Year%4 == 0 and Year%100 != 0) or Year%400 == 0:
                if Month > 2:
                    DOM1 += 1
        if i == 1:
            LTxt.insert(END, "\n")
            LTxt.insert(END, "%s"%(CALMON[Month]+" "+str(Year)).center(29))
            LTxt.insert(END, "\n\n")
            IdxS = LTxt.index(CURRENT)
            LTxt.tag_config(IdxS, background = Clr["W"], foreground = Clr["R"])
            LTxt.insert(END, " Sun ", IdxS)
            IdxS = LTxt.index(CURRENT)
            LTxt.tag_config(IdxS, background = Clr["W"], foreground = Clr["U"])
            LTxt.insert(END, "Mon Tue Wed Thu Fri", IdxS)
            IdxS = LTxt.index(CURRENT)
            LTxt.tag_config(IdxS, background = Clr["W"], foreground = Clr["R"])
            LTxt.insert(END, " Sat", IdxS)
            LTxt.insert(END, "\n")
        else:
            LTxt.insert(END, "\n")
            LTxt.insert(END, "%s"%(CALMON[Month]+" "+str(Year)).center(29))
            LTxt.insert(END, "\n\n")
            LTxt.insert(END, " Sun Mon Tue Wed Thu Fri Sat")
            LTxt.insert(END, "\n")
        All = monthcalendar(Year, Month)
        if CALTmModeRVar.get() == "gmt":
            NowYear, NowMonth, NowDay = getGMT(4)
        elif CALTmModeRVar.get() == "lt":
            NowYear, DDD, HH, MM, SS = getGMT(11)
            NowMonth, NowDay = ydoy2md(NowYear, DDD)
            GMTDiff = getLTGMTDiff()
            if GMTDiff != 0:
                NowYear, DDD, HH, MM, SS = dateTimeMath(0, GMTDiff, NowYear, \
                        DDD, HH, MM, SS)
                NowMonth, NowDay = ydoy2md(NowYear, DDD)
        elif CALTmModeRVar.get() == "tz":
            NowYear, DDD, HH, MM, SS = getGMT(11)
            NowMonth, NowDay = ydoy2md(NowYear, DDD)
            GMTDiff = int(floatt(CALOffsetVar.get())*3600.0)
            if GMTDiff != 0:
                NowYear, DDD, HH, MM, SS = dateTimeMath(0, GMTDiff, NowYear, \
                        DDD, HH, MM, SS)
                NowMonth, NowDay = ydoy2md(NowYear, DDD)
        TargetDay = DOM1+NowDay
        for Week in All:
            LTxt.insert(END, " ")
            for DD in Week:
                if DD != 0:
                    ThisDay = DOM1+DD
                    if ThisDay == TargetDay and Month == NowMonth and \
                            Year == NowYear:
                        IdxS = LTxt.index(CURRENT)
                        LTxt.tag_config(IdxS, background = Clr["C"], \
                                foreground = Clr["B"])
                        LTxt.insert(END, "%3d"%ThisDay, IdxS)
                        LTxt.insert(END, " ")
                    else:
                        LTxt.insert(END, "%3d "%ThisDay)
                else:
                    LTxt.insert(END, "    ")
            LTxt.insert(END, "\n")
        LTxt.configure(state = DISABLED)
        Month += 1
        if Month > 12:
            Year += 1
            Month = 1
    return
# END: formCAL




##########################################
# BEGIN: formFind(Who, WhereMsg, e = None)
# LIB:formFind():2010.285
#   The caller must set up the global Vars:
#      <Who>FindLookForVar = StringVar()
#      <Who>FindLastLookForVar = StringVar()
#      <Who>FindLinesVar = StringVar()
#      <Who>FindIndexVar = IntVar()
#   Then on the form whose Text field wants to be searched set up an Entry
#   field and two Buttons like
#
#   LEnt = Entry(Sub, width = 20, textvariable = HELPFindLookForVar)
#   LEnt.pack(side = LEFT)
#   LEnt.bind("<Double-Button-1>", Command(formKB, "HELP", "Find", \
#           HELPFindLookForVar))
#   LEnt.bind("<Return>", Command(formFind, "HELP", "HELP"))
#   LEnt.bind("<KP_Enter>", Command(formFind, "HELP", "HELP"))
#   BButton(Sub, text = "Find", command = Command(formFind, "HELP", \
#           "HELP")).pack(side = LEFT)
#   BButton(Sub, text = "Next", command = Command(formFindNext, \
#           "HELP", "HELP")).pack(side = LEFT)
#
def formFind(Who, WhereMsg, e = None):
    setMsg(WhereMsg, "CB", "Finding...")
    LTxt = Txt[Who]
    LookFor = eval("%sFindLookForVar"%Who).get().lower()
    if LookFor == "":
        LTxt.tag_delete("FI")
        LTxt.tag_delete("FIN")
        eval("%sFindLinesVar"%Who).set("")
        eval("%sFindIndexVar"%Who).set(-1)
        setMsg(WhereMsg, "", "")
        return 0
    Found = 0
    LTxt.tag_delete("FI")
    LTxt.tag_delete("FIN")
    eval("%sFindLastLookForVar"%Who).set(LookFor)
    eval("%sFindLinesVar"%Who).set("")
    eval("%sFindIndexVar"%Who).set(-1)
    FindLines = ""
    N = 1
    while 1:
        if LTxt.get("%d.0"%N) == "":
            break
        Line = LTxt.get("%d.0"%N, "%d.0"%(N+1)).lower()
        if Line.find(LookFor) != -1:
            TagStart = "%d.%d"%(N, Line.find(LookFor))
            TagEnd = "%d.%d"%(N, Line.find(LookFor)+len(LookFor))
            LTxt.tag_add("FI", TagStart, TagEnd)
            LTxt.tag_config("FI", background = Clr["U"], \
                    foreground = Clr["W"])
            FindLines += " %s,%s"%(TagStart, TagEnd)
            Found += 1
        N += 1
    if Found == 0:
        setMsg(WhereMsg, "", "No matches found.")
    else:
        eval("%sFindLinesVar"%Who).set(FindLines)
        formFindNext(Who, WhereMsg, True)
        setMsg(WhereMsg, "", "Matches found: %d"%Found)
    return Found
############################################################
# BEGIN: formFindNext(Who, WhereMsg, Find = False, e = None)
# FUNC:formFindNext():2010.284
def formFindNext(Who, WhereMsg, Find = False, e = None):
    LTxt = Txt[Who]
    LTxt.tag_delete("FIN")
    FindLines = eval("%sFindLinesVar"%Who).get().split()
    if len(FindLines) == 0:
        beep(1)
        return
    Index = eval("%sFindIndexVar"%Who).get()
    Index += 1
    try:
        Line = FindLines[Index]
        eval("%sFindIndexVar"%Who).set(Index)
    except IndexError:
        Index = 0
        Line = FindLines[Index]
        eval("%sFindIndexVar"%Who).set(0)
# Make the "current find" red.
    TagStart, TagEnd = Line.split(",")
    LTxt.tag_add("FIN", TagStart, TagEnd)
    LTxt.tag_config("FIN", background = Clr["R"], foreground = Clr["W"])
    Txt[Who].see(TagStart)
# If this is the first find just let the caller set a message.
    if Find == False:
        setMsg(WhereMsg, "", "Match %d of %d."%(Index+1, len(FindLines)))
    return
# END: formFind




#############################################
# BEGIN: formKB(Parent, Title, Var, e = None)
# LIB:formKB():2009.154
Frm["KB"] = None
KBEntryVar = StringVar()

def formKB(Parent, Title, Var, e = None):
    if Frm["KB"] != None:
        Frm["KB"].deiconify()
        Frm["KB"].lift()
        beep(2)
        return
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    LFrm = Frm["KB"] = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.resizable(0, 0)
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "KB"))
    LFrm.title(Title)
    LFrm.iconname("Keyboard")
    LEnt = Entry(LFrm, textvariable = KBEntryVar)
    LEnt.pack(side = TOP, fill = X)
    LEnt.bind("<Return>", Command(formKBReturn, Var))
    LEnt.bind("<KP_Enter>", Command(formKBReturn, Var))
    Sub = Frame(LFrm)
    for K in ("!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "+", \
            "|", "~"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Sub = Frame(LFrm)
    for K in ("1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", \
            "\\"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Frame(LFrm, height = 1, bg = Clr["B"], relief = GROOVE).pack(side = TOP, \
            fill = X, pady = 1)
    Sub = Frame(LFrm)
    for K in ("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "{", "}", \
            "BS"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Sub = Frame(LFrm)
    for K in ("A", "S", "D", "F", "G", "H", "J", "K", "L", ":"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    BButton(Sub, text = "RETURN", command = Command(formKBReturn, Var), \
            font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP)
    Sub = Frame(LFrm)
    for K in ("Z", "X", "C", "V", "B", "N", "M", "<", ">", "?"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Frame(LFrm, height = 1, bg = Clr["B"], relief = GROOVE).pack(side = TOP, \
            fill = X, pady = 1)
    Sub = Frame(LFrm)
    for K in ("q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", \
            "BS"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, fill = Y)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Sub = Frame(LFrm)
    for K in ("a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    BButton(Sub, text = "RETURN", command = Command(formKBReturn, Var), \
            font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Sub = Frame(LFrm)
    for K in ("z", "x", "c", "v", "b", "n", "m", ",", ".", "/"):
        BButton(Sub, text = K, command = Command(formKBHit, K), \
                font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    Sub = Frame(LFrm)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "          SPACE          ", \
            command = Command(formKBHit, " "), \
            font = PROGKBFont).pack(side = LEFT, padx = 1, pady = 1)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Cancel", font = PROGKBFont, \
            command = Command(closeForm, "KB")).pack(side = LEFT, padx = 1, \
            pady = 1)
    Sub.pack(side = TOP, padx = 1, pady = 1)
    KBEntryVar.set(Var.get())
    center(Parent, LFrm, "C", "I", True)
    LEnt.focus_set()
    LEnt.icursor(END)
    return
###############################
# BEGIN: formKBHit(K, e = None)
# FUNC:formKBHit():2008.012
Keysyms = {"!":"exclam", "@":"at", "#":"numbersign", "$":"dollar", \
        "%":"percent", "^":"asciicircum", "&":"ampersand", "*":"asterisk", \
        "(":"parenleft", ")":"parenright", "_":"underscore", "+":"plus", \
        "|":"bar", "~":"asciitilde", "-":"minus", "=":"equal", \
        "\\":"backslash", "{":"braceleft", "}":"braceright", \
        "[":"bracketleft", "]":"bracketright", ":":"colon", ";":"semicolon", \
        "'":"quoteright", "<":"less", ">":"greater", "?":"question", \
        ",":"comma", ".":"period", "/":"slash", " ":"space", "BS":"BackSpace"}

def formKBHit(K, e = None):
    if K == "BS":
        Root.event_generate("<KeyPress-BackSpace>")
        return
    elif (K >= "a" and K <= "z") or (K >= "A" and K <= "Z"):
        Root.event_generate("<KeyPress-"+K+">")
        return
    elif (K >= "0" and K <= "9"):
        Root.event_generate("<KeyPress-"+K+">")
        return
    try:
        Root.event_generate("<KeyPress-"+Keysyms[K]+">")
    except KeyError:
        beep(1)
    return
####################################
# BEGIN: formKBReturn(Var, e = None)
# FUNC:formKBReturn():2008.012
def formKBReturn(Var, e = None):
    Var.set(KBEntryVar.get().strip())
    closeForm("KB")
    return
# END: formKB




####################################################################
# BEGIN: formMYD(Parent, Clicks, Close, C, Title, Msg1, Msg2 = "", \
#                Bell = 0, CenterX = 0, CenterY = 0, Width = 0)
# LIB:formMYD():2010.257
#   The built-in dialog boxes cannot be associated with a particular frame, so
#   the Root/Main window kept popping to the front and covering up everything
#   on some systems when they were used, so I wrote this. I'm sure there is a
#   "classy" way of doing this, but I couldn't figure out how to return a
#   value after the window was destroyed from a classy-way.
#
#   The dialog box can contain an input field by using something like:
#
#   Answer = formMYD(Root, (("Input60", TOP, "input"), ("Write", LEFT, \
#           "input"), ("(Cancel)", LEFT, "cancel")), "cancel", "YB"\
#           "Let it be written...", \
#   "Enter a message to write to the Messages section (60 characters max.):")
#   if Answer == "cancel":
#       return
#   What = Answer.strip()
#   if len(What) == 0 or len(What) > 60:
#       Root.bell()
#   print(What)
#
#   The "Input60" tells the function to make an entry field 60 characters
#   long.  The "input" return value for the "Write" button tells the routine
#   to return whatever was entered into the input field. The "Cancel" button
#   will return "cancel", which, of course, could be confusing if the user
#   entered "cancel" in the input field and hit the Write button. In the case
#   above the Cancel button should probably return something like "!@#$%^&",
#   or something else that the user would never normally enter.
#
#   A "default" button may be designated by enclosing the text in ()'s.
#   Pressing the Return or keypad Enter keys will return that button's value.
#   The Cancel button is the default button in this example.
#
#   A caller must clear, or may set MYDAnswerVar to clear a previous
#   call's entry or to provide a default value for the input field before
#   calling formMYD().
#
#   To bring up a "splash dialog" for messages like "Working..." use
#
#       formMYD(Root, (), "", "", "", "Working...")
#
#   Call formMYDReturn to get rid of the dialog:
#
#       formMYDReturn("")
#
#   CenterX and CenterY can be used to position the dialog box when there is
#   no Parent if they are set to something other than 0 and 0.
#
#   Width may be set to something other than 0 to not use the default message
#   width.
MYDFrame = None
MYDLabel = None
MYDAnswerVar = StringVar()
PROGTrans["MYDyes-LE"] = "Yes"
PROGTrans["MYDyes-LS"] = unicode("S\xed", "iso8859-1")
PROGTrans["MYDno-LE"] = "No"
PROGTrans["MYDno-LS"] = "No"
PROGTrans["MYDclear-LE"] = "Clear"
PROGTrans["MYDclear-LS"] = "Limpio"
PROGTrans["MYDclose-LE"] = "Close"
PROGTrans["MYDclose-LS"] = "Cerrar"
PROGTrans["MYDcancel-LE"] = "Cancel"
PROGTrans["MYDcancel-LS"] = "Cancelar"
PROGTrans["MYDok-LE"] = "OK"
PROGTrans["MYDok-LS"] = "OK"

def formMYD(Parent, Clicks, Close, C, Title, Msg1, Msg2 = "", Bell = 0, \
        CenterX = 0, CenterY = 0, Width = 0):
    global MYDFrame
    global MYDLabel
    if Parent != None:
# Allow either way of passing the parent.
        if isinstance(Parent, str) == True:
            Parent = Frm[Parent]
# Without this update() sometimes when running a program through ssh everyone
# loses track of where the parent is and the dialog box ends up at 0,0.
        Parent.update()
    LFrm = MYDFrame = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.resizable(0, 0)
    LFrm.protocol("WM_DELETE_WINDOW", Command(formMYDReturn, Close))
# A number shows up in the title bar if you do .title(""), and if you don't
# set the title it ends up with the program name in it.
    if Title == "":
        Title = " "
    LFrm.title(Title)
    LFrm.iconname(Title)
# Gets rid of some of the extra title bar buttons.
    LFrm.transient(Parent)
    LFrm.bind("<Visibility>", formMYDStay)
    if C != "":
        LFrm.configure(bg = Clr[C[0]])
# Break up the incoming message about every 50 characters or whatever Width is
# set to.
    if Width == 0:
        Width = 50
    if len(Msg1) > Width:
        Count = 0
        Msg = ""
        for c in Msg1:
            if Count == 0 and c == " ":
                continue
            if Count > Width and c == " ":
                Msg += "\n"
                Count = 0
                continue
            if c == "\n":
                Msg += c
                Count = 0
                continue
            Count += 1
            Msg += c
        Msg1 = Msg
# This is an extra line that gets added to the message after a blank line.
    if Msg2 != "":
        if len(Msg2) > Width:
            Count = 0
            Msg = ""
            for c in Msg2:
                if Count == 0 and c == " ":
                    continue
                if Count > Width and c == " ":
                    Msg += "\n"
                    Count = 0
                    continue
                if c == "\n":
                    Msg += c
                    Count = 0
                    continue
                Count += 1
                Msg += c
            Msg1 += "\n\n"+Msg
        else:
            Msg1 += "\n\n"+Msg2
    if C == "":
        MYDLabel = Label(LFrm, text = Msg1, bd = 20)
        MYDLabel.pack(side = TOP)
        Sub = Frame(LFrm)
    else:
        MYDLabel = Label(LFrm, text = Msg1, bd = 20, bg = Clr[C[0]], \
                fg = Clr[C[1]])
        MYDLabel.pack(side = TOP)
        Sub = Frame(LFrm, bg = Clr[C[0]])
    One = False
    InputField = False
    for Click in Clicks:
        if Click[0].startswith("Input"):
            LEnt = Entry(LFrm, textvariable = MYDAnswerVar, \
                    width = intt(Click[0][5:]))
            LEnt.pack(side = TOP, padx = 10, pady = 10)
            LEnt.bind("<Double-Button-1>", Command(formKB, MYDFrame, "Input", \
                    MYDAnswerVar))
# So we know to do the focus_set at the end.
            InputField = True
            continue
        if One == True:
            if C == "":
                Label(Sub, text = " ").pack(side = LEFT)
            else:
                Label(Sub, text = " ", bg = Clr[C[0]]).pack(side = LEFT)
        But = BButton(Sub, text = Click[0], command = Command(formMYDReturn, \
                Click[2]))
        if Click[0].startswith(PROGTrans['MYDclear'+PROGLang]) or \
                Click[0].startswith("("+PROGTrans['MYDclear'+PROGLang]):
            But.configure(fg = Clr["U"], activeforeground = Clr["U"])
        elif Click[0].startswith(PROGTrans['MYDclose'+PROGLang]) or \
                Click[0].startswith("("+PROGTrans['MYDclose'+PROGLang]):
            But.configure(fg = Clr["R"], activeforeground = Clr["R"])
        But.pack(side = Click[1])
        if Click[0].startswith("(") and Click[0].endswith(")"):
            LFrm.bind("<Return>", Command(formMYDReturn, Click[2]))
            LFrm.bind("<KP_Enter>", Command(formMYDReturn, Click[2]))
        if Click[1] != TOP:
            One = True
    Sub.pack(side = TOP, padx = 3, pady = 3)
    center(Parent, LFrm, "C", "I", True, CenterX, CenterY)
# If the user clicks to dismiss the window before any one of these things get
# taken care of then there will be touble. This may only happen when the user
# is running the program over a network and not on the local machine. It has
# something to do with changes made to the beep() routine which fixed a
# problem of occasional missing beeps.
    try:
        LFrm.focus_set()
        LFrm.grab_set()
        if InputField == True:
            LEnt.focus_set()
            LEnt.icursor(END)
        if Bell != 0:
            beep(Bell)
# Everything will pause here until one of the buttons are pressed if there are
# any, then the box will be destroyed, but the value will still be returned.
# since it was saved in a "global".
        if len(Clicks) != 0:
            LFrm.wait_window()
    except:
        pass
# At least do this much cleaning for the caller.
    MYDAnswerVar.set(MYDAnswerVar.get().strip())
    return MYDAnswerVar.get()
######################################
# BEGIN: formMYDReturn(What, e = None)
# FUNC:formMYDReturn():2008.145
def formMYDReturn(What, e = None):
# If What is "input" just leave whatever is in the var in there.
    if What != "input":
        MYDAnswerVar.set(What)
    MYDAnswerVar.set(MYDAnswerVar.get().strip())
    MYDFrame.destroy()
    updateMe(0)
    return
############################
# BEGIN: formMYDMsg(Message)
# FUNC:formMYDMsg():2008.012
def formMYDMsg(Message):
    global MYDLabel
    MYDLabel.config(text = Message)
    updateMe(0)
    return
##############################
# BEGIN: formMYDStay(e = None)
# FUNC:formMYDStay():2010.257
def formMYDStay(e = None):
# The user may dismiss the dialog box before these get a chance to do their
# thing.
    try:
        MYDFrame.unbind("<Visibility>")
        MYDFrame.focus_set()
        MYDFrame.update()
        MYDFrame.lift()
        MYDFrame.bind("<Visibility>", formMYDStay)
    except TclError:
        pass
    return
# END: formMYD




#####################################################################
# BEGIN: formMYDF(Parent, Mode, Title, StartDir, StartFile, Msg = "",
#                EndsWith = "", SameCase = True)
# LIB:formMYDF():2010.248
#   Mode = 0 = allow picking a file
#          1 = just allow picking directories
#          2 = allow picking and making directories only
#          3 = pick/save as directories and files (the works)
#          4 = pick multiple files/change dirs
#   Msg = A message that can be displayed at the top of the form. It's a
#         Label, so \n's should be put in the passed Msg string.
#   EndsWith = The module will only display files ending with EndsWith, the
#              entered filename's case will be matched with the case of
#              EndsWith (IF it is all one case or another). EndsWith may be
#              a passed string of file extensions seperated by commas. EndsWith
#              will be added to the entered filename if it is not there before
#              returning, but only if there is one extension passed.
#   SameCase = If True then the case of the filename must match the case of
#              the EndsWith items.
#   Needs: PROGMYDFFont set (usually the same as the Entry() font)
MYDFFrame = None
MYDFModeVar = IntVar()
MYDFDirVar = StringVar()
MYDFFiles = None
MYDFFileVar = StringVar()
MYDFEndsWithVar = StringVar()
MYDFAnswerVar = StringVar()
MYDFHiddenCVar = IntVar()
MYDFSameCase = True

def formMYDF(Parent, Mode, Title, StartDir, StartFile, Msg = "", \
        EndsWith = "", SameCase = True):
    global MYDFFrame
    global MYDFFiles
    global MYDFMsg
    global MYDFSameCase
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    MYDFModeVar.set(Mode)
    MYDFEndsWithVar.set(EndsWith)
    MYDFSameCase = SameCase
# Without this update() sometimes when running a program through ssh everyone
# loses track of where the parent is and the dialog box ends up at 0,0.
    Parent.update()
    LFrm = MYDFFrame = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.protocol("WM_DELETE_WINDOW", Command(formMYDFReturn, None))
    LFrm.title(Title)
    LFrm.iconname("PickDF")
    LFrm.bind("<Visibility>", formMYDFStay)
    Sub = Frame(LFrm)
    if Msg != "":
        Label(Sub, text = Msg).pack(side = TOP)
    BButton(Sub, text = "up", command = formMYDFUp).pack(side = LEFT)
    LEnt = Entry(Sub, textvariable = MYDFDirVar, width = 65, \
            font = PROGMYDFFont)
    LEnt.pack(side = LEFT, fill = X, expand = YES)
    LEnt.bind("<Double-Button-1>", Command(formKB, MYDFFrame, "Dir", \
                    MYDFDirVar))
    LEnt.bind("<Return>", formMYDFFillFiles)
    LEnt.bind("<KP_Enter>", formMYDFFillFiles)
    if Mode == 2 or Mode == 3:
        But = BButton(Sub, text = "Mkdir", command = formMYDFNew)
        But.pack(side = LEFT)
        ToolTip(But, 25, \
                "Add the name of the new directory to the end of the current contents of the entry field and click this button to create the new directory.")
    Sub.pack(side = TOP, fill = X)
    Sub = Frame(LFrm)
    if Mode == 4:
        LLb = MYDFFiles = Listbox(Sub, relief = SUNKEN, bd = 2, \
                font = PROGMYDFFont, height = 15, selectmode = EXTENDED)
    else:
        LLb = MYDFFiles = Listbox(Sub, relief = SUNKEN, bd = 2, \
                font = PROGMYDFFont, height = 15, selectmode = SINGLE)
    LLb.pack(side = LEFT, expand = YES, fill = BOTH)
    LLb.bind("<ButtonRelease-1>", formMYDFPicked)
    Scroll = Scrollbar(Sub, command = LLb.yview)
    Scroll.pack(side = RIGHT, fill = Y)
    LLb.configure(yscrollcommand = Scroll.set)
    Sub.pack(side = TOP, expand = YES, fill = BOTH)
# The user can type in the filename.
    if Mode == 0 or Mode == 3:
        Sub = Frame(LFrm)
        Label(Sub, text = "Filename:=").pack(side = LEFT)
        LEnt = Entry(Sub, textvariable = MYDFFileVar, width = 65, \
                font = PROGMYDFFont)
        LEnt.pack(side = LEFT, fill = X, expand = YES)
        LEnt.bind("<Double-Button-1>", Command(formKB, MYDFFrame, "Filename", \
                    MYDFFileVar))
        LEnt.bind("<Return>", Command(formMYDFReturn, ""))
        LEnt.bind("<KP_Enter>", Command(formMYDFReturn, ""))
        Sub.pack(side = TOP, fill = X, padx = 3)
    Sub = Frame(LFrm)
    BButton(Sub, text = "OK", command = Command(formMYDFReturn, \
            "")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Cancel", \
            command = Command(formMYDFReturn, None)).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    LCb = Checkbutton(Sub, text = "Show hidden\nfiles", \
            variable = MYDFHiddenCVar, command = formMYDFFillFiles)
    LCb.pack(side = LEFT)
    ToolTip(LCb, 30, "Select this to show hidden/system files in the list.")
    Sub.pack(side = TOP, pady = 3)
    MYDFMsg = Text(LFrm, width = 1, height = 1, highlightthickness = 0, \
            insertwidth = 0, font = PROGMYDFFont, takefocus = 0)
    MYDFMsg.pack(side = TOP, expand = YES, fill = X)
    if len(StartDir) == 0:
        if PROGSystem == "dar" or PROGSystem == "lin" or PROGSystem == "sun":
            StartDir = sep
        elif PROGSystem == "win":
# Where else?
            StartDir = "C:"+sep
    if StartDir.endswith(sep) == False:
        StartDir += sep
    MYDFDirVar.set(StartDir)
    Ret = formMYDFFillFiles()
    if Ret == True and (Mode == 0 or Mode == 3):
        MYDFFileVar.set(StartFile)
    center(Parent, LFrm, "C", "I", True)
    MYDFFrame.grab_set()
# Set the cursor for the user.
    if Mode == 0 or Mode == 3:
        LEnt.focus_set()
        LEnt.icursor(END)
# Everything will pause here until one of the buttons are pressed, then the
# box will be destroyed, but the value will still be returned since it was
# saved in a "global".
    MYDFFrame.wait_window()
    return MYDFAnswerVar.get()
####################################
# BEGIN: formMYDFFillFiles(e = None)
# FUNC:formMYDFFillFiles():2010.248
def formMYDFFillFiles(e = None):
# Some directoryies may have a lot of files in them which could make listdir()
# take a long time, so do this.
    setMsg(MYDFMsg, "CB", "Working...")
# Make sure whatever is in the directory field ends in a separator.
    if len(MYDFDirVar.get()) == 0:
        if PROGSystem == "dar" or PROGSystem == "lin" or PROGSystem == "sun":
            MYDFDirVar.set(sep)
        elif PROGSystem == "win":
            MYDFDirVar.set("C:\\")
    if MYDFDirVar.get().endswith(sep) == False:
        MYDFDirVar.set(MYDFDirVar.get()+sep)
    Dir = MYDFDirVar.get()
    try:
        Files = listdir(Dir)
    except:
        MYDFFileVar.set("")
        setMsg(MYDFMsg, "YB", " There is no such directory.", 2)
        return False
    MYDFFiles.delete(0, END)
    Files.sort(formMYDFCmp)
# Always add this to the top of the list.
    MYDFFiles.insert(END, " .."+sep)
# To show or not to show.
    ShowHidden = MYDFHiddenCVar.get()
    Mode = MYDFModeVar.get()
# Do the directories first.
    for File in Files:
        if ShowHidden == 0:
# FUTUREME - This may need/want to be system dependent at some point (i.e. more
# than just files that start with a .).
            if File.startswith(".") or File.startswith("_"):
                continue
        if isdir(Dir+sep+File):
            MYDFFiles.insert(END, " "+File+sep)
# Check to see if we are going to be filtering.
    EndsWith = ""
    if MYDFEndsWithVar.get() != "":
        EndsWith = MYDFEndsWithVar.get()
    EndsWithParts = EndsWith.split(",")
    Found = False
    for File in Files:
        if ShowHidden == 0:
            if File.startswith(".") or File.startswith("_"):
                continue
        if isdir(Dir+sep+File) == False:
            if EndsWith == "":
# We only want to see the file sizes when we are looking for files.
                if Mode == 0 or Mode == 3:
# Trying to follow links will trip this so just show them.
                    try:
                        MYDFFiles.insert(END, " %s  (bytes: %s)"%(File, \
                                fmti(getsize(Dir+sep+File))))
                    except OSError:
                        MYDFFiles.insert(END, " %s  (a link?)"%File)
                else:
                    MYDFFiles.insert(END, " %s"%File)
                Found += 1
            else:
                for EndsWithPart in EndsWithParts:
                    if File.endswith(EndsWithPart):
                        if Mode == 0 or Mode == 3:
                            try:
                                MYDFFiles.insert(END, " %s  (bytes: %s)"% \
                                        (File, fmti(getsize(Dir+sep+File))))
                            except OSError:
                                MYDFFiles.insert(END, " %s  (a link?)"%File)
                        else:
                            MYDFFiles.insert(END, " %s"%File)
                        Found += 1
                        break
    if Mode == 0 or Mode == 3:
        if Found == 1:
            setMsg(MYDFMsg, "", " 1 file found.")
        else:
            setMsg(MYDFMsg, "", " %d files found."%Found)
    else:
        setMsg(MYDFMsg, "", "")
    MYDFMsg.focus_set()
    return True
##########################
# BEGIN: formMYDFCmp(x, y)
# FUNC:formMYDFCmp():2009.171
#   So the directory listings are sorted in alphabetical and not ASCII order.
def formMYDFCmp(x, y):
    x = x.lower()
    y = y.lower()
    if x < y:
        return -1
    if x == y:
        return 0
    if x > y:
        return 1
######################
# BEGIN: formMYDFNew()
# FUNC:formMYDFNew():2009.100
def formMYDFNew():
    setMsg(MYDFMsg, "", "")
# Make sure whatever is in the directory field ends in a separator.
    if len(MYDFDirVar.get()) == 0:
        MYDFDirVar.set(sep)
    if MYDFDirVar.get().endswith(sep) == False:
        MYDFDirVar.set(MYDFDirVar.get()+sep)
    Dir = MYDFDirVar.get()
    if exists(Dir):
        setMsg(MYDFMsg, "YB", " Directory already exists.", 2)
        return
    try:
        makedirs(Dir)
        formMYDFFillFiles()
        setMsg(MYDFMsg, "GB", " New directory made.", 1)
    except Exception, e:
# The system messages can be a bit cryptic and/or long, so simplifiy them here.
        if str(e).find("ermission") != -1:
            setMsg(MYDFMsg, "RW", " Permission denied.", 2)
        else:
            setMsg(MYDFMsg, "RW", " "+str(e), 2)
        return
    return
#################################
# BEGIN: formMYDFPicked(e = None)
# FUNC:formMYDFPicked():2008.208
def formMYDFPicked(e = None):
# This is just to get the focus off of the entry field if it was there since
# the user is now clicking on things.
    MYDFMsg.focus_set()
    setMsg(MYDFMsg, "", "")
# Make sure whatever is in the directory field ends with a separator.
    if len(MYDFDirVar.get()) == 0:
        MYDFDirVar.set(sep)
    if MYDFDirVar.get().endswith(sep) == False:
        MYDFDirVar.set(MYDFDirVar.get()+sep)
    Dir = MYDFDirVar.get()
    Mode = MYDFModeVar.get()
# Otherwise the selected stuff will just keep piling up.
    if Mode == 4:
        MYDFFileVar.set("")
# There could be multiple files selected. Go through all of them and see if any
# of them will make us change directories.
    Sel = MYDFFiles.curselection()
    SelectedFiles = ""
    for Index in Sel:
# If the user is not right on the money this will sometimes trip.
        try:
            Selected = MYDFFiles.get(Index).strip()
        except TclError:
            beep(1)
            return
        if Selected == ".."+sep:
            Parts = Dir.split(sep)
# If there are only two Parts then we have hit the top of the directory tree.
# If we don't do this things like "C:" will be wiped out.
            NewDir = ""
            if len(Parts) == 2 and Parts[1] == "":
                NewDir = Parts[0]+sep
            else:
                for i in xrange(0, len(Parts)-2):
                    NewDir += Parts[i]+sep
# Insurance.
            if len(NewDir) == 0:
                if PROGSystem == "dar" or PROGSystem == "lin" or \
                        PROGSystem == "sun":
                    NewDir = sep
# For lack of anyplace else.
                elif PROGSystem == "win":
                    NewDir = "C:"+sep
            MYDFDirVar.set(NewDir)
            formMYDFFillFiles()
            return
        if isdir(Dir+Selected):
            MYDFDirVar.set(Dir+Selected)
            formMYDFFillFiles()
            return
        if Mode == 1 or Mode == 2:
            setMsg(MYDFMsg, "YB", "That is not a directory.", 2)
            MYDFFiles.selection_clear(0, END)
            return
# Must have clicked on a file with byte size and that must be allowed.
        if Selected.find("  (") != -1:
            Selected = Selected[:Selected.index("  (")]
# Build the whole path for the multiple file mode.
        if Mode == 4:
            if SelectedFiles == "":
                SelectedFiles = Dir+Selected
            else:
# An * should be a safe separator, right?
                SelectedFiles += "*"+Dir+Selected
        else:
# This should end up the only file.
            SelectedFiles = Selected
    MYDFFileVar.set(SelectedFiles)
    return
#############################
# BEGIN: formMYDFUp(e = None)
# FUNC:formMYDFUp():2008.098
def formMYDFUp(e = None):
# This is just to get the focus off of the entry field if it was there.
    MYDFMsg.focus_set()
    setMsg(MYDFMsg, "", "")
    Dir = MYDFDirVar.get()
    Parts = Dir.split(sep)
# If there are only two Parts then we have hit the top of the directory tree.
# If we don't do this things like "C:" will be wiped out.
    NewDir = ""
    if len(Parts) == 2 and Parts[1] == "":
        NewDir = Parts[0]+sep
    else:
        for i in xrange(0, len(Parts)-2):
            NewDir += Parts[i]+sep
# Insurance.
    if len(NewDir) == 0:
        if PROGSystem == "dar" or PROGSystem == "lin" or PROGSystem == "sun":
            NewDir = sep
# For lack of anyplace else.
        elif PROGSystem == "win":
            NewDir = "C:"+sep
    MYDFDirVar.set(NewDir)
    formMYDFFillFiles()
    return
#########################################
# BEGIN: formMYDFReturn(Return, e = None)
# FUNC:formMYDFReturn():2008.210
def formMYDFReturn(Return, e = None):
# This update keeps the "OK" button from staying pushed in when there is a lot
# to do before returning.
    MYDFFrame.update()
    setMsg(MYDFMsg, "", "")
    Mode = MYDFModeVar.get()
    if Return == None:
        MYDFAnswerVar.set("")
    elif Return != "":
        MYDFAnswerVar.set(Return)
    elif Return == "":
        if Mode == 1 or Mode == 2:
            if MYDFDirVar.get() == "":
                setMsg(MYDFMsg, "YB", "There is no directory name.", 2)
                return
            if MYDFDirVar.get().endswith(sep) == False:
                MYDFDirVar.set(MYDFDirVar.get()+sep)
            MYDFAnswerVar.set(MYDFDirVar.get())
        elif Mode == 0 or Mode == 3:
# Just in case the user tries to pull a fast one.
            if MYDFDirVar.get() == "":
                setMsg(MYDFMsg, "YB", "There is no directory name.", 2)
                return
# What was the point of coming here??
            if MYDFFileVar.get() == "":
                setMsg(MYDFMsg, "YB", "No filename has been entered.", 2)
                return
            if MYDFEndsWithVar.get() != "":
# I'm sure this may come back to haunt US someday, but make sure that the case
# of the entered filename matches the passed 'extension'.  My programs, as a
# general rule, are written to handle all upper or lowercase file names, but
# not mixed. Of course, on some operating systems it won't make any difference.
                if MYDFSameCase == True:
                    if MYDFEndsWithVar.get().isupper():
                        if MYDFFileVar.get().isupper() == False:
                            setMsg(MYDFMsg, "YB", \
                              "Filename needs to be all uppercase letters.", 2)
                            return
                    elif MYDFEndsWithVar.get().islower():
                        if MYDFFileVar.get().islower() == False:
                            setMsg(MYDFMsg, "YB", \
                              "Filename needs to be all lowercase letters.", 2)
                            return
# If the user didn't put the 'extension' on the file add it so the caller
# won't have to do it, unless the caller passed multiple extensions, then don't
# do anything.
                if MYDFEndsWithVar.get().find(",") == -1:
                    if MYDFFileVar.get().endswith( \
                            MYDFEndsWithVar.get()) == False:
                        MYDFFileVar.set(MYDFFileVar.get()+ \
                            MYDFEndsWithVar.get())
            MYDFAnswerVar.set(MYDFDirVar.get()+MYDFFileVar.get())
        elif Mode == 4:
            MYDFAnswerVar.set(MYDFFileVar.get())
    MYDFFrame.destroy()
    updateMe(0)
    return
###############################
# BEGIN: formMYDFStay(e = None)
# FUNC:formMYDFStay():2008.012
def formMYDFStay(e = None):
    MYDFFrame.unbind("<Visibility>")
    MYDFFrame.focus_set()
    MYDFFrame.update()
    MYDFFrame.lift()
    MYDFFrame.bind("<Visibility>", formMYDFStay)
    return
# END: formMYDF




###########################################################
# BEGIN: formPCAL(Parent, Where, VarSet, Var, Wait, Format)
# LIB:formPCAL():2010.239
#    Fills in Var with a date selected by the user in YYYY-MM-DD, YYYY:DDD or
#    YYYYMMMDD format. If a time like
#        YYYY-MM-DD HH:MM:SS
#        YYYY:DDD:HH:MM:SS
#        YYYYMMMDD HH:MM:SS
#    is in the Var value then that time will be preserved and returned
#    appended to the selected date.
#    Whatever is detected as the time will just be kept as a string and
#    appended back to the rest of the date. No error checking or anything is
#    done.
#    VarSet = If "" then the calling form's ChgBar will not be messed with.
#    Format = The format of the date to return. Can also be a StringVar that
#             contains the desired format string (shown above).
Frm["PCAL"] = None
PCALTitle = None
PCALYear = 0
PCALMonth = 0
PCALTime = ""
PCALText = None
PCALModeRVar = StringVar()
PCALModeRVar.set("dates")
PCALDefCur = None
PROGSetups += ("PCALModeRVar", )

# WARNING - Needs CALMON and CALFDOM from formCAL()

def formPCAL(Parent, Where, VarSet, Var, Wait, Format):
    global PCALYear
    global PCALMonth
    global PCALTime
    global PCALText
    global PCALDefCur
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    if isinstance(Format, StringVar):
        Format = Format.get()
# Set the calendar to the month of whatever may already be in the Var and
# seal with any time that was passed.
    PCALTime = ""
    if rtnPattern(Var.get()).startswith("0000-0"):
        PCALYear = intt(Var.get())
        PCALMonth = intt(Var.get()[5:])
        Parts = Var.get().split()
        if len(Parts) == 2:
            PCALTime = Parts[1]
    elif rtnPattern(Var.get()).startswith("0000:0"):
        PCALYear = intt(Var.get())
        DDD = intt(Var.get()[5:])
        PCALMonth, DD = ydoy2md(PCALYear, DDD)
        Parts = Var.get().split(":")
        if len(Parts) > 2:
            Parts += (5-len(Parts))*["0"]
            PCALTime = "%02d:%02d:%02d"%(intt(Parts[2]), intt(Parts[3]), \
                    intt(Parts[4]))
    elif rtnPattern(Var.get()).startswith("0000AAA"):
        PCALYear = intt(Var.get())
        MMM = Var.get()[4:4+3]
        PCALMonth = MMM2m(MMM)
        Parts = Var.get().split()
        if len(Parts) == 2:
            PCALTime = Parts[1]
    if Frm["PCAL"] != None:
        formPCALMove("c", VarSet, Var, Format)
        Frm["PCAL"].deiconify()
        Frm["PCAL"].lift()
        Frm["PCAL"].focus_set()
        return
    LFrm = Frm["PCAL"] = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.resizable(0, 0)
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "PCAL"))
    LFrm.title("Pick A Date")
    LFrm.iconname("PickCal")
    if Wait == True:
# Gets rid of some of the extra title bar buttons.
        LFrm.transient(Parent)
        LFrm.bind("<Visibility>", formPCALStay)
    PCALText = Text(LFrm, width = 29, height = 11, font = PROGMonoFont, \
            fg = Clr["B"], bg = Clr["W"], relief = SUNKEN, state = DISABLED)
    PCALText.pack(side = TOP, padx = 3, pady = 3)
    PCALDefCur = PCALText.cget("cursor")
    if PCALYear != 0:
        formPCALMove("c", VarSet, Var, Format)
    else:
        formPCALMove("n", VarSet, Var, Format)
    Sub = Frame(LFrm)
    BButton(Sub, text = "<<", command = Command(formPCALMove, \
            "-y", VarSet, Var, Format)).pack(side = LEFT)
    BButton(Sub, text = "<", command = Command(formPCALMove, \
            "-m", VarSet, Var, Format)).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Now", command = Command(formPCALMove, \
            "n", VarSet, Var, Format)).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = ">", command = Command(formPCALMove, \
            "+m", VarSet, Var, Format)).pack(side = LEFT)
    BButton(Sub, text = ">>", command = Command(formPCALMove, \
            "+y", VarSet, Var, Format)).pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3, pady = 3)
    Sub = Frame(LFrm)
    Radiobutton(Sub, text = "Dates", value = "dates", \
            variable = PCALModeRVar, command = Command(formPCALMove, \
            "c", VarSet, Var, Format)).pack(side = LEFT)
    Radiobutton(Sub, text = "DOY", value = "doy", variable = PCALModeRVar, \
            command = Command(formPCALMove, "c", VarSet, Var, \
            Format)).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Close", fg = Clr["R"], command = Command(closeForm, \
            "PCAL")).pack(side = TOP)
    Sub.pack(side = TOP, padx = 3, pady = 3)
    center(Parent, LFrm, Where, "I", True)
    if Wait == True:
        LFrm.grab_set()
        LFrm.focus_set()
        LFrm.wait_window()
    return
###############################
# BEGIN: formPCALStay(e = None)
# FUNC:formPCALStay():2008.040
def formPCALStay(e = None):
    LFrm = Frm["PCAL"]
    LFrm.unbind("<Visibility>")
    LFrm.focus_set()
    LFrm.update()
    LFrm.lift()
    LFrm.bind("<Visibility>", formPCALStay)
    return
#################################################
# BEGIN: formPCALCurCont(Widget, Which, e = None)
# FUNC:formPCALCurCont():2008.040
def formPCALCurCont(Widget, Which, e = None):
    if Which != "":
        Widget.config(cursor = "%s"%Which)
    else:
        Widget.config(cursor = PCALDefCur)
    return
################################################
# BEGIN: formPCALMove(What, VarSet, Var, Format)
# FUNC:formPCALMove():2008.154
#   Handles changing the calendar form's display.
def formPCALMove(What, VarSet, Var, Format):
    global PCALYear
    global PCALMonth
    global PCALText
    Year = PCALYear
    Month = PCALMonth
    if What == "-y":
        Year -= 1
    elif What == "-m":
        Month -= 1
    elif What == "n":
        (Year, Month, Day) = getGMT(4)
    elif What == "+m":
        Month += 1
    elif What == "+y":
        Year += 1
    elif What == "c":
        pass
    if Year < 1971:
        beep(1)
        return
    elif Year > 2050:
        beep(1)
        return
    if Month > 12:
        Year += 1
        Month = 1
    elif Month < 1:
        Year -= 1
        Month = 12
    PCALYear = Year
    PCALMonth = Month
    LTxt = PCALText
    LTxt.configure(state = NORMAL)
    LTxt.delete(0.0, END)
# Otherwise "today" is cyan on every month.
    LTxt.tag_delete(*LTxt.tag_names())
    if PCALModeRVar.get() == "dates":
        DOM1 = 0
    else:
        DOM1 = CALFDOM[Month]
        if (Year%4 == 0 and Year%100 != 0) or Year%400 == 0:
            if Month > 2:
                DOM1 += 1
    LTxt.insert(END, "\n%s\n\n "%(CALMON[Month]+" "+str(Year)).center(29))
    IdxS = LTxt.index(CURRENT)
    LTxt.tag_config(IdxS, background = Clr["W"], foreground = Clr["R"])
    LTxt.insert(END, "Sun", IdxS)
    IdxS = LTxt.index(CURRENT)
    LTxt.tag_config(IdxS, background = Clr["W"], foreground = Clr["U"])
    LTxt.insert(END, " Mon Tue Wed Thu Fri ", IdxS)
    IdxS = LTxt.index(CURRENT)
    LTxt.tag_config(IdxS, background = Clr["W"], foreground = Clr["R"])
    LTxt.insert(END, "Sat ", IdxS)
    LTxt.insert(END, "\n")
    All = monthcalendar(Year, Month)
    NowYear, NowMonth, NowDay = getGMT(4)
    TargetDay = DOM1+NowDay
    for Week in All:
        LTxt.insert(END, " ")
        for DD in Week:
            if DD != 0:
                ThisDay = DOM1+DD
                IdxS = LTxt.index(CURRENT)
                if ThisDay == TargetDay and Month == NowMonth and \
                        Year == NowYear:
                    LTxt.tag_config(IdxS, background = Clr["C"], \
                            foreground = Clr["B"])
                    LTxt.tag_bind(IdxS, "<Button-1>", Command(formPCALPicked, \
                            VarSet, Var, (Year, Month, DD), Format))
                    LTxt.tag_bind(IdxS, "<Enter>", Command(formPCALCurCont, \
                            LTxt, "right_ptr black"))
                    LTxt.tag_bind(IdxS, "<Leave>", Command(formPCALCurCont, \
                            LTxt, ""))
                    LTxt.insert(END, "%3d"%ThisDay, IdxS)
                    LTxt.insert(END, " ")
                else:
                    LTxt.tag_bind(IdxS, "<Button-1>", Command(formPCALPicked, \
                            VarSet, Var, (Year, Month, DD), Format))
                    LTxt.tag_bind(IdxS, "<Enter>", Command(formPCALCurCont, \
                            LTxt, "right_ptr black"))
                    LTxt.tag_bind(IdxS, "<Leave>", Command(formPCALCurCont, \
                            LTxt, ""))
                    LTxt.insert(END, "%3d"%ThisDay, IdxS)
                    LTxt.insert(END, " ")
            else:
                LTxt.insert(END, "    ")
        LTxt.insert(END, "\n")
    LTxt.configure(state = DISABLED)
    return
############################################################
# BEGIN: formPCALPicked(VarSet, Var, Date, Format, e = None)
# FUNC:formPCALPicked():2010.239
def formPCALPicked(VarSet, Var, Date, Format, e = None):
    if Format.startswith("YYYY-MM-DD"):
        if PCALTime == "":
            Var.set("%d-%02d-%02d"%Date)
        else:
            Var.set("%d-%02d-%02d %s"%(Date, PCALTime))
    elif Format == "YYYY:DDD":
        DDD = ymd2doy(Date[0], Date[1], Date[2])
        if PCALTime == "":
            Var.set("%d:%03d"%(Date[0], DDD))
        else:
            Var.set("%d:%03d:%s"%(Date[0], DDD, PCALTime))
    elif Format == "YYYYMMMDD":
        MMM = m2MMM(str(Date[1]))
        if PCALTime == "":
            Var.set("%d%s%02d"%(Date[0], MMM, Date[2]))
        else:
            Var.set("%d%s%02d %s"%(Date[0], MMM, Date[2], PCALTime))
# The program or the VarSet form may not have any changebars.
    try:
        if VarSet != "":
            chgChgBar(VarSet, 1)
    except NameError:
        pass
    closeForm("PCAL")
    return
# END: formPCAL




############################################################################
# BEGIN: formWrite(Parent, WhereMsg, TextWho, Title, FilespecVar, AllowPick)
# LIB:formWrite():2009.162
#   Writes the contents of the passed TextWho Text() widget to a file.
def formWrite(Parent, WhereMsg, TextWho, Title, FilespecVar, AllowPick):
# Sometimes it can take a while if there is a lot of text.
    updateMe(0)
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    if AllowPick == True:
        Filespec = formMYDF(Parent, 0, Title, dirname(FilespecVar.get()), \
                basename(FilespecVar.get()))
        if Filespec == "":
            return ""
    setMsg(WhereMsg, "CB", "Working...")
    Answer = "over"
    if exists(Filespec):
        Answer = formMYD(Parent, (("Append", LEFT, "append"), \
                ("Overwrite", LEFT, "over"), ("Cancel", LEFT, "cancel")), \
                "cancel", "YB", "Keep Everything.", \
                "The file\n\n%s\n\nalready exists. Would you like to append to that file, overwrite it, or cancel?"% \
                Filespec)
        if Answer == "cancel":
            setMsg(WhereMsg, "", "")
            return ""
    try:
        if Answer == "over":
            Fp = open(Filespec, "wb")
        elif Answer == "append":
            Fp = open(Filespec, "ab")
    except Exception, e:
        setMsg(WhereMsg, "MW", "Error opening file\n   %s\n   %s"% \
                (Filespec, e), 3)
        return ""
# Now that the file is OK...
    FilespecVar.set(Filespec)
    LTxt = Txt[TextWho]
    N = 1
# In case the text field is empty.
    Line = "\n"
    while 1:
        if LTxt.get("%d.0"%N) == "":
            if Line != "\n":
                Fp.write(Line)
            break
# This is a little funny, but it keeps blank lines from sneaking in at the end
# of the written lines.
        if N > 1:
            Fp.write(Line)
        Line = LTxt.get("%d.0"%N, "%d.0"%(N+1))
        N += 1
    Fp.close()
    if Answer == "append":
        setMsg(WhereMsg, "WB", "Appended text to file\n   %s"%Filespec)
    elif Answer == "over":
        setMsg(WhereMsg, "WB", "Wrote text to file\n   %s"%Filespec)
# Return this in case the caller is interested.
    return Filespec
# END: formWrite




#################################################
# BEGIN: formWritePS(Parent, VarSet, FilespecVar)
# LIB:formWritePS():2010.250
def formWritePS(Parent, VarSet, FilespecVar):
    setMsg(VarSet, "", "")
    if isinstance(Parent, str):
        Parent = Frm[Parent]
    LCan = Can[VarSet]
    Running = 0
# The form may not have an associated Running var.
    try:
        Running = eval("%sRunning.get()"%VarSet)
    except:
        pass
    if Running != 0:
        setMsg(VarSet, "YB", "I'm busy...", 2)
        sleep(.5)
        return
# This may not make any difference depending on the form.
    try:
        if LCan.cget("bg") != "#FFFFFF":
            Answer = formMYD(Parent, (("Stop And Let Me Redo It", TOP, \
                    "stop"), ("Continue anyway", TOP, "cont")), "stop", \
                    "YB", "Charcoal Footprint?", \
                    "For best results the background color of the plot area should be white. In fact, for most plots the .ps file's background will be white, and so will the text, so you won't be able to see anything.  Do you want to stop and replot, or continue anyway?")
        if Answer == "stop":
            return
    except:
        pass
# This will cryptically crash if the canvas is empty.
    try:
        L, T, R, B = LCan.bbox(ALL)
# Postscript is so litteral.
        R += 15
        B += 15
    except:
        setMsg(VarSet, "RW", "Is the area to write blank?", 2)
        return
    Dir = dirname(FilespecVar.get())
    File = basename(FilespecVar.get())
    Filespec = formMYDF(Parent, 3, ".ps File To Save To...", \
            Dir, File, "", ".ps", False)
    if Filespec == "":
        return False
    Answer = overwriteFile(Parent, Filespec)
    if Answer == "stop":
        return
    setMsg(VarSet, "CB", "Working on a %d x %d pixel area..."%(R, B))
# This might crash if the canvas is huge?
    try:
        Ps = LCan.postscript(height = B, width = R, pageheight = B, \
                pagewidth = R, pageanchor = "nw", pagex = 0, pagey = B, \
                x = 0, y = 0, colormode = "color")
    except Exception, e:
        setMsg(VarSet, "MW", "Error converting canvas to postscript.\n   %s"% \
                e, 3)
        return
    try:
        Fp = open(Filespec, "w")
        Fp.write(Ps)
        Fp.close()
    except Exception, e:
        setMsg(VarSet, "MW", "Error saving postscript commands.\n   %s"%e, 3)
        return
    setMsg(VarSet, "", "Wrote %d x %d area (%s bytes) to file\n   %s"% \
            (R, B, fmti(len(Ps)), Filespec))
    FilespecVar.set(Filespec)
    return
# END: formWritePS




#################
# BEGIN: getCWD()
# LIB:getCWD():2008.209
def getCWD():
    CWD = getcwd()
    if CWD.endswith(sep) == False:
        CWD += sep
    return CWD
# END: getCWD




#######################
# BEGIN: getGMT(Format)
# LIB:getGMT():2008.168
#   Gets the time in various forms from the system.
def getGMT(Format):
# YYYY:DDD:HH:MM:SS
    if Format == 0:
        return strftime("%Y:%j:%H:%M:%S", gmtime(time()))
# YYYYDDDHHMMSS
    elif Format == 1:
        return strftime("%Y%j%H%M%S", gmtime(time()))
# YYYY-MM-DD
    elif Format == 2:
        return strftime("%Y-%m-%d", gmtime(time()))
# YYYY-MM-DD HH:MM:SS
    elif Format == 3:
        return strftime("%Y-%m-%d %H:%M:%S", gmtime(time()))
# YYYY, MM and DD returned as ints
    elif Format == 4:
        GMT = gmtime(time())
        return (GMT[0], GMT[1], GMT[2])
# YYYY-Jan-01
    elif Format == 5:
        return strftime("%Y-%b-%d", gmtime(time()))
# YYYYMMDDHHMMSS
    elif Format == 6:
        return strftime("%Y%m%d%H%M%S", gmtime(time()))
# Reftek Texan (year-1984) time stamp in BBBBBB format
    elif Format == 7:
        GMT = gmtime(time())
        return pack(">BBBBBB", (GMT[0]-1984), 0, 1, GMT[3], GMT[4], GMT[5])
# Number of seconds
    elif Format == 8:
        return time()
# YYYY-MM-DD/DDD HH:MM:SS
    elif Format == 9:
        return strftime("%Y-%m-%d/%j %H:%M:%S", gmtime(time()))
# YYYY-MM-DD/DDD
    elif Format == 10:
        return strftime("%Y-%m-%d/%j", gmtime(time()))
# YYYY, DDD, HH, MM, SS returned as ints
    elif Format == 11:
        GMT = gmtime(time())
        return (GMT[0], GMT[7], GMT[3], GMT[4], GMT[5])
# HH:MM:SS
    elif Format == 12:
        return strftime("%H:%M:%S", gmtime(time()))
# YYYY:DDD:HH:MM:SS in local time
    elif Format == 13:
        return strftime("%Y:%j:%H:%M:%S", localtime(time()))
# HHMMSS in GMT
    elif Format == 14:
        return strftime("%H%M%S", gmtime(time()))
    return ""
# END: getGMT




#######################
# BEGIN: getLTGMTDiff()
# LIB:getLTGMTDiff():2007.016
#   Returns the number of seconds between the system's GMT and LT.
def getLTGMTDiff():
# Use the same time for both.
    Secs = time()
    LT = localtime(Secs)
    GMT = gmtime(Secs)
    return ydhms2Epoch(LT[0], LT[7], LT[3], LT[4], LT[5])- \
            ydhms2Epoch(GMT[0], GMT[7], GMT[3], GMT[4], GMT[5])
# END: getLTGMTDiff




#################################################
# BEGIN: getPROGStarted(Warn = True, Load = True)
# LIB:getPROGStarted():2010.180
#   Used by everyone to look for the setups file and get the party started.
#   Warn = if False the function won't generate any error responses, except
#          True or False.
#   Load = some programs will just want PROGSetupsDirVar set.
# This does not get saved in the setups file.
PROGSetupsDirVar = StringVar()

def getPROGStarted(Warn = True, Load = True):
    try:
        if PROGSystem == 'dar' or PROGSystem == 'lin' or PROGSystem == 'sun':
            Dir = environ["HOME"]
            LookFor = "HOME"
# Of course Windows had to be different.
        elif PROGSystem == 'win':
            Dir = environ["HOMEDRIVE"]+environ["HOMEPATH"]
            LookFor = "HOMEDRIVE+HOMEPATH"
        else:
            if Warn == False:
                return False
            else:
                return (2, "RW", \
                        "I don't know how to get the HOME directory on this system. This system is not supported: %s"% \
                        PROGSystem, 2)
        if Dir.endswith(sep) == False:
            Dir += sep
    except:
        if Warn == False:
            return False
        else:
            return (2, "MW", \
                    "This program cannot get the environment variable(s) %s from the operating system. This will need to be corrected before this program can be used."% \
                    LookFor, 3)
    if access(Dir, W_OK) == False:
        if Warn == False:
            return False
        else:
            return (2, "MW", \
                    "The %s directory\n\n%s\n\nis not accessible for writing. This will need to be corrected before this program may be used."% \
                    (LookFor, Dir), 3)
    PROGSetupsDirVar.set(Dir)
    if Load == False:
        return True
    else:
        Ret = loadPROGSetups()
        return Ret
###############################
# BEGIN: getPROGStartDir(Which)
# FUNC:getPROGStartDir():2010.180
def getPROGStartDir(Which):
# PETM
    if Which == 0:
        Answer = formMYDF(Root, 1, "Pick A Starting Directory", \
                PROGSetupsDirVar.get(), "", \
                "This may be the first time this program has been started on\nthis computer or in this account. Select a directory for\nthe program to use as the directory where all files should\nstart out being saved. Click the OK button IF the displayed\ndirectory is OK to use.")
# POCUS, CHANGEO...
    elif Which == 1:
        Answer = formMYDF(Root, 1, "Pick A Starting Directory", \
                PROGSetupsDirVar.get(), "", \
                "This may be the first time this program has been started on\nthis computer or in this account. Select a directory for\nthe program to use as the directory where all files should\nstart out being saved -- NOT necessarily where any data files\nmay be. We'll get to that later. Click the OK button if the\ndisplayed directory is OK to use.")
    elif Which == 2:
# LOGPEEK (no messages file).
        Answer = formMYDF(Root, 1, "Pick A Starting Directory...", \
                PROGSetupsDirVar.get(), "", \
                "This may be the first time this program has been started\non this computer or in this account. Select a directory\nfor the program to use as a starting point.\nClick the OK button to use the displayed\ndirectory.")
    return Answer
# END: getPROGStarted




###########################
# BEGIN: getRange(Min, Max)
# LIB:getRange():2008.360
#   Returns the absolute value of the difference between Min and Max.
def getRange(Min, Max):
    if Min <= 0 and Max >= 0:
        return Max+abs(Min)
    elif Min <= 0 and Max <= 0:
        return abs(Min-Max)
    elif Max >= 0 and Min >= 0:
        return Max-Min
# END: getRange




#####################
# BEGIN: isLeap(YYYY)
# LIB:isLeap():2007.015
def isLeap(YYYY):
    if YYYY%4 != 0:
        return 0
    elif YYYY%100 != 0 or YYYY%400 == 0:
        return 1
    else:
        return 0
# END: isLeap




######################################
# BEGIN: iText57(Who, x, y, What, Clr)
# LIB:iText57():2007.294
#   Draws 5x7 characters on a PIS Image.
# Height of the characters +1, width of the characters +1.
GFontW = 6
GFontH = 8
PILVers = Image.VERSION

def iText57(Who, x, y, What, Clr):
    for c in What:
        if c == "A":
# There was a bug in PIL that required some line segments of some of the
# characters to be commanded to be longer than they should have been. That was
# fixed in version 1.1.6.
            if PILVers > "1.1.5":
                Who.line((x,y+6, x,y+1, x+2,y, x+3,y, x+4,y+1, x+4,y+6), Clr)
                Who.line((x,y+4, x+4,y+4), Clr)
            else:
                Who.line((x,y+6, x,y+1, x+2,y, x+3,y, x+4,y+1, x+4,y+7), Clr)
                Who.line((x,y+4, x+4,y+4), Clr)
        elif c == "B":
            Who.line((x,y+6, x,y, x+3,y, x+4,y+1, x+4,y+2, x+3,y+3, \
                    x,y+3), Clr)
            Who.line((x+4,y+4, x+4,y+5, x+3,y+6, x,y+6), Clr)
        elif c == "C":
            if PILVers > "1.1.5":
                Who.line((x+4,y+1, x+3,y, x+1,y, x,y+1, x,y+5, x+1,y+6, \
                        x+3,y+6, x+4,y+5), Clr)
            else:
                Who.line((x+4,y+1, x+3,y, x+1,y, x,y+1, x,y+5, x+1,y+6, \
                        x+3,y+6, x+5,y+4), Clr)
        elif c == "D":
            Who.line((x,y, x+3,y, x+4,y+1, x+4,y+5, x+3,y+6, x,y+6, x,y), \
                    Clr)
        elif c == "E":
            Who.line((x+4,y+6, x,y+6, x,y, x+4,y), Clr)
            Who.line((x,y+3, x+3,y+3), Clr)
        elif c == "F":
            Who.line((x,y+6, x,y, x+4,y), Clr)
            Who.line((x,y+3, x+3,y+3), Clr)
        elif c == "G":
            if PILVers > "1.1.5":
                Who.line((x+2,y+3, x+4,y+3, x+4,y+5, x+3,y+6, x+1,y+6, x,y+5, \
                        x,y+1, x+1,y, x+3,y, x+4,y+1), Clr)
            else:
                Who.line((x+2,y+3, x+4,y+3, x+4,y+5, x+3,y+6, x+1,y+6, x,y+5, \
                        x,y+1, x+1,y, x+3,y, x+5,y+2), Clr)
        elif c == "H":
            if PILVers > "1.1.5":
                Who.line((x,y, x,y+6), Clr)
                Who.line((x+4,y, x+4,y+6), Clr)
                Who.line((x,y+3, x+4,y+3), Clr)
            else:
                Who.line((x,y, x,y+7), Clr)
                Who.line((x+4,y, x+4,y+7), Clr)
                Who.line((x,y+3, x+4,y+3), Clr)
        elif c == "I":
            Who.line((x+1,y, x+3,y), Clr)
            Who.line((x+2,y, x+2,y+6), Clr)
            Who.line((x+1,y+6, x+3,y+6), Clr)
        elif c == "J":
            if PILVers > "1.1.5":
                Who.line((x+1,y, x+4,y), Clr)
                Who.line((x+3,y, x+3,y+5, x+2,y+6, x+1,y+6, x,y+5), Clr)
            else:
                Who.line((x+1,y, x+4,y), Clr)
                Who.line((x+3,y, x+3,y+5, x+2,y+6, x+1,y+6, x-1,y+4), Clr)
        elif c == "K":
            if PILVers > "1.1.5":
                Who.line((x,y, x,y+6), Clr)
                Who.line((x+1,y+3, x+4,y), Clr)
                Who.line((x+1,y+3, x+4,y+6), Clr)
            else:
                Who.line((x,y, x,y+7), Clr)
                Who.line((x+1,y+3, x+5,y-1), Clr)
                Who.line((x+1,y+3, x+5,y+7), Clr)
        elif c == "L":
            Who.line((x,y, x,y+6, x+4,y+6), Clr)
        elif c == "M":
            if PILVers > "1.1.5":
                Who.line((x,y+6, x,y, x+2,y+2, x+4,y, x+4,y+6), Clr)
            else:
                Who.line((x,y+6, x,y, x+2,y+2, x+4,y, x+4,y+7), Clr)
        elif c == "N":
            if PILVers > "1.1.5":
                Who.line((x,y, x,y+6), Clr)
                Who.line((x+4,y, x+4,y+6), Clr)
                Who.line((x,y+1, x+4,y+5), Clr)
            else:
                Who.line((x,y, x,y+7), Clr)
                Who.line((x+4,y, x+4,y+7), Clr)
                Who.line((x,y+1, x+4,y+5), Clr)
        elif c == "O":
            Who.line((x+1,y, x+3,y, x+4,y+1, x+4,y+5, x+3,y+6, x+1,y+6, \
                    x,y+5, x,y+1, x+1,y), Clr)
        elif c == "P":
            Who.line((x,y+6, x,y, x+3,y, x+4,y+1, x+4,y+2, x+3,y+3, \
                    x,y+3), Clr)
        elif c == "Q":
            Who.line((x+1,y, x+3,y, x+4,y+1, x+4,y+5, x+3,y+6, x+1,y+6, \
                    x,y+5, x,y+1, x+1,y), Clr)
            Who.line((x+2,y+4, x+5,y+7), Clr)
        elif c == "R":
            if PILVers > "1.1.5":
                Who.line((x,y+6, x,y, x+3,y, x+4,y+1, x+4,y+2, x+3,y+3, \
                        x,y+3), Clr)
                Who.line((x+3,y+3, x+4,y+4, x+4,y+6), Clr)
            else:
                Who.line((x,y+6, x,y, x+3,y, x+4,y+1, x+4,y+2, x+3,y+3, \
                        x,y+3), Clr)
                Who.line((x+3,y+3, x+4,y+4, x+4,y+7), Clr)
        elif c == "S":
            if PILVers > "1.1.5":
                Who.line((x+4,y+1, x+3,y, x+1,y, x,y+1, x,y+2, x+1,y+3, \
                        x+3,y+3, x+4,y+4, x+4,y+5, x+3,y+6, x+1,y+6, \
                        x,y+5), Clr)
            else:
                Who.line((x+4,y+1, x+3,y, x+1,y, x,y+1, x,y+2, x+1,y+3, \
                        x+3,y+3, x+4,y+4, x+4,y+5, x+3,y+6, x+1,y+6, \
                        x-1,y+4), Clr)
        elif c == "T":
            if PILVers > "1.1.5":
                Who.line((x,y, x+4,y), Clr)
                Who.line((x+2,y, x+2,y+6), Clr)
            else:
                Who.line((x,y, x+4,y), Clr)
                Who.line((x+2,y, x+2,y+7), Clr)
        elif c == "U":
            if PILVers > "1.1.5":
                Who.line((x,y, x,y+5, x+1,y+6, x+3,y+6, x+4,y+5, x+4,y), Clr)
            else:
                Who.line((x,y, x,y+5, x+1,y+6, x+3,y+6, x+4,y+5, x+4,y-1), Clr)
        elif c == "V":
            if PILVers > "1.1.5":
                Who.line((x,y, x,y+4, x+2,y+6, x+4,y+4, x+4,y), Clr)
            else:
                Who.line((x,y, x,y+4, x+2,y+6, x+4,y+4, x+4,y-1), Clr)
        elif c == "W":
            if PILVers > "1.1.5":
                Who.line((x,y, x,y+6, x+2,y+4, x+4,y+6, x+4,y), Clr)
            else:
                Who.line((x,y, x,y+6, x+2,y+4, x+4,y+6, x+4,y-1), Clr)
        elif c == "X":
            if PILVers > "1.1.5":
                Who.line((x,y, x,y+1, x+4,y+5, x+4,y+6), Clr)
                Who.line((x,y+6, x,y+5, x+4,y+1, x+4,y), Clr)
            else:
                Who.line((x,y, x,y+1, x+4,y+5, x+4,y+7), Clr)
                Who.line((x,y+6, x,y+5, x+4,y+1, x+4,y-1), Clr)
        elif c == "Y":
            if PILVers > "1.1.5":
                Who.line((x,y, x,y+2, x+2,y+4, x+2,y+6), Clr)
                Who.line((x+3,y+3, x+4,y+2, x+4,y), Clr)
            else:
                Who.line((x,y, x,y+2, x+2,y+4, x+2,y+7), Clr)
                Who.line((x+3,y+3, x+4,y+2, x+4,y-1), Clr)
        elif c == "Z":
            Who.line((x,y, x+4,y, x+4,y+1, x,y+5, x,y+6, x+4,y+6), Clr)
        elif c == "0":
            Who.line((x+1,y, x+3,y, x+4,y+1, x+4,y+5, x+3,y+6, x+1,y+6, \
                    x,y+5, x,y+1, x+1,y), Clr)
        elif c == "1":
            if PILVers > "1.1.5":
                Who.line((x+1,y+1, x+2,y, x+2,y+6), Clr)
            else:
                Who.line((x+1,y+1, x+2,y, x+2,y+7), Clr)
        elif c == "2":
            Who.line((x,y+1, x+1,y, x+3,y, x+4,y+1, x+4,y+2, x,y+6, \
                    x+4,y+6), Clr)
        elif c == "3":
            if PILVers > "1.1.5":
                Who.line((x,y+1, x+1,y, x+3,y, x+4,y+1, x+4,y+2, x+3,y+3, \
                        x+1,y+3), Clr)
                Who.line((x+3,y+3, x+4,y+4, x+4,y+5, x+3,y+6, x+1,y+6, \
                        x,y+5), Clr)
            else:
                Who.line((x,y+1, x+1,y, x+3,y, x+4,y+1, x+4,y+2, x+3,y+3, \
                        x+1,y+3), Clr)
                Who.line((x+3,y+3, x+4,y+4, x+4,y+5, x+3,y+6, x+1,y+6, \
                        x-1,y+4), Clr)
        elif c == "4":
            if PILVers > "1.1.5":
                Who.line((x+4,y+4, x,y+4, x,y+3, x+3,y, x+3,y+6), Clr)
            else:
                Who.line((x+4,y+4, x,y+4, x,y+3, x+3,y, x+3,y+7), Clr)
        elif c == "5":
            if PILVers > "1.1.5":
                Who.line((x+4,y, x,y, x,y+2, x+3,y+2, x+4,y+3, x+4,y+5, \
                        x+3,y+6, x+1,y+6, x,y+5), Clr)
            else:
                Who.line((x+4,y, x,y, x,y+2, x+3,y+2, x+4,y+3, x+4,y+5, \
                        x+3,y+6, x+1,y+6, x-1,y+4), Clr)
        elif c == "6":
            Who.line((x+4,y+1, x+3,y, x+1,y, x,y+1, x,y+5, x+1,y+6, \
                    x+3,y+6, x+4,y+5, x+4,y+4, x+3,y+3, x,y+3), Clr)
        elif c == "7":
            if PILVers > "1.1.5":
                Who.line((x,y, x+4,y, x+4,y+1, x+2,y+4, x+2,y+6), Clr)
            else:
                Who.line((x,y, x+4,y, x+4,y+1, x+2,y+4, x+2,y+7), Clr)
        elif c == "8":
            Who.line((x+1,y, x+3,y, x+4,y+1, x+4,y+2, x+3,y+3, x+1,y+3, \
                    x,y+2, x,y+1, x+1,y), Clr)
            Who.line((x+4,y+4, x+4,y+5, x+3,y+6, x+1,y+6, x,y+5, \
                    x,y+4, x+1,y+3), Clr)
        elif c == "9":
            if PILVers > "1.1.5":
                Who.line((x+4,y+3, x+1,y+3, x,y+2, x,y+1, x+1,y, x+3,y, \
                        x+4,y+1, x+4,y+5, x+3,y+6, x+1,y+6, x,y+5), Clr)
            else:
                Who.line((x+4,y+3, x+1,y+3, x,y+2, x,y+1, x+1,y, x+3,y, \
                        x+4,y+1, x+4,y+5, x+3,y+6, x+1,y+6, x-1,y+4), Clr)
        elif c == "e":
            Who.line((x+1,y+4, x+4,y+4, x+4,y+3, x+3,y+2, x+1,y+2, x,y+3, \
                    x,y+5, x+1,y+6, x+4,y+6), Clr)
        elif c == "m":
            if PILVers > "1.1.5":
                Who.line((x,y+2, x,y+6), Clr)
                Who.line((x+1,y+2, x+2,y+3, x+2,y+6), Clr)
                Who.line((x+3,y+2, x+4,y+3, x+4,y+6), Clr)
            else:
                Who.line((x,y+2, x,y+7), Clr)
                Who.line((x+1,y+2, x+2,y+3, x+2,y+7), Clr)
                Who.line((x+3,y+2, x+4,y+3, x+4,y+7), Clr)
        elif c == "s":
            Who.line((x+4,y+2, x+1,y+2, x,y+3, x+1,y+4, x+3,y+4, x+4,y+5, \
                    x+3,y+6, x,y+6), Clr)
        elif c == "u":
            if PILVers > "1.1.5":
                Who.line((x,y+2, x,y+5, x+1,y+6, x+2,y+6, x+4,y+4), Clr)
                Who.line((x+4,y+2, x+4,y+6), Clr)
            else:
                Who.line((x,y+2, x,y+5, x+1,y+6, x+2,y+6, x+4,y+4), Clr)
                Who.line((x+4,y+2, x+4,y+7), Clr)
        elif c == "/":
            Who.line((x+1,y+6, x+1,y+5, x+2,y+4, x+2,y+3, x+3,y+2, \
                    x+3,y+1, x+4,y, x+4,y-1), Clr)
        elif c == ".":
            Who.line((x+2,y+5, x+3,y+5, x+3,y+6, x+2,y+6, x+2,y+5), Clr)
        elif c == ":":
            Who.point((x+2, y+2), Clr)
            Who.point((x+2, y+4), Clr)
        elif c == "-":
            Who.line((x, y+3, x+4,y+3), Clr)
        elif c == "+":
            if PILVers > "1.1.5":
                Who.line((x, y+3, x+4,y+3), Clr)
                Who.line((x+2,y+1, x+2,y+5), Clr)
            else:
                Who.line((x, y+3, x+4,y+3), Clr)
                Who.line((x+2,y+1, x+2,y+6), Clr)
        x += GFontW
    return
# END: iText57




#################
# BEGIN: InIntt()
# FUNC:InIntt():2008.360
def InIntt():
    global InLine
    Number = ""
    for c in InLine.lstrip():
        if c.isdigit() or c == "-" or c == "+":
            Number += c
        elif c == ",":
            continue
        else:
            break
    try:
        return int(Number)
    except ValueError:
        return 0
# END: InIntt




#################
# BEGIN: intt(In)
# FUNC:intt():2007.270
def intt(In):
    Number = ""
    for c in In:
        if c.isdigit():
            Number += c
        elif Number == "" and (c == "-" or c == "+"):
            Number += c
        elif c == "," or c == " ":
            continue
        else:
            break
    try:
        return int(Number)
    except ValueError:
        return 0
# END: intt




###################
# BEGIN: isHex(Str)
# LIB:isHex():2009.026
def isHex(Hex):
    Hex = str(Hex).strip()
    for Char in Hex:
        if Char not in "0123456789abcdefABCDEF":
            return False
    return True
# END: isHex




############################
# BEGIN: isprintableInLine()
# FUNC:isprintableInLine():2010.063
#   I hate to do this, but pass all of the lines through here to make sure they
#   don't contain non-printable characters that could create havoc in many
#   places.
def isprintableInLine():
    global InLine
    for C in InLine:
        C = ord(C)
        if C >= 32 and C <= 126:
            continue
        else:
# This will take even more CPU cycles, but the bad characters need to be gotten
# rid of or they can cause display problems. There is rarely any bad lines
# anyway.
            NewLine = ""
            for i in xrange(0, len(InLine)):
                C = ord(InLine[i])
                if C >= 32 and C <= 126:
                    NewLine += InLine[i]
                else:
                    NewLine += "_"
            InLine = NewLine
            return False
    return True
# END: isprintableInLine




####################################################
# BEGIN: labelTip(Sub, LText, Side, TTWidth, TTText)
# LIB:labelTip():2006.262
#   Creates a label and assignes the passed ToolTip to it. Returns the Label()
#   widget.
def labelTip(Sub, LText, Side, TTWidth, TTText):
    Lab = Label(Sub, text = LText)
    Lab.pack(side = Side)
    ToolTip(Lab, TTWidth, TTText)
    return Lab
# END: labelTip




#########################
# BEGIN: loadPROGSetups()
# LIB:loadPROGSetups():2010.246logpeek
#   A standard setups file loader for programs that don't require anything
#   special loaded from the .set file just the PROGSetups items.
def loadPROGSetups():
# The .set file may not be there.
    Setfile = PROGSetupsDirVar.get()+PROG_NAMELC+".set"
    if exists(Setfile) == False:
        return (1, "", "Setups file not found. Was looking for\n   %s"% \
                Setfile, 0)
    try:
        Fp = open(Setfile, "rb")
    except Exception, e:
        return (2, "MW", "Error opening setups file\n   %s\n   %s"% \
                (Setfile, e), 3)
    Found = False
# Just catch anything that might go wrong and blame it on the .set file.
    try:
        while 1:
            Line = Fp.readline()
            if Line.strip() == "":
                break
            if Line.startswith(PROG_NAME+":"):
                Found = True
                continue
            if Found == True:
                Parts = map(strip, Line.split(";", 1))
# This is a lot slower than just using the key that was read in and hoping
# that there is a matching Var, but this way is safer since we will only look
# for Vars that we know exist (PROGSetups).
                for Item in PROGSetups:
                    if Parts[0] == Item:
                        if isinstance(eval(Item), StringVar):
                            eval(Item).set(Parts[1])
                            break
                        elif isinstance(eval(Item), IntVar):
                            eval(Item).set(int(Parts[1]))
                            break
                    elif Parts[0] == "DGrf":
                        Parts2 = map(strip, Parts[1].split(";"))
                        DGrf[Parts2[0]].set(int(Parts2[1]))
        Fp.close()
        if Found == False:
            return (1, "YB", "No %s setups found in\n   %s"%(PROG_NAME, \
                    Setfile), 2)
        else:
            return (0, "WB", "Setups loaded from\n   %s"%Setfile, 0)
    except Exception, e:
        Fp.close()
        return (2, "MW", \
           "Error loading setups from\n   %s\n   %s\n   Was loading line %s"% \
                (Setfile, e, Line), 3)
#################################
# BEGIN: loadPROGSetupsCmd(Which)
# FUNC:loadPROGSetups():2008.029
def loadPROGSetupsCmd(Which):
    Ret = loadPROGSetups()
    msgLn(Which, Ret[1], Ret[2], True, Ret[3])
    return
#########################
# BEGIN: savePROGSetups()
# FUNC:savePROGSetupsCmd():2010.247
#   A standard setups file saver for programs that don't require anything
#   special saved to the .set file just the PROGSetups items.
def savePROGSetups():
    Setfile = PROGSetupsDirVar.get()+PROG_NAMELC+".set"
    try:
        Fp = open(Setfile, "wb")
    except Exception, e:
        return (2, "MW", "Error opening setups file\n   %s\n   %s"%(Setfile, \
                e), 3)
    try:
        Fp.write("%s: %s\n"%(PROG_NAME, PROG_VERSION))
        for Item in PROGSetups:
            if isinstance(eval(Item), StringVar):
                Fp.write("%s; %s\n"%(Item, eval(Item).get()))
            elif isinstance(eval(Item), IntVar):
                Fp.write("%s; %d\n"%(Item, eval(Item).get()))
        for Item in DGrf.keys():
            Fp.write("DGrf; %s; %d\n"%(Item, eval("DGrf[\"%s\"]"%Item).get()))
        Fp.close()
        return (0, "", "Setups saved to\n   %s"%Setfile, 0)
    except Exception, e:
        Fp.close()
        return (2, "MW", "Error saving setups to\n   %s\n   %s"%(Setfile, \
                e), 3)
########################################
# BEGIN: savePROGSetupsCmd(Speak = True)
# FUNC:savePROGSetupsCmd():2008.195
def savePROGSetupsCmd(Speak = True):
    Ret = savePROGSetups()
    if Speak == True:
        msgLn(0, Ret[1], Ret[2], True, Ret[3])
    return
###########################
# BEGIN: deletePROGSetups()
# FUNC:deletePROGSetups():2010.192
def deletePROGSetups():
    Answer = formMYD(Root, (("Delete And Quit", TOP, "doit"), ("Cancel", \
            TOP, "cancel")), "cancel", "YB", "Be careful.", \
            "This will delete the current setups file and quit the program. This should only be done if the contents of the current setups file is known to be causing the program problems.")
    if Answer == "cancel":
        return
    try:
        remove(PROGSetupsDirVar.get()+PROG_NAMELC+".set")
    except Exception, e:
        formMYD(Root, (("(OK)", TOP, "ok"), ), "ok", "MW", "On No.", \
                "The setups file could not be deleted.\n\n%s"%e)
        return
    progQuitter(False)
    return
# END: loadPROGSetups




#####################################
# BEGIN: loadRTFiles(Filebox, VarSet)
# FUNC:loadRTFiles():2010.248
#   Looks through the directory specified in the PROGDataDirVar and creates a
#   list of the files that it comes across which it places in Filebox.
def loadRTFiles(Filebox, VarSet):
    Filebox.delete(0, END)
    setMsg(VarSet, "CB", "Working...")
    Dir = PROGDataDirVar.get()
    if exists(Dir) == False:
        setMsg(VarSet, "RW", "Entered directory does not exist.", 2)
        return
# Either get the list of files in the directory or get the filename portion
# of the passed path/filename.
    if CLAFile == "":
# The user needs to select somebody.
        if eval("%sShowLogsCVar"%VarSet).get() == 0 and \
                eval("%sShowRefsCVar"%VarSet).get() == 0 and \
                eval("%sShowUCFDCVar"%VarSet).get() == 0 and \
                eval("%sShowZCFCVar"%VarSet).get() == 0:
            setMsg(VarSet, "RW", \
                    "No file type checkboxes have been selected.", 2)
            return
        Files = listdir(Dir)
        Files.sort()
        LOGSFound = 0
        REFSFound = 0
        ZIPSFound = 0
        UCFDFound = 0
        UCFDDFound = 0
# Go through these this way so all of the .logs are listed together, all of the
# .refs are listed together, etc.
        if eval("%sShowLogsCVar"%VarSet).get() == 1:
            for File in Files:
                if File.startswith(".") or File.startswith("_"):
                    continue
                FileLC = File.lower()
                if FileLC.endswith(".log"):
                    Size = getsize(Dir+sep+File)
                    Filebox.insert(END, File+" (~%s lines)"% \
                            (fmti(Size/50)))
                    LOGSFound += 1
        if LOGSFound > 0:
            Filebox.insert(END, "")
        if eval("%sShowRefsCVar"%VarSet).get() == 1:
            for File in Files:
                if File.startswith(".") or File.startswith("_"):
                    continue
                FileLC = File.lower()
                if FileLC.endswith(".ref"):
                    Size = getsize(Dir+sep+File)
                    Filebox.insert(END, File+" (%s bytes)"%fmti(Size))
                    REFSFound += 1
        if REFSFound > 0:
            Filebox.insert(END, "")
        if eval("%sShowUCFDCVar"%VarSet).get() == 1:
            for File in Files:
                if File.startswith(".") or File.startswith("_"):
                    continue
                FileLC = File.lower()
# Get the DAS(s) in "File(s)" (it really must be a directory) and list them.
                if FileLC.endswith(".cf"):
                    if isdir(Dir+File):
                        DASs = rt130FindCFDASs(Dir+File)
                        if len(DASs) > 0:
                            UCFDFound += 1
                            for DAS in DASs:
# Combine the .cf directory and the DAS so we have a clue where to go looking
# for data when the user clicks.
                                Filebox.insert(END, File+sep+DAS)
# If the current CWDDir is a directory with only YYYYDDD sub-directories in it
# (plus a possible saved parameters .CFG file) then we must be "in" a CF card.
# Grab the DAS IDs and list them.
            InCF = True
            for File in Files:
                if File.startswith(".") or File.startswith("_") or \
                        File.endswith(".CFG"):
                    continue
                if isdir(Dir+File) == False or \
                        rtnPattern(File) != "0000000":
                    InCF = False
                    break
            if InCF == True:
                UCFDDFound += 1
                DASs = rt130FindCFDASs(Dir)
                for DAS in DASs:
# Just insert the DAS ID. When it is selected the lack of any extension will
# tell us what needs to be done.
                    Filebox.insert(END, DAS)
                    UCFDFound += 1
        if UCFDFound > 0:
            Filebox.insert(END, "")
        if eval("%sShowZCFCVar"%VarSet).get() == 1:
            for File in Files:
                if File.startswith(".") or File.startswith("_"):
                    continue
                FileLC = File.lower()
                if FileLC.endswith(".zip"):
                    Size = getsize(Dir+sep+File)
                    Filebox.insert(END, File+" (%s bytes)"%fmti(Size))
                    ZIPSFound += 1
        if ZIPSFound > 0:
            Filebox.insert(END, "")
        if LOGSFound == 0 and REFSFound == 0 and ZIPSFound == 0 and \
                UCFDFound == 0:
            setMsg(VarSet, "YB", \
                    "No data source files found in\n   %s"%Dir)
        else:
            setMsg(VarSet, "WB", \
       "Found   .log: %d   .ref: %d   .zip: %d   .cf: %d/%d"% \
                    (LOGSFound, REFSFound, ZIPSFound, UCFDFound, UCFDDFound))
    else:
        File = basename(CLAFile)
        Size = getsize(CLAFile)
        Filebox.insert(END, File+" (~%s lines)"%fmti((Size/50)))
    return
########################################
# BEGIN: loadRTFilesCmd(Filebox, VarSet)
# FUNC:loadRTFilesCmd():2010.167
def loadRTFilesCmd(Filebox, VarSet):
    if VarSet == "MF":
        setInfoMsg("")
    setMsg(VarSet, "", "")
    loadRTFiles(Filebox, VarSet)
    return
######################################
# BEGIN: loadRTFilesSelectAll(Filebox)
# FUNC:loadRTFilesSelectAll():2010.167
def loadRTFilesSelectAll(Filebox):
    Size = Filebox.size()
    NotSelected = 0
    for Index in xrange(0, Size):
        if Filebox.get(Index) == "":
            continue
        if Filebox.selection_includes(Index) == False:
            NotSelected += 1
# If they are not all on turn them all on.
    if NotSelected > 0:
        for Index in xrange(0, Size):
            if Filebox.get(Index) == "":
                Filebox.selection_clear(Index)
            else:
                Filebox.selection_set(Index)
# If they are all on turn them all off.
    elif NotSelected == 0:
        Filebox.selection_clear(0, END)
    return
# END: loadRTFiles




#######################
# BEGIN: notYet(Parent)
# LIB:notYet():2009.162
def notYet(Parent):
   formMYD(Parent, (("(OK)", LEFT, "ok"), ), "ok", "", "Coming Someday?", \
       "This feature is not yet available.", "", 1)
   return
# END: notYet




###########################
# BEGIN: nullCall(e = None)
# LIB:nullCall():2009.164
#   Mostly for binds to call when they don't want anything to happen or for
#   standard widget binds to call to stop things like Text()'s and shift-clicks
#   from going through.
def nullCall(e = None):
    return "break"
# END: nullCall




########################################
# BEGIN: overwriteFile(Parent, Filespec)
# LIB:overwriteFile():2009.265
#   Returns False if the file does not exist, or the Answer.
def overwriteFile(Parent, Filespec):
    if exists(Filespec):
        if isinstance(Parent, str):
            Parent = Frm[Parent]
        Answer = formMYD(Parent, (("Overwrite", LEFT, "over"), ("(Stop)", \
                LEFT, "stop")), "stop", "YB", "Well?", \
              "File %s already exists. Do you want to overwrite it or stop?"% \
                basename(Filespec))
        return Answer
    return False
# END: overwriteFile




###################################
# BEGIN: plotMF(WhereMsg, e = None)
# FUNC:plotMF():2010.263
def plotMF(WhereMsg, e = None):
    global MFTKGraph
    global MFGraphed
    global MFLead
    global CHeight
    global CWidth
    global CurTimerange
    global MFGW
    global MFTimeMode
    global TopSpace
    global BotSpace
    global MFTickY
    global TickX
    global ACQxy
    global NETxy
    global DUMPxy
    global TEMPxy
    global VOLTxy
    global BKUPxy
    global MP1xy
    global MP2xy
    global MP3xy
    global MP4xy
    global MP5xy
    global MP6xy
    global DCDIFFxy
    global DRSETxy
    global RESETxy
    global GPSLKxy
    global TMJMPxy
    global EVTxy
    global GPSxy
    global ICPExy
    global DEFSxy
    global MRCxy
    global JERKxy
    global PWRUPxy
    global CLKPWRxy
    global SOHxy
    global DISCREPxy
    global ERRORxy
    global WARNxy
# This is faster than doing the .get() all the time.
    OPTIgTEC = OPTIgTECVar.get()
# There will always be at least 1 EVT/DS line even if it is blank.
# MaxEVT used to be like "5" if there were 5 data streams, then it changed
# into a List so data streams 1 and 5, for example, could be plotted without
# showing a bunch of blank lines, but it kept the same name.
    MaxEVT = [1]
# Same idea as MaxEVT. Just the data streams with errors, but same goofy name.
    MaxERR = []
# Each graph has a weight which determines how much screen space it will get.
# Those weights need to be added up before we start so we will know how many
# pixels each weight point will get.
    GrfWeights = 0
    for Key in DPlotWts.keys():
        if DGrf[Key].get() == 1:
            if Key == "EVT":
# Go through all of the EVT points so the same number of graphs will show
# up no matter where the user is zoomed into (i.e. don't exclude evt lines
# with no points inside the plotted timerange) and get a list of the DSs that
# we will be plotting (in addition to DS1).
                for Data in EVT:
                    if Data[2] not in MaxEVT:
                        MaxEVT.append(Data[2])
                MaxEVT.sort()
                GrfWeights += DPlotWts["EVT"]*len(MaxEVT)
            elif Key == "ERR":
# Only plot the err file stuff if there are any points to plot.
                if len(TMJMP) > 0:
                    for Data in TMJMP:
                        if Data[3] not in MaxERR:
                            MaxERR.append(Data[3])
                    MaxERR.sort()
                    GrfWeights += DPlotWts["ERR"]*len(MaxERR)
# These are channels 123 and/or 456
            elif Key == "MP123" or Key == "MP456":
                    GrfWeights += DPlotWts[Key]*3
            else:
                GrfWeights += DPlotWts[Key]
    if GrfWeights == 0:
        formMYD(Root, (("(Sigh)", LEFT, "ok"), ), "ok", "RW", "Picky Picky", \
                "You need to select at least one graph to plot.", "", 1)
        return ""
    setMsg("MF", "CB", "Preparing to plot...")
# Get the size of the canvas.
    LCan = Can["MF"]
    CHeight = LCan.winfo_height()
    CWidth = LCan.winfo_width()
# Get the time range for what we are about to plot for other stuff to use.
    CurTimerange = yRange(CurMainStart, CurMainEnd)
    Timerange = CurTimerange
# Where everything will be drawn.
    PILGraph = Image.new('RGB', (CWidth, CHeight), DClr["Image"])
    IDGraph = ImageDraw.Draw(PILGraph)
# Border - a unit of space before the labels, etc.
    Border = GFontW
# These are the longest labels. Get the amount of space for them to leave.
    if RTModel == "72A":
        MFLead = Border+len("JERKS/DSP SETS ")*GFontW
    elif RTModel == "RT130":
        MFLead = Border+len("DSP WAKE/SLEEP ")*GFontW
# TopSpace - the amount of space above the graphs for the clock display.
# This should leave enough room for the clock font (which is probably not the
# same height as the graph font i.e. GFontH, so this may need to be adjusted).
    TopSpace = GFontH*2.0
# BotSpace - the amount of space below the graphs for the time axis.
    BotSpace = GFontH*3.0
# EndSpace - the amount of space to leave following the graphs for the point
# counts.
    EndSpace = Border+len("000000")*GFontW
# AGHeight - the amount of space the graphs get.
    AGHeight = CHeight-TopSpace-BotSpace
# Calculate how much screen per weight unit the graphs will get.
    PixPerWeight = float(AGHeight/GrfWeights)
# FINISHME - check to make sure the smallest unit of graph height is not less
# than the GSpace height.
# The width of the canvas, minus the space for the labels, minus some space at
# the trailing end.
    MFGW = float(CWidth-MFLead-EndSpace-Border)
# The first graph starts after leaving a bit of space at the top.
    Top = TopSpace
# Clock difference messages.
    if DGrf["DCDIFF"].get() == 1:
        del DCDIFFxy[:]
        GTop = Top+GFontH12
        GHeight = PixPerWeight*DPlotWts["DCDIFF"]-GFontH
        if len(DCDIFF) == 0:
            iText57(IDGraph, Border, GTop+GHeight/2-GFontH12, \
                    "DSP-CLK DIFF: NO MESSAGES FOUND.", DClr["Label"])
        else:
            setMsg("MF", "CB", "Plotting clock difference messages...")
            IDGraph.line(((MFLead, GTop), (MFLead+MFGW, GTop)), \
                    DClr["MaxMinL"])
            IDGraph.line(((MFLead, GTop+GHeight), (MFLead+MFGW, \
                    GTop+GHeight)), DClr["MaxMinL"])
            iText57(IDGraph, Border, GTop+GHeight/2-GFontH12, "DSP-CLK DIFF", \
                    DClr["Label"])
            YRange = yRange(DCDIFFMin, DCDIFFMax)
# Label the lines at the top and bottom with the max and min range
# of the data values.
            if abs(DCDIFFMax) > 1000.0:
                Label = str(DCDIFFMax/1000.0)+"s"
            elif abs(DCDIFFMax) > 1.0:
                Label = str(DCDIFFMax)+"ms"
            else:
                Label = str(DCDIFFMax*1000.0)+"us"
# "-5" just leaves a bit of space between the end of the number and the start
# of the line.
            Xx = MFLead-len(Label)*GFontW-5
            iText57(IDGraph, Xx, GTop-GFontH12, Label, DClr["MaxMinV"])
            if abs(DCDIFFMin) > 1000.0:
                Label = str(DCDIFFMin/1000.0)+"s"
            elif abs(DCDIFFMin) > 1.0:
                Label = str(DCDIFFMin)+"ms"
            else:
                Label = str(DCDIFFMin*1000.0)+"us"
            Xx = MFLead-len(Label)*GFontW-5
            iText57(IDGraph, Xx, GTop+GHeight-GFontH12, Label, DClr["MaxMinV"])
# Draw the connecting line, then the points on top of it. Find the first point
# that is greater than the start time of the graph to use as a starting point.
            for Data in DCDIFF:
                if Data[1] >= CurMainStart:
                    LastX = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    LastY = GTop+(GHeight-GHeight*(Data[2]-DCDIFFMin)/YRange)
                    break
# Will stay 0 if there is nothing to plot in the current time range.
            Xx = 0
            Yy = 0
# The lines between two dot positions are draw then the first dot is drawn to
# write over the line in the same loop (it used to be two -- it looked a bit
# better than this on the screen, but...).
            for Data in DCDIFF:
                if Data[1] >= CurMainStart:
                    if Data[1] <= CurMainEnd:
                        Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                        Yy = GTop+(GHeight-GHeight*(Data[2]-DCDIFFMin)/YRange)
                        DCDIFFxy.append((Data[0], Xx, Yy))
                        IDGraph.line(((LastX, LastY), (Xx, Yy)), DClr["Plot"])
                        IDGraph.rectangle((LastX-1.5, LastY-1.5, LastX+1.5, \
                                LastY+1.5), DClr["DCDIFF"])
                        LastX = Xx
                        LastY = Yy
                    else:
# Breaking out at this point will speed things up a bit when zoomed in, but if
# we are ignoring timing errors then we still need to go through all of the
# data points.
                        if OPTIgTEC == 0:
                            break
# If we plotted anything this draws the graph's last dot.
            if Xx != 0 and Yy != 0:
                IDGraph.rectangle((Xx-1.5, Yy-1.5, Xx+1.5, Yy+1.5), \
                        DClr["DCDIFF"])
# Write the number of data points plotted at the end of the graph.
            iText57(IDGraph, MFLead+MFGW+Border, GTop+GHeight/2-GFontH12,
                    str(len(DCDIFFxy)), DClr["DCDIFF"])
# Adjust this for the start of the next graph's area.
        Top += PixPerWeight*DPlotWts["DCDIFF"]
# Internal clock phase errors graph.
    if DGrf["ICPE"].get() == 1:
        del ICPExy[:]
        GTop = Top+GFontH12
        GHeight = PixPerWeight*DPlotWts["ICPE"]-GFontH
        if len(ICPE) == 0:
            iText57(IDGraph, Border, GTop+GHeight/2-GFontH12, \
                    "PHASE ERROR: NO MESSAGES FOUND.", DClr["Label"])
        else:
            setMsg("MF", "CB", "Plotting internal clock phase errors...")
            IDGraph.line(((MFLead, GTop), (MFLead+MFGW, GTop)), \
                    DClr["MaxMinL"])
            IDGraph.line(((MFLead, GTop+GHeight), (MFLead+MFGW, \
                    GTop+GHeight)), DClr["MaxMinL"])
            iText57(IDGraph, Border, GTop+GHeight/2-GFontH12, "PHASE ERROR", \
                    DClr["Label"])
            YRange = yRange(ICPEMin, ICPEMax)
# Add labels to the lines with the max and min range.
            if abs(ICPEMax) > 1000.0:
                Label = str(ICPEMax/1000.0)+"s"
            elif abs(ICPEMax) > 1.0:
                Label = str(ICPEMax)+"ms"
            else:
                Label = str(ICPEMax*1000.0)+"us"
# "-5" just leaves a bit of space between the end of the number and the start
# of the line.
            Xx = MFLead-len(Label)*GFontW-5
            iText57(IDGraph, Xx, GTop-GFontH12, Label, DClr["MaxMinV"])
            if abs(ICPEMin) > 1000.0:
                Label = str(ICPEMin/1000.0)+"s"
            elif abs(ICPEMin) > 1.0:
                Label = str(ICPEMin)+"ms"
            else:
                Label = str(ICPEMin*1000.0)+"us"
            Xx = MFLead-len(Label)*GFontW-5
            iText57(IDGraph, Xx, GTop+GHeight-GFontH12, Label, DClr["MaxMinV"])
# Draw the connecting line, then the points on top of it.
            for Data in ICPE:
                if Data[1] >= CurMainStart:
                    LastX = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    LastY = GTop+(GHeight-GHeight*(Data[2]-ICPEMin)/YRange)
                    break
# Will stay 0 if there is nothing to plot.
            Xx = 0
            Yy = 0
            for Data in ICPE:
                if Data[1] >= CurMainStart:
                    if Data[1] <= CurMainEnd:
                        Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                        Yy = GTop+(GHeight-GHeight*(Data[2]-ICPEMin)/YRange)
                        IDGraph.line(((LastX, LastY), (Xx, Yy)), DClr["Plot"])
                        IDGraph.rectangle((LastX-1.5, LastY-1.5, LastX+1.5, \
                                LastY+1.5), DClr["ICPE"])
                        ICPExy.append((Data[0], Xx, Yy))
                        LastX = Xx
                        LastY = Yy
                    else:
                        if OPTIgTEC == 0:
                            break
            if Xx != 0 and Yy != 0:
                IDGraph.rectangle((Xx-1.5, Yy-1.5, Xx+1.5, Yy+1.5), \
                        DClr["ICPE"])
            iText57(IDGraph, MFLead+MFGW+Border, GTop+GHeight/2-GFontH12, \
                    str(len(ICPExy)), DClr["ICPE"])
        Top += PixPerWeight*DPlotWts["ICPE"]
# Time Jerks and DSP resets(72's) or DSP sets(130's).
    if DGrf["JERK"].get() == 1:
        setMsg("MF", "CB", "Plotting clock related messages...")
        del JERKxy[:]
        del DRSETxy[:]
        Yy = Top+PixPerWeight*DPlotWts["JERK"]/2.0
        IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
        iText57(IDGraph, Border, Yy-GFontH12, "JERKS/DSP SETS", DClr["Label"])
        for Data in JERK:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    if Data[2] == 0:
                        IDGraph.rectangle((Xx-1.5, Yy-4.0, Xx+1.5, Yy-1), \
                                DClr["JERK"])
                        JERKxy.append((Data[0], Xx, Yy-2.0))
                    else:
                        IDGraph.rectangle((Xx-1.5, Yy+1, Xx+1.5, Yy+4.0), \
                                DClr["DRSET"])
                        DRSETxy.append((Data[0], Xx, Yy+2.0))
                else:
                    if OPTIgTEC == 0:
                        break
        iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH, str(len(JERKxy)), \
                DClr["JERK"])
        iText57(IDGraph, MFLead+MFGW+Border, Yy+1, str(len(DRSETxy)), \
                DClr["DRSET"])
        Top += PixPerWeight*DPlotWts["JERK"]
# .err file plots.
    if DGrf["ERR"].get() == 1 and len(TMJMP) > 0:
        setMsg("MF", "CB", "Plotting err file data...")
# Will be 'DSx:Y'.
        Yy = {}
        del TMJMPxy[:]
# Will be 'DS:number of points plotted'.
        PCount = {}
        GTop = Top+GFontH12
# There needs to be just a liitle bit more space here for some reason.
        GTop += (PixPerWeight*DPlotWts["ERR"]-GFontH12/len(MaxERR))/2
        for DS in MaxERR:
            Yy[DS] = GTop
            GTop = GTop+PixPerWeight*DPlotWts["ERR"]-GFontH12/len(MaxERR)
# Stick this in here now so we don't have to has_key() below.
            PCount[DS] = 0
        for DS in MaxERR:
            IDGraph.line(((MFLead, Yy[DS]), (MFLead+MFGW, Yy[DS])), \
                    DClr["MaxMinL"])
            iText57(IDGraph, Border, Yy[DS]-GFontH12, "ERR CH%d"%DS, \
                    DClr["Label"])
        for Data in TMJMP:
            if Data[1] >= CurMainStart and Data[1] <= CurMainEnd and \
                    Data[2] >= CurMainStart and Data[2] <= CurMainEnd:
                X1 = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                X2 = MFLead+MFGW*(Data[2]-CurMainStart)/Timerange
                DS = Data[3]
                if X1 < X2:
                    IDGraph.rectangle((X1, Yy[DS]-4.0, X2, Yy[DS]-1.0), \
                            DClr["TMJMPPos"])
# We'll do this in here so we always get stuff in the correct time order for
# the handlePoint() routine.
                    TMJMPxy.append((Data[0], X1, X2, Yy[DS]-2.0, 1))
                else:
                    IDGraph.rectangle((X1, Yy[DS]+1.0, X2, Yy[DS]+4.0), \
                            DClr["TMJMPNeg"])
                    TMJMPxy.append((Data[0], X2, X1, Yy[DS]+2.0, -1))
                PCount[DS] += 1
        for DS in MaxERR:
            iText57(IDGraph, MFLead+MFGW+Border, Yy[DS]-GFontH12, \
                    str(PCount[DS]), DClr["Label"])
        Top += PixPerWeight*DPlotWts["ERR"]*len(MaxERR)
# GPS on/off.
    if DGrf["GPSON"].get() == 1:
        setMsg("MF", "CB", "Plotting GPS power messages...")
        del GPSxy[:]
        Yy = Top+PixPerWeight*DPlotWts["GPSON"]/2.0
        IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
        iText57(IDGraph, Border, Yy-GFontH12, "GPS ON/OFF", DClr["Label"])
        PCount0 = 0
        PCount1 = 0
        for Data in GPS:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    if Data[2] == 0:
                        PCount0 += 1
                        IDGraph.rectangle((Xx-1.5, Yy+1, Xx+1.5, Yy+4.0), \
                                DClr["GPSOff"])
                        GPSxy.append((Data[0], Xx, Yy+2.0, Data[2]))
                    else:
                        PCount1 += 1
                        IDGraph.rectangle((Xx-1.5, Yy-4.0, Xx+1.5, Yy-1), \
                                DClr["GPSOn"])
                        GPSxy.append((Data[0], Xx, Yy-2.0, Data[2]))
                else:
                    if OPTIgTEC == 0:
                        break
        iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH, str(PCount1), \
                DClr["GPSOn"])
        iText57(IDGraph, MFLead+MFGW+Border, Yy+1, str(PCount0), \
                DClr["GPSOff"])
        Top += PixPerWeight*DPlotWts["GPSON"]
# External clock locked/unlocked, power state.
    if DGrf["GPSLK"].get() == 1:
        setMsg("MF", "CB", "Plotting GPS lock messages...")
        del GPSLKxy[:]
        Ylk = Top+GFontH12
        Yulk = Top+PixPerWeight*DPlotWts["GPSLK"]-GFontH
        if len(GPSLK) == 0:
            iText57(IDGraph, Border, (Yulk+Ylk)/2-GFontH12, \
                    "GPS LK-UNLK: NO GPS STATUS MESSAGES FOUND.", \
                    DClr["Label"])
        else:
            IDGraph.line(((MFLead, Ylk), (MFLead+MFGW, Ylk)), DClr["MaxMinL"])
            IDGraph.line(((MFLead, Yulk), (MFLead+MFGW, Yulk)), \
                    DClr["MaxMinL"])
            iText57(IDGraph, Border, (Yulk+Ylk)/2-GFontH12, "GPS LK-UNLK", \
                    DClr["Label"])
            LastX = 0
            LastY = 0
            for Data in GPSLK:
                if Data[1] >= CurMainStart:
                    if Data[2] == 0:
                        LastY = Yulk
                    else:
                        LastY = Ylk
                    LastX = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    break
            PCount0 = 0
            PCount1 = 0
            for Data in GPSLK:
                if Data[1] >= CurMainStart:
                    if Data[1] <= CurMainEnd:
                        Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                        if Data[2] == 0:
                            GPSLKxy.append((Data[0], Xx, Yulk))
                            IDGraph.line(((LastX, LastY), (Xx, Yulk)), \
                                    DClr["Plot"])
                            IDGraph.rectangle((LastX-1.5, LastY-1.5, \
                                    LastX+1.5, LastY+1.5), DClr["GPSLK"])
                            LastY = Yulk
                            PCount0 += 1
                        else:
                            GPSLKxy.append((Data[0], Xx, Ylk))
                            IDGraph.line(((LastX, LastY), (Xx, Ylk)), \
                                    DClr["Plot"])
                            IDGraph.rectangle((LastX-1.5, LastY-1.5, \
                                    LastX+1.5, LastY+1.5), DClr["GPSLK"])
                            LastY = Ylk
                            PCount1 += 1
                        LastX = Xx
                    else:
                        if OPTIgTEC == 0:
                            break
            if LastX != 0 and LastY != 0:
                IDGraph.rectangle((Xx-1.5, LastY-1.5, Xx+1.5, LastY+1.5), \
                        DClr["GPSLK"])
            iText57(IDGraph, MFLead+MFGW+Border, Ylk-GFontH12, str(PCount1), \
                    DClr["GPSLK"])
            iText57(IDGraph, MFLead+MFGW+Border, Yulk-GFontH12, \
                    str(PCount0), DClr["GPSLK"])
            del CLKPWRxy[:]
            Ypwr = (Ylk+Yulk)/2
            PCount0 = 0
            for Data in CLKPWR:
                if Data[1] >= CurMainStart:
                    if Data[1] <= CurMainEnd:
                        Xx = MFLead+(MFGW*(Data[1]-CurMainStart)/Timerange)
                        CLKPWRxy.append((Data[0], Xx, Ypwr))
                        IDGraph.rectangle((Xx-1.5, Ypwr-1.5, Xx+1.5, \
                                Ypwr+1.5), DClr["CLKPWR"])
                        PCount0 += 1
                    else:
                        if OPTIgTEC == 0:
                            break
            iText57(IDGraph, MFLead+MFGW+Border, Ypwr-GFontH12, \
                    str(PCount0), DClr["CLKPWR"])
        Top += PixPerWeight*DPlotWts["GPSLK"]
# Temperatures.
    if DGrf["TEMP"].get() == 1:
        setMsg("MF", "CB", "Plotting temperatures...")
        GTop = Top+GFontH12
        TBHeight = PixPerWeight*DPlotWts["TEMP"]-GFontH
        del TEMPxy[:]
        if len(TEMP) == 0:
            iText57(IDGraph, Border, GTop+TBHeight/2-GFontH12, \
                    "DAS TEMP: NO TEMPERATURE MESSAGES FOUND.", DClr["Label"])
        else:
            IDGraph.line(((MFLead, GTop), (MFLead+MFGW, GTop)), \
                    DClr["MaxMinL"])
            IDGraph.line(((MFLead, GTop+TBHeight), (MFLead+MFGW, \
                    GTop+TBHeight)), DClr["MaxMinL"])
            iText57(IDGraph, Border, GTop+TBHeight/2-GFontH12, "DAS TEMP", \
                    DClr["Label"])
            Label = str(TEMPMax)+"C"
# "-5" just leaves a bit of space between the end of the number and the start
# of the line.
            Xx = MFLead-len(Label)*GFontW-5
            iText57(IDGraph, Xx, GTop-GFontH12, Label, DClr["MaxMinV"])
            Label = str(TEMPMin)+"C"
            Xx = MFLead-len(Label)*GFontW-5
            iText57(IDGraph, Xx, GTop+TBHeight-GFontH12, Label, \
                    DClr["MaxMinV"])
            YRange = yRange(TEMPMin, TEMPMax)
# Draw the connecting line, then the points on top of it.
            for Data in TEMP:
                if Data[1] >= CurMainStart:
                    LastX = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    LastY = GTop+(TBHeight-TBHeight*(Data[2]-TEMPMin)/YRange)
                    break
            Xx = 0
            Yy = 0
            for Data in TEMP:
                if Data[1] >= CurMainStart:
                    if Data[1] <= CurMainEnd:
                        Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                        Yy = GTop+(TBHeight-TBHeight*(Data[2]-TEMPMin)/YRange)
                        TEMPxy.append((Data[0], Xx, Yy))
                        IDGraph.line(((LastX, LastY), (Xx, Yy)), DClr["Plot"])
                        IDGraph.rectangle((LastX-1.5, LastY-1.5, LastX+1.5, \
                                LastY+1.5), DClr["TEMP"])
                        LastX = Xx
                        LastY = Yy
                    else:
                        if OPTIgTEC == 0:
                            break
            if Xx != 0 and Yy != 0:
                IDGraph.rectangle((Xx-1.5, Yy-1.5, Xx+1.5, Yy+1.5), \
                        DClr["TEMP"])
            iText57(IDGraph, MFLead+MFGW+Border, GTop+TBHeight/2-GFontH12, \
                    str(len(TEMPxy)), DClr["TEMP"])
        Top += PixPerWeight*DPlotWts["TEMP"]
# Now the battery voltages.
    if DGrf["VOLT"].get() == 1:
        setMsg("MF", "CB", "Plotting battery voltages...")
        GTop = Top+GFontH12
        TBHeight = PixPerWeight*DPlotWts["VOLT"]-GFontH
        del VOLTxy[:]
        YRange = yRange(VOLTMin, VOLTMax)
        if len(VOLT) == 0:
            iText57(IDGraph, Border, GTop+TBHeight/2-GFontH12, \
                    "BATTERY VOLTS: NO BATTERY VOLTAGE MESSAGES FOUND.", \
                    DClr["Label"])
        else:
            IDGraph.line(((MFLead, GTop), (MFLead+MFGW, GTop)), \
                    DClr["MaxMinL"])
            IDGraph.line(((MFLead, GTop+TBHeight), (MFLead+MFGW, \
                    GTop+TBHeight)), DClr["MaxMinL"])
            iText57(IDGraph, Border, GTop+TBHeight/2-GFontH12, \
                    "BATTERY VOLTS", DClr["Label"])
            Label = str(VOLTMax)+"V"
# "-5" just leaves a bit of space between the end of the number and the start
# of the line.
            Xx = MFLead-len(Label)*GFontW-5
            iText57(IDGraph, Xx, GTop-GFontH12, Label, DClr["MaxMinV"])
            Label = str(VOLTMin)+"V"
            Xx = MFLead-len(Label)*GFontW-5
            iText57(IDGraph, Xx, GTop+TBHeight-GFontH12, Label, \
                    DClr["MaxMinV"])
            for Data in VOLT:
                if Data[1] >= CurMainStart:
                    LastX = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    LastY = GTop+(TBHeight-TBHeight*(Data[2]-VOLTMin)/YRange)
                    break
            Xx = 0
            Yy = 0
            for Data in VOLT:
                if Data[1] >= CurMainStart:
                    if Data[1] <= CurMainEnd:
                        Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                        Yy = GTop+(TBHeight-TBHeight*(Data[2]-VOLTMin)/YRange)
                        VOLTxy.append((Data[0], Xx, Yy))
                        IDGraph.line(((LastX, LastY), (Xx, Yy)), DClr["Plot"])
                        IDGraph.rectangle((LastX-1.5, LastY-1.5, LastX+1.5, \
                                LastY+1.5), DClr["VOLT"])
                        LastX = Xx
                        LastY = Yy
                    else:
                        if OPTIgTEC == 0:
                            break
            if Xx != 0 and Yy != 0:
                IDGraph.rectangle((Xx-1.5, Yy-1.5, Xx+1.5, Yy+1.5), \
                        DClr["VOLT"])
            iText57(IDGraph, MFLead+MFGW+Border, GTop+TBHeight/2-GFontH12, \
                    str(len(VOLTxy)), DClr["VOLT"])
        Top += PixPerWeight*DPlotWts["VOLT"]
# BKUP battery voltage messages.
    if DGrf["BKUP"].get() == 1 and RTModel == "RT130":
        setMsg("MF", "CB", "Plotting backup battery voltage information...")
        del BKUPxy[:]
        Yy = Top+PixPerWeight*DPlotWts["BKUP"]/2.0
        IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
        iText57(IDGraph, Border, Yy-GFontH12, "BACKUP VOLTS", DClr["Label"])
        for Data in BKUP:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    if Data[3] == 1:
                        C = "BKUPG"
                    elif Data[3] == 2:
                        C = "BKUPB"
                    else:
                        C = "BKUPU"
                    BKUPxy.append((Data[0], Xx, Yy, C))
                    IDGraph.rectangle((Xx-1.5, Yy-1.5, Xx+1.5, Yy+1.5), \
                            DClr[C])
                else:
                    if OPTIgTEC == 0:
                        break
        iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH12, str(len(BKUPxy)), \
                DClr["BKUP"])
        Top += PixPerWeight*DPlotWts["BKUP"]
# Auto Dump Called/Completed.
    if DGrf["DUMP"].get() == 1:
        setMsg("MF", "CB", "Plotting dump call messages...")
        del DUMPxy[:]
        Yy = Top+PixPerWeight*DPlotWts["DUMP"]/2.0
        IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
        iText57(IDGraph, Border, Yy-GFontH12, "DUMP CALL", DClr["Label"])
        PCount0 = 0
        PCount1 = 0
        for Data in DUMP:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    if Data[2] == 1:
                        IDGraph.rectangle((Xx-1.5, Yy-4.0, Xx+1.5, Yy-1), \
                                DClr["DUMPOn"])
                        DUMPxy.append((Data[0], Xx, Yy-2.0, Data[2]))
                        PCount1 += 1
                    else:
                        IDGraph.rectangle((Xx-1.5, Yy+1.0, Xx+1.5, Yy+4.0), \
                                DClr["DUMPOff"])
                        DUMPxy.append((Data[0], Xx, Yy+2.0, Data[2]))
                        PCount0 += 1
                else:
                    if OPTIgTEC == 0:
                        break
        iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH, str(PCount1), \
                DClr["DUMPOn"])
        iText57(IDGraph, MFLead+MFGW+Border, Yy+1, str(PCount0), \
                DClr["DUMPOff"])
        Top += PixPerWeight*DPlotWts["DUMP"]
# Acquisition on/off.
    if DGrf["ACQ"].get() == 1:
        del ACQxy[:]
        Yy = Top+PixPerWeight*DPlotWts["ACQ"]/2.0
        IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
        iText57(IDGraph, Border, Yy-GFontH12, "ACQ ON-OFF", DClr["Label"])
        PCount0 = 0
        PCount1 = 0
        for Data in ACQ:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    if Data[2] == 0:
                        IDGraph.rectangle((Xx-1.5, Yy+1.0, Xx+1.5, Yy+4.0), \
                                DClr["ACQStop"])
                        ACQxy.append((Data[0], Xx, Yy+2.0, Data[2]))
                        PCount0 += 1
                    else:
                        IDGraph.rectangle((Xx-1.5, Yy-4.0, Xx+1.5, Yy-1.0), \
                                DClr["ACQStart"])
                        ACQxy.append((Data[0], Xx, Yy-2.0, Data[2]))
                        PCount1 += 1
                else:
                    if OPTIgTEC == 0:
                        break
        iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH, str(PCount1), \
                DClr["ACQStart"])
        iText57(IDGraph, MFLead+MFGW+Border, Yy+1, str(PCount0), \
                DClr["ACQStop"])
        Top += PixPerWeight*DPlotWts["ACQ"]
# Station reset graph.
    if DGrf["RESET"].get() == 1:
        setMsg("MF", "CB", "Plotting reset information...")
        del PWRUPxy[:]
        del RESETxy[:]
        Yy = Top+PixPerWeight*DPlotWts["RESET"]/2.0
        IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
        iText57(IDGraph, Border, Yy-GFontH12, "RESET/POWERUP", DClr["Label"])
        for Data in RESET:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    RESETxy.append((Data[0], Xx, Yy-2.0))
                    IDGraph.rectangle((Xx-1.5, Yy-4.0, Xx+1.5, Yy-1.0), \
                            DClr["RESET"])
                else:
                    break
        for Data in PWRUP:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    PWRUPxy.append((Data[0], Xx, Yy+2.0))
                    IDGraph.rectangle((Xx-1.5, Yy+1.0, Xx+1.5, Yy+4.0), \
                            DClr["PWRUP"])
                else:
                    if OPTIgTEC == 0:
                        break
        iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH, str(len(RESETxy)), \
                DClr["RESET"])
        iText57(IDGraph, MFLead+MFGW+Border, Yy+1, str(len(PWRUPxy)), \
                DClr["PWRUP"])
        Top += PixPerWeight*DPlotWts["RESET"]
# WARNING/ERROR messages.
    if DGrf["ERRWARN"].get() == 1:
        setMsg("MF", "CB", "Plotting warning/error messages...")
        del WARNxy[:]
        del ERRORxy[:]
        Yy = Top+PixPerWeight*DPlotWts["ERRWARN"]/2.0
        IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
        iText57(IDGraph, Border, Yy-GFontH12, "ERROR/WARNING", DClr["Label"])
        for Data in ERROR:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    ERRORxy.append((Data[0], Xx, Yy-2.0))
                    IDGraph.rectangle((Xx-1.5, Yy-4.0, Xx+1.5, Yy-1.0), \
                            DClr["ERROR"])
                else:
                    if OPTIgTEC == 0:
                        break
        for Data in WARN:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    WARNxy.append((Data[0], Xx, Yy+2.0))
                    IDGraph.rectangle((Xx-1.5, Yy+1.0, Xx+1.5, Yy+4.0), \
                            DClr["WARN"])
                else:
                    if OPTIgTEC == 0:
                        break
        iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH, str(len(ERRORxy)), \
                DClr["ERROR"])
        iText57(IDGraph, MFLead+MFGW+Border, Yy+1, str(len(WARNxy)), \
                DClr["WARN"])
        Top += PixPerWeight*DPlotWts["ERRWARN"]
# DISCREP messages.
    if DGrf["DISCREP"].get() == 1:
        setMsg("MF", "CB", "Plotting discrepancy information...")
        del DISCREPxy[:]
        Yy = Top+PixPerWeight*DPlotWts["DISCREP"]/2.0
        IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
        iText57(IDGraph, Border, Yy-GFontH12, "DISCREPANCIES", DClr["Label"])
        for Data in DISCREP:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    DISCREPxy.append((Data[0], Xx, Yy))
                    IDGraph.rectangle((Xx-1.5, Yy-1.5, Xx+1.5, Yy+1.5), \
                            DClr["DISCREP"])
                else:
                    if OPTIgTEC == 0:
                        break
        iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH12, \
                str(len(DISCREPxy)), DClr["DISCREP"])
        Top += PixPerWeight*DPlotWts["DISCREP"]
# Station Channel definitions/SOH info.
    if DGrf["SOHDEF"].get() == 1:
        del SOHxy[:]
        del DEFSxy[:]
        Yy = Top+PixPerWeight*DPlotWts["SOHDEF"]/2.0
        IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
        iText57(IDGraph, Border, Yy-GFontH12, "SOH/DATA DEFS", DClr["Label"])
        for Data in SOH:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    IDGraph.rectangle((Xx-1.5, Yy-4.0, Xx+1.5, Yy-1.0), \
                            DClr["SOH"])
                    SOHxy.append((Data[0], Xx, Yy-2.0))
                else:
                    if OPTIgTEC == 0:
                        break
        for Data in DEFS:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    IDGraph.rectangle((Xx-1.5, Yy+1.0, Xx+1.5, Yy+4.0), \
                            DClr["DEFS"])
                    DEFSxy.append((Data[0], Xx, Yy+2.0))
                else:
                    if OPTIgTEC == 0:
                        break
        iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH, str(len(SOHxy)), \
                DClr["SOH"])
        iText57(IDGraph, MFLead+MFGW+Border, Yy+1, str(len(DEFSxy)), \
                DClr["DEFS"])
        Top += PixPerWeight*DPlotWts["SOHDEF"]
# Network Up/Down.
    if DGrf["NET"].get() == 1:
        del NETxy[:]
        Yy = Top+PixPerWeight*DPlotWts["NET"]/2.0
        IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
        iText57(IDGraph, Border, Yy-GFontH12, "NET UP-DOWN", DClr["Label"])
        PCount0 = 0
        PCount1 = 0
        for Data in NET:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    if Data[2] == 0:
                        IDGraph.rectangle((Xx-1.5, Yy+1.0, Xx+1.5, Yy+4.0), \
                                DClr["NETDown"])
                        ACQxy.append((Data[0], Xx, Yy+2.0, Data[2]))
                        PCount0 += 1
                    else:
                        IDGraph.rectangle((Xx-1.5, Yy-4.0, Xx+1.5, Yy-1.0), \
                                DClr["NETUp"])
                        ACQxy.append((Data[0], Xx, Yy-2.0, Data[2]))
                        PCount1 += 1
                else:
                    if OPTIgTEC == 0:
                        break
        iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH, str(PCount1), \
                DClr["NETUp"])
        iText57(IDGraph, MFLead+MFGW+Border, Yy+1, str(PCount0), \
                DClr["NETDown"])
        Top += PixPerWeight*DPlotWts["NET"]
# Events/data streams graph(s).
    if DGrf["EVT"].get() == 1:
        setMsg("MF", "CB", "Plotting events/data streams...")
# This will be 'DSx:Y'.
        Yy = {}
        del EVTxy[:]
        GTop = Top+GFontH12
# This will be 'DSx:number of points plotted'. Just fill it in with 0's as we
# go through this loop so we don't have to check has_key() while plotting.
        PCount = {}
        for DS in MaxEVT:
            Yy[DS] = GTop
            GTop = GTop+PixPerWeight*DPlotWts["EVT"]-GFontH12/len(MaxEVT)
            PCount[DS] = 0
        for DS in MaxEVT:
            IDGraph.line(((MFLead, Yy[DS]), (MFLead+MFGW, Yy[DS])), \
                    DClr["MaxMinL"])
            iText57(IDGraph, Border, Yy[DS]-GFontH12, "EVENTS DS%d"%DS, \
                    DClr["Label"])
        for Data in EVT:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    DS = Data[2]
                    IDGraph.rectangle((Xx-1.5, Yy[DS]-1.5, Xx+1.5, \
                            Yy[DS]+1.5), DClr["EVT"])
                    EVTxy.append((Data[0], Xx, Yy[DS]))
                    PCount[DS] += 1
                else:
                    if OPTIgTEC == 0:
                        break
        for DS in MaxEVT:
            iText57(IDGraph, MFLead+MFGW+Border, Yy[DS]-GFontH12, \
                    str(PCount[DS]), DClr["EVT"])
        Top += (PixPerWeight*DPlotWts["EVT"]*len(MaxEVT))
# Mass Re-centering messages.
    if DGrf["MRC"].get() == 1:
        setMsg("MF", "CB", "Plotting centering commands information...")
        del MRCxy[:]
        Yy = Top+PixPerWeight*DPlotWts["MRC"]/2.0
        IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
        iText57(IDGraph, Border, Yy-GFontH12, "RE-CENTER", DClr["Label"])
        for Data in MRC:
            if Data[1] >= CurMainStart:
                if Data[1] <= CurMainEnd:
                    Xx = MFLead+MFGW*(Data[1]-CurMainStart)/Timerange
                    MRCxy.append((Data[0], Xx, Yy))
                    IDGraph.rectangle((Xx-1.5, Yy-1.5, Xx+1.5, Yy+1.5), \
                            DClr["MRC"])
                else:
                    if OPTIgTEC == 0:
                        break
        iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH12, str(len(MRCxy)), \
                DClr["MRC"])
        Top += PixPerWeight*DPlotWts["MRC"]
# MP123 mass position data. These are not messages in the file, but data
# extracted and left in the MPx Lists.
    if DGrf["MP123"].get() == 1:
        setMsg("MF", "CB", "Plotting 123 mass positions...")
        del MP1xy[:]
        del MP2xy[:]
        del MP3xy[:]
        for M in (1, 2, 3):
            Yy = Top+PixPerWeight*DPlotWts["MP123"]/2.0
            IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
            iText57(IDGraph, Border, Yy-GFontH12, "MASS POS %d"%M, \
                    DClr["Label"])
            Datas = eval("MP%d"%M)
# MPx = (Epoch, MP Value, Color Range Code)
            for Data in Datas:
                if Data[0] >= CurMainStart:
                    if Data[0] <= CurMainEnd:
                        Xx = MFLead+MFGW*(Data[0]-CurMainStart)/Timerange
# Put the Epoch in the first position so we can use that for matching when we
# zap points.
                        eval("MP%dxy"%M).append((Data[0], Data[1], Xx, Yy))
                        if Data[2] == 0:
                            C = "MPP"
                        elif Data[2] == 1:
                            C = "MPG"
                        elif Data[2] == 2:
                            C = "MPB"
                        elif Data[2] == 3:
                            C = "MPU"
                        elif Data[2] == 4:
                            C = "MPH"
                        IDGraph.rectangle((Xx-1.5, Yy-1.5, Xx+1.5, Yy+1.5), \
                                DClr[C])
                    else:
                        if OPTIgTEC == 0:
                            break
            iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH12, \
                    str(len(eval("MP%dxy"%M))), DClr["MP"])
            Top += PixPerWeight*DPlotWts["MP123"]
# MP456 mass position (aux data) messages.
    if DGrf["MP456"].get() == 1:
        setMsg("MF", "CB", "Plotting 456 mass positions...")
        del MP4xy[:]
        del MP5xy[:]
        del MP6xy[:]
        for M in (4, 5, 6):
            Yy = Top+PixPerWeight*DPlotWts["MP456"]/2.0
            IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["MaxMinL"])
            iText57(IDGraph, Border, Yy-GFontH12, "MASS POS %d"%M, \
                    DClr["Label"])
            Datas = eval("MP%d"%M)
# MPx = (Epoch, MP Value, Color Range Code)
            for Data in Datas:
                if Data[0] >= CurMainStart:
                    if Data[0] <= CurMainEnd:
                        Xx = MFLead+MFGW*(Data[0]-CurMainStart)/Timerange
# Put the Epoch in the first position so we can use that for matching when we
# zap points.
                        eval("MP%dxy"%M).append((Data[0], Data[1], Xx, Yy))
                        if Data[2] == 0:
                            C = "MPP"
                        elif Data[2] == 1:
                            C = "MPG"
                        elif Data[2] == 2:
                            C = "MPB"
                        elif Data[2] == 3:
                            C = "MPU"
                        elif Data[2] == 4:
                            C = "MPH"
                        IDGraph.rectangle((Xx-1.5, Yy-1.5, Xx+1.5, Yy+1.5), \
                                DClr[C])
                    else:
                        if OPTIgTEC == 0:
                            break
            iText57(IDGraph, MFLead+MFGW+Border, Yy-GFontH12, \
                    str(len(eval("MP%dxy"%M))), DClr["MP"])
            Top += PixPerWeight*DPlotWts["MP456"]
# Now the X-axis scale across the bottom of the graph area.
    Yy = TopSpace+AGHeight+GFontH12
    IDGraph.line(((MFLead, Yy), (MFLead+MFGW, Yy)), DClr["Ticks"])
    MFTickY = Yy
    TickX = []
# Plot tick marks showing months, days, hours, minutes or seconds depending
# on the range of the currently displayed graph.
    Zero = epoch2Str(CurMainStart)
# 30 days.
    if Timerange >= 2592000.0:
        iText57(IDGraph, Border, Yy-GFontH12, "10DAYS", DClr["Label"])
        MFTimeMode = "DD"
        Zero = Zero[:9]+"00:00:00"
        Add = 864000.0
    elif Timerange >= 864000.0:
        iText57(IDGraph, Border, Yy-GFontH12, "DAYS", DClr["Label"])
        MFTimeMode = "D"
        Zero = Zero[:9]+"00:00:00"
        Add = 86400.0
    elif Timerange >= 3600.0:
        iText57(IDGraph, Border, Yy-GFontH12, "HOURS", DClr["Label"])
        MFTimeMode = "H"
        Zero = Zero[:12]+"00:00"
        Add = 3600.0
    elif Timerange >= 60.0:
        iText57(IDGraph, Border, Yy-GFontH12, "MINUTES", DClr["Label"])
        MFTimeMode = "M"
        Zero = Zero[:15]+"00"
        Add = 60.0
    else:
        iText57(IDGraph, Border, Yy-GFontH12, "SECONDS", DClr["Label"])
        MFTimeMode = "S"
        Zero = Zero[:17]
        Add = 1.0
    Time = str2Epoch(None, Zero)
    LastTimeEndX = 0.0
    First = True
    while 1:
        Time += Add
        if Time < CurMainEnd:
            if Time >= CurMainStart:
                GX = MFLead+MFGW*(Time-CurMainStart)/Timerange
                IDGraph.line(((GX, Yy-2), (GX, Yy)), DClr["Ticks"])
                TickX.append(GX)
                if OPTDateFormatRVar.get() == "YYYY:DDD":
                    Zero = epoch2Str(Time)[:17]
                elif OPTDateFormatRVar.get() == "YYYYMMMDD":
                    Zero = ydhms2ymdhms(epoch2Str(Time)[:17])
                elif OPTDateFormatRVar.get() == "YYYY-MM-DD":
                    Zero = ydhms2ymdhmsDash(epoch2Str(Time)[:17])
                elif OPTDateFormatRVar.get() == "":
                    Zero = str(Time)
                Length = len(Zero)*GFontW
                Length2 = Length/2
# Print the date/time of the first and last ticks.
                if First == True or (GX-Length2) > (LastTimeEndX+100):
                    IDGraph.line(((GX, Yy-6), (GX, Yy)), DClr["Ticks"])
# Keep the times away from extending to far left or right.
                    if (GX-Length2) < MFLead:
                        GXX = MFLead
                    elif (GX+Length2) > (MFLead+MFGW):
                        GXX = MFLead+MFGW-Length
                    else:
                        GXX = GX-Length2
                    LastTimeEndX = GXX+Length
# Fudging to get the text in just the right place.
                    iText57(IDGraph, GXX, TopSpace+AGHeight+GFontH, Zero, \
                            DClr["Ticks"])
                    First = False
        else:
            break
# Display it.
    setMsg("MF", "CB", "Drawing...")
    MFTKGraph = ImageTk.PhotoImage(PILGraph)
    LCan.create_image(0, 0, anchor = NW, image = MFTKGraph)
    if OPTDateFormatRVar.get() == "YYYY:DDD":
        Msg = "Showing: "+epoch2Str(CurMainStart)+" to "+epoch2Str(CurMainEnd)
    elif OPTDateFormatRVar.get() == "YYYYMMMDD":
        Msg = "Showing: "+ydhms2ymdhms(epoch2Str(CurMainStart))+" to "+ \
                ydhms2ymdhms(epoch2Str(CurMainEnd))
    elif OPTDateFormatRVar.get() == "YYYY-MM-DD":
        Msg = "Showing: "+ydhms2ymdhmsDash(epoch2Str(CurMainStart))+" to "+ \
                ydhms2ymdhmsDash(epoch2Str(CurMainEnd))
    elif OPTDateFormatRVar.get() == "":
        Msg = "Showing: "+str(CurMainStart)+" to "+str(CurMainEnd)
    if CurMainStart != FStart or CurMainEnd != FEnd:
        Msg += " (zoomed)"
    if MFZapped != 0:
        if MFZapped == 1:
            Msg += "   1 point zapped."
        else:
            Msg += "    %d points zapped."%MFZapped
# If the caller is also going to plot raw data then they won't want this stuff
# to happen. The message will be saved by the caller until everything is done.
    if WhereMsg != None:
        setMsg(WhereMsg, "", Msg)
    MFGraphed = True
    return Msg
##########################
# BEGIN: plotMFClear(What)
# FUNC:plotMFClear():2010.251
def plotMFClear(What):
    global MFTKGraph
    global MFGridOn
    global FirstSelRule
    global SecondSelRule
    global MFGraphed
    global MFZapped
# The user may have selected a different color scheme, so get everything
# ready for that.
    setColors()
    if MFGraphed == True:
        LCan = Can["MF"]
        LCan.delete("all")
        MFGridOn = False
        LCan.delete(FirstSelRule)
        FirstSelRule = None
        LCan.delete(SecondSelRule)
        SecondSelRule = None
        del MFTKGraph
        LCan.configure(bg = DClr["MFCAN"])
        setMsg("MF", "", "")
        MFGraphed = False
# If What is not "all" then we must just be zooming or something.
        if What == "all":
# Clear out the lines from an old file.
            if Frm["LOG"] != None:
                Txt["LOG"].delete(0.0, END)
# Close any old err file window.
            if Frm["ERR"] != None:
                closeForm("ERR")
# Close any old GPS plot display.
            if Frm["GPS"] != None:
                closeForm("GPS")
# Close any log search window.
            if Frm["SEARCH"] != None:
                closeForm("SEARCH")
            setInfoMsg("")
            MFZapped = 0
    updateMe(0)
    return
########################
# BEGIN: plotMFClock(CX)
# FUNC:plotMFClock():2010.251
#   Actually draws the RAW clock rule and time.
def plotMFClock(CX):
    LCan = Can["MF"]
    LCan.delete("Clock")
# Just to the left of the graphs...
    if CX < MFLead:
        CX = MFLead
# Just to the right of the graphs...
    elif CX > MFLead+MFGW:
        CX = MFLead+MFGW
# Draw the rule then figure out where to draw the date/time.
    LCan.create_line(CX, TopSpace, CX, CHeight-TopSpace-BotSpace/2, \
            fill = DClr["Sel"], tags = "Clock")
    Epoch = plotMFEpochAtX(CX)
    if MFTimeMode != "S":
        if OPTDateFormatRVar.get() == "YYYY:DDD":
            Time = epoch2Str(Epoch)[:17]
        elif OPTDateFormatRVar.get() == "YYYYMMMDD":
            Time = ydhms2ymdhms(epoch2Str(Epoch)[:17])
        elif OPTDateFormatRVar.get() == "YYYY-MM-DD":
            Time = ydhms2ymdhmsDash(epoch2Str(Epoch)[:17])
        elif OPTDateFormatRVar.get() == "":
            Time = str(Epoch)
    else:
        if OPTDateFormatRVar.get() == "YYYY:DDD":
            Time = epoch2Str(Epoch)
        elif OPTDateFormatRVar.get() == "YYYYMMMDD":
            Time = ydhms2ymdhms(epoch2Str(Epoch))
        elif OPTDateFormatRVar.get() == "YYYY-MM-DD":
            Time = ydhms2ymdhmsDash(epoch2Str(Epoch))
        elif OPTDateFormatRVar.get() == "":
            Time = str(Epoch)
# Adjust the time to be centered over the rule, but don't print it beyond the
# beginning or the end of the graph.
    Length12 = CFont.measure(Time)/2
    if CX+Length12 > MFLead+MFGW:
        CX = MFLead+MFGW-Length12
    if CX-Length12 < MFLead:
        CX = MFLead+Length12
    LCan.create_text(CX, GFontH, fill = DClr["Time"], font = CFont, \
            text = Time, tags = "Clock")
    return Epoch
###########################
# BEGIN: plotMFEpochAtX(CX)
# FUNC:plotMFEpochAtX():2010.251
#    Takes the passed CX pixel location and returns the epoch time at that
#    graph location on the main form.
def plotMFEpochAtX(CX):
# How far across the graph did we click?
    Time = (CX-MFLead)/MFGW
    Time = CurMainStart+(CurTimerange*Time)
    return Time
##############################
# BEGIN: plotMFXAtEpoch(Epoch)
# FUNC:plotMFXAtEpoch():2010.251
def plotMFXAtEpoch(Epoch):
    XX = (Epoch-CurMainStart)/CurTimerange
    XX = MFLead+(MFGW*XX)
    return XX
############################
# BEGIN: plotMFPointClick(e)
# FUNC:plotMFPointClick():2010.251
#   Handles all regular clicking on the MF Canvas.
def plotMFPointClick(e):
    global CurMainStart
    global CurMainEnd
    if MFGraphed == False:
        setMsg("MF", "RW", "Nothing is plotted.", 2)
        return
    if Frm["LOG"] == None:
        setMsg("MF", "RW", "There is no LOG Messages window.", 2)
        return
    LFrm = Frm["LOG"]
    LTxt = Txt["LOG"]
    LCan = Can["MF"]
    CX = LCan.canvasx(e.x)
    CY = LCan.canvasy(e.y)
# Check to see if the user did a regular click below the tick marks and scroll
# the timerange accordingly.
    if CY >= MFTickY:
        if CurMainStart != FStart or CurMainEnd != FEnd:
# We will move 90% of the currently displayed range.
            MoveRange = yRange(CurMainStart, CurMainEnd)*.90
            CHalf = LCan.winfo_width()/2.0
            if CX < CHalf:
# Check to see if we are already against the start time.
                if CurMainStart == FStart:
                    beep(1)
                    return
# Adjust the start and end times checking to make sure we don't try to plot
# stuff beyond either end of the file start and end times.
                if CurMainStart-MoveRange < FStart:
                    CurMainStart = FStart
                    CurMainEnd = CurMainStart+MoveRange
                else:
                    CurMainStart -= MoveRange
                    CurMainEnd -= MoveRange
            else:
                if CurMainEnd == FEnd:
                    beep(1)
                    return
                if CurMainEnd+MoveRange > FEnd:
                    CurMainEnd = FEnd
                    CurMainStart = CurMainEnd-MoveRange
                else:
                    CurMainStart += MoveRange
                    CurMainEnd += MoveRange
            progControl("gozoom")
            setMinMax()
            Msge = plotMF(None)
            plotRAW()
            plotTPS()
            setMsg("MF", "", Msge)
            progControl("stopped")
        else:
            beep(1)
        return
# See if they clicked on a dot.
# Get rid of any previously selected line(s).
    LTxt.tag_delete("standout")
    if Frm["ERR"] != None:
        Txt["ERR"].tag_delete("standout")
# Look at a 6x8 pixel area centered on the click location (the dots are 3wx4h).
    XL = CX-3
    XM = CX+3
    YL = CY-4
    YM = CY+4
# Now check to see what point we clicked near.
    if DGrf["ACQ"].get() == 1:
        for Data in ACQxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                if Data[3] == 0:
                    LTxt.tag_configure("standout",
                            background = DClr["ACQStopBG"], \
                            foreground = Clr["B"])
                else:
                    LTxt.tag_configure("standout",
                            background = DClr["ACQStartBG"], \
                            foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["DUMP"].get() == 1:
        for Data in DUMPxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                if Data[3] == 1:
                    LTxt.tag_configure("standout",
                            background = DClr["DUMPOnBG"], \
                            foreground = Clr["B"])
                else:
                    LTxt.tag_configure("standout", \
                            background = DClr["DUMPOffBG"], \
                            foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["VOLT"].get() == 1:
        for Data in VOLTxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["VOLTBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["TEMP"].get() == 1:
        for Data in TEMPxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["TEMPBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["DCDIFF"].get() == 1:
        for Data in DCDIFFxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["DCDIFFBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["GPSLK"].get() == 1:
        for Data in GPSLKxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["GPSLKBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
        for Data in CLKPWRxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["CLKPWRBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["EVT"].get() == 1:
        for Data in EVTxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["EVTBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["GPSON"].get() == 1:
        for Data in GPSxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                if Data[3] == 0:
                    LTxt.tag_configure("standout", \
                            background = DClr["GPSOffBG"], \
                            foreground = Clr["B"])
                else:
                    LTxt.tag_configure("standout", \
                            background = DClr["GPSOnBG"], \
                            foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["ICPE"].get() == 1:
        for Data in ICPExy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["ICPEBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["JERK"].get() == 1:
        for Data in JERKxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["JERKBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
        for Data in DRSETxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["DRSETBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["RESET"].get() == 1:
        for Data in RESETxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["RESETBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
        for Data in PWRUPxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["PWRUPBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["MRC"].get() == 1:
        for Data in MRCxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["MRCBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["SOHDEF"].get() == 1:
        for Data in SOHxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["SOHBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
        for Data in DEFSxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["DEFSBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["DISCREP"].get() == 1:
        for Data in DISCREPxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", \
                        background = DClr["DISCREPBG"], \
                        foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["BKUP"].get() == 1:
        for Data in BKUPxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", \
                        background = DClr[Data[3]+"BG"], foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
# These are different.
# MPxxy = (Epoch, MP Value, X, Y)
# Just show the value in the status area if a point is clicked on.
    if DGrf["MP123"].get() == 1:
        for M in (1, 2, 3):
            Datas = eval("MP%dxy"%M)
            for Data in Datas:
                if Data[2] >= XL and Data[2] <= XM and Data[3] >= YL and \
                        Data[3] <= YM:
                    setMsg("MF", "", \
                            "Channel %d mass position voltage: %.1fV"%(M, \
                            Data[1]))
                    return
    if DGrf["MP456"].get() == 1:
        for M in (4, 5, 6):
            Datas = eval("MP%dxy"%M)
            for Data in Datas:
                if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                        Data[2] <= YM:
                    setMsg("MF", "", \
                            "Channel %d mass position voltage: %.1fV"%(M, \
                            Data[0]))
                    return
    if DGrf["ERRWARN"].get() == 1:
        for Data in ERRORxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["ERRORBG"], \
                      foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
        for Data in WARNxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                LTxt.tag_configure("standout", background = DClr["WARNBG"], \
                       foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
    if DGrf["NET"].get() == 1:
        for Data in NETxy:
            if Data[1] >= XL and Data[1] <= XM and Data[2] >= YL and \
                    Data[2] <= YM:
                LTxt.yview(Data[0]-5)
                LTxt.tag_add("standout", str(Data[0])+".0", \
                        str(Data[0])+".end")
                if Data[3] == 0:
                    LTxt.tag_configure("standout",
                            background = DClr["NETDownBG"], \
                            foreground = Clr["B"])
                else:
                    LTxt.tag_configure("standout",
                            background = DClr["NETUpBG"], \
                            foreground = Clr["B"])
                LFrm.lift()
                LFrm.deiconify()
                return
# Check for the err file points if there is anything plotted.
    if DGrf["ERR"].get() == 1:
        if Frm["ERR"] == None:
            beep(1)
            return
        if len(TMJMP) > 0 and Frm["ERR"] != None:
            for Data in TMJMPxy:
                if Data[1]-2.0 <= CX and Data[2]+2.0 >= CX and Data[3] >= YL \
                        and Data[3] <= YM:
                    Txt["ERR"].yview(Data[0]-5)
                    Txt["ERR"].tag_add("standout", str(Data[0])+".0", \
                            str(Data[0])+".end")
                    if Data[4] == 1:
                        Txt["ERR"].tag_configure("standout", \
                                background = DClr["TMJMPPosBG"], \
                                foreground = Clr["B"])
                    else:
                        Txt["ERR"].tag_configure("standout", \
                                background = DClr["TMJMPNegBG"], \
                                foreground = Clr["B"])
                    Frm["ERR"].lift()
                    Frm["ERR"].deiconify()
                    return
    return
#######################
# BEGIN: plotMFReplot()
# FUNC:plotMFReplot():2010.251
def plotMFReplot():
    if MFGraphed == False:
        setMsg("MF", "RW", "There is nothing to replot.", 2)
        return
    plotMFClear("")
    plotRAWClear()
    plotTPSClear()
    Msge = plotMF(None)
    plotRAW()
    plotTPS()
    setMsg("MF", "", Msge)
    return
############################
# BEGIN: plotMFShiftClick(e)
# FUNC:plotMFShiftClick():2010.251
#   Handles shift-clicks on the MF Canvas.
def plotMFShiftClick(e):
    global CurMainStart
    global CurMainEnd
    global FirstSelRule
    global SecondSelRule
    global FirstSelRuleX
    global SecondSelRuleX
    global StartEndRecord
    if MFGraphed == False:
        beep(1)
        return
    LCan = Can["MF"]
    Xx = LCan.canvasx(e.x)
# If the user has shift-clicked over the labels...
    if Xx < MFLead-25:
        if FirstSelRule != None:
            LCan.delete(FirstSelRule)
            FirstSelRule = None
            LCan.delete(SecondSelRule)
            SecondSelRule = None
        elif CurMainStart != FStart or CurMainEnd != FEnd:
            progControl("gozoom")
            Item = len(StartEndRecord)
# If there are no more remembered items then go back to the original range.
            if Item == 0:
                setOrigMinMax()
            else:
# "Pop" the last remembered range.
                Data = StartEndRecord[Item-1]
                CurMainStart = Data[0]
                CurMainEnd = Data[1]
                del StartEndRecord[Item-1]
                setMinMax()
            plotMFClear("")
            plotRAWClear()
            plotTPSClear()
            Msge = plotMF(None)
            plotRAW()
            plotTPS()
            setMsg("MF", "WB", Msge)
            progControl("stopped")
        else:
            beep(1)
        return
# If the user shift-clicks just to the left of the graphs then set Xx to the
# beginning of the graphs.
    elif Xx < MFLead:
        Xx = MFLead
# If the user clicks beyond the end of the graph then set Xx to the end of the
# graphs.
    elif Xx > MFLead+MFGW:
        Xx = MFLead+MFGW
# If this is the first shift-click...
    if FirstSelRule == None:
        FirstSelRule = LCan.create_line(Xx, TopSpace, Xx, \
                CHeight-TopSpace-BotSpace/2, fill = DClr["Sel"])
        FirstSelRuleX = Xx
# If this is the second shift-click...
    elif SecondSelRule == None:
        SecondSelRule = LCan.create_line(Xx, TopSpace, Xx, \
                CHeight-TopSpace-BotSpace/2, fill = DClr["Sel"])
        SecondSelRuleX = Xx
        updateMe(0)
        sleep(.2)
# If the user clicks in the same place twice then just cancel the whole thing.
        if FirstSelRuleX == SecondSelRuleX:
            LCan.delete(FirstSelRule)
            FirstSelRule = None
            LCan.delete(SecondSelRule)
            SecondSelRule = None
        else:
            progControl("gozoom")
# Remember the current range before we set things up for the new range.
            StartEndRecord.append((CurMainStart, CurMainEnd))
# The user can click the two points in either time order.
            if FirstSelRuleX < SecondSelRuleX:
                Wait = plotMFEpochAtX(FirstSelRuleX)
                CurMainEnd = plotMFEpochAtX(SecondSelRuleX)
                CurMainStart = Wait
            else:
                Wait = plotMFEpochAtX(SecondSelRuleX)
                CurMainEnd = plotMFEpochAtX(FirstSelRuleX)
                CurMainStart = Wait
# Plot the new range.
            setMinMax()
            plotMFClear("")
            plotRAWClear()
            plotTPSClear()
            Msge = plotMF(None)
            plotRAW()
            plotTPS()
            setMsg("MF", "WB", Msge)
            progControl("stopped")
    return
##########################
# BEGIN: plotMFTime(Epoch)
# FUNC:plotMFTime():2010.251
#   For external callers.
def plotMFTime(Epoch):
    if MFGraphed == False:
        return
    if Epoch == -1:
        Can["MF"].delete("Clock")
    else:
        CX = plotMFXAtEpoch(Epoch)
        plotMFClock(CX)
    return
##################################
# BEGIN: plotMFTimeClick(e = None)
# FUNC:plotMFTimeClick():2010.249
#   For time clicks (i.e. Control-Button-1) on the MF Canvas.
CFont = Font(family = "Helvetica", size = "8")
MFGridOn = False

def plotMFTimeClick(e = None):
    global MFGridOn
    if MFGraphed == False:
        beep(1)
        return
    LCan = Can["MF"]
    CX = LCan.canvasx(e.x)
    CY = LCan.canvasx(e.y)
# If the click is way to the left erase everything (MF stuff done above).
    if CX < MFLead/2:
        LCan.delete("Clock")
        LCan.delete("Grid")
        MFGridOn = False
        plotRAWTime(-1)
        plotTPSTime(-1)
# If the click is on the graphs above the bottom tick marks.
    elif CY < MFTickY:
        Epoch = plotMFClock(CX)
        plotRAWTime(Epoch)
        plotTPSTime(Epoch)
        return
# Must be below the tick marks. Turn the grid on or off.
    elif CY >= MFTickY:
        if MFGridOn == False:
            for CX in TickX:
                LCan.create_line(CX, MFTickY, CX, TopSpace, \
                        fill = DClr["Grid"], tags = "Grid")
            MFGridOn = True
        else:
            LCan.delete("Grid")
            MFGridOn = False
    return
##########################
# BEGIN: plotMFZapClick(e)
# FUNC:plotMFZapClick():2010.251
#   Removes a point from existance.
def plotMFZapClick(e):
    global MFZapped
    if MFGraphed == False:
        beep(1)
        return
    LCan = Can["MF"]
    CX = LCan.canvasx(e.x)
    CY = LCan.canvasy(e.y)
# Look at a 6x6 pixel area centered on the dot location (the dots are 3x3)
    XL = CX-3
    XM = CX+3
    YL = CY-3
    YM = CY+3
# Now check to see what point we clicked near
    for Data in ACQxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
# The ACQxy entry has the line number. Now we need to go through the
# ACQ list and remove the entry that has that same line number
                for Data2 in ACQ:
                    if Data[0] == Data2[0]:
                        ACQ.remove(Data2)
                        MFZapped += 1
                        setMinMax()
                        plotMF("MF")
                        return
    for Data in NETxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
                for Data2 in NET:
                    if Data[0] == Data2[0]:
                        NET.remove(Data2)
                        MFZapped += 1
                        setMinMax()
                        plotMF("MF")
                        return
    for Data in DUMPxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in DUMP:
                if Data[0] == Data2[0]:
                    DUMP.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in VOLTxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in VOLT:
                if Data[0] == Data2[0]:
                    VOLT.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in TEMPxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in TEMP:
                if Data[0] == Data2[0]:
                    TEMP.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in DCDIFFxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in DCDIFF:
                if Data[0] == Data2[0]:
                    DCDIFF.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in RESETxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in RESET:
                if Data[0] == Data2[0]:
                    RESET.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in GPSLKxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in GPSLK:
                if Data[0] == Data2[0]:
                    GPSLK.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in EVTxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in EVT:
                if Data[0] == Data2[0]:
                    EVT.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in GPSxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in GPS:
                if Data[0] == Data2[0]:
                    GPS.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in ICPExy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in ICPE:
                if Data[0] == Data2[0]:
                    ICPE.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in JERKxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in JERK:
                if Data[0] == Data2[0]:
                    JERK.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in PWRUPxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in PWRUP:
                if Data[0] == Data2[0]:
                    PWRUP.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in MRCxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in MRC:
                if Data[0] == Data2[0]:
                    MRC.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in DEFSxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in DEFS:
                if Data[0] == Data2[0]:
                    DEFS.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in SOHxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in SOH:
                if Data[0] == Data2[0]:
                    SOH.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in DISCREPxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in DISCREP:
                if Data[0] == Data2[0]:
                    DISCREP.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in ERRORxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in ERROR:
                if Data[0] == Data2[0]:
                    ERROR.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in WARNxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in WARN:
                if Data[0] == Data2[0]:
                    WARN.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in CLKPWRxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in CLKPWR:
                if Data[0] == Data2[0]:
                    CLKPWR.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Data in BKUPxy:
        if Data[1] >= XL and Data[1] <= XM and \
            Data[2] >= YL and Data[2] <= YM:
            for Data2 in BKUP:
                if Data[0] == Data2[0]:
                    BKUP.remove(Data2)
                    MFZapped += 1
                    setMinMax()
                    plotMF("MF")
                    return
    for Chan in (1, 2, 3, 4, 5, 6):
        for Data in eval("MP%dxy"%Chan):
            if Data[2] >= XL and Data[2] <= XM and \
                Data[3] >= YL and Data[3] <= YM:
                for Data2 in eval("MP%d"%Chan):
# We're comparing epoch's here, instead of SOH message line numbers.
                    if Data[0] == Data2[0]:
                        eval("MP%d"%Chan).remove(Data2)
                        MFZapped += 1
                        setMinMax()
                        plotMF("MF")
                        return
# Check for the err file points if there is anything plotted.
    if len(TMJMP) > 0 and DGrf["ERR"].get() == 1:
        for Data in TMJMPxy:
# This does not use XL and XM. The "dots" are only 1 pixel wide.
            if Data[1]-2.0 <= CX and Data[2]+2.0 >= CX and \
                Data[3] >= YL and Data[3] <= YM:
                for Data2 in TMJMP:
                    if Data[0] == Data2[0]:
                        TMJMP.remove(Data2)
                        MFZapped += 1
                        setMinMax()
                        plotMF("MF")
                        return
    beep(1)
    return
# END: plotMF




##################
# BEGIN: plotRAW()
# FUNC:plotRAW():2011.038
# The size of the plotted bits, not the window. These just need to be global
# for the clock and selection functions.
RAWGH = 125.0
RAWGW = 2000.0
RAWMargin = 25.0
RAWGraphed = False
RAWClockBottom = 0

def plotRAW():
    global RAWGraphed
    global RAWClockBottom
# If the user doesn't want to do the RAW plot get rid of it if it is up.
    if OPTPlotRAWCVar.get() == 0:
        closeForm("RAW")
        return
# Bring up the form if necessary.
    if Frm["RAW"] == None:
        LFrm = Frm["RAW"] = Toplevel(Root)
        LFrm.withdraw()
        LFrm.protocol("WM_DELETE_WINDOW", Command(beep, 1))
        Sub = Frame(LFrm)
        SSub = Frame(Sub)
        Parts = Root.geometry().split("+", 1)
        Width, Height = map(int, Parts[0].split("x"))
# This gets the window about the right size for 3 channels of plots, the text,
# times and other fudging.
        Height = RAWGH*3+PROGLabelFontHeight*15
        Width = Width*.90
        LCan = Can["RAW"] = Canvas(SSub, bg = DClr["MFCAN"], bd = 0, \
                relief = SUNKEN, height = Height, width = Width, \
                scrollregion = (0, 0, Width, Height), highlightthickness = 0)
        LCan.pack(side = LEFT, expand = YES, fill = BOTH)
        LCan.bind("<Control-Button-1>", plotRAWTimeClick)
        Sb = Scrollbar(SSub, orient = VERTICAL, command = LCan.yview)
        Sb.pack(side = RIGHT, expand = NO, fill = Y)
        LCan.configure(yscrollcommand = Sb.set)
        SSub.pack(side = TOP, expand = YES, fill = BOTH)
        Sb = Scrollbar(Sub, orient = HORIZONTAL, command = LCan.xview)
        Sb.pack(side = BOTTOM, expand = NO, fill = X)
        LCan.configure(xscrollcommand = Sb.set)
        Sub.pack(side = TOP, expand = YES, fill = BOTH)
        Sub = Frame(LFrm)
        BButton(Sub, text = "Write .ps", command = Command(formWritePS, \
                "RAW", "RAW", LastRAWPSFilespecVar)).pack(side = LEFT)
        Msg["RAW"] = Text(Sub, font = PROGMsgFont, height = 2, wrap = WORD, \
                cursor = "")
        Msg["RAW"].pack(side = LEFT, fill = X, expand = YES)
        LLb = Label(Sub, text = "Hints")
        LLb.pack(side = LEFT)
        ToolTip(LLb, 35, "PLOT AREA HINT:\n--Control-click: Control-click to show the time at the position of the click.\n--Control-click on left: Control-click on the far left to remove the time marker.")
        Sub.pack(side = TOP, fill = X, expand = NO)
        center(Root, LFrm, "W", "O", True)
    else:
        LFrm = Frm["RAW"]
        LCan = Can["RAW"]
        plotRAWClear()
    LFrm.title("Raw Data Plot - %s"%MainFilename)
# Oops, maybe?
    if OPTIncNonSOHCVar.get() == 0:
        setMsg("RAW", "", \
                "The 'Include Non-SOH Items' checkbutton was not selected.")
        return
# Collect the state of the data stream checkbuttons.
    DSs = []
    ColorMode = PROGColorModeRVar.get()
    for i in xrange(1, 1+PROG_DSS):
        if eval("Stream%dVar"%i).get() == 1:
            DSs.append(i)
    if len(DSs) == 0:
        setMsg("RAW", "", "No DS (Data Stream) checkbuttons were selected.")
        return
# Finish gatering info before starting.
    PlotMass123 = False
    if DGrf["MP123"].get() == 1:
        PlotMass123 = True
    PlotMass456 = False
    if DGrf["MP456"].get() == 1:
        PlotMass456 = True
# Just in case.
    if len(RawData) == 0:
        setMsg("RAW", "", "%s: No raw data found for selected data streams."% \
                MainFilename)
        return
# Just in case.
    CurMainTimerange = CurMainEnd-CurMainStart
    if CurMainTimerange <= 0.0:
        setMsg("RAW", "", "%s: Not enough time selected to plot anything."% \
                MainFilename)
        return
    progControl("gozoom")
    setMsg("MF", "CB", "Plotting raw data...")
# The keys are (DS, Chan).
    Graphs = RawData.keys()
    Graphs.sort()
    GY = PROGLabelFontHeight
# Display the actual time of the data, because this may differ greatly from the
# time range of the SOH messages (there may be "old" SOH messages that got
# recorded before acquisition was started, for example).
    if OPTDateFormatRVar.get() == "YYYY:DDD":
        LCan.create_text(10, GY, anchor = "w", fill = DClr["RAWT"], \
                font = PROGLabelFont, text = "%s: Time range: %s to %s"% \
                (MainFilename, epoch2Str(CurMainStart), epoch2Str(CurMainEnd)))
    elif OPTDateFormatRVar.get() == "YYYYMMMDD":
        LCan.create_text(10, GY, anchor = "w", fill = DClr["RAWT"], \
                font = PROGLabelFont, text = "%s: Time range: %s to %s"% \
                (MainFilename, ydhms2ymdhms(epoch2Str(CurMainStart)), \
                ydhms2ymdhms(epoch2Str(CurMainEnd))))
    elif OPTDateFormatRVar.get() == "YYYY-MM-DD":
        LCan.create_text(10, GY, anchor = "w", fill = DClr["RAWT"], \
                font = PROGLabelFont, text = "%s: Time range: %s to %s"% \
                (MainFilename, ydhms2ymdhmsDash(epoch2Str(CurMainStart)), \
                ydhms2ymdhmsDash(epoch2Str(CurMainEnd))))
    elif OPTDateFormatRVar.get() == "":
        LCan.create_text(10, GY, anchor = "w", fill = DClr["RAWT"], \
                font = PROGLabelFont, text = "%s: Time range: %s to %s"% \
                (MainFilename, str(CurMainStart), str(CurMainEnd)))
    GY += PROGLabelFontHeight*1.5
# We know how wide the plot area is in pixels and in time, so figure out how
# much time per pixel there will be and then go through the points and bin
# as needed.
    TimerangePerPixel = CurMainTimerange/RAWGW
# Main loop. Each iteration plots a DS/Chan's graph.
    for Graph in Graphs:
        setMsg("RAW", "CB", "Plotting data plot DS%d CH%d..."%(Graph[0], \
                Graph[1]))
        TheData = RawData[Graph]
# Normally there should always be something to plot, otherwise nothing would
# have been extracted, or this condition would have been caught by the
# DataTimerange above, but you never know.
        if len(TheData) == 0:
            if ColorMode == "B":
                C = "Y"
            elif ColorMode == "W":
                C = "O"
            LCan.create_text(10, GY, anchor = "w", fill = Clr[C], \
                    font = PROGLabelFont, \
                    text = "Data stream: %d  Channel: %d  No data to plot."% \
                    (Graph[0], Graph[1]))
            GY += PROGLabelFontHeight*2
            continue
# Go through all of the data points for this ds/chan and count how many data
# points there is going to be over the ManTimerange and how much of the full
# graphing width (RAWGW) will be used (i.e. the data may not start when the log
# information did). Also get the max and min data values for scaling.
        DataMin = maxint
        DataMax = -maxint
        DataCount = 0
        for DataPoint in TheData:
            if DataPoint[0] >= CurMainStart:
# Jump out as soon as we've gone through all of the good points.
                if DataPoint[0] > CurMainEnd:
                    break
                DataCount += 1
                if DataPoint[1] > DataMax:
                    DataMax = DataPoint[1]
                if DataPoint[1] < DataMin:
                    DataMin = DataPoint[1]
# If no data was found in the current time range...
        if DataCount == 0:
            if ColorMode == "B":
                C = "Y"
            elif ColorMode == "W":
                C = "O"
            LCan.create_text(10, GY, anchor = "w", fill = Clr[C], \
                    font = PROGLabelFont, \
              text = "Data stream: %d  Channel: %d  No data in timerange/%d"% \
                    (Graph[0], Graph[1], len(TheData)))
            GY += PROGLabelFontHeight*2
            continue
        DataRange = float(getRange(DataMin, DataMax))
        if DataRange == 0.0:
            DataRange = 1.0
# DataNorm will be added to the data values so that the lowest of the values to
# be plotted will have a value of 0 and all values will go up from there to
# make figuring out where to plot a point easier.
        if DataMin > 0:
            DataNorm = float(-DataMin)
        else:
            DataNorm = float(abs(DataMin))
# We're ready to start.
        LCan.create_text(10, GY, anchor = "w", fill = DClr["RAWT"], \
                font = PROGLabelFont, \
                text = "Data stream: %d     Channel: %d     Points: %s / %s     Max/Min: %s / %s     Range: %s"% \
                (Graph[0], Graph[1], fmti(DataCount), fmti(len(TheData)), \
                fmti(DataMax), fmti(DataMin), fmti(DataRange)))
        GY += PROGLabelFontHeight
# GGY will be the lowest point/bottom of each plot.
        GGY = GY+RAWGH
        LenOfData = len(TheData)
# As each bin is filled this will be reset to the last point that was used so
# the for loop below will not have to start over at the beginning of the data
# each time through.
        IndexStart = 0
        Cmd = []
        for Pixel in xrange(0, RAWGW):
# Calculate this each time to minimize rounding errors.
            BinStart = CurMainStart+(Pixel*TimerangePerPixel)
            BinEnd = BinStart+TimerangePerPixel
            BinMin = maxint
            BinMax = -maxint
# Look through the data points to find points that are in the current bin.
            for i in xrange(IndexStart, LenOfData):
                Point = TheData[i]
# Too early...
                if Point[0] < BinStart:
                    continue
# End of bin...
                if Point[0] > BinEnd:
# If BinMin is still maxint it means that no points were found for this bin, so
# just jump out, otherwise figure out what will be plotted.
                    if BinMin != maxint:
                        PlotMin = GGY-((BinMin+DataNorm)/DataRange)*RAWGH
                        PlotMax = GGY-((BinMax+DataNorm)/DataRange)*RAWGH
                        Cmd += [RAWMargin+Pixel, PlotMin, RAWMargin+Pixel, \
                                PlotMax]
# Just set this so the code outside the loop will know if it has to do
# anything or not when the loop has finished.
                        BinMin = maxint
                        IndexStart = i-1
                    break
# In the bin...
                if Point[1] < BinMin:
                    BinMin = Point[1]
                if Point[1] > BinMax:
                    BinMax = Point[1]
            if BinMin != maxint:
                PlotMin = GGY-((BinMin+DataNorm)/DataRange)*RAWGH
                PlotMax = GGY-((BinMax+DataNorm)/DataRange)*RAWGH
                Cmd += [RAWMargin+Pixel, PlotMin, RAWMargin+Pixel, PlotMax]
# Clean up. Same thing so we get the last bin of the plot.
        if BinMin != maxint:
            PlotMin = GGY-((BinMin+DataNorm)/DataRange)*RAWGH
            PlotMax = GGY-((BinMax+DataNorm)/DataRange)*RAWGH
            Cmd += [RAWMargin+Pixel, PlotMin, RAWMargin+Pixel, PlotMax]
# Plot what we got.
        if len(Cmd) > 0:
            if DataMin < 0.0 and 0.0 < DataMax:
                PlotZero = GGY-(DataNorm/DataRange)*RAWGH
                LCan.create_line((RAWMargin, PlotZero, RAWMargin+RAWGW, \
                        PlotZero), fill = Clr["U"])
            LCan.create_line(Cmd, fill = DClr["RAWD"])
        else:
            LCan.create_text(RAWMArgin, GY, anchor = "w", \
                    fill = DClr["RAWT"], font = PROGLabelFont,
           text = "No data points for this channel in the selected timerange.")
        GY += RAWGH
# If the user is looking for mass positions, and there is mass position info
# then let 'er plot.
        if PlotMass123 == True or PlotMass456 == True:
            Chan = Graph[1]
# Just beyond the bottom of the plot.
            GM = GY+4
            Masses = eval("MP%d"%Chan)
            if (PlotMass123 == True and (Chan >= 1 and Chan <= 3) and \
                    len(Masses) > 0) or \
                    (PlotMass456 == True and (Chan >= 4 and Chan <= 6) and \
                    len(Masses) > 0):
                for Mass in Masses:
                    if Mass[0] >= CurMainStart and Mass[0] <= CurMainEnd:
                        XX = RAWMargin+(Mass[0]-CurMainStart)/ \
                                CurMainTimerange*RAWGW
                        if Mass[2] == 0:
                            C = "MPP"
                        elif Mass[2] == 1:
                            C = "MPG"
                        elif Mass[2] == 2:
                            C = "MPB"
                        elif Mass[2] == 3:
                            C = "MPU"
                        elif Mass[2] == 4:
                            C = "MPH"
                        ID = LCan.create_rectangle(XX-2, GM-2, XX+2, GM+2, \
                                fill = DClr[C], outline = DClr[C])
                        LCan.tag_bind(ID, "<Button-1>", \
                                Command(plotRAWShowMass, Chan, Mass[0], \
                                Mass[1]))
            GY += PROGLabelFontHeight
        GY += PROGLabelFontHeight*1.5
        L, T, R, B = LCan.bbox(ALL)
        LCan.configure(scrollregion = (0, 0, R+RAWMargin, (B+15)))
        updateMe(0)
        if PROGRunning.get() == 0:
            setMsg("MF", "YB", "Stopped.")
            setMsg("RAW", "YB", "Stopped.")
            progControl("stopped")
            return
# Add just a little more space between the bottom of the last plot and the axis
# stuff mostly so the recenter dots (below) don't hit a pegged-low signal.
    GY += 5
# Now the X-axis scale across the bottom of the graph area.
    LCan.create_line((RAWMargin, GY, RAWMargin+RAWGW, GY), fill = DClr["RAWT"])
# Plot tick marks showing 10 days, 1 day, hours, minutes or seconds depending
# on the range of the currently displayed graph.
    Zero = epoch2Str(CurMainStart)
# 30 days.
    if CurMainTimerange >= 2592000.0:
        Zero = Zero[:9]+"00:00:00"
        Add = 864000.0
    elif CurMainTimerange >= 864000.0:
        Zero = Zero[:9]+"00:00:00"
        Add = 86400.0
    elif CurMainTimerange >= 3600.0:
        Zero = Zero[:12]+"00:00"
        Add = 3600.0
    elif CurMainTimerange >= 60.0:
        Zero = Zero[:15]+"00"
        Add = 60.0
    else:
        Zero = Zero[:17]
        Add = 1.0
    Time = str2Epoch(None, Zero)
    First = True
    LastTimeEndX = 0.0
    while 1:
        Time += Add
        if Time < CurMainEnd:
            if Time >= CurMainStart:
                GX = RAWMargin+RAWGW*((Time-CurMainStart)/CurMainTimerange)
                LCan.create_line((GX, GY-2, GX, GY), fill = DClr["RAWT"])
                if OPTDateFormatRVar.get() == "YYYY:DDD":
                    Zero = epoch2Str(Time)[:17]
                elif OPTDateFormatRVar.get() == "YYYYMMMDD":
                    Zero = ydhms2ymdhms(epoch2Str(Time)[:17])
                elif OPTDateFormatRVar.get() == "YYYY-MM-DD":
                    Zero = ydhms2ymdhmsDash(epoch2Str(Time)[:17])
                elif OPTDateFormatRVar.get() == "":
                    Zero = str(Time)
                Length = len(Zero)*GFontW
# Print the date/time of the first tick and all of the ones there is room for
# after that.
                if First == True or (GX-Length/2) > (LastTimeEndX+100):
                    LCan.create_line((GX, GY-6, GX, GY), fill = DClr["RAWT"])
# Make sure the times are not off either edge of the display.
                    if (GX-Length/2) < 1:
                        GX = RAWMargin+Length/2
                    if (GX+Length/2) > (RAWMargin+RAWGW):
                        GX = (RAWMargin+RAWGW)-Length/2
# This won't take into account the first time needing to be shoved to the
# right a little, but there should always be enough space.
                    LastTimeEndX = GX+Length/2
                    LCan.create_text(GX, GY+GFontH, anchor = "n", \
                            fill = DClr["RAWT"], text = Zero)
                    First = False
        else:
            break
# Preserve this for the control-click clock rule. The tall ticks above are
# GY-6, so make this a little higher.
    RAWClockBottom = GY-8
# Add the recentering pulses along the axis.
    for Data in MRC:
        if Data[1] >= CurMainStart:
            if Data[1] <= CurMainEnd:
                GX = RAWMargin+RAWGW*(Data[1]-CurMainStart)/CurMainTimerange
                ID = LCan.create_rectangle(GX-2, GY-2-12, GX+2, GY+2-12, \
                        fill = DClr["MRC"], outline = DClr["MRC"])
                LCan.tag_bind(ID, "<Button-1>", \
                        Command(plotRAWShowTime, Data[1]))
    L, T, R, B = LCan.bbox(ALL)
    LCan.configure(scrollregion = (0, 0, R+RAWMargin, (B+15)))
# Even though we are finished let the user know this happened.
    if PROGRunning.get() == 0:
        setMsg("MF", "YB", "Stopped.")
        setMsg("RAW", "YB", "Stopped.")
    else:
        setMsg("MF", "", "")
        setMsg("RAW", "", "")
    progControl("stopped")
    RAWGraphed = True
    return
#######################
# BEGIN: plotRAWClear()
# FUNC:plotRAWClear():2010.251
def plotRAWClear():
    global RAWGraphed
    if Frm["RAW"] != None:
        Frm["RAW"].title("Raw Data Plot")
        LCan = Can["RAW"]
        LCan.delete(ALL)
        LCan.xview_moveto(0.0)
        LCan.yview_moveto(0.0)
        LCan.configure(bg = DClr["MFCAN"])
        setMsg("RAW", "", "")
    RAWGraphed = False
    return
########################
# BEGIN: plotRAWReplot()
# FUNC:plotRAWReplot():2010.251
def plotRAWReplot():
    if RAWGraphed == False:
        setMsg("RAW", "RW", "There is nothing to replot.", 2)
        return
    plotRAW()
    return
###################################################
# BEGIN: plotRAWShowMass(Chan, TimeValue, MassValue, e)
# FUNC:plotRAWShowMass():2010.309
def plotRAWShowMass(Chan, TimeValue, MassValue, e):
    if OPTDateFormatRVar.get() == "YYYY:DDD":
        Time = epoch2Str(TimeValue)[:17]
    elif OPTDateFormatRVar.get() == "YYYYMMMDD":
        Time = ydhms2ymdhms(epoch2Str(TimeValue)[:17])
    elif OPTDateFormatRVar.get() == "YYYY-MM-DD":
        Time = ydhms2ymdhmsDash(epoch2Str(TimeValue)[:17])
    elif OPTDateFormatRVar.get() == "":
        Time = str(TimeValue)
    setMsg("RAW", "", "Channel %d mass position voltage %.1fV at %s."%(Chan, \
            MassValue, Time))
    return
##################################
# BEGIN: plotRAWShowTime(Value, e)
# FUNC:plotRAWShowTime():2010.309
def plotRAWShowTime(Value, e):
    if OPTDateFormatRVar.get() == "YYYY:DDD":
        Time = epoch2Str(Value)[:17]
    elif OPTDateFormatRVar.get() == "YYYYMMMDD":
        Time = ydhms2ymdhms(epoch2Str(Value)[:17])
    elif OPTDateFormatRVar.get() == "YYYY-MM-DD":
        Time = ydhms2ymdhmsDash(epoch2Str(Value)[:17])
    elif OPTDateFormatRVar.get() == "":
        Time = str(Value)
    setMsg("RAW", "", "Mass recenter time %s."%Time)
    return
############################
# BEGIN: plotRAWTimeClick(e)
# FUNC:plotRAWTimeClick():2010.251
#   For time clicks (i.e. Control-Button-3) on the RAW Canvas().
def plotRAWTimeClick(e):
    if RAWGraphed == False:
        beep(1)
    else:
        LCan = Can["RAW"]
        CX = LCan.canvasx(e.x)
        CY = LCan.canvasy(e.y)
# Way to the left.
        if CX < RAWMargin/2:
            LCan.delete("Clock")
            setMsg("TPS", "", "")
            plotMFTime(-1)
            plotTPSTime(-1)
# Somewhere on the plots.
        else:
            if CY < RAWClockBottom:
                Epoch = plotRAWClock(CX)
                plotMFTime(Epoch)
                plotTPSTime(Epoch)
# Blow the plots.
            else:
                beep(1)
    return
##########################
# BEGIN plotRAWTime(Epoch)
# FUNC:plotRAWTime():2010.251
#   For external callers to control the RAW clock rule.
def plotRAWTime(Epoch):
    if Frm["RAW"] == None or RAWGraphed == False:
        return
    if Epoch == -1:
        Can["RAW"].delete("Clock")
    else:
        RAWCX = plotRAWXAtEpoch(Epoch)
        plotRAWClock(RAWCX)
    return
############################
# BEGIN: plotRAWEpochAtX(CX)
# FUNC:plotRAWEpochAtX():2010.251
#   Takes the passed CX pixel location and returns the epoch time at that
#   graph location.
def plotRAWEpochAtX(CX):
# How far across the graph did we click?
    Epoch = (CX-RAWMargin)/RAWGW
    Epoch = CurMainStart+(CurTimerange*Epoch)
    return Epoch
###############################
# BEGIN: plotRAWXAtEpoch(Epoch)
# FUNC:plotRAWXAtEpoch():2010.251
#   Takes the passed Epoch and figures out where on the RAW graphs that is.
def plotRAWXAtEpoch(Epoch):
    XX = (Epoch-CurMainStart)/CurTimerange
    XX = RAWMargin+(RAWGW*XX)
    return XX
#########################
# BEGIN: plotRAWClock(CX)
# FUNC:plotRAWClock():2010.251
def plotRAWClock(CX):
    LCan = Can["RAW"]
    LCan.delete("Clock")
# Select min or max time if a little off-graph.
    if CX < RAWMargin:
        CX = RAWMargin
    elif CX > RAWMargin+RAWGW:
        CX = RAWMargin+RAWGW
    Epoch = plotRAWEpochAtX(CX)
# Draw the rule and put the time in the message field.
    LCan.create_line(CX, PROGLabelFontHeight*3, CX, \
            RAWClockBottom, fill = DClr["Sel"], tags = "Clock")
    if OPTDateFormatRVar.get() == "YYYY:DDD":
        Time = epoch2Str(Epoch)
    elif OPTDateFormatRVar.get() == "YYYYMMMDD":
        Time = ydhms2ymdhms(epoch2Str(Epoch))
    elif OPTDateFormatRVar.get() == "YYYY-MM-DD":
        Time = ydhms2ymdhmsDash(epoch2Str(Epoch))
    elif OPTDateFormatRVar.get() == "":
        Time = str(Epoch)
    setMsg("RAW", "", "Time: %s"%Time)
    return Epoch
# END: plotRAW




##################
# BEGIN: plotTPS()
# FUNC:plotTPS():2011.038
TPSColorRangeRVar = StringVar()
TPSColorRangeRVar.set("med")
PROGSetups += ("TPSColorRangeRVar", )
TPSStart = 0
TPSGraphed = False

def plotTPS():
    global TPSStart
    global TPSGraphed
# If the user doesn't want to do the TPS plot get rid of it if it is up.
    if OPTPlotTPSCVar.get() == 0:
        closeForm("TPS")
        TPSGraphed = False
        return
# Create the form if necessary.
    if Frm["TPS"] == None:
        LFrm = Frm["TPS"] = Toplevel(Root)
        LFrm.withdraw()
        LFrm.protocol("WM_DELETE_WINDOW", Command(beep, 1))
        Sub = Frame(LFrm)
        SSub = Frame(Sub)
# 915 = 25+(3*288)+25, plus 1
        LCan = Can["TPS"] = Canvas(SSub, bg = DClr["MFCAN"], bd = 0, \
                relief = SUNKEN, height = 500, width = 915, \
                scrollregion = (0, 0, 915, 500), highlightthickness = 0)
        LCan.bind("<Button-1>", Command(plotTPSTimeClick, -1))
        LCan.bind("<Control-Button-1>", Command(plotTPSTimeClick, -1))
        LCan.pack(side = LEFT, expand = YES, fill = BOTH)
        Sb = Scrollbar(SSub, orient = VERTICAL, command = LCan.yview)
        Sb.pack(side = RIGHT, expand = NO, fill = Y)
        LCan.configure(yscrollcommand = Sb.set)
        SSub.pack(side = TOP, expand = YES, fill = BOTH)
        Sb = Scrollbar(Sub, orient = HORIZONTAL, command = LCan.xview)
        Sb.pack(side = BOTTOM, expand = NO, fill = X)
        LCan.configure(xscrollcommand = Sb.set)
        Sub.pack(side = TOP, expand = YES, fill = BOTH)
        Sub = Frame(LFrm)
        LRb = Radiobutton(Sub, text = "L", variable = TPSColorRangeRVar, \
                value = "low")
        LRb.pack(side = LEFT)
        ToolTip(LRb, 30, "\"Low\" color range.")
        LRb = Radiobutton(Sub, text = "M", variable = TPSColorRangeRVar, \
                value = "med")
        LRb.pack(side = LEFT)
        ToolTip(LRb, 30, "\"Medium\" color range.")
        LRb = Radiobutton(Sub, text = "H", variable = TPSColorRangeRVar, \
                value = "high")
        LRb.pack(side = LEFT)
        ToolTip(LRb, 30, "\"High\" color range.")
        BButton(Sub, text = "Replot", \
                command = plotTPSReplot).pack(side = LEFT)
        BButton(Sub, text = "Write .ps", command = Command(formWritePS, \
                "TPS", "TPS", LastTPSPSFilespecVar)).pack(side = LEFT)
        Msg["TPS"] = Text(Sub, font = PROGMsgFont, height = 2, wrap = WORD, \
                cursor = "")
        Msg["TPS"].pack(side = LEFT, fill = X, expand = YES)
        LLb = Label(Sub, text = "Hints")
        LLb.pack(side = LEFT)
        ToolTip(LLb, 35, "PLOT AREA HINT:\n--Control-click: Control-click on a point on the plot to show the time at that position.\n--Control-click on left: Control-click on the far left to clear the time.")
        Sub.pack(side = TOP, fill = X, expand = NO)
        center(Root, LFrm, "E", "O", True)
        TPSGraphed = False
    else:
        LFrm = Frm["TPS"]
        LCan = Can["TPS"]
        plotTPSClear()
    LFrm.title("Time-Power-Squared Plot - %s"%MainFilename)
# There wpon't be any data to plot.
    if OPTIncNonSOHCVar.get() == 0:
        setMsg("TPS", "", \
                "The 'Include Non-SOH Items' checkbutton was not selected.")
        return
# Collect the state of the data stream checkbuttons.
    DSs = []
    ColorMode = PROGColorModeRVar.get()
    for i in xrange(1, 1+PROG_DSS):
        if eval("Stream%dVar"%i).get() == 1:
            DSs.append(i)
    if len(DSs) == 0:
        setMsg("TPS", "", "No DS (Data Stream) checkbuttons were selected.")
        return
# Just in case.
    if len(RawData) == 0:
        setMsg("TPS", "", "%s: No raw data found for selected data streams."% \
                MainFilename)
        return
    ColorRange = TPSColorRangeRVar.get()
# Set the ranges for the colors based on the H M L radiobuttons.
    if ColorRange == "low":
        Bin0 = 0.0
        Bin1 = 400.0   # 20
        Bin2 = 40000.0   # 200
        Bin3 = 4000000.0   # 2000
        Bin4 = 400000000.0   # 20000
        Bin5 = 40000000000.0   # 200000
        Bin6 = 4000000000000.0   # 2000000
    if ColorRange == "med":
        Bin0 = 0.0
        Bin1 = 2500.0   # 50
        Bin2 = 250000.0   # 500
        Bin3 = 25000000.0   # 5000
        Bin4 = 2500000000.0   # 50000
        Bin5 = 250000000000.0   # 500000
        Bin6 = 25000000000000.0   # 5000000
    elif ColorRange == "high":
        Bin0 = 0.0
        Bin1 = 6400.0   # 80
        Bin2 = 640000.0   # 800
        Bin3 = 64000000.0   # 8000
        Bin4 = 6400000000.0   # 80000
        Bin5 = 640000000000.0   # 800000
        Bin6 = 64000000000000.0   # 8000000
# Will be a list of lists with a list for each 5-minute bin as
#    [[sum of squared counts, number of data points], ...]
    PlotData = []
# The keys are (DS, Chan).
    Graphs = RawData.keys()
    Graphs.sort()
    progControl("gozoom")
    setMsg("MF", "CB", "Plotting TPS data...")
    setMsg("TPS", "CB", "Working...")
# Make sure GY never becomes a float, otherwise it could make the day plot
# lines run together and generally look really bad on some operating/X11
# systems.
    GY = PROGLabelFontHeight
    TPSMargin = 25
# The display will always show whole days, but only plot the data corresponding
# to the main form's time range.
    SYYYY, SDDD, HH, MM, SS = epoch2Str(CurMainStart, "y")
    EYYYY, EDDD, HH, MM, SS = epoch2Str(CurMainEnd, "y")
    TPSStart = ydhms2Epoch(SYYYY, SDDD, 0, 0, 0)
    TPSEnd = ydhms2Epoch(EYYYY, EDDD, 24, 0, 0)
# Put the name of the file at the top in case someone wants to print the plots.
    ID = LCan.create_text(10, GY, anchor = "w", font = PROGLabelFont, \
            fill = DClr["RAWT"], text = MainFilename)
    GY += PROGLabelFontHeight
# DS/Channel loop.
    for Graph in Graphs:
        TheData = RawData[Graph]
        if len(TheData) == 0:
            ID = LCan.create_text(10, GY, anchor = "w", font = PROGLabelFont, \
                    fill = DClr["RAWT"], \
                    text = "No data to plot for DS%d CH%d"%(Graph[0], \
                    Graph[1]))
            L, T, R, B = LCan.bbox(ID)
            ID2 = LCan.create_rectangle(L, T-1, R, B, fill = DClr["MFCAN"], \
                    outline = DClr["MFCAN"])
            LCan.tag_raise(ID, ID2)
            GY += PROGLabelFontHeight
            continue
# The labels "in" the plot need to be printed, then a box the same color as
# the background be made, then the text lifted above the box, so the hour
# lines that will be generated at the end will not be visible through the text.
        ID = LCan.create_text(10, GY, anchor = "w", font = PROGLabelFont, \
                fill = DClr["RAWT"], text = "DS%d CH%d"%(Graph[0], Graph[1]))
        L, T, R, B = LCan.bbox(ID)
        ID2 = LCan.create_rectangle(L, T-1, R, B, fill = DClr["MFCAN"], \
                outline = DClr["MFCAN"])
        LCan.tag_raise(ID, ID2)
# Put in the hour numbers here.
        for i in xrange(4, 24, 4):
            XX = TPSMargin+(i*(3.0*288.0/24.0))
            ID = LCan.create_text(XX, GY, justify = CENTER, \
                    font = PROGLabelFont, fill = DClr["RAWT"], \
                    text = "%02d"%i)
            L, T, R, B = LCan.bbox(ID)
            ID2 = LCan.create_rectangle(L, T-1, R, B, fill = DClr["MFCAN"], \
                    outline = DClr["MFCAN"])
            LCan.tag_raise(ID, ID2)
        GY += PROGLabelFontHeight
# Create a list with as many 5-minute bins as we are going to need to cover
# TPSStart to TPSEnd days.
        del PlotData[:]
        PlotData = [[0, 0] for i in range((TPSEnd-TPSStart)/86400*288)]
# Now go through all of the raw data points, calculate which bin created above
# each data point value should be added to based on the epoch time of each
# point and add it in.
        for Data in TheData:
            if Data[0] < TPSStart:
                continue
            if Data[0] > TPSEnd:
                break
# Filter once more so we only plot what the user has selected and not whole
# days (that's what the above lets pass).
            if Data[0] < CurMainStart:
                continue
            if Data[0] > CurMainEnd:
                break
            Index = int((Data[0]-TPSStart)//300)
            PlotData[Index][0] += Data[1]**2
            PlotData[Index][1] += 1
# Now go through the bins by day and each bin within each day.
        Day = 0
        for DayIndex in xrange(0, len(PlotData), 288):
            Day += 1
            setMsg("TPS", "CB", \
                "Plotting time-power-squared plot DS%d CH%d day %d..."% \
                (Graph[0], Graph[1], Day))
            GX = TPSMargin
            for BinIndex in xrange(DayIndex, DayIndex+288):
# If there are no points in this bin check the bins on either side. If they
# both have values then calculate an average and use that.
                if PlotData[BinIndex][1] == 0:
                    try:
                        if PlotData[BinIndex-1][1] != 0 and \
                                PlotData[BinIndex+1][1] != 0:
                            Value = (PlotData[BinIndex-1][0]+ \
                                    PlotData[BinIndex+1][0])
                            Points = (PlotData[BinIndex-1][1]+ \
                                    PlotData[BinIndex+1][1])
# Save the results so we don't have to do this again.
                            PlotData[BinIndex][0] = Value
                            PlotData[BinIndex][1] = Points
                            AveValue = Value/Points
                        else:
                            AveValue = 0.0
                    except:
                        AveValue = 0.0
                else:
                    AveValue = float(PlotData[BinIndex][0])/ \
                            PlotData[BinIndex][1]
                if AveValue == Bin0:
                    C = "K"
                elif AveValue < Bin1:
                    C = "U"
                elif AveValue < Bin2:
                    C = "C"
                elif AveValue < Bin3:
                    C = "G"
                elif AveValue < Bin4:
                    C = "Y"
                elif AveValue < Bin5:
                    C = "R"
                elif AveValue < Bin6:
                    C = "M"
                else:
                    C = "E"
                ID = LCan.create_rectangle(GX-1, GY-1, GX+1, GY+2, \
                        fill = Clr[C], outline = Clr[C])
                LCan.tag_bind(ID, "<Control-Button-1>", \
                        Command(plotTPSTimeClick, BinIndex))
# For next 5-minute block.
                GX += 3
# For next day.
            GY += 5
            updateMe(0)
# The user may only want to plot a little and stop, so set this here,
# otherwise they won't be able to click on any points.
            TPSGraphed = True
            if PROGRunning.get() == 0:
                setMsg("MF", "YB", "Stopped.")
                setMsg("TPS", "YB", "Stopped.")
                progControl("stopped")
                return
# For next ds/channel.
        GY += PROGLabelFontHeight
        L, T, R, B = LCan.bbox(ALL)
        LCan.configure(scrollregion = (0, 0, R+25, (B+15)))
        updateMe(0)
        if PROGRunning.get() == 0:
            setMsg("MF", "YB", "Stopped.")
            setMsg("TPS", "YB", "Stopped.")
            progControl("stopped")
            return
    L, T, R, B = LCan.bbox(ALL)
    for i in xrange(1, 24):
        XX = TPSMargin+(i*(3.0*288.0/24.0))
        ID = LCan.create_line(XX, T+PROGLabelFontHeight*2, XX, B+5, \
                fill = Clr["A"])
        LCan.tag_lower(ID, ALL)
# Print a key to the colors.
    GY = B+25
    Index = 0
    for C in ("K", "U", "C", "G", "Y", "R", "M", "E"):
        GYY = GY+PROGLabelFontHeight*Index
        LCan.create_rectangle(25, GYY-5, 40, GYY+5, fill = Clr[C], \
                outline = Clr["B"])
        if Index == 0:
            LCan.create_text(45, GYY, anchor = "w", font = PROGLabelFont, \
                    fill = DClr["RAWT"], text = "%s counts"% \
                    fmti(int(sqrt(eval("Bin%d"%Index)))))
        elif Index != 7:
            LCan.create_text(45, GYY, anchor = "w", font = PROGLabelFont, \
                    fill = DClr["RAWT"], text = "+/- %s counts"% \
                    fmti(int(sqrt(eval("Bin%d"%Index)))))
        else:
            LCan.create_text(45, GYY, anchor = "w", font = PROGLabelFont, \
                    fill = DClr["RAWT"], text = "> %s counts"% \
                    fmti(int(sqrt(Bin6))))
        Index += 1
    L, T, R, B = LCan.bbox(ALL)
    LCan.configure(scrollregion = (0, 0, R+25, (B+15)))
# Even though we are finished let the user know this happened.
    if PROGRunning.get() == 0:
        setMsg("MF", "YB", "Stopped.")
        setMsg("TPS", "YB", "Stopped.")
    else:
        setMsg("MF", "", "")
        setMsg("TPS", "", "")
    progControl("stopped")
    return
#######################
# BEGIN: plotTPSClear()
# FUNC:plotTPSClear():2010.251
def plotTPSClear():
    global TPSGraphed
# Clear the TPS plot if it is up.
    if Frm["TPS"] != None:
        Frm["TPS"].title("Time-Power-Squared Plot")
        LCan = Can["TPS"]
        LCan.delete("all")
        LCan.xview_moveto(0.0)
        LCan.yview_moveto(0.0)
        LCan.configure(bg = DClr["MFCAN"])
        setMsg("TPS", "", "")
    TPSGraphed = False
    return
########################
# BEGIN: plotTPSReplot()
# FUNC:plotTPSReplot():2010.251
def plotTPSReplot():
    if TPSGraphed == False:
        setMsg("TPS", "RW", "There is nothing to replot.", 2)
        return
    plotTPS()
    return
###########################
# BEGIN: plotTPSTime(Epoch)
# FUNC:plotTPSTime():2010.251
#   For external callers to use to control the TPS clock display (of which
#   there is none).
def plotTPSTime(Epoch):
    if Frm["TPS"] == None:
        return
# Callers cannot get anything displayed on this plot, so just erase.
    setMsg("TPS", "", "")
    return
###################################
# BEGIN: plotTPSTimeClick(Index, e)
# FUNC:plotTPSTimeClick():2010.309
#   Handles Canvas clicks.
def plotTPSTimeClick(Index, e):
    if TPSGraphed == False:
        beep(1)
        return
# This is a click from the Canvas().
    if Index == -1:
        LCan = Can["TPS"]
        CX = LCan.canvasx(e.x)
# Keep the same value as TPSMargin.
        if CX < 25:
            setMsg("TPS", "", "")
            plotMFTime(-1)
            plotRAWTime(-1)
# This is a click from one of the rectangles.
    else:
        Epoch = float(TPSStart+(Index*300)+150)
        if OPTDateFormatRVar.get() == "YYYY:DDD":
            Time= epoch2Str(Epoch)[:17]
        elif OPTDateFormatRVar.get() == "YYYYMMMDD":
            Time = ydhms2ymdhms(epoch2Str(Epoch)[:17])
        elif OPTDateFormatRVar.get() == "YYYY-MM-DD":
            Time = ydhms2ymdhmsDash(epoch2Str(Epoch)[:17])
        elif OPTDateFormatRVar.get() == "":
            Time = str(Epoch)
        setMsg("TPS", "", "Time: %s"%Time)
        plotMFTime(Epoch)
        plotRAWTime(Epoch)
    return
# END: plotTPS




################################################
# BEGIN: popDirFID(Parent, Which, Var, e = None)
# LIB:popDirFID():2010.162
#   Provides a popup menu for things to use to set their associated Var to the
#   value of the "main" directory vars or the main FID var.
#   Which can be something like "self work" to get more than one menu item.
#   Usage:
#     Thing.bind("<Button-3>", Command(popDir, "<form>", "<Which>", Var))
#
#   Not all of these will be used by all programs.
def popDirFID(Parent, Which, Var, e = None):
    Xx = Root.winfo_pointerx()
    Yy = Root.winfo_pointery()
    if isinstance(Parent, str):
# Only do this if the caller passed what we need.
        setMsg(Parent, "", "")
        Parent = Frm[Parent]
    PMenu = Menu(Parent, tearoff = 0, bg = Clr["D"])
    if Which == "thedata":
        PMenu.add_command(label = "Change The Data Directory To...", \
                command = Command(popDirFIDCmd, Parent, "thedata", Var))
        PMenu.tk_popup(Xx, Yy)
        return
    if Which == "thework":
        PMenu.add_command(label = "Change The Work Directory To...", \
                command = Command(popDirFIDCmd, Parent, "thework", Var))
        PMenu.tk_popup(Xx, Yy)
        return
    if Which == "thecut":
        PMenu.add_command(label = "Change The Cut Directory To...", \
                command = Command(popDirFIDCmd, Parent, "thecut", Var))
        PMenu.tk_popup(Xx, Yy)
        return
    if Which == "theorig":
        PMenu.add_command(label = "Change The Orig Directory To...", \
                command = Command(popDirFIDCmd, Parent, "theorig", Var))
        PMenu.tk_popup(Xx, Yy)
        return
    if Which.find("self") != -1:
        PMenu.add_command(label = "Change To Directory...", \
                command = Command(popDirFIDCmd, Parent, "self", Var))
    if Which.find("data") != -1:
        PMenu.add_command(label = "Set To Main Data Directory", \
                command = Command(popDirFIDCmd, Parent, "data", Var))
    elif Which.find("fid") != -1:
        PMenu.add_command(label = "Set To Main FID Value", \
                command = Command(popDirFIDCmd, Parent, "fid", Var))
    elif Which.find("msgs") != -1:
        PMenu.add_command(label = "Set To Main Messages Directory", \
                command = Command(popDirFIDCmd, Parent, "msgs", Var))
    elif Which.find("work") != -1:
        PMenu.add_command(label = "Set To Main Work Directory", \
                command = Command(popDirFIDCmd, Parent, "work", Var))
    elif Which.find("cut") != -1:
        PMenu.add_command(label = "Set To Main Cut Directory", \
                command = Command(popDirFIDCmd, Parent, "cut", Var))
    elif Which.find("orig") != -1:
        PMenu.add_command(label = "Set To Main Orig Directory", \
                command = Command(popDirFIDCmd, Parent, "orig", Var))
    PMenu.tk_popup(Xx, Yy)
    return
#########################################
# BEGIN: popDirFIDCmd(Parent, Which, Var)
# FUNC:popDirFIDCmd():2010.162
def popDirFIDCmd(Parent, Which, Var):
    if Which == "thedata":
        changeDirsCmd(Parent, "data", 1, Var)
        return
    if Which == "thework":
        changeDirsCmd(Parent, "work", 1, Var)
        return
    if Which == "thecut":
        changeDirsCmd(Parent, "cut", 1, Var)
        return
    if Which == "theorig":
        changeDirsCmd(Parent, "orig", 1, Var)
        return
    if Which == "self":
        Filespec = formMYDF(Parent, 1, "Pick A Directory", \
                dirname(Var.get()), "")
        if Filespec != "":
            Var.set(Filespec)
        return
    if Which == "data":
        Var.set(PROGDataDirVar.get())
    elif Which == "fid":
        Var.set(PROGFileIDVar.get())
    elif Which == "msgs":
        Var.set(PROGMsgsDirVar.get())
    elif Which == "work":
        Var.set(PROGWorkDirVar.get())
    elif Which == "cut":
        Var.set(TCUTCutDirVar.get())
    elif Which == "orig":
        Var.set(CLTRDOrigDirVar.get())
    return
# END: popDirFID




###################################
# BEGIN: progQuitter(Dummy = False)
# FUNC:progQuitter():2010.249
def progQuitter(Save):
    if Save == True:
# Load this with the current main display position and size.
        PROGGeometryVar.set(Root.geometry())
        savePROGSetups()
    setMsg("MF", "CB", "Quitting...")
    closeFormAll()
    exit()
# END: progQuitter




################################################
# BEGIN: readFileLines(Fp, Strip = False, N = 0)
# LIB:readFileLines():2009.290
#   Reads the passed file and determines how to split the lines which may end
#   differently depending on which operating system the file was written by.
def readFileLines(Fp, Strip = False, N = 0):
    if N == 0:
        RawLines = Fp.readlines()
    else:
        RawLines = Fp.readlines(N)
    Lines = []
# In case the file was empty.
    try:
# The order is important: \r\n  then  \r  then  \n.
        if RawLines[0].find("\r\n") != -1:
            Count = RawLines[0].count("\r\n")
# If there is only one \r\n (presumably at the end of the line) then the OS
# must have split the file up correctly. In that case just run the map() and
# clean off the ends of the lines.
            if Count == 1:
                if Strip == False:
                    Lines += map(rstrip, RawLines)
                else:
                    Lines += map(strip, RawLines)
# If there is more than one \r\n in the string then it could mean that all of
# the file lines are all jammed together into one long string. In that case
# split the line up first then add the parts to Lines, but leave off the
# "extra" blank line ([:-1]) that the split() will produce.
            else:
                for Line in RawLines:
                    Parts = Line.split("\r\n")
                    if Strip == False:
                        Lines += Parts[:-1]
                    else:
                        Lines += map(strip, Parts[:-1])
# Same as \r\n.
        elif RawLines[0].find("\r") != -1:
            Count = RawLines[0].count("\r")
            if Count == 1:
                if Strip == False:
                    Lines += map(rstrip, RawLines)
                else:
                    Lines += map(strip, RawLines)
            else:
                for Line in RawLines:
                    Parts = Line.split("\r")
                    if Strip == False:
                        Lines += Parts[:-1]
                    else:
                        Lines += map(strip, Parts[:-1])
# Same as \r.
        elif RawLines[0].find("\n") != -1:
            Count = RawLines[0].count("\n")
            if Count == 1:
                if Strip == False:
                    Lines += map(rstrip, RawLines)
                else:
                    Lines += map(strip, RawLines)
            else:
                for Line in RawLines:
                    Parts = Line.split("\n")
                    if Strip == False:
                        Lines += Parts[:-1]
                    else:
                        Lines += map(strip, Parts[:-1])
# What else can we do?
        else:
            Lines += RawLines
    except:
        pass
    return Lines
# END: readFileLines




##################################
# BEGIN: reconfigDisplay(e = None)
# FUNC:reconfigDisplay():2010.251
def reconfigDisplay(e = None):
    if MFGraphed == False:
        return
    plotMF("MF")
    return
# END: reconfigDisplay




################################################
# BEGIN: rt130MPDecode(FromDate, ToDate, Packet)
# LIB:rt130MPDecode():2010.242
#   Pulls out what should be the first mass position measurement from the
#   passed packet.  The caller is responsible for passing a packet with the
#   mass positions in it.
#   Returns (Epoch, Channel, MP Value, Color Range Code (0-4))
#   The Color Range Code is 0 for OK, 4 for pegged sensor element.
def rt130MPDecode(FromDate, ToDate, Packet):
# Check to see if the user even wants this packet.
    Epoch = rt72130HeaderTime2Epoch(Packet)
    if Epoch < FromDate or Epoch > ToDate:
        return (0, )
    Chan = BCDTable[ord(Packet[19])]+1
    if Chan > 0 and Chan < 7:
        Value = (ord(Packet[24]) << 8)+ord(Packet[25])
        if Value > 0x7FFF:
            Value -= 0x10000
        Value = int((Value/32767.0*10.0)*10.0)/10.0
        AValue = abs(Value)
        if AValue <= .5:
            return (Epoch, Chan, Value, 0)
        elif AValue <= 2.0:
            return (Epoch, Chan, Value, 1)
        elif AValue <= 4.0:
            return (Epoch, Chan, Value, 2)
        elif AValue <= 7.0:
            return (Epoch, Chan, Value, 3)
        else:
            return (Epoch, Chan, Value, 4)
    return (0, )
# END: rt130MPDecode




################################################################
# BEGIN: rt130cfTimeRange(CFSpec, StopBut, RunningVar, WhereMsg)
# LIB:rt130cfTimeRange():2010.252
#   Scans through the SOH files of a CF card and finds the earliest and
#   latest times.
#   Expects the CFSpec to be <path>/file/DAS.
def rt130cfTimeRange(CFSpec, StopBut, RunningVar, WhereMsg):
    Dir = dirname(CFSpec)
    DAS = basename(CFSpec)
# We will want to return the blah.cf/DAS version of the file name.
    CFDAS = basename(Dir)+sep+DAS
# Now do this since we are done with it.
    Dir += sep
    Ret = walkDirs(Dir, False)
    if Ret[0] != 0:
        return (2, Ret[1], Ret[2], Ret[3])
    SOHFiles = []
    DASLookFor = sep+DAS+sep
    SOHLookFor = sep+"0"+sep
    for File in Ret[1]:
        if File.endswith(".CFG"):
            continue
        if File.find(DASLookFor) != -1:
            if File.find(SOHLookFor) != -1:
                SOHFiles.append(File)
    if len(SOHFiles) == 0:
        return (1, "YB", "%s: No SOH files found."%CFDAS, 2)
    SOHFiles.sort()
    Earliest = maxint
    Latest = -maxint
    DASID = ""
# Read through all of the files and decode the header time stamp. Collect the
# earliest one and the latest one as we go.
    for Filespec in SOHFiles:
        if StopBut != None:
            StopBut.update()
            if RunningVar.get() == 0:
                return (2, "YB", "Stopped.", 2)
# If the file is not a multiple of 1024 bytes it could mean the data on the CF
# card was corrupted and that could crash LOGPEEK.
        if getsize(Filespec)%1024 != 0:
            return (1, "MW", "%s: Possibily corrupted."%CFDAS, 3)
        try:
            Fp = open(Filespec, "rb")
        except:
            return (1, "MW", "%s: Error opening a SOH file."%CFDAS, 3)
        while 1:
# Read through the file 100 packets at a time to speed things along.
# This failed once on a corrupted CF card and the error message meant nothing
# sensible: IOError: [Error 7] Argment list too long. I suspect even Python
# couldn't figure out what was going on with the card, so we'll try.
            try:
                Block = Fp.read(102400)
            except:
                Fp.close()
                return (1, "MW", "%s: IOError: Is the CF card corrupted?"% \
                        CFDAS, 3)
# This will lose processing of the last block if the file ends badly, but that
# should be caught in the 1024 test above.
            if len(Block) < 1024:
                break
# Go through the upto 100 packets read above. Use the length of the Block so
# when we get to the end of the file we will stop at the last block instead of
# just continuing for a full block.
            for Offset in xrange(0, len(Block), 1024):
                Packet = Block[Offset:Offset+1024]
                if len(Packet) < 1024:
                    break
                PacketType = Packet[:2]
# We do this to try and keep packets of garbage from getting their times
# processed.
                if PacketType == "SH":
                    Time = rt72130HeaderTime2Epoch(Packet)
                    if Time < Earliest:
                        Earliest = Time
                    if Time > Latest:
                        Latest = Time
                    if DASID == "":
                        DASID = "%04X"%((ord(Packet[4]) << 8)+ord(Packet[5]))
        Fp.close()
# Both of these should be either true or false.
    if Earliest == maxint or Latest == -maxint:
        return (1, "RW", "%s: Could not process timing information."%CFDAS, 2)
    return (0, CFDAS, Earliest, Latest, DASID)
# END: rt130cfTimeRange




##################################################################
# BEGIN: rt130zcfTimeRange(ZCFSpec, StopBut, RunningVar, WhereMsg)
# LIB:rt130zcfTimeRange():2010.252
#   Scans through the SOH files of a CF card and finds the earliest and
#   latest times.
def rt130zcfTimeRange(ZCFSpec, StopBut, RunningVar, WhereMsg):
    Dir = dirname(ZCFSpec)+sep
    CFFile = basename(ZCFSpec)
    if is_zipfile(ZCFSpec) == False:
        return (1, "YB", "%s: Not a valid zip file."%CFFile, 2)
    try:
        Zp = ZipFile(ZCFSpec)
    except:
        return (1, "MW", "%s: Error opening file."%CFFile, 3)
    DASID = ""
    SOHFiles = []
    SOHLookFor = sep+"0"+sep
    for File in Zp.namelist():
        if basename(File).startswith(".") or File.startswith("_") or \
                File.endswith(".CFG") or File.endswith(sep):
            continue
        if File.find(SOHLookFor) != -1:
            SOHFiles.append(File)
    if len(SOHFiles) == 0:
        return (1, "YB", "%s: No SOH files found."%File, 2)
    SOHFiles.sort()
    Earliest = maxint
    Latest = -maxint
    for File in SOHFiles:
        if StopBut != None:
            StopBut.update()
            if RunningVar.get() == 0:
                Zp.close()
                return (2, "YB", "Stopped.", 2)
        Packets = Zp.read(File)
# If Packets is not a multiple of 1024 bytes it could mean the data on the CF
# card was corrupted and that could crash LOGPEEK.
        if len(Packets)%1024 != 0:
            Zp.close()
            return (1, "MW", \
                    "%s: Packets not 1024 bytes. Possibily corrupted."%File, 3)
        for Offset in xrange(0, len(Packets), 1024):
            Packet = Packets[Offset:Offset+1024]
            if len(Packet) < 1024:
                break
            PacketType = Packet[:2]
# We do this to try and keep packets of garbage from getting their times
# processed.
            if PacketType == "SH":
                Time = rt72130HeaderTime2Epoch(Packet)
                if Time < Earliest:
                    Earliest = Time
                if Time > Latest:
                    Latest = Time
                if DASID == "":
                    DASID = "%04X"%((ord(Packet[4]) << 8)+ord(Packet[5]))
    try:
        Zp.close()
    except:
        pass
# Both of these should be either true or false.
    if Earliest == maxint or Latest == -maxint:
        return (1, "RW", "%s: Could not process timing information."% \
                basename(ZCFSpec), 2)
    return (0, basename(ZCFSpec), Earliest, Latest, DASID)
# END: rt130zcfTimeRange




#############################################################################
# BEGIN: rt130ExtractUCFData(Dir, DAS, StopBut, Running, WhereMsg, IncNonSOH,
#                DSs, IncDS9, FromDate = 0, ToDate = maxint)
# LIB:rt130ExtractUCFData():2010.249
#   Extracts data from Unzipped CF card/image (UCF).
#   setMsg() being used in here in a LIB function is a bit abnormal, but it
#   keeps things simple.
def rt130ExtractUCFData(Dir, DAS, StopBut, Running, WhereMsg, IncNonSOH, DSs, \
            IncDS9, FromDate = 0, ToDate = maxint):
    global RawData
    global RTModel
# WARNING: This part is highly specialized for LOGPEEK.
    global MP1
    global MP2
    global MP3
    global MP4
    global MP5
    global MP6
    setMsg(WhereMsg, "CB", "Working...")
# It must be.
    RTModel = "RT130"
# The passed "File" is really just a directory, so get a list of the files in
# it that are also for the passed DAS (the data from more than one DAS may be
# in there).
    Ret = walkDirs(Dir, False)
    if Ret[0] != 0:
        return Ret
    CFFiles = Ret[1]
    TheCFFiles = []
    if IncNonSOH == 0:
# Somehow Python keeps all of this separator-stuff straight.
        DASLookFor = sep+DAS+sep
        SOHLookFor = sep+"0"+sep
        for File in CFFiles:
# We don't process the saved configuration files. Directories and hidden files
# are filtered out by walkDirs().
            if File.endswith(".CFG"):
                continue
            if File.find(DASLookFor) != -1 and File.find(SOHLookFor) != -1:
                TheCFFiles.append(File)
    elif IncNonSOH == 1:
        DASLookFor = sep+DAS+sep
        for File in CFFiles:
            if File.endswith(".CFG"):
                continue
            if File.find(DASLookFor) != -1:
                TheCFFiles.append(File)
    TotalFiles = len(TheCFFiles)
    if TotalFiles == 0:
        return (1, "YB", "No valid files for DAS %s found in\n   %s"%(DAS, \
                Dir), 2)
    TheCFFiles.sort()
    RetMessages = []
# Where the names of the files that are not multiples of 1024 bytes will be
# kept.  They will be added to the end of the RetMessages after all of the
# zipped files have been read.
    Failed1024 = []
    Samples = {}
    FileCount = 0
    for Filespec in TheCFFiles:
        if StopBut != None:
            StopBut.update()
            if Running.get() == 0:
                return (1, "YB", "Stopped.", 2)
# If Packets is not a multiple of 1024 bytes it could mean the data on the CF
# card was corrupted and that could crash LOGPEEK.
        if getsize(Filespec)%1024 != 0:
            Failed1024.append([Filespec, getsize(Filespec)])
            continue
        try:
            Fp = open(Filespec, "rb")
        except Exception, e:
            return (2, "MW", "Error opening file\n   %s\n   %s"%(Filespec, \
                    e), 3)
        FileCount += 1
        if FileCount%10 == 0:
            setMsg(WhereMsg, "CB", \
                    "Working on DAS %s.  Reading file %d of %d..."% \
                    (DAS, FileCount, TotalFiles))
        while 1:
# Read through the file 100 blocks at a time to speed things along.
# This failed once on a corrupted CF card and the error message meant nothing
# sensible: IOError: [Error 7] Argment list too long. I suspect even Python
# couldn't figure out what was going on with the card, so try.
            try:
                Block = Fp.read(102400)
            except IOError, e:
                Fp.close()
                return(2, "MW", "IOError: Is the CF card corrupted?:\n   %s"% \
                        e, 3)
# This will lose the last block if the file ends badly, but that should be
# caught in the 1024 test above.
            if len(Block) < 1024:
                break
# Go through the upto 100 packets read above. Use the length of the Block so
# when we get to the end of the file we will stop at the last block instead of
# just continuing for a full block (there is nothing to trigger when the last
# packet of the Block has been read unlike the RT125s where the ord(Page[0])
# is used).
            for Offset in xrange(0, len(Block), 1024):
                Packet = Block[Offset:Offset+1024]
                if len(Packet) < 1024:
                    if len(Packet) > 0:
                        Failed1024.append(Filespec, "-1")
                    break
                PacketType = Packet[:2]
                if PacketType == "SH":
                    rt72130SHDecode(FromDate, ToDate, Packet, RetMessages)
                    continue
                if IncNonSOH == 1:
# These will be the majority, so check for them first.
                    if PacketType == "DT":
                        DS = BCDTable[ord(Packet[18])]+1
# Only if the user wants it.
                        if DS in DSs:
                            DCE = (DS, BCDTable[ord(Packet[19])]+1, \
                                    (BCDTable[ord(Packet[16])]*100)+ \
                                    (BCDTable[ord(Packet[17])]))
                            if DCE in Samples:
                                Samples[DCE] += \
                                        (BCDTable[ord(Packet[20])]*100)+ \
                                        (BCDTable[ord(Packet[21])])
                            else:
                                Samples[DCE] = \
                                        (BCDTable[ord(Packet[20])]*100)+ \
                                        (BCDTable[ord(Packet[21])])
# For raw data we don't care about the event number, just the data stream and
# the channel.
                            DC = (DCE[0], DCE[1])
                            if DC in RawData:
                                pass
                            else:
                                RawData[DC] = []
                            rt72130DTDecode(0, FromDate, ToDate, DC, Packet, \
                                    RawData, RetMessages)
# WARNING: This part is highly specialized for LOGPEEK.
# Check to see if the user wants to plot the mass positions.
                        elif DS == 9 and IncDS9 == 1:
# Info = (Epoch, Channel, MP Value, Color Range Code (0-4))
                            Info = rt130MPDecode(FromDate, ToDate, Packet)
                            if Info[0] != 0:
# MPx = (Epoch, MP Value, Color Range Code)
                                eval("MP%d"%Info[1]).append([Info[0], \
                                        Info[2], Info[3]])
                    elif PacketType == "ET":
                        rt72130ETDecode(FromDate, ToDate, DSs, Packet, \
                                Samples, RetMessages)
                    elif PacketType == "SC":
                        rt72130SCDecode(FromDate, ToDate, Packet, RetMessages)
                    elif PacketType == "DS":
                        rt72130DSDecode(FromDate, ToDate, Packet, RetMessages)
                    elif PacketType == "CD":
                        rt72130CDDecode(FromDate, ToDate, RTModel, Packet, \
                                RetMessages)
                    elif PacketType == "OM":
                        rt72130OMDecode(FromDate, ToDate, RTModel, Packet, \
                                RetMessages)
        Fp.close()
# List any Samples left with no ET packet found.
    for Leftover in Samples:
        RetMessages.append( \
                "Missing ET packets?: DS %d, Chan %d, Event %d: %d samples"% \
                (Leftover[0], Leftover[1], Leftover[2], Samples[Leftover]))
    if len(Failed1024) != 0:
        RetMessages.append("")
        for File in Failed1024:
            RetMessages.append("WARNING: Not 1024 multiple: %s (%s bytes)"% \
                    (File[0], fmti(File[1])))
    return (0, RetMessages)
# END: rt130ExtractUCFData




##############################################################################
# BEGIN: rt130ExtractZCFData(Dir, File, StopBut, Running, WhereMsg, IncNonSOH,
#                DSs, IncDS9, FromDate = 0, ToDate = maxint)
# LIB:rt130ExtractZCFData():2010.249
#   Extract data from a Zipped CF card image file (ZCF).
#   Passes back a List of all of the SOH messages in a ".zip" file (the CF card
#   image from one DAS zipped by, for example, rt130Cut(), or an error message.
#   setMsg() being used in here is a bit abnormal, but it keeps things simple.
def rt130ExtractZCFData(Dir, File, StopBut, Running, WhereMsg, IncNonSOH, \
            DSs, IncDS9, FromDate = 0, ToDate = maxint):
    global RawData
    global RTModel
# WARNING: This part is highly specialized for LOGPEEK.
    global MP1
    global MP2
    global MP3
    global MP4
    global MP5
    global MP6
    setMsg(WhereMsg, "CB", "Working...")
    ZipFilespec = Dir+File
    if is_zipfile(ZipFilespec) == False:
        return (1, "YB", "Not a valid zip file\n   %s."%ZipFilespec, 2)
    try:
        Zp = ZipFile(ZipFilespec)
    except Exception, e:
        return (1, "MW", "Error opening zip file\n   %s\n   %s"% \
                (ZipFilespec, e), 3)
# If it is a zipped CF then this must be true.
    RTModel = "RT130"
    CFFiles = Zp.namelist()
    CFFiles.sort()
    TheCFFiles = []
    if IncNonSOH == 0:
# Somehow Python keeps all of this separator-stuff straight. SOH files are
# 'data stream 0'.
        SOHLookFor = sep+"0"+sep
        for CFFile in CFFiles:
# Stinking hidden files are EVERYWHERE from OSX.
            if CFFile.find(sep+".") != -1:
                continue
# CFFiles also has directory entries, so throw those out and also skip the
# saved parameters file if it is there.
            if CFFile.endswith(sep) or CFFile.endswith(".CFG"):
                continue
            if CFFile.find(SOHLookFor) != -1:
                TheCFFiles.append(CFFile)
    elif IncNonSOH == 1:
        for CFFile in CFFiles:
            if CFFile.find(sep+".") != -1:
                continue
            if CFFile.endswith(sep) or CFFile.endswith(".CFG"):
                continue
            TheCFFiles.append(CFFile)
    TotalFiles = len(TheCFFiles)
    if TotalFiles == 0:
        return (2, "RW", "%s: No files found to read."% \
                basename(ZipFilespec), 2)
    RetMessages = []
# Where the names of the files that are not multiples of 1024 bytes will be
# kept.  They will be added to the end of the RetMessages after all of the
# zipped files have been read.
    Failed1024 = []
    Samples = {}
    FileCount = 0
# Read through those 1K at a time just as if we were reading the .ref file.
    for CFFile in TheCFFiles:
        if StopBut != None:
            StopBut.update()
            if Running.get() == 0:
                Zp.close()
                return (1, "YB", "Stopped.", 2)
        FileCount += 1
        if FileCount%10 == 0:
            setMsg("MF", "CB", \
                    "Working on %s.  Reading zipped file %d of %d..."% \
                    (File, FileCount, TotalFiles))
        Packets = Zp.read(CFFile)
# If Packets is not a multiple of 1024 bytes it could mean the data on the CF
# card was corrupted and that could crash LOGPEEK.
        if len(Packets)%1024 != 0:
            Failed1024.append([CFFile, len(Packets)])
            continue
        for Offset in xrange(0, len(Packets), 1024):
            Packet = Packets[Offset:Offset+1024]
            if len(Packet) < 1024:
                if len(Packet) > 0:
                    Failed1024.append(CFFile, -1)
                break
            PacketType = Packet[:2]
            if PacketType == "SH":
                rt72130SHDecode(FromDate, ToDate, Packet, RetMessages)
                continue
            if IncNonSOH == 1:
                if PacketType == "DT":
                    DS = BCDTable[ord(Packet[18])]+1
# Only if the user wants it.
                    if DS in DSs:
                        DCE = (DS, BCDTable[ord(Packet[19])]+1, \
                                (BCDTable[ord(Packet[16])]*100)+ \
                                (BCDTable[ord(Packet[17])]))
                        if DCE in Samples:
                            Samples[DCE] += (BCDTable[ord(Packet[20])]*100)+ \
                                    (BCDTable[ord(Packet[21])])
                        else:
                            Samples[DCE] = (BCDTable[ord(Packet[20])]*100)+ \
                                    (BCDTable[ord(Packet[21])])
# For raw data we don't care about the event number, just the data stream and
# the channel.
                        DC = (DCE[0], DCE[1])
                        if DC in RawData:
                            pass
                        else:
                            RawData[DC] = []
                        rt72130DTDecode(0, FromDate, ToDate, DC, Packet, \
                                RawData, RetMessages)
# WARNING: This part is highly specialized for LOGPEEK.
# Check to see if the user wants to plot the mass positions.
                    elif DS == 9 and IncDS9 == 1:
# Info = (Epoch, Channel, MP Value, Color Range Code (0-4))
                        Info = rt130MPDecode(FromDate, ToDate, Packet)
                        if Info[0] != 0:
# MPx = (Epoch, MP Value, Color Range Code)
                            eval("MP%d"%Info[1]).append([Info[0], Info[2], \
                                    Info[3]])
                elif PacketType == "ET":
                    rt72130ETDecode(FromDate, ToDate, DSs, Packet, Samples, \
                            RetMessages)
                elif PacketType == "SC":
                    rt72130SCDecode(FromDate, ToDate, Packet, RetMessages)
                elif PacketType == "DS":
                    rt72130DSDecode(FromDate, ToDate, Packet, RetMessages)
                elif PacketType == "CD":
                    rt72130CDDecode(FromDate, ToDate, RTModel, Packet, \
                            RetMessages)
                elif PacketType == "OM":
                    rt72130OMDecode(FromDate, ToDate, RTModel, Packet, \
                            RetMessages)
    try:
        Zp.close()
    except:
        pass
# List any Samples left with no ET packet found.
    for Leftover in Samples:
        RetMessages.append( \
                "Missing ET packets?: DS %d, Chan %d, Event %d: %d samples"% \
                (Leftover[0], Leftover[1], Leftover[2], Samples[Leftover]))
# List any files that failed.
    if len(Failed1024) != 0:
        RetMessages.append("")
        for CFFile in Failed1024:
            RetMessages.append("WARNING: Not 1024 multiple: %s (%s bytes)"% \
                    (CFFile[0], fmti(CFFile[1])))
    return (0, RetMessages)
# END: rt130ExtractZCFData




#############################
# BEGIN: rt130FindCFDASs(Dir)
# LIB:rt130FindCFDASs():2008.173
#    Scans through the passed directory, assumed to be a directory where all
#    of the YYYYDDD directories are located, and returns the names of the
#    directories that look like RT130 DAS numbers (4 chars, hex).
def rt130FindCFDASs(Dir):
    DASs = []
    if Dir.endswith(sep) == False:
        Dir += sep
    DayDirs = listdir(Dir)
    for DayDir in DayDirs:
        if len(DayDir) == 7 and DayDir.isdigit():
            DASDirs = listdir(Dir+DayDir)
            for DASDir in DASDirs:
                if len(DASDir) == 4 and isHex(DASDir):
                    if DASDir not in DASs:
                        DASs.append(DASDir)
    return DASs
# END: rt130FindCFDASs




#####################################################################
# BEGIN: rt72130CDDecode(FromDate, ToDate, RTModel, Packet, Messages)
# LIB:rt72130CDDecode():2010.177
def rt72130CDDecode(FromDate, ToDate, RTModel, Packet, Messages):
# Check to see if the user even wants this packet.
    Epoch = rt72130HeaderTime2Epoch(Packet)
    if Epoch < FromDate or Epoch > ToDate:
        return
    YYYY, DDD, HH, MM, SS, TTT = rt72130HeaderTime2ydhmst(Packet)
    Messages.append("")
    Messages.append( \
           "Calibration Definition  %02d:%03d:%02d:%02d:%02d:%03d  ST: %04X"% \
            (YYYY, DDD, HH, MM, SS, TTT, \
            ((ord(Packet[4]) << 8)+ord(Packet[5]))))
    Messages.append("    Implemented = %s"% \
            ydhmst2YDHMST(Packet[1008:1008+16]))
    if RTModel == "72A":
# YYYYDDDHHMMSS is only 13 bytes, but the field is 14 bytes, so +14.
        Messages.append("    Start Time = %s"%ydhmst2YDHMST(Packet[16:16+14]))
        Messages.append("    Repeat Interval = %s"%Packet[30:30+8].strip())
        Messages.append("    Number Of Intervals = %s"%Packet[38:38+4].strip())
        Messages.append("    Length = %s"%Packet[42:42+8].strip())
        Messages.append("    Step On/Off = %s"%Packet[50:50+4].strip())
        Messages.append("    Step Period = %s"%Packet[54:54+8].strip())
        Messages.append("    Step Size = %s"%Packet[62:62+8].strip())
        Messages.append("    Step Amplitude = %s"%Packet[70:70+8].strip())
        Messages.append("    Step Output = %s"%Packet[78:78+4].strip())
    elif RTModel == "RT130":
        First = True
        Any = False
        for Offset in xrange(130, 130+64, 16):
            Sensor = intt(Packet[Offset:Offset+1])
            if Sensor == 0:
                continue
            if First == True:
                Messages.append("    130 Sensor Auto-Center Information")
                First = False
            Any = True
            Messages.append("        Sensor = %d"%Sensor)
            Value = Packet[Offset+1:Offset+1+1]
            if Value == " ":
                Messages.append("            Enable = Disabled")
            else:
                Messages.append("            Enable = Enabled")
            Messages.append("            Reading Interval = %s"% \
                    Packet[Offset+2:Offset+2+4].strip())
            Messages.append("            Cycle Interval = %s"% \
                    Packet[Offset+6:Offset+6+2].strip())
            Messages.append("            Level = %s"% \
                    Packet[Offset+8:Offset+8+4].strip())
            Messages.append("            Attempts = %s"% \
                    Packet[Offset+12:Offset+12+2].strip())
            Messages.append("            Attempt Interval = %s"% \
                    Packet[Offset+14:Offset+14+2].strip())
        First = True
        for Offset in xrange(194, 194+112, 28):
            Sensor = intt(Packet[Offset:Offset+1])
            if Sensor == 0:
                continue
            if First == True:
                Messages.append( \
                        "    130 Sensor Calibration Signal Information")
                First = False
            Any = True
            Messages.append("        Sensor = %d"%Sensor)
            Value = Packet[Offset+1:Offset+1+1]
            if Value == " ":
                Messages.append("            Enable = Disabled")
            else:
                Messages.append("            Enable = Enabled")
            Messages.append("            Duration = %s"% \
                    Packet[Offset+4:Offset+4+4].strip())
            Messages.append("            Amplitude = %s"% \
                    Packet[Offset+8:Offset+8+4].strip())
            Messages.append("            Signal = %s"% \
                    Packet[Offset+12:Offset+12+4].strip())
            Messages.append("            Step Interval = %s"% \
                    Packet[Offset+16:Offset+16+4].strip())
            Messages.append("            Step Width = %s"% \
                    Packet[Offset+20:Offset+20+4].strip())
            Messages.append("            Sine Frequency = %s"% \
                    Packet[Offset+24:Offset+24+4].strip())
        First = True
        for Offset in xrange(306, 306+538, 28):
            Seq = intt(Packet[Offset:Offset+2])
            if Seq == 0:
                continue
            if First == True:
                Messages.append( \
                        "    130 Sensor Calibration Sequence Information")
                First = False
            Any = True
            Messages.append("        Sequence = %d"%Seq)
            Value = Packet[Offset+1:Offset+1+1]
            if Value == " ":
                Messages.append("            Enable = Disabled")
            else:
                Messages.append("            Enable = Enabled")
            Messages.append("            Start Time = %s"% \
                    ydhmst2YDHMST(Packet[Offset+4:Offset+4+14]))
            Messages.append("            Interval = %s"% \
                    dhms2DHMS(Packet[Offset+18:Offset+18+8]))
            Messages.append("            Count = %s"% \
                    Packet[Offset+26:Offset+26+2].strip())
            Messages.append("            Record Length = %s"% \
                    Packet[Offset+28:Offset+28+8].strip())
            Messages.append("            Sensor = %s"% \
                    Packet[Offset+36:Offset+36+4].strip())
        if Any == False:
            Messages.append("    No parameters defined.")
    return
# END: rt72130CDDecode




############################################################
# BEGIN: rt72130DSDecode(FromDate, ToDate, Packet, Messages)
# LIB:rt72130DSDecode():2010.253
#   Needs PROG_DSS set to the max data stream number.
def rt72130DSDecode(FromDate, ToDate, Packet, Messages):
# Check to see if the user even wants this packet.
    Epoch = rt72130HeaderTime2Epoch(Packet)
    if Epoch < FromDate or Epoch > ToDate:
        return
    YYYY, DDD, HH, MM, SS, TTT = rt72130HeaderTime2ydhmst(Packet)
    Messages.append("")
    Messages.append( \
       "Data Stream Definition  %02d:%03d:%02d:%02d:%02d:%03d  ST: %04X"% \
            (YYYY, DDD, HH, MM, SS, TTT, \
            ((ord(Packet[4]) << 8)+ord(Packet[5]))))
    Messages.append("    Implemented = %s"% \
            ydhmst2YDHMST(Packet[1008:1008+16]))
    for Offset in xrange(16, 16+920, 230):
        DS = intt(Packet[Offset:Offset+2])
        if DS == 0 or DS > PROG_DSS:
            continue
        Messages.append("    Data Stream Number = %d"%DS)
        Messages.append("        Name = %s"% \
                Packet[Offset+2:Offset+2+16].strip())
        Value = Packet[Offset+18:Offset+18+4]
        Dest = ""
        if Value[0] != " ":
            Dest += "RAM "
        if Value[1] != " ":
            Dest += "Disk "
        if Value[2] != " ":
            Dest += "Ethernet "
        if Value[3] != " ":
            Dest += "Serial"
        Messages.append("        Recording Destination = %s"%Dest)
        Value = Packet[Offset+26:Offset+26+16]
        Chans = ""
        Ch = 0
        for C in Value:
            Ch += 1
            if C != " ":
                Chans += "%d "%Ch
        Messages.append("        Channels Included = %s"%Chans)
        Messages.append("        Sample Rate = %s"% \
                Packet[Offset+42:Offset+42+4].strip())
        Messages.append("        Data Format = %s"% \
                Packet[Offset+46:Offset+46+2].strip())
        Trig = Packet[Offset+64:Offset+64+4].strip()
        Messages.append("        Trigger Type = %s"%Trig)
        TOffset = Offset+68
        if Trig == "CON":
            Messages.append("            Record Length = %s"% \
                    Packet[TOffset+0:TOffset+0+8].strip())
            Messages.append("            Start Time = %s"% \
                    ydhmst2YDHMST(Packet[TOffset+8:TOffset+8+14]))
        elif Trig == "CRS":
            Messages.append("            Trigger Stream Number = %s"% \
                    Packet[TOffset+0:TOffset+0+2].strip())
            Messages.append("            Pretrigger Length = %s"% \
                    Packet[TOffset+2:TOffset+2+8].strip())
            Messages.append("            Record Length = %s"% \
                    Packet[TOffset+10:TOffset+10+8].strip())
        elif Trig == "EXT":
            Messages.append("            Pretrigger Length = %s"% \
                    Packet[TOffset+0:TOffset+0+8].strip())
            Messages.append("            Record Length = %s"% \
                    Packet[TOffset+8:TOffset+8+8].strip())
        elif Trig == "EVT":
            Value = Packet[TOffset+0:TOffset+0+16]
            Chans = ""
            Ch = 0
            for C in Value:
                Ch += 1
                if C != " ":
                    Chans += "%d "%Ch
            Messages.append("            Trigger Channels = %s"%Chans)
            Messages.append("            Minimum Channels = %s"% \
                    Packet[TOffset+16:TOffset+16+2].strip())
            Messages.append("            Trigger Window = %s"% \
                    Packet[TOffset+18:TOffset+18+8].strip())
            Messages.append("            Pretrigger Length = %s"% \
                    Packet[TOffset+26:TOffset+26+8].strip())
            Messages.append("            Post-trigger Length = %s"% \
                    Packet[TOffset+34:TOffset+34+8].strip())
            Messages.append("            Record Length = %s"% \
                    Packet[TOffset+42:TOffset+42+8].strip())
            Messages.append("            STA Length = %s"% \
                    Packet[TOffset+58:TOffset+58+8].strip())
            Messages.append("            LTA Length = %s"% \
                    Packet[TOffset+66:TOffset+66+8].strip())
            Messages.append("            Mean Removal = %s"% \
                    Packet[TOffset+74:TOffset+74+8].strip())
            Messages.append("            Trigger Ratio = %s"% \
                    Packet[TOffset+82:TOffset+82+8].strip())
            Messages.append("            De-trigger Ratio = %s"% \
                    Packet[TOffset+90:TOffset+90+8].strip())
            Messages.append("            LTA Hold = %s"% \
                    Packet[TOffset+98:TOffset+98+4].strip())
            Messages.append("            Low Pass Corner Freq = %s"% \
                    Packet[TOffset+102:TOffset+102+4].strip())
            Messages.append("            High Pass Corner Freq = %s"% \
                    Packet[TOffset+106:TOffset+106+4].strip())
        elif Trig == "LEV":
            Messages.append("            Level = %s"% \
                    Packet[TOffset+0:TOffset+0+8].strip())
            Messages.append("            Pretrigger Length = %s"% \
                    Packet[TOffset+8:TOffset+8+8].strip())
            Messages.append("            Record Length = %s"% \
                    Packet[TOffset+16:TOffset+16+8].strip())
            Messages.append("            Low Pass Corner Freq = %s"% \
                    Packet[TOffset+24:TOffset+24+4].strip())
            Messages.append("            High Pass Corner Freq = %s"% \
                    Packet[TOffset+28:TOffset+28+4].strip())
        elif Trig == "TIM":
            Messages.append("            Start Time = %s"% \
                    ydhmst2YDHMST(Packet[TOffset+0:TOffset+0+14]))
            Messages.append("            Repeat Interval = %s"% \
                    dhms2DHMS(Packet[TOffset+14:TOffset+14+8]))
            Messages.append("            Number Of Intervals = %s"% \
                    Packet[TOffset+22:TOffset+22+4].strip())
            Messages.append("            Record Length = %s"% \
                    Packet[TOffset+34:TOffset+34+8].strip())
        elif Trig == "TML":
            for i in xrange(1, 12):
                Messages.append("            Start Time %d = %s"%(i, \
                        ydhmst2YDHMST(Packet[TOffset+(i*14): \
                        TOffset+(i*14)+14])))
            Messages.append("            Record Length = %s"% \
                    Packet[TOffset+154:TOffset+154+8].strip())
        elif Trig == "VOT":
            Messages.append("            Pretrigger Length = %s"% \
                    Packet[TOffset+0:TOffset+0+8].strip())
            Messages.append("            Post-trigger Length = %s"% \
                    Packet[TOffset+8:TOffset+8+8].strip())
            Messages.append("            Record Length = %s"% \
                    Packet[TOffset+16:TOffset+16+8].strip())
            Messages.append("            Level Units = %s"% \
                    Packet[TOffset+24:TOffset+24+1].strip())
# 1-G is 1-16. Stupid.
            Value = Packet[TOffset+28:TOffset+28+6].upper()
            Chans = ""
            for C in Value:
               if C == " ":
                   continue
               if isHex(C):
                   Chans += "%d "%int(C, 16)
               elif C == "G":
                   Chans += "16 "
            Messages.append("            Trigger Channels = %s"%Chans)
            Value = Packet[TOffset+34:TOffset+34+6]
            Votes = ""
            for C in Value:
                if C == " ":
                    continue
                Votes += "%s "%C
            Messages.append("            Trigger Channel Votes = %s"%Votes)
            Levels = ""
            for i in xrange(0, 8):
                Value = Packet[TOffset+40+(i*6):TOffset+40+(i*6)+6].strip()
                if Value == "":
                    continue
                Levels += "%s "%Value
            Messages.append("            Trigger Channel Levels = %s"%Levels)
            Messages.append("            Trigger Minimum Votes = %s"% \
                    Packet[TOffset+88:TOffset+88+2].strip())
            Messages.append("            Trigger Window = %s"% \
                    Packet[TOffset+90:TOffset+90+8].strip())
            Value = Packet[TOffset+98:TOffset+98+6]
            Votes = ""
            for C in Value:
                if C == " ":
                    continue
                Votes += "%s "%C
            Messages.append("            De-trigger Channel Votes = %s"%Votes)
            Levels = ""
            for i in xrange(0, 8):
                Value = Packet[TOffset+104+(i*6):TOffset+104+(i*6)+6].strip()
                if Value == "":
                    continue
                Levels += "%s "%Value
            Messages.append("            De-trigger Channel Levels = %s"% \
                    Levels)
            Messages.append("            De-trigger Minimum Votes = %s"% \
                    Packet[TOffset+152:TOffset+152+2].strip())
            Messages.append("            Low Pass Corner Freq = %s"% \
                    Packet[TOffset+154:TOffset+154+4].strip())
            Messages.append("            High Pass Corner Freq = %s"% \
                    Packet[TOffset+158:TOffset+158+4].strip())
        else:
            Messages.append("            Unknown trigger type: %s"%Trig)
    return
# END: rt72130DSDecode




#######################################################################
# BEGIN: rt72130DTDecode(Mode, FromDate, ToDate, DC, Packet, RawData, \
#                RetMessages)
# LIB:rt72130DTDecode():2010.249
#   Mode = 0 = read only the first value from the packet
#              16, 32 - first value
#              C0, C2 - first value is max value
# FINISHME - Mode 1
#   Mode = 1 = read all data points (not implemented yet)
def rt72130DTDecode(Mode, FromDate, ToDate, DC, Packet, RawData, RetMessages):
# Check to see if the user even wants this packet.
    Epoch = rt72130HeaderTime2Epoch(Packet)
    if Epoch < FromDate or Epoch > ToDate:
        return
    Format = ord(Packet[23])
    RawSamples = bcd2Int(Packet[20:22])
# In order of PASSCAL experiments' popularity.
    if Format == 0xC0:
# Start value for the packet is at offset 24+40+4+4=72.
        Value = (ord(Packet[72]) << 24)+(ord(Packet[73]) << 16)+ \
                (ord(Packet[74]) << 8)+ord(Packet[75])
        if Value > 0x7FFFFFFF:
            Value -= 0x100000000
        RawData[DC] += [Epoch, Value],
    elif Format == 0xC2:
        Value = (ord(Packet[72]) << 24)+(ord(Packet[73]) << 16)+ \
                (ord(Packet[74]) << 8)+ord(Packet[75])
        if Value > 0x7FFFFFFF:
            Value -= 0x100000000
        RawData[DC] += [Epoch, Value],
    elif Format >= 32:
# Fist value after the standard header 24 bytes.
        Value = (ord(Packet[24]) << 24)+(ord(Packet[25]) << 16)+ \
                (ord(Packet[26]) << 8)+ord(Packet[27])
        if Value > 0x7FFFFFFF:
            Value -= 0x100000000
        RawData[DC] += [Epoch, Value],
    elif Format == 16:
        Value = (ord(Packet[24]) << 8)+(ord(Packet[25]))
        if Value > 0x7FFF:
            Value -= 0x10000
        RawData[DC] += [Epoch, Value],
    else:
        RawData[DC] += [0, 0],
    return
# END: rt72130DTDecode




# FINISHME - why isn't this used again??
############################################################
# BEGIN: rt72130EHDecode(FromDate, ToDate, Packet, Messages)
# LIB:rt72130EHDecode():2008.299
def rt72130EHDecode(FromDate, ToDate, Packet, Messages):
# Check to see if the user even wants this packet.
    Epoch = rt72130HeaderTime2Epoch(Packet)
    if Epoch < FromDate or Epoch > ToDate:
        return
    DS = BCDTable[ord(Packet[18:18+1])]+1
    SPS = intt(Packet[88:88+4])
    Messages.append("DAS: %04X  EV: %04d  DS: %d  FST = %s  TT = %s  NS: ?????  SPS: %d  ETO: ?"% \
            ((ord(Packet[4]) << 8)+ord(Packet[5]), \
            (BCDTable[ord(Packet[16])]*100)+(BCDTable[ord(Packet[17])]), DS, \
            ydhmst2YDHMST(Packet[112:112+16]), \
            ydhmst2YDHMST(Packet[96:96+16]), SPS))
    return
# END: rt72130EHDecode




##########################################################################
# BEGIN: rt72130ETDecode(FromDate, ToDate, DSs, Packet, Samples, Messages)
# LIB:rt72130ETDecode():2010.246
def rt72130ETDecode(FromDate, ToDate, DSs, Packet, Samples, Messages):
# Check to see if the user even wants this packet.
    Epoch = rt72130HeaderTime2Epoch(Packet)
    if Epoch < FromDate or Epoch > ToDate:
        return
    DS = BCDTable[ord(Packet[18:18+1])]+1
# No DS9 stuff.
    if DS < 0 or DS > 8:
        return
    Event = (BCDTable[ord(Packet[16])]*100)+(BCDTable[ord(Packet[17])])
# Go through this exercise to determine which channels are in this data stream.
    Chans = []
    Ch = 0
    for Offset in xrange(416, 416+16):
        Ch += 1
        if Packet[Offset] != " ":
            Chans.append(Ch)
    if len(Chans) == 0:
        Messages.append( \
                "WARNING: No channels set in ET packet (DS %s, Event %d)."% \
                (DS, Event))
        return
# FINISHME - we should check to make sure all of the channels have the same
#            sample count here some day.
# Just use the sample count from the first channel (they should all be the
# same, unless the file is truncated in which case the error message below will
# be listed in the source file).
    DCE = (DS, Chans[0], Event)
# We only want complaints about channels in data streams that the user is
# plotting. The numer of samples are not counted unless the raw data is going
# to be plotted.
    if DS in DSs:
        try:
            NSamples = Samples[DCE]
        except KeyError:
            Messages.append( \
                    "WARNING: ET Samples KeyError (DS, Channel, Event): %s  Event data truncated?"% \
                    str(DCE))
            NSamples = -1
    else:
        NSamples = -1
    SPS = intt(Packet[88:88+4])
    FST = ydhmst2YDHMST(Packet[112:112+16])
    TT = ydhmst2YDHMST(Packet[96:96+16])
# FINISHME - it's not clear how to calculate this
# Get the length of the event, calculate the number of samples there should
# have been and use that for the ETO.
#    EpochFST = YDHMST2Epoch(FST)
#    LST = ydhmst2YDHMST(Packet[144:144+16])
#    EpochLST = YDHMST2Epoch(LST)
#    EpochTT = YDHMST2Epoch(TT)
#    DTT = ydhmst2YDHMST(Packet[128:128+16])
#    EpochDTT = YDHMST2Epoch(DTT)
#    print FST, TT, DTT, LST, (EpochLST-EpochFST)
# +1 = it's a fence post thing...kinda. Counting samples gives what you would
# expect +1, and calculating gives that number almost minus 1, which is what
# you would expect. So I'm not sure who is lying.
#    ETO = NSamples-(((EpochLST-EpochFST)*SPS)+1)
#    Messages.append("DAS: %04X  EV: %04d  DS: %d  FST = %s  TT = %s  NS: %d  SPS: %d  ETO: %d"% \
#            ((ord(Packet[4]) << 8)+ord(Packet[5]), Event, DS, FST, TT, \
#            NSamples, SPS, ETO))
    Messages.append("DAS: %04X  EV: %04d  DS: %d  FST = %s  TT = %s  NS: %d  SPS: %d  ETO: ?"% \
            ((ord(Packet[4]) << 8)+ord(Packet[5]), Event, DS, FST, TT, \
            NSamples, SPS))
# Now go through the Samples dictonary and delete entries matching the DCE with
# all of this data stream's channels. This will error for every data stream and
# channel that the user is not plotting (see above), but that's what try-except
# is for.
    for Chan in Chans:
        DCE = (DS, Chan, Event)
        try:
            del Samples[DCE]
        except KeyError:
            pass
    return
# END: rt72130ETDecode




############################################################################
# BEGIN: rt72130ExtractRefData(Dir, File, Model, StopBut, Running, WhereMsg,
#                IncNonSOH, DSs, IncDS9, FromDate = 0, ToDate = maxint)
# LIB:rt72130ExtractRefData():2010.249
#   Passes back a List of all of the SOH messages in a ".ref" file (one large
#   file from one DAS), or an error message.
#   If IncNonSOH is 1 then more than just the SOH packets will be read. If
#   DSs is also not [] then the DT packets will be read and the data points
#   left in the global RawData (the data streams that will be looked for will
#   be in the List DSs).
#   setMsg() being used in here is a bit abnormal, but it keeps things simple.
def rt72130ExtractRefData(Dir, File, Model, StopBut, Running, WhereMsg, \
        IncNonSOH, DSs, IncDS9, FromDate = 0, ToDate = maxint):
    global RawData
    global RTModel
# WARNING: This part is highly specialized for LOGPEEK.
    global MP1
    global MP2
    global MP3
    global MP4
    global MP5
    global MP6
    setMsg(WhereMsg, "CB", "Working...")
    try:
        Fp = open(Dir+File, "rb")
    except Exception, e:
        return (2, "MW", "Error opening file\n   %s\n   %s"%((Dir+File), \
                e), 3)
# If the caller did not supply the recorder model we'll need to go looking for
# in the the beginning of the .ref file.
    if Model == "":
# There are getting to be more of these now.
        RTModel = "RT130"
        Packet = Fp.read(1024)
        if len(Packet) == 1024:
            UID = rt72130GetUID(Packet[4:4+2])
            if UID < "9000":
                RTModel = "72A"
        Fp.seek(0)
    else:
        RTModel = Model
    RetMessages = []
    Samples = {}
    PacketTotal = int(getsize(Dir+File)/1024)
    PacketCount = 0
    while 1:
        if StopBut != None:
            StopBut.update()
            if Running.get() == 0:
                Fp.close()
                return (1, "YB", "Stopped.", 2)
# Read through the file 100 blocks at a time to speed things along.
        Block = Fp.read(102400)
# This will lose the last block if the file ends badly.
        if len(Block) < 1024:
            Fp.close()
            break
        PacketCount += 100
        if PacketCount%10000 == 0:
            setMsg(WhereMsg, "CB", \
                    "Working on %s.  Reading packet %d of %d..."% \
                    (File, PacketCount, PacketTotal))
# Go through the upto 100 packets read above. Use the length of the Block so
# when we get to the end of the file we will stop at the last block instead of
# just continuing for a full block (there is nothing to trigger when the last
# packet of the Block has been read unlike the RT125s where the ord(Page[0])
# is used).
        for Offset in xrange(0, len(Block), 1024):
            Packet = Block[Offset:Offset+1024]
            if len(Packet) < 1024:
                break
            PacketType = Packet[:2]
            if PacketType == "SH":
                rt72130SHDecode(FromDate, ToDate, Packet, RetMessages)
                continue
            if IncNonSOH == 1:
# These will be the majority, so check for them first.
                if PacketType == "DT":
                    DS = BCDTable[ord(Packet[18])]+1
# Only if the user wants it.
                    if DS in DSs:
                        DCE = (DS, BCDTable[ord(Packet[19])]+1, \
                                (BCDTable[ord(Packet[16])]*100)+ \
                                (BCDTable[ord(Packet[17])]))
                        if DCE in Samples:
                            Samples[DCE] += (BCDTable[ord(Packet[20])]*100)+ \
                                    (BCDTable[ord(Packet[21])])
                        else:
                            Samples[DCE] = (BCDTable[ord(Packet[20])]*100)+ \
                                    (BCDTable[ord(Packet[21])])
# For raw data we don't care about the event number, just the data stream and
# the channel.
                        DC = (DCE[0], DCE[1])
                        if DC in RawData:
                            pass
                        else:
                            RawData[DC] = []
                        rt72130DTDecode(0, FromDate, ToDate, DC, Packet, \
                                RawData, RetMessages)
# WARNING: This part is highly specialized for LOGPEEK.
# Check to see if the user wants to plot the mass positions.
                    elif DS == 9 and IncDS9 == 1:
# Info = (Epoch, Channel, MP Value, Color Range Code (0-4))
                        Info = rt130MPDecode(FromDate, ToDate, Packet)
                        if Info[0] != 0:
# MPx = (Epoch, MP Value, Color Range Code)
                            eval("MP%d"%Info[1]).append([Info[0], Info[2], \
                                    Info[3]])
                elif PacketType == "ET":
                    rt72130ETDecode(FromDate, ToDate, DSs, Packet, Samples, \
                            RetMessages)
                elif PacketType == "SC":
                    rt72130SCDecode(FromDate, ToDate, Packet, RetMessages)
                elif PacketType == "DS":
                    rt72130DSDecode(FromDate, ToDate, Packet, RetMessages)
                elif PacketType == "CD":
                    rt72130CDDecode(FromDate, ToDate, RTModel, Packet, \
                            RetMessages)
                elif PacketType == "OM":
                    rt72130OMDecode(FromDate, ToDate, RTModel, Packet, \
                            RetMessages)
# List any Samples left with no ET packet found.
    for Leftover in Samples:
        RetMessages.append( \
                "Missing ET packets?: DS %d, Chan %d, Event %d: %d samples"% \
                (Leftover[0], Leftover[1], Leftover[2], Samples[Leftover]))
    return (0, RetMessages)
# END: rt72130ExtractRefData




########################################
# BEGIN: rt72130HeaderTime2Epoch(Packet)
# LIB:rt72130HeaderTime2Epoch():2010.243
#    Returns the number of seconds since Jan 1, 1970.
#    Does not know anything about leap seconds.
def rt72130HeaderTime2Epoch(Packet):
    global PROGYEF70
    YYYY = BCDTable[ord(Packet[3])]
    if YYYY >= 70:
        YYYY += 1900
    else:
        YYYY += 2000
    Epoch = 0.0
    try:
# This bit of trickery ends up saving quite a bit of time. The Epoch for each
# year only needs to be loop-calculated once. The rest of the time it just
# gets looked up.
        try:
            Epoch = PROGYEF70[YYYY]
        except KeyError:
            for YYY in xrange(1970, YYYY):
                if YYY%4 != 0:
                    Epoch += 31536000.0
                elif YYY%100 != 0 or YYY%400 == 0:
                    Epoch += 31622400.0
                else:
                    Epoch += 31536000.0
            PROGYEF70[YYYY] = Epoch
# DDD
        Epoch += 86400.0*((BCDTable[ord(Packet[6])]*10)+ \
                ((ord(Packet[7]) & 0xF0) >> 4)-1)
# HH
        Epoch += 3600.0*(((ord(Packet[7]) & 0x0F)*10)+ \
                ((ord(Packet[8]) & 0xF0) >> 4))
# MM
        Epoch += 60.0*(((ord(Packet[8]) & 0x0F)*10)+ \
                ((ord(Packet[9]) & 0xF0) >> 4))
# SS
        Epoch += ((ord(Packet[9]) & 0x0F)*10)+((ord(Packet[10]) & 0xF0) >> 4)
# TTT
        Epoch += (((ord(Packet[10]) & 0x0F)*100)+ \
                 (((ord(Packet[11]) & 0xF0) >> 4)*10)+ \
                 (ord(Packet[11]) & 0x0F))/1000.0
    except ValueError:
        Epoch = 0.0
    return Epoch
# END: rt72130HeaderTime2Epoch




#########################################
# BEGIN: rt72130HeaderTime2ydhmst(Packet)
# LIB:rt72130HeaderTime2ydhmst():2008.299
def rt72130HeaderTime2ydhmst(Packet):
    return (BCDTable[ord(Packet[3])], \
            (BCDTable[ord(Packet[6])]*10)+((ord(Packet[7]) & 0xF0) >> 4), \
            ((ord(Packet[7]) & 0x0F)*10)+((ord(Packet[8]) & 0xF0) >> 4), \
            ((ord(Packet[8]) & 0x0F)*10)+((ord(Packet[9]) & 0xF0) >> 4), \
            ((ord(Packet[9]) & 0x0F)*10)+((ord(Packet[10]) & 0xF0) >> 4), \
            ((ord(Packet[10]) & 0x0F)*100)+BCDTable[ord(Packet[11])])
# END: rt72130HeaderTime2ydhmst




#####################################################################
# BEGIN: rt72130OMDecode(FromDate, ToDate, RTModel, Packet, Messages)
# LIB:rt72130OMDecode():2010.177
def rt72130OMDecode(FromDate, ToDate, RTModel, Packet, Messages):
# Check to see if the user even wants this packet.
    Epoch = rt72130HeaderTime2Epoch(Packet)
    if Epoch < FromDate or Epoch > ToDate:
        return
    YYYY, DDD, HH, MM, SS, TTT = rt72130HeaderTime2ydhmst(Packet)
    Messages.append("")
    Messages.append( \
        "Operating Mode Definition  %02d:%03d:%02d:%02d:%02d:%03d  ST: %04X"% \
            (YYYY, DDD, HH, MM, SS, TTT, \
            ((ord(Packet[4]) << 8)+ord(Packet[5]))))
    Messages.append("    Implemented = %s"% \
            ydhmst2YDHMST(Packet[1008:1008+16]))
    if RTModel == "72A":
        Messages.append("    Power State = %s"%Packet[16:16+2].strip())
        Messages.append("    Recording Mode = %s"%Packet[18:18+2].strip())
        Messages.append("    Auto-Dump On ET = %s"%Packet[24:24+1].strip())
        Messages.append("    Auto-Dump Threshold = %s"% \
                Packet[26:26+2].strip())
        Messages.append("    Power-Down Delay = %s"%Packet[28:28+4].strip())
        Messages.append("    Disk Wrap = %s"%Packet[32:32+1].strip())
        Messages.append("    Disk Power = %s"%Packet[34:34+1].strip())
        Messages.append("    Terminator Power = %s"%Packet[35:35+1].strip())
        Messages.append("    Disk Retry = %s"%Packet[36:36+1].strip())
        Messages.append("    Wakeup Start Time = %s"% \
                ydhmst2YDHMST(Packet[50:50+12]))
        Messages.append("    Wakeup Duration = %s"%dhms2DHMS(Packet[62:62+6]))
        Messages.append("    Wakeup Repeat Interval = %s"% \
                dhms2DHMS(Packet[68:68+6]))
        Messages.append("    Wakeup Number Of Intervals = %s"% \
                Packet[74:74+2].strip())
    elif RTModel == "RT130":
        Messages.append("    Auto-Dump On ET = %s"%Packet[24:24+1].strip())
        Messages.append("    Auto-Dump Threshold = %s"% \
                Packet[26:26+2].strip())
        Messages.append("    Disk Wrap = %s"%Packet[32:32+1].strip())
        Messages.append("    Disk Retry = %s"%Packet[36:36+1].strip())
# END: rt72130OMDecode




############################################################
# BEGIN: rt72130SCDecode(FromDate, ToDate, Packet, Messages)
# LIB:rt72130SCDecode():2010.177
def rt72130SCDecode(FromDate, ToDate, Packet, Messages):
# Check to see if the user even wants this packet.
    Epoch = rt72130HeaderTime2Epoch(Packet)
    if Epoch < FromDate or Epoch > ToDate:
        return
    YYYY, DDD, HH, MM, SS, TTT = rt72130HeaderTime2ydhmst(Packet)
    Messages.append("")
    Messages.append( \
       "Station Channel Definition  %02d:%03d:%02d:%02d:%02d:%03d  ST: %04X"% \
            (YYYY, DDD, HH, MM, SS, TTT, \
            ((ord(Packet[4]) << 8)+ord(Packet[5]))))
    Messages.append("    Implemented = %s"% \
            ydhmst2YDHMST(Packet[1008:1008+16]))
    Messages.append("    Experiment Number = %s"%Packet[16:16+2].strip())
    Messages.append("    Experiment Name = %s"%Packet[18:18+24].strip())
    Messages.append("    Experiment Comment = %s"%Packet[42:42+40].strip())
    Messages.append("    Station Number = %s"%Packet[82:82+4].strip())
    Messages.append("    Station Name = %s"%Packet[86:86+24].strip())
    Messages.append("    Station Comment = %s"%Packet[110:110+40].strip())
    Messages.append("    DAS Model Number = %s"%Packet[150:150+12].strip())
    Messages.append("    DAS Serial Number = %s"%Packet[162:162+12].strip())
    Messages.append("    Experiment Start Time = %s"% \
            Packet[174:174+14].strip())
    Messages.append("    Time Clock Type = %s"%Packet[188:188+4].strip())
    Messages.append("    Clock Serial Number = %s"%Packet[192:192+10].strip())
    for Offset in xrange(202, 202+730, 146):
        Channel = intt(Packet[Offset:Offset+2])
        if Channel == 0:
            continue
        Messages.append("    Channel Number = %d"%Channel)
        Messages.append("        Name = %s"% \
                Packet[Offset+2:Offset+2+10].strip())
        Messages.append("        Azimuth = %s"% \
                Packet[Offset+12:Offset+12+10].strip())
        Messages.append("        Inclination = %s"% \
                Packet[Offset+22:Offset+22+10].strip())
        Messages.append("        X Coordinate = %s"% \
                Packet[Offset+32:Offset+32+10].strip())
        Messages.append("        Y Coordinate = %s"% \
                Packet[Offset+42:Offset+42+10].strip())
        Messages.append("        Z Coordinate = %s"% \
                Packet[Offset+52:Offset+52+10].strip())
        Messages.append("        XY Unit Type = %s"% \
                Packet[Offset+62:Offset+62+4].strip())
        Messages.append("        Z Unit Type = %s"% \
                Packet[Offset+66:Offset+66+4].strip())
        Messages.append("        Preamp Gain = %s"% \
                Packet[Offset+70:Offset+70+4].strip())
        Messages.append("        Sensor Model = %s"% \
                Packet[Offset+74:Offset+74+12].strip())
        Messages.append("        Sensor Serial Number = %s"% \
                Packet[Offset+86:Offset+86+12].strip())
        Messages.append("        Comments = %s"% \
                Packet[Offset+98:Offset+98+40].strip())
        Messages.append("        Adjusted Nominal Bit Weight = %s"% \
                Packet[Offset+138:Offset+138+8].strip())
    return
# END: rt72130SCDecode




##################################################################
# BEGIN: rt72130logTimeRange(FileLines, File, StopBut, RunningVar)
# LIB:rt72130logTimeRange():2010.252
#   Reads a .log file from a 72A or RT130 DAS and returns the earliest time
#   and the latest time in the file. FileLines can also be the SOH message
#   lines already read.
def rt72130logTimeRange(FileLines, File, StopBut, RunningVar):
    if isinstance(FileLines, str):
        try:
            Fp = open(FileLines, "r")
            Lines = readFileLines(Fp)
            Fp.close()
        except:
            return (2, "MW", "%s: Error opening file."%basename(FileLines), 3)
    else:
        Lines = FileLines
    Earliest = maxint
    Latest = -maxint
# Start through the file and look for any of these things that have the year
# and date/time. The calls will update the globals.
    LineCount = 0
    for Line in Lines:
        LineCount += 1
        if LineCount%500 == 0:
            if StopBut != None:
                StopBut.update()
                if RunningVar.get() == 0:
                    Fp.close()
                    return (2, "YB", "Stopped.", 2)
# Ex: State of Health  01:251:09:41:35:656   ST: 0108
        if Line.startswith("State of Health"):
# If anything is wrong (like maybe the line is scrambled) just go on.
            try:
                Parts = Line.split()
# Parts[3] == DateTime
                Time = str2Epoch(None, Parts[3])
                if Time < Earliest:
                    Earliest = Time
                if Time > Latest:
                    Latest = Time
# The last thing on the line should be the unit ID. Grab it and then check to
# make sure it is a number/hex number. If it is not then keep looking.
                if DASID == "":
                    DASID = Parts[-1]
                    try:
                        int(DASID, 16)
                    except:
                        DASID = ""
            except:
                pass
            continue
# Ex 172:23:41:45 DSP CLOCK SET: OLD=01:172:23:41:45.996, NEW=01:172:23:41:45.007
        if Line.find("DSP CLOCK SET:") != -1:
            try:
                Parts = Line.split()
                if Parts[5].startswith("NEW="):
                    Time = str2Epoch(None, Parts[5][4:])
                    if Time < Earliest:
                        Earliest = Time
                    if Time > Latest:
                        Latest = Time
            except:
                pass
            continue
# Ex: DAS: 933F   EV: 1131   DS: 1   FST = 2006:310:23:53:31:615   TT  = 2006:310:23:53:31:615   NS:    360000   SPS:  100   ETO:         0
        if Line.find("FST =") != -1:
            try:
                Parts = Line.split()
# I'm not always sure which Part the FST is since these lines are made up by
# different programs, so search for it.
                Index = 0
                for Part in Parts:
                    if Part == "FST":
                        Time = str2Epoch(None, Parts[Index+2])
                        if Time < Earliest:
                            Earliest = Time
                        if Time > Latest:
                            Latest = Time
                        break
                    if DASID == "" and Part == "DAS:":
                        DASID = Parts[Index+1]
                        try:
                            int(DASID, 16)
                        except:
                            DASID = ""
                    Index += 1
            except:
                pass
            continue
    if isinstance(FileLines, str):
# Both of these should be either true or false.
        if Earliest == maxint or Latest == -maxint:
            return (1, "RW", "%s: Could not process timing information."% \
                    basename(FileLines), 2)
        else:
            return (0, basename(FileLines), Earliest, Latest)
    else:
        if Earliest == maxint or Latest == -maxint:
            return (1, "RW", "%s: Could not process timing information."% \
                    File, 2)
        else:
            return (0, File, Earliest, Latest, DASID)
# END: rt72130logTimeRange





###########################################################
# BEGIN: rt72130refTimeRange(Filespec, StopBut, RunningVar)
# LIB:rt72130refTimeRange():2010.252
def rt72130refTimeRange(Filespec, StopBut, RunningVar):
# If the file is not a multiple of 1024 bytes it could mean that the file is
# corrupted and that could crash LOGPEEK.
    if getsize(Filespec)%1024 != 0:
        return (1, "MW", "%s: Possibily corrupted."%basename(Filespec), 3)
    try:
        Fp = open(Filespec, "rb")
    except:
        return (1, "MW", "%s: Error opening a SOH file."%basename(Filespec), 3)
    Earliest = maxint
    Latest = -maxint
    ChunkCount = 0
    DASID = ""
    while 1:
# Read through the file 100 packets at a time to speed things along.
# This failed once on a corrupted file and the error message meant nothing
# sensible: IOError: [Error 7] Argment list too long. I suspect even Python
# couldn't figure out what was going on, so we'll try.
        try:
            Block = Fp.read(102400)
        except:
            Fp.close()
            return (1, "MW", "%s: IOError: Is the file corrupted?"% \
                    basename(Filespec), 3)
# This will lose processing of the last block if the file ends badly, but that
# should be caught in the 1024 test above.
        if len(Block) < 1024:
            break
        ChunkCount += 1
        if ChunkCount%20 == 0:
            if StopBut != None:
                StopBut.update()
                if RunningVar.get() == 0:
                    Fp.close()
                    return (2, "YB", "Stopped.", 2)
# Go through the upto 100 packets read above. Use the length of the Block so
# when we get to the end of the file we will stop at the last block instead of
# just continuing for a full block.
        for Offset in xrange(0, len(Block), 1024):
            Packet = Block[Offset:Offset+1024]
            if len(Packet) < 1024:
                break
            PacketType = Packet[:2]
# We do this to try and keep packets of garbage from getting their times
# processed.
            if PacketType == "SH":
                Time = rt72130HeaderTime2Epoch(Packet)
                if Time < Earliest:
                    Earliest = Time
                if Time > Latest:
                    Latest = Time
                if DASID == "":
                    DASID = "%04X"%((ord(Packet[4]) << 8)+ord(Packet[5]))
    Fp.close()
# Both of these should be either true or false.
    if Earliest == maxint or Latest == -maxint:
        return (1, "RW", "%s: Could not process timing information."% \
                basename(Filespec), 2)
    return (0, basename(Filespec), Earliest, Latest, DASID)
# END: rt72130refTimeRange




############################################################
# BEGIN: rt72130SHDecode(FromDate, ToDate, Packet, Messages)
# LIB:rt72130SHDecode():2010.177
def rt72130SHDecode(FromDate, ToDate, Packet, Messages):
# Check to see if the user even wants this packet.
    Epoch = rt72130HeaderTime2Epoch(Packet)
    if Epoch < FromDate or Epoch > ToDate:
        return
    YYYY, DDD, HH, MM, SS, TTT = rt72130HeaderTime2ydhmst(Packet)
    Messages.append("")
    Messages.append( \
            "State of Health  %02d:%03d:%02d:%02d:%02d:%03d   ST: %04X"% \
            (YYYY, DDD, HH, MM, SS, TTT, \
            ((ord(Packet[4]) << 8)+ord(Packet[5]))))
    EOP = (BCDTable[ord(Packet[12])]*100)+(BCDTable[ord(Packet[13])])
# -1 is to not get a "" in the last List item.
    Messages += Packet[24:EOP].split("\r\n")[:-1]
    return
# END: rt72130SHDecode




#############################
# BEGIN: rt72130GetUID(InStr)
# LIB:rt72130GetUID():2010.173
#   Takes the passed 2-byte UID code and returns the string version.
def rt72130GetUID(InStr):
# Since we don't know the Reftek DAS model it's a little tricky. The 2 bytes
# can be a BCD number (72A) or a hex number (RT130). This should work either
# way.
# FINISHME - are they really different?
    Value = ((ord(InStr[0]) & 0xF0) >> 4)*1000
# 72A's are 0-8999, and 130's are 0x9000-0xFFFF
    if Value < 9000:
        Value += (ord(InStr[0]) & 0x0F)*100
        Value += ((ord(InStr[1]) & 0xF0) >> 4)*10
        Value += (ord(InStr[1]) & 0x0F)
        UID = "%04d"%Value
    else:
        UID = "%04X"%((BCDTable[ord(InStr[0])]*100)+BCDTable[ord(InStr[1])])
    return UID
# END: rt72130GetUID




#######################
# BEGIN: rtnPattern(In)
# LIB:rtnPattern():2006.113
def rtnPattern(In):
    Rtn = ""
    for c in In:
        if c.isdigit():
            Rtn += "0"
        elif c.isupper():
            Rtn += "A"
        elif c.islower():
            Rtn += "a"
        else:
            Rtn += c
    return Rtn
# END: rtnPattern




####################
# BEGIN: setColors()
# FUNC:setColors():2010.211
#   Uses the value of PROGColorModeRVar and sets the colors in the global DClr
#   dictionary.
def setColors():
# These are the background colors for highlighting the text in the log display
# window. We want them to always be the black background colors.
    DClr["ACQStartBG"] = Clr["G"]
    DClr["ACQStopBG"] = Clr["R"]
    DClr["ClockTimeBG"] = Clr["W"]
    DClr["DCDIFFBG"] = Clr["Y"]
    DClr["DEFSBG"] = Clr["W"]
    DClr["DISCREPBG"] = Clr["R"]
    DClr["DRSETBG"] = Clr["Y"]
    DClr["DUMPOnBG"] = Clr["G"]
    DClr["DUMPOffBG"] = Clr["R"]
    DClr["ERRORBG"] = Clr["R"]
    DClr["EVTBG"] = Clr["W"]
    DClr["GPSOffBG"] = Clr["R"]
    DClr["GPSOnBG"] = Clr["G"]
    DClr["GPSLKBG"] = Clr["W"]
    DClr["ICPEBG"] = Clr["C"]
    DClr["JERKBG"] = Clr["R"]
    DClr["MRCBG"] = Clr["W"]
    DClr["NETDownBG"] = Clr["R"]
    DClr["NETUpBG"] = Clr["G"]
    DClr["PWRUPBG"] = Clr["G"]
    DClr["CLKPWRBG"] = Clr["G"]
    DClr["RESETBG"] = Clr["Y"]
    DClr["SOHBG"] = Clr["C"]
    DClr["TEMPBG"] = Clr["C"]
    DClr["TMJMPPosBG"] = Clr["R"]
    DClr["TMJMPNegBG"] = Clr["G"]
    DClr["VOLTBG"] = Clr["G"]
    DClr["BKUPGBG"] = Clr["G"]
    DClr["BKUPBBG"] = Clr["Y"]
    DClr["BKUPUBG"] = Clr["R"]
    DClr["WARNBG"] = Clr["Y"]
    if PROGColorModeRVar.get() == "B":
        DClr["ACQStart"] = Clr["G"]
        DClr["ACQStop"] = Clr["R"]
        DClr["MFCAN"] = Clr["B"]
        DClr["GPSCanvas"] = Clr["B"]
        DClr["Time"] = Clr["W"]
        DClr["DCDIFF"] = Clr["Y"]
        DClr["DEFS"] = Clr["W"]
        DClr["DISCREP"] = Clr["R"]
        DClr["DRSET"] = Clr["Y"]
        DClr["DUMPOn"] = Clr["G"]
        DClr["DUMPOff"] = Clr["R"]
        DClr["ERROR"] = Clr["R"]
        DClr["EVT"] = Clr["W"]
        DClr["GPSOff"] = Clr["R"]
        DClr["GPSOn"] = Clr["G"]
        DClr["GPSLK"] = Clr["W"]
        DClr["Grid"] = Clr["y"]
        DClr["ICPE"] = Clr["C"]
        DClr["Image"] = Clr["B"]
        DClr["JERK"] = Clr["R"]
        DClr["Label"] = Clr["C"]
        DClr["MaxMinL"] = Clr["K"]
        DClr["MaxMinV"] = Clr["W"]
        DClr["MRC"] = Clr["W"]
        DClr["NETDown"] = Clr["R"]
        DClr["NETUp"] = Clr["G"]
        DClr["Plot"] = Clr["A"]
        DClr["PWRUP"] = Clr["G"]
        DClr["CLKPWR"] = Clr["G"]
        DClr["RESET"] = Clr["Y"]
        DClr["Sel"] = Clr["Y"]
        DClr["SOH"] = Clr["C"]
        DClr["TEMP"] = Clr["C"]
        DClr["TMJMPPos"] = Clr["R"]
        DClr["Ticks"] = Clr["W"]
        DClr["TMJMPNeg"] = Clr["G"]
        DClr["VOLT"] = Clr["G"]
        DClr["BKUP"] = Clr["W"]
        DClr["BKUPG"] = Clr["G"]
        DClr["BKUPB"] = Clr["Y"]
        DClr["BKUPU"] = Clr["R"]
        DClr["MP"] = Clr["W"]
        DClr["MPP"] = Clr["C"]
        DClr["MPG"] = Clr["G"]
        DClr["MPB"] = Clr["Y"]
        DClr["MPU"] = Clr["R"]
        DClr["MPH"] = Clr["M"]
        DClr["WARN"] = Clr["Y"]
# For the raw data plot.
        DClr["RAWD"] = Clr["G"]
        DClr["RAWT"] = Clr["W"]
    elif PROGColorModeRVar.get() == "W":
        DClr["ACQStart"] = Clr["U"]
        DClr["ACQStop"] = Clr["B"]
        DClr["MFCAN"] = Clr["W"]
        DClr["GPSCanvas"] = Clr["B"]
        DClr["Time"] = Clr["B"]
        DClr["DCDIFF"] = Clr["B"]
        DClr["DEFS"] = Clr["U"]
        DClr["DISCREP"] = Clr["B"]
        DClr["DRSET"] = Clr["B"]
        DClr["DUMPOn"] = Clr["U"]
        DClr["DUMPOff"] = Clr["B"]
        DClr["ERROR"] = Clr["B"]
        DClr["EVT"] = Clr["B"]
        DClr["GPSOff"] = Clr["B"]
        DClr["GPSOn"] = Clr["U"]
        DClr["GPSLK"] = Clr["B"]
        DClr["Grid"] = Clr["A"]
        DClr["ICPE"] = Clr["B"]
        DClr["Image"] = Clr["W"]
        DClr["JERK"] = Clr["B"]
        DClr["Label"] = Clr["B"]
        DClr["MaxMinL"] = Clr["E"]
        DClr["MaxMinV"] = Clr["B"]
        DClr["MRC"] = Clr["B"]
        DClr["NETDown"] = Clr["B"]
        DClr["NETUp"] = Clr["U"]
        DClr["Plot"] = Clr["A"]
        DClr["PWRUP"] = Clr["U"]
        DClr["CLKPWR"] = Clr["U"]
        DClr["RESET"] = Clr["B"]
        DClr["Sel"] = Clr["A"]
        DClr["SOH"] = Clr["B"]
        DClr["TEMP"] = Clr["B"]
        DClr["Ticks"] = Clr["B"]
        DClr["TMJMPPos"] = Clr["B"]
        DClr["TMJMPNeg"] = Clr["U"]
        DClr["VOLT"] = Clr["U"]
        DClr["BKUP"] = Clr["U"]
        DClr["BKUPG"] = Clr["E"]
        DClr["BKUPB"] = Clr["A"]
        DClr["BKUPU"] = Clr["B"]
        DClr["MP"] = Clr["B"]
        DClr["MPP"] = Clr["E"]
        DClr["MPG"] = Clr["A"]
        DClr["MPB"] = Clr["K"]
        DClr["MPU"] = Clr["U"]
        DClr["MPH"] = Clr["B"]
        DClr["WARN"] = Clr["U"]
        DClr["RAWD"] = Clr["B"]
        DClr["RAWT"] = Clr["B"]
# END: setColors




########################
# BEGIN: setInfoMsg(Msg)
# FUNC:setInfoMsg():2008.285
def setInfoMsg(Msg):
    Info.delete(0.0, END)
    Info.insert(END, Msg)
    Info.update()
    return
# END: setInfoMsg




####################
# BEGIN: setMinMax()
# FUNC:setMinMax():2008.285
#    Goes through the data lists and calculates the min and max values for the
#    graphs over the range of time CurMainStart to CurMainEnd.
def setMinMax():
    global ICPEMin
    global ICPEMax
    global VOLTMin
    global VOLTMax
    global TEMPMin
    global TEMPMax
    global DCDIFFMin
    global DCDIFFMax
    ICPEMin = 10.0E100
    ICPEMax = -10.0E100
    VOLTMin = 10.0E100
    VOLTMax = -10.0E100
    TEMPMin = 10.0E100
    TEMPMax = -10.0E100
    DCDIFFMin = 10.0E100
    DCDIFFMax = -10.0E100
    for Data in ICPE:
        if Data[1] >= CurMainStart and Data[1] <= CurMainEnd:
            if Data[2] < ICPEMin:
                ICPEMin = Data[2]
            if Data[2] > ICPEMax:
                ICPEMax = Data[2]
    for Data in VOLT:
        if Data[1] >= CurMainStart and Data[1] <= CurMainEnd:
            if Data[2] < VOLTMin:
                VOLTMin = Data[2]
            if Data[2] > VOLTMax:
                VOLTMax = Data[2]
    for Data in TEMP:
        if Data[1] >= CurMainStart and Data[1] <= CurMainEnd:
            if Data[2] < TEMPMin:
                TEMPMin = Data[2]
            if Data[2] > TEMPMax:
                TEMPMax = Data[2]
    for Data in DCDIFF:
        if Data[1] >= CurMainStart and Data[1] <= CurMainEnd:
            if Data[2] < DCDIFFMin:
                DCDIFFMin = Data[2]
            if Data[2] > DCDIFFMax:
                DCDIFFMax = Data[2]
    return
# END: setMinMax




##############################################################
# BEGIN: setMsg(WhichMsg, Colors, Message, Beep = 0, e = None)
# LIB:setMsg():2008.269
def setMsg(WhichMsg, Colors, Message, Beep = 0, e = None):
# So callers don't have to always be checking for this.
    if WhichMsg == None:
        return
# This might get called when a window is not, or never has been up so try.
    try:
        if isinstance(WhichMsg, str):
            LMsg = Msg[WhichMsg]
        else:
            LMsg = WhichMsg
        LMsg.configure(state = NORMAL)
        LMsg.delete(0.0, END)
        if Colors == "":
            LMsg.configure(bg = Clr["W"], fg = Clr["B"])
        else:
            LMsg.configure(bg = Clr[Colors[0]], fg = Clr[Colors[1]])
        LMsg.insert(END, Message)
        LMsg.update()
        LMsg.configure(state = DISABLED)
# This may get called from a generated event with no Beep value set.
        if isinstance(Beep, int) and Beep > 0:
            beep(Beep)
        updateMe(0)
    except (KeyError, TclError):
        pass
    return
# END: setMsg




########################
# BEGIN: setOrigMinMax()
# FUNC:setOrigMinMax():2008.285
def setOrigMinMax():
    global CurMainStart
    global CurMainEnd
    CurMainStart = FStart
    CurMainEnd = FEnd
    setMinMax()
    return
# END: setOrigMinMax()




#####################
# BEGIN: showUp(Fram)
# LIB:showUp():2010.177
def showUp(Fram):
# If anything should go wrong just close the form and let the caller fix it
# (i.e. redraw it).
    try:
        if Frm[Fram] != None:
            Frm[Fram].deiconify()
            Frm[Fram].lift()
            return True
    except TclError:
# This call makes sure that the Frm[] value gets set to None.
        closeForm(Fram)
    return False
########################
# BEGIN: showForms(Fram)
# FUNC:showWindows():2010.177
#   A simple way for the program to implement an OSX Windows-like menu item.
def showForms(Fram):
    if showUp(Fram) == False:
        beep(1)
    return
# END: showUp




#####################
# BEGIN: str2Dddd(LL)
# FUNC:str2Dddd():2008.285
def str2Dddd(LL):
    Parts = LL.split(":")
    Deg = floatt(Parts[0][1:])
    Deg += floatt(Parts[1])/60.0
    Deg += floatt(Parts[2])/3600.0
    if Parts[0][0] == "S" or Parts[0][0] == "W":
        Deg *= -1.0
    return Deg
# END: str2Dddd




##################################
# BEGIN: str2Epoch(YYYY, DateTime)
# LIB:str2Epoch():2011.080
#   Returns the number of WHOLE SECONDS since Jan 1, 1970 for either
#   YYYY, DDD:HH:MM:SS:TTT, YYYY:DDD:HH:MM:SS:TTT or YYYY-MM-DD:HH:MM:SS:TTT.
#   The separator between SS and TTT may be : or . since the function only
#   returns the seconds truncated.  Returns 0 if anything goes wrong.
def str2Epoch(YYYY, DateTime):
    global PROGYEI70
    try:
        Epoch = 0
        if DateTime.find("-") != -1:
            DT = DateTime.split(":", 1)
            Parts = map(float, DT[0].split("-"))
            Parts += map(float, DT[1].split(":"))
        else:
            Parts = map(float, DateTime.split(":"))
        if YYYY == None:
# Just in case someone generates 2-digit years.
            if Parts[0] < 100:
                if Parts[0] < 70:
                    Parts[0] += 2000
                else:
                    Parts[0] += 1900
        else:
# The caller will just have to figure this one out.
            if YYYY < 1970:
                YYYY = 1970
            Parts = [YYYY, ]+Parts
        Parts += (5-len(Parts))*[0]
# This makes each year's Epoch get calculated only once.
        try:
            Epoch = PROGYEI70[Parts[0]]
        except KeyError:
            for YYY in xrange(1970, Parts[0]):
                if YYY%4 != 0:
                    Epoch += 31536000
                elif YYY%100 != 0 or YYY%400 == 0:
                    Epoch += 31622400
                else:
                    Epoch += 31536000
            PROGYEI70[Parts[0]] = Epoch
# This goes along with forcing YYYY to 1970 if things are bad.
        if Parts[1] < 1:
            Parts[1] = 1
        Epoch += ((int(Parts[1])-1)*86400)+(int(Parts[2])*3600)+ \
                (int(Parts[3])*60)+int(Parts[4])
    except ValueError:
        Epoch = 0
    return Epoch
# END: str2Epoch




######################
# BEGIN: class ToolTip
# LIB:ToolTip():2009.179
#   Add tooltips to objects.
#   Usage: ToolTip(obj, Len, "text")
#   Nice and clever.
class ToolTipBase:
    def __init__(self, button):
        self.button = button
        self.tipwindow = None
        self.id = None
        self.x = self.y = 0
        self._id1 = self.button.bind("<Enter>", self.enter)
        self._id2 = self.button.bind("<Leave>", self.leave)
        self._id3 = self.button.bind("<ButtonPress>", self.leave)
        return
    def enter(self, event = None):
        self.schedule()
        return
    def leave(self, event = None):
        self.unschedule()
        self.hidetip()
        return
    def schedule(self):
        self.unschedule()
        self.id = self.button.after(500, self.showtip)
        return
    def unschedule(self):
        id = self.id
        self.id = None
        if id:
            self.button.after_cancel(id)
        return
    def showtip(self):
        if self.tipwindow:
            return
# The tip window must be completely clear of the mouse pointer so offset the
# x and y a little. This is all in a try because I started getting TclErrors
# to the effect that the window no longer existed by the time the geometry and
# deiconify functions were reached after adding the 'keep the tooltip off the
# edge of the display' stuff. I think this additional stuff was adding enough
# time to the whole process that it would get caught trying to bring up a tip
# that was no longer needed as the user quickly moved the pointer around the
# display.
        try:
            self.tipwindow = tw = Toplevel(self.button)
            tw.withdraw()
            tw.wm_overrideredirect(1)
            self.showcontents()
            x = self.button.winfo_pointerx()
            y = self.button.winfo_pointery()
# After much trial and error...keep the tooltip away from the right edge of the
# screen and the bottom of the screen.
            tw.update()
            if x+tw.winfo_reqwidth()+5 > Root.winfo_screenwidth():
                x -= (tw.winfo_reqwidth()+5)
            else:
                x += 5
            if y+tw.winfo_reqheight()+5 > Root.winfo_screenheight():
                y -= (tw.winfo_reqheight()+5)
            else:
                y += 5
            tw.wm_geometry("+%d+%d" % (x, y))
# If you do a tw.lift() along with the deiconify the tooltip "flashes", so I'm
# not doing it and it seems to work OK.
            tw.deiconify()
        except TclError:
            self.hidetip()
        return
    def showcontents(self, Len, text = "Your text here"):
# Break up the incoming message about every Len characters.
        if len(text) > Len:
            Msg = ""
            Count = 0
            for c in text:
                if Count == 0 and c == " ":
                    continue
                if Count > Len and c == " ":
                    Msg += "\n"
                    Count = 0
                    continue
                if c == "\n":
                    Msg += c
                    Count = 0
                    continue
                Count += 1
                Msg += c
            text = Msg
# Override this in derived class.
        Lab = Label(self.tipwindow, text = text, justify = LEFT, \
                bg = Clr["Y"], bd = 1, fg = Clr["B"], relief = SOLID, \
                padx = 3, pady = 2)
        Lab.pack()
        return
    def hidetip(self):
# If it is already gone then just go back.
        try:
            tw = self.tipwindow
            self.tipwindow = None
            if tw:
                tw.destroy()
        except TclError:
            pass
        return
class ToolTip(ToolTipBase):
    def __init__(self, button, Len, text):
        ToolTipBase.__init__(self, button)
        self.Len = Len
        self.text = text
        return
    def showcontents(self):
        ToolTipBase.showcontents(self, self.Len, self.text)
        return
# END: ToolTip




##############################################################################
# BEGIN: txLn(VarSet, Color, What, Newline = True, Bell = 0, Update = False, \
#                Tag = False)
# LIB:txLn():2010.194
#   Roughly the same as msgLn, but is made for regular Text() message areas.
def txLn(VarSet, Color, What, Newline = True, Bell = 0, Update = False, \
        Tag = False):
    LTxt = Txt[VarSet]
    NormallyDisabled = False
    if LTxt.cget("state") == DISABLED:
        LTxt.config(state = NORMAL)
        NormallyDisabled = True
    if Color == "" and What == "" and Newline == False and Bell == 0 and \
            Update == False:
        LTxt.tag_delete(*LTxt.tag_names())
        LTxt.delete(0.0, END)
        LTxt.update()
        if NormallyDisabled == True:
            LTxt.config(state = DISABLED)
        return
    IdxS = ""
    if Tag == False:
        if Color != "":
# This mouthful keeps user mouse clicks in the field from screwing up the tag
# indexes. END always points to the "next" line so we have to back that up one
# to get the "current" line which INSERT (which used to be used) doesn't
# always point to if the user has clicked somewhere in the Text widget (which
# I thought was covered by the value in CURSOR, but isn't).
            IdxS = LTxt.index(str(intt(LTxt.index(END))-1)+".end")
            LTxt.tag_config(IdxS, foreground = Clr[Color[0]])
            LTxt.insert(END, What, IdxS)
        else:
            LTxt.insert(END, What)
    else:
# Generates a tag even if there is no Color choice (which we don't want to do
# ALL of the time, but only when the caller needs the tag IdxS passed back).
        IdxS = LTxt.index(str(intt(LTxt.index(END))-1)+".end")
        if Color != "":
            LTxt.tag_config(IdxS, foreground = Clr[Color[0]])
        LTxt.insert(END, What, IdxS)
    if Newline == True:
        LTxt.insert(END, "\n")
# The Text field may not have a scrollbar defined for this behaviour (i.e.
# only scroll when the scrollbar is all the way down).
        try:
            if Sb[VarSet].get()[1] == 1.0:
                LTxt.see(END)
                LTxt.update()
        except:
            pass
# Instead of updating everything.
    if Update == True:
        LTxt.update()
    if Bell != 0:
        beep(Bell)
    if NormallyDisabled == True:
        LTxt.config(state = DISABLED)
    return IdxS
# END: txLn




########################
# BEGIN: updateMe(Which)
# FUNC:updateMe():2006.112
def updateMe(Which):
    if Which == 0:
        Root.update_idletasks()
        Root.update()
    return
# END: updateMe




########################################
# BEGIN: walkDirs(Dir, Hidden, End = "")
# LIB:walkDirs():2010.248
#   Walks the passed Dir returns a list of every file in Dir with full path.
def walkDirs(Dir, Hidden, End = ""):
    if (Dir.startswith(".") or Dir.startswith("_")) and Hidden == False:
        return (1, "RW", "Directory %s is hidden or special."%Dir, 2)
    if exists(Dir) == False:
        return (1, "RW", "Directory %s does not exist."%Dir, 2)
    if isdir(Dir) == False:
        return (1, "RW", "%s is not a directory."%Dir, 2)
    Files = []
# Collect the directories we come across in here.
    Dirs = []
    Dirs.append(Dir)
    while len(Dirs) > 0:
        Dir = Dirs.pop()
        if Dir.endswith(sep) == False:
            Dir += sep
        for Name in listdir(Dir):
# No hidden files or directories, please.
            if (Name.startswith(".") or Name.startswith("_")) and \
                    Hidden == False:
                continue
            Fullpath = Dir+Name
# Save this so we can pop it and do a listdir() on it.
            if isdir(Fullpath):
                Dirs.append(Fullpath)
                continue
            if Fullpath.endswith(End):
                Files.append(Fullpath)
    Files.sort()
    return (0, Files)
# END: walkDirs




###########################
# BEGIN: YDHMST2Epoch(Time)
# LIB:YDHMST2Epoch():2010.242
#   YYYY:DDD:HH:MM:SS(.sss or :sss) to Epoch seconds since Jan 1, 1970.
#   Does not know about leap seconds so the results should only be used for
#   calculating differences between two times and things like that.
def YDHMST2Epoch(Time):
    global PROGYEF70
    Parts = Time.split(":")
# The caller can pass something like YYYY:DDD:HH:MM and get away with it.
# If the seconds are SS.sss then this will make the TTT part 0 which will be
# OK.
    Parts += (6-len(Parts))*["0"]
    Epoch = 0.0
    try:
        Parts[0] = int(Parts[0])
# This trick makes it so the Epoch for a year only has to be calculated once.
        try:
            Epoch = PROGYEF70[Parts[0]]
        except KeyError:
            for YYY in xrange(1970, Parts[0]):
                if YYY%4 != 0:
                    Epoch += 31536000.0
                elif YYY%100 != 0 or YYY%400 == 0:
                    Epoch += 31622400.0
                else:
                    Epoch += 31536000.0
            PROGYEF70[Parts[0]] = Epoch
        Epoch += (int(Parts[1])-1)*86400.0
        Epoch += int(Parts[2])*3600.0
        Epoch += int(Parts[3])*60.0
        Epoch += float(Parts[4])
        Epoch += float(Parts[5])/1000.0
    except ValueError:
        Epoch = 0.0
    return Epoch
# END: YDHMST2Epoch




#########################
# BEGIN: ydhms2ymdhms(Yd)
# LIB:ydhms2ymdhms():2011.080
#   Takes the passed string time in YYYY:DDD:HH:MM:SS and returns a formatted
#   string of YYYYMMMDD:HH:MM:SS.
def ydhms2ymdhms(Yd):
    Parts = Yd.split(":")
    YYYY = intt(Parts[0])
    DDD = intt(Parts[1])
    MM, DD = ydoy2md(YYYY, DDD)
    return "%d%s%02d:%s:%s:%s"%(YYYY, m2MMM(MM), DD, Parts[2], Parts[3], \
            Parts[4])
# END: ydhms2ymdhms




#############################
# BEGIN: ydhms2ymdhmsDash(Yd)
# LIB:ydhms2ymdhmsDash():2011.080
#   Takes the passed string time in YYYY:DDD:HH:MM:SS and returns a formatted
#   string of YYYY-MM-DD:HH:MM:SS.
def ydhms2ymdhmsDash(Yd):
    Parts = Yd.split(":")
    YYYY = intt(Parts[0])
    DDD = intt(Parts[1])
    MM, DD = ydoy2md(YYYY, DDD)
    return "%d-%02d-%02d:%s:%s:%s"%(YYYY, MM, DD, Parts[2], Parts[3], Parts[4])
# END: ydhms2ymdhmsDash




###########################################
# BEGIN: ydhms2Epoch(YYYY, DDD, HH, MM, SS)
# LIB:ydhms2Epoch():2010.242
#   Converts the passed date to seconds since Jan 1, 1970.
#   Should only be used for doing things like converting two times to
#   calculate GMT vs LT differences and other short-term things like that
#   since it doesn't know anything about leap seconds.
def ydhms2Epoch(YYYY, DDD, HH, MM, SS):
    global PROGYEI70
    Epoch = 0
# This trick makes it so a year's Epoch only needs to be calculated once.
    try:
        Epoch = PROGYEI70[YYYY]
    except KeyError:
        for YYY in xrange(1970, YYYY):
            if YYY%4 != 0:
                Epoch += 31536000
            elif YYY%100 != 0 or YYY%400 == 0:
                Epoch += 31622400
            else:
                Epoch += 31536000
        PROGYEI70[YYYY] = Epoch
    Epoch += (DDD-1)*86400
    Epoch += HH*3600
    Epoch += MM*60
    Epoch += SS
    return Epoch
# END: ydhms2Epoch




############################################
# BEGIN: ydhms2Epoch2(YYYY, DDD, HH, MM, SS)
# LIB:ydhms2Epoch2():2010.242
#   Converts the passed date to seconds since Jan 1, 1970.
#   Should only be used for doing things like converting two times to
#   calculate GMT vs LT differences and other short-term things like that
#   since it doesn't know anything about leap seconds.
#   This version is best for low-bandwidth uses since it has the 2 to 4-digit
#   year check at the beginning.
def ydhms2Epoch2(YYYY, DDD, HH, MM, SS):
    global PROGYEI70
    Epoch = 0
    if YYYY < 70:
        YYYY += 2000
    if YYYY < 100:
        YYYY += 1900
# This calculates the Epoch for a year only once.
    try:
        Epoch = PROGYEI70[YYYY]
    except KeyError:
        for YYY in xrange(1970, YYYY):
            if YYY%4 != 0:
                Epoch += 31536000
            elif YYY%100 != 0 or YYY%400 == 0:
                Epoch += 31622400
            else:
                Epoch += 31536000
        PROGYEI70[YYYY] = Epoch
    Epoch += (DDD-1)*86400
    Epoch += HH*3600
    Epoch += MM*60
    Epoch += SS
    return Epoch
# END: ydhms2Epoch2




#############################
# BEGIN: ydhmst2YDHMST(InStr)
# LIB:ydhmst2YDHMST():2009.057
#   Accepts yyyydddhhmmssttt or yyyydddhhmmss.
def ydhmst2YDHMST(InStr):
    Len = len(InStr)
    InStr = InStr.strip()
# YYYYDDDHHMM
    if Len == 12:
        if InStr == "":
            return "0000:000:00:00"
        return "%s:%s:%s:%s"%(InStr[:4], InStr[4:7], InStr[7:9], \
                InStr[9:11])
# YYYYDDDHHMMSS  All of the fields that may contain this are 14 bytes long
# with a trailing space which got removed above.
    elif Len == 14:
        if InStr == "":
            return "0000:000:00:00:00"
        return "%s:%s:%s:%s:%s"%(InStr[:4], InStr[4:7], InStr[7:9], \
                InStr[9:11], InStr[11:13])
# YYYYDDDHHMMSSTTT
    elif Len == 16:
        if InStr == "":
            return "0000:000:00:00:00:000"
        return "%s:%s:%s:%s:%s:%s"%(InStr[:4], InStr[4:7], InStr[7:9], \
                InStr[9:11], InStr[11:13], InStr[13:])
    return ""
# END: ydhmst2YDHMST




###########################
# BEGIN: ydoy2md(YYYY, DDD)
# LIB:ydoy2md():2009.103
def ydoy2md(YYYY, DDD):
    if DDD < 1:
        return 0, 0
    if DDD < 32:
        return 1, DDD
    elif DDD < 60:
        return 2, DDD-31
    if YYYY%4 != 0:
        Leap = 0
    elif YYYY%100 != 0 or YYYY%400 == 0:
        Leap = 1
    else:
        Leap = 0
# Check for this special day.
    if Leap == 1 and DDD == 60:
        return 2, 29
# The if statements for Mar-Dec are set up for non-leap years. If it is a
# leap year and the date is going to be Mar-Dec, subtract 1 from the day.
    DDD -= Leap
# March
    if DDD < 91:
        return 3, DDD-59
# April
    if DDD < 121:
        return 4, DDD-90
# May
    if DDD < 152:
        return 5, DDD-120
# June
    if DDD < 182:
        return 6, DDD-151
# July
    if DDD < 213:
        return 7, DDD-181
# August
    if DDD < 244:
        return 8, DDD-212
# September
    if DDD < 274:
        return 9, DDD-243
# October
    if DDD < 305:
        return 10, DDD-273
# November
    if DDD < 335:
        return 11, DDD-304
# December
    if DDD < 366:
        return 12, DDD-334
    return 0, 0
# END: ydoy2md




###############################
# BEGIN: ymd2doy(YYYY, MMM, DD)
# LIB:ymd2doy():2008.002
FDOM = (0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)

def ymd2doy(YYYY, MMM, DD):
# It is a leap year if...
    if YYYY%4 != 0:
        Leap = 0
    elif (YYYY%100 != 0 or YYYY%400 == 0) and MMM > 2:
        Leap = 1
    else:
        Leap = 0
    return FDOM[MMM]+DD+Leap
# END: ymd2doy




###################################
# BEGIN: ydoyMath(Delta, YYYY, DDD)
# LIB:ydoyMath():2008.070
#   Adds or subtracts the passed number of days (Delta) to the passed year and
#   day of year values. Returns YYYY and DDD. This same functionality can be
#   accomplished with dateTimeMath() using more arguments.
def ydoyMath(Delta, YYYY, DDD):
    if Delta == 0:
        return YYYY, DDD
    if Delta > 0:
        Forward = 1
    elif Delta < 0:
        Forward = 0
    while 1:
# Speed limit the change to keep things simpler.
        if Delta < -365 or Delta > 365:
            if Forward == 1:
                DDD += 365
                Delta -= 365
            else:
                DDD -= 365
                Delta += 365
        else:
            DDD += Delta
            Delta = 0
        Leap = isLeap(YYYY)
        if DDD < 1 or DDD > 365+Leap:
            if Forward == 1:
                DDD -= 365+Leap
                YYYY += 1
            else:
                YYYY -= 1
                Leap = isLeap(YYYY)
                DDD += 365+Leap
            break
        if Delta == 0:
            break
    return YYYY, DDD
# END: ydoyMath




#########################
# BEGIN: yRange(Min, Max)
# FUNC:yRange():2008.090
#   Figure out the range of the passed Max and Min values.
def yRange(Min, Max):
    if Max >= 0.0 and Min <= 0.0:
        YRange = Max+abs(Min)
    elif Max <= 0.0 and Min <= 0.0:
        YRange = Max-Min
    elif Max >= 0.0 and Min >= 0.0:
        YRange = Max-Min;
    else:
        YRange = 1.0
# Do this just in case so we don't divide anything by 0.
    if YRange == 0.0:
        YRange = 1.0
    return YRange
# END: yRange




# =====================================
# BEGIN: ========== COMMANDS ==========
# =====================================


#####################
# BEGIN: allPlotsOn()
# FUNC:allPlotsOn():2010.253
def allPlotsOn():
    for Key in DGrf.keys():
        if Key != "MP123" and Key != "MP456":
            DGrf[Key].set(1)
    reconfigDisplay()
    return
# END: allPlotsOn




##################
# BEGIN: formGPS()
# FUNC:formGPS():2010.212
Frm["GPS"] = None

def formGPS():
    global GPSGraph
# If no file has been read yet then don't do any of this
    if MFGraphed == False:
        beep(1)
        return
    if Frm["GPS"] != None:
        Frm["GPS"].deiconify()
        Frm["GPS"].lift()
        return
    LFrm = Frm["GPS"] = Toplevel(Root)
    LFrm.withdraw()
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "GPS"))
    LFrm.title("GPS Information")
    GPSGraph = Canvas(LFrm, relief = SUNKEN, bg = DClr["GPSCanvas"], \
            height = 450, width = 500)
    GPSGraph.pack(side = TOP, expand = YES, fill = BOTH)
# Text area
    Msg["GPS"] = Text(LFrm, font = PROGMsgFont, height = 6, wrap = WORD, \
            cursor = "")
    Msg["GPS"].pack(side = TOP, fill = X, expand = YES)
    Sub = Frame(LFrm)
    BButton(Sub, text = "Close", fg = Clr["R"], command = Command(closeForm, \
            "GPS")).pack(side = LEFT)
    Sub.pack(side = TOP, pady = 3)
# We need to bring the window up, THEN do the update BEFORE plotting or the
# dimensions don't get computed properly and nothing shows up on the plot.
# This must be an Image-only thing since nothing else has this problem. If the
# .withdraw() above is not done then the window jumps all over the place as it
# is getting positioned
    center(Root, "GPS", "C", "I", True)
    formGPSPlot()
    return
######################
# BEGIN: formGPSPlot()
# FUNC:formGPSPlot():2008.361
def formGPSPlot():
    global GPSTKGraph
    global GPSGraph
# Get the size of the canvas.
    GPSHeight = GPSGraph.winfo_height()
    GPSWidth = GPSGraph.winfo_width()
    PILGraph = Image.new('RGB', (GPSWidth, GPSHeight), Clr["B"])
    IDGraph = ImageDraw.Draw(PILGraph)
    GraphHeight = GPSHeight-40
    GraphWidth = GPSWidth-40
# Check to see if there even are any points to plot.
    if len(GPOSd) > 0 and MFGraphed == True:
# Prepare for math.
        LatMean = 0.0
        LonMean = 0.0
# Mean positions.
        Points = float(len(GPOSd))
        for Data in GPOSd:
            LatMean += Data
        LatMean = LatMean/Points
        for Data in GPOSr:
            LonMean += Data
        LonMean = LonMean/Points
# Go through again and calculate the standard deviation of all of the points.
        LatSum = 0.0
        for Data in GPOSd:
            LatSum += (Data-LatMean)**2.0
        LatStd = sqrt(LatSum/Points)
        LonSum = 0.0
        for Data in GPOSr:
            LonSum += (Data-LonMean)**2.0
        LonStd = sqrt(LonSum/Points)
# Only allow a range of points +/- 1 standard deviation.
        LatMin = LatMean-LatStd
        LatMax = LatMean+LatStd
        LonMin = LonMean-LonStd
        LonMax = LonMean+LonStd
# Recompute the means and standard deviations with the points we are going to
# keep.
        LatMean = 0.0
        LonMean = 0.0
        Points = len(GPOSd)
        Used = 0
        for i in xrange(Points):
            if LatMin <= GPOSd[i] and LatMax >= GPOSd[i]:
                if LonMin <= GPOSr[i] and LonMax >= GPOSr[i]:
                    LatMean += GPOSd[i]
                    LonMean += GPOSr[i]
                    Used += 1
        LatMean /= float(Used)
        LonMean /= float(Used)
        LatSum = 0.0
        LonSum = 0.0
        for i in xrange(Points):
            if LatMin <= GPOSd[i] and LatMax >= GPOSd[i]:
                if LonMin <= GPOSr[i] and LonMax >= GPOSr[i]:
                    LatSum += (GPOSd[i]-LatMean)**2.0
                    LonSum += (GPOSr[i]-LonMean)**2.0
        LatStd = sqrt(LatSum/float(Used))
        LonStd = sqrt(LonSum/float(Used))
# Set the range at the average +/- 5 sigma.
        LatMin = LatMean-LatStd*5.0
        LatMax = LatMean+LatStd*5.0
        LatRange = yRange(LatMin, LatMax)
        LonMin = LonMean-LonStd*5.0
        LonMax = LonMean+LonStd*5.0
        LonRange = yRange(LonMin, LonMax)
# Recompute the mean of the final set of points excluding anything beyond the
# 5 sigma using all of the original points.
        LatMean = 0.0
        LonMean = 0.0
        Points = len(GPOSd)
        Used = 0
        for i in xrange(Points):
            if LatMin <= GPOSd[i] and LatMax >= GPOSd[i]:
                if LonMin <= GPOSr[i] and LonMax >= GPOSr[i]:
                    LatMean += GPOSd[i]
                    LonMean += GPOSr[i]
                    Used += 1
        LatMean /= float(Used)
        LonMean /= float(Used)
# Now plot the stuff that falls in the range allowed.
        ElevMean = 0.0
        Plotted = 0
        for i in xrange(Points):
            if LatMin <= GPOSd[i] and LatMax >= GPOSd[i]:
                if LonMin <= GPOSr[i] and LonMax >= GPOSr[i]:
                    Yy = (GPSHeight-20)-GraphHeight* \
                                        (GPOSd[i]-LatMin)/LatRange
# Have to use "Xx" or it confilcts with "fill = X" above.
                    Xx = 20+GraphWidth*(GPOSr[i]-LonMin)/LonRange
                    IDGraph.rectangle((Xx-1, Yy-1, Xx+1, Yy+1), Clr["W"])
# Only use the elevations from the points that get plotted.
                    ElevMean += GPOSe[i]
                    Plotted += 1
# Plot lines over the range of +/- 1 std dev.
        Y1 = (GPSHeight-20)-GraphHeight*((LatMean-LatStd)-LatMin)/LatRange
        Y2 = (GPSHeight-20)-GraphHeight*((LatMean+LatStd)-LatMin)/LatRange
        Xx = 20+GraphWidth*(LonMean-LonMin)/LonRange
        IDGraph.line(((Xx, Y1), (Xx, Y2)), Clr["R"])
        Yy = (GPSHeight-20)-GraphHeight*(LatMean-LatMin)/LatRange
        X1 = 20+GraphWidth*((LonMean-LonStd)-LonMin)/LonRange
        X2 = 20+GraphWidth*((LonMean+LonStd)-LonMin)/LonRange
        IDGraph.line(((X1, Yy), (X2, Yy)), Clr["R"])
# Average location.
        Yy = (GPSHeight-20)-GraphHeight*(LatMean-LatMin)/LatRange
        Xx = 20+GraphWidth*(LonMean-LonMin)/LonRange
        IDGraph.rectangle((Xx-4, Yy-4, Xx+4, Yy+4), Clr["G"])
# Lat: 111133.633 = 24859.82mi/360deg->meters.
# Lon: 111320.156 = 24901.55mi/360deg->meters.
        setMsg("GPS", "WB", "Points plotted: "+str(Plotted)+" of "+ \
                str(len(GPOSd))+"\nMean location: "+"Lat: %.6f"%LatMean+"  "+ \
                "Long: %.6f"%LonMean+"\n1 sigma degrees: "+ \
                "Lat: %.4E"%LatStd+"  "+"Long: %.4E"%LonStd+ \
                "\n1 sigma meters: "+"Lat: %.2fm"%(LatStd*111133.633)+"  "+ \
                "Long: %.2fm"%(LonStd*(111320.156*abs(cos(LatMean))))+ \
                "\nElevation: "+"%+.2fm"%(ElevMean/Plotted))
    else:
        setMsg("GPS", "WB", "No GPS data available.")
    GPSTKGraph = ImageTk.PhotoImage(PILGraph)
    GPSGraph.create_image(0, 0, anchor = NW, image = GPSTKGraph)
    return
# END: formGPS




#################
# BEGIN: HELPText
#   The text of the help form.
HELPText = "QUICK START\n\
===========\n\
1. Enter  logpeek  or  logpeek.py  on the command line, or click on the \
provided icon (it all depends on which operating system is in use).\n\
\n\
2. The initial directory where LOGPEEK will look for files to read will \
be read from a setups file that was saved when the program was last run \
to the users \"home\" directory (the specific direcotry will depend on \
the operating system in use). If needed navigate using the Browse \
button and the file dialog box that will be displayed to the directory \
contaning the source data files. Use the List checkboxes (.log, .cf, etc.) \
to control the types of files that will be listed. The Reload button will \
fill in the list.\n\
\n\
3. If it is desired to also look at a simple plot of the raw data the \
Include Non-SOH Items checkbox and any of the DSs (data streams) checkboxes \
should be selected.\n\
\n\
\n\
DESCRIPTION\n\
===========\n\
LOGPEEK allows reading and examining in a graphical manner the State \
of Health messages and other data from a Reftek log file produced by \
PASSCAL programs such as the ref2log and the ref2segy group of programs \
as well as the State of Health messages and raw data information \
contained in all-in-one '.ref' files, and zipped or unzipped \
CompactFlash card images from Reftek 130 recorders.\n\
\n\
LOGPEEK is started by entering its name on the command line, \
double-clicking on an icon, or selecting an icon from a menu (it depends \
on the operating system). When started LOGPEEK will load the contents \
of a setups file, logpeek.set, in the in the directory specified by the \
HOME environment variable for Linux, OSX and Sun systems, or the \
combination of HOMEDRIVE and HOMEPATH on Windows. The initial working \
directory and all of the button and option settings will also be read from \
that file. If logpeek.set cannot be found then the default settings \
will be used and the initial data directory will the the \"home\" \
directory described above.\n\
\n\
If the logpeek.set file is not found a file selection dialog box will \
appear when LOGPEEK is started. This may be used to navigate to an \
initial starting directory where source information files are located.\n\
\n\
The list of source information files in the data directory is controlled \
by the selection of the List checkbuttons (.log, .ref, .cf, .zip) below \
the list of files area. The Reload button will reload the files list.\n\
\n\
The source to be examined is selected from the list by double-clicking \
on its name or by selecting the name and clicking the Read button.\n\
\n\
The number of lines in a log file source, or the number of bytes \
in a raw data source file is displayed to the right of each name in the \
list when possible. The number of lines value is just an estimate (it \
assumes about 50 characters per SOH line).\n\
\n\
Changing the data directory is done by editing the directory listed \
in the field near the top of the main window and hitting the Return \
key, or by using the Browse button and navigating to the directory \
of interest. When the directory to be examined has been manually \
entered in the directory field pressing the Return key will generate a \
list of the information source files that LOGPEEK finds in the new \
directory.\n\
\n\
When a source has been selected it is opened and read. Various lines of \
interest in the file's SOH information are parsed, and their \
information saved. A smaller second window will then be created. All of \
the SOH information will be written into that window. The information of \
interest will then be plotted in the plot area, and some information \
about what was read will be placed into the information area below \
the list of files. Status messages will be displayed in the status \
area at the bottom of the display as the reading and plotting processes \
are performed.\n\
\n\
If there is an error file (files ending in \".err\") with the same \
basename as a selected .log file that file will also be opened and \
read. If there are any lines of interest in the .err file another small \
window will be created and the contents of the file will be displayed \
there. Data from the file will be plotted in the plot area along \
with the data from the main/selected .log file.\n\
\n\
If the .err file is large (over 1,000,000 bytes) a dialog box will appear \
asking if the user wants to read the whole file, just the first 10,000 \
lines of the .err file, or not read the .err file at all.\n\
\n\
An additional window can be requested from the menu item Commands|GPS \
Information, that will display information about the DAS's position \
(latatude and longitude) based on the GPS POSITION messages found in \
the SOH information along with a plot of the data points found.\n\
\n\
Another window can be requested from the menu item Commands|Log \
Search, that will allow a string to search through the current log \
to be entered.\n\
\n\
LOGPEEK examines the DAS serial number that it gleans from the source \
file it is requested to read. If the DAS serial number is in the \
range 9000 to FFFF then LOGPEEK guesses that the DAS is an RT130 model \
recorder. Any other number and LOGPEEK will assume the information is \
from a Reftek 72A series DAS.\n\
\n\
All of the program settings are saved to the file \"logpeek.set\" in \
the \"HOME\" directory that was determined when the program was \
started. See the General Info section above for more information \
about the \"HOME\" directory above.\n\
\n\
\n\
Zooming\n\
-------\n\
Once information has been plotted shift-click on the plot area to select \
a first point, and then shift-click in another point to select the second \
selection point. The plot will then zoom in on the selected area. To zoom \
back out shift-click over the labels along the left side of the plot area. \
Shift-click over the labels to cancel the first selection point before the \
second point is selected.\n\
\n\
Clock\n\
-----\n\
Control-click on the main plot area to display a vertical rule indicating \
the time at that point. Control-click below the time plot at the bottom \
of the plot area to toggle the extension of all of the time tick marks \
up across all of the plots. Control-click over the labels along the left \
side of the plot area to hide the clock rule and/or the tick mark lines.\n\
\n\
Control-clicking on the main plot area will also show a vertical rule at \
same time on the raw data plot if it is being shown, and vice versa. This \
can be used, for example, to shift-click on an interesting feature in the \
raw data plot and then go back to the main plot area and zoom in on the \
position of the clock rule with the shift-click function.\n\
\n\
Use Options|Show YYYYMMMDD menu selection to show the date at the top of the \
clock rule as 1999JAN15, instead of 1999:015.\n\
\n\
The time on both plots is actually a calculated value based on how far \
across the display the user clicks, so under some circumstances it may \
not be quite accurate, actually that will be most of the time since \
many seconds, minutes or hours may be compressed into a single screen \
pixel depending on the length of time being plotted.\n\
\n\
Point Selection\n\
---------------\n\
Click the left mouse button near one of the points to show the point's \
corresponding line in the SOH Messages window.\n\
\n\
Time Scrolling\n\
--------------\n\
Click in the area below the time tick marks at the bottom of the plot area \
to scroll forward or backward 90% of the currently displayed time range.\n\
\n\
General Info\n\
------------\n\
Check the Options|Ignore Timing Errors menu selection to force the program \
to plot all of the lines in the SOH messages. Normally, when the option \
is not checked, LOGPEEK will ignore lines that are timestamped earlier in \
time than preceding lines. The lines that LOGPEEK skips will be displayed \
in yellow in the SOH Messages display.\n\
\n\
When the program is fist started on a machine it will attempt to determine \
the \"HOME\" directory for the current user. This will be done using the \
HOME environment variable on Apple OSX, Linux and Sun operating systems, \
and the combination of HOMEDRIVE+HOMEPATH environment variables on \
Windows. If this directory can be written to all will be well and a \
dialog box will appear indicating that the file \"logpeek.set\" could \
not be found. That is OK. When the user quits the program all of the \
current settings (checkboxs, menu options, the current working directory, \
etc.) will be saved to that file. When the program is started again all of \
that information will be restored.\n\
\n\
If the \"HOME\" directory cannot be written to then the program will \
quit. This will have to be resolved before the LOGPEEK may be used.\n\
\n\
Because of the irregularities caused when the program is started by \
clicking on or selecting some kind of icon the program will either ask \
for an initial directory where the log source information files are \
located, or directory paths saved in the setups file will be used. If \
LOGPEEK is started from the command line the command line argument -c \
may be used to set the directory paths of the program to the current \
working directory of the shell window where the program is being started.\n\
\n\
LOGPEEK attempts to remember its last position and size when it quits. \
If the last position it remembers is for a laptop connected to an \
external monitor, and it is then started with the external monitor \
disconnected it should at least show up such that the window can be \
dragged around on the display, but it might not be possible to get at \
the resize controls. If this happens quit LOGPEEK and restart it with \
the -g command line option. LOGPEEK will then restart with the main \
program window fully displayed within the laptop display.\n\
\n\
\n\
MAIN PLOT AREA OPTIONS\n\
======================\n\
The main plot area supports several clicking options to allow detailed \
examination of the plotted information. The program uses only the \
left mouse button by itself, and in conjunction with either the Shift \
key or the Control key.\n\
\n\
Regular click (Point click)\n\
Clicking near a plotted point (or line if the points are close together) \
will direct the program to display in the \"SOH Messages\" window the \
line in the messages that corresponds to the point clicked on. This \
does not work with Mass Position points since these are not generated \
from lines in the SOH messages.\n\
\n\
Clicking on points plotted on the ERR DSx lines will show the \
corresponding line in the Error File Lines window.\n\
\n\
Clicking below the time tick marks at the bottom of the plot area \
will scroll the display ahead or backward in time. Clicking to the \
right of center of the plots will scroll ahead in time, and to the \
left of center backward in time. The amount of scroll is 90% of the \
currently displayed time range so there will be some overlap between \
subsequent refreshes.\n\
\n\
Control-click (\"C\"lock click)\n\
Clicking on the plot area while holding down the Control key will display \
a vertical rule with the time corresponding to the X-axis position of \
the click displayed above the rule. The time above the rule is \
computed based on the start and end times of the displayed plots, and \
the pixel position of the mouse cursor. This will undoubtedly cause \
some rounding errors since the number of seconds covered by the plots \
will usually be much larger than the number of plot pixels.\n\
\n\
Clicking just to the left of the beginning of the plots will place \
the rule at the starting pixel of the plots. Likewise, clicking just \
to the right of the end of the plots will place the rule at the last \
pixel of the plots.\n\
\n\
Performing a control-click below the time line at the bottom of the \
plot area will toggle the extension of the tick marks of the \
time line to the top of the plot area.\n\
\n\
To remove the rule and the time, and/or the extended tick marks, \
perform a control-click in the area of the plot labels on the left \
side of the plot area.\n\
\n\
Shift-click (\"S\"election click)\n\
Clicking on the plot area while holding down the Shift key will \
allow the user to select an area of the plots to be zoomed in on. \
The first shift-click will display a vertical rule marking one boundary \
of the area to be selected. The second shift-click will select the other \
boundry. The plot area will be cleared and the selected area \
redrawn. \"(zoomed)\" will be displayed in the status area until the \
plots return to the original scale.\n\
\n\
Shift-clicking just to the left of the beginning of the plots will place \
the selection rule at the starting pixel of the plots. Likewise, \
shift-clicking just to the right of the end of the plots will place \
the selection rule at the last pixel of the plots.\n\
\n\
To return to the original scale of the plotted information perform a \
shift-click in the plot labels on the left side of the plot area. The \
program will step back out through each of the previous selection \
ranges until the original time range is reached.\n\
\n\
The first selection boundry rule can be cancelled by shift-clicking \
in the label area on the left side of the plot area before \
shift-clicking at the second selection rule's position.\n\
\n\
Right-click (Zapping)\n\
Clicking the right mouse button on a point will remove that point from \
the data set. \"x point(s) zapped\" will be displayed in the status \
area after this function has been used. The file must be reloaded to \
recover and re-plot the zapped points.\n\
\n\
\n\
TIME DETAILS\n\
============\n\
The time quality of SOH messages can range from perfect to ridiculous. \
Most SOH messages do not know what year it is. The program begins reading \
lines and ignores all of them that it comes to until the first \"State \
of Health\" line is reached (which, thechnically, is a line generated \
by reading a SH -- State of Health -- packet header). The program uses \
the timestamp from that line, which contains the year, as the beginning \
time of the file. Lines timestamped before that time, either because of \
a file problem, or a real DAS clock/timing problem of some sort, will be \
ignored. These lines will be counted as \"skipped\" lines. The number \
of lines skipped while reading the file will be displayed in the \
information area of the display (lower left-hand corner). The skipped \
lines will also be displayed in yellow color. For a well-behaved \
DAS/normally produced log file this number will be 2 -- PASSCAL programs \
that produce log files (and LOGPEEK when reading raw data information \
source files) place a line with their name, and the blank line before \
the first \"State of Health\" line. If the number of skipped lines is \
large then the file may have to be looked at manually with an editor, \
or see the Options|Ignore Timing Errors option below.\n\
\n\
In addition to individual lines timestamped before the begin time of \
the file being rejected, subsequent \"State of Health\" lines are also \
checked against each other. If a \"State of Health\" line with time X \
is found, and the next \"State of Health\" line has a time before X all \
lines will be skipped until the next \"State of Health\" line with a \
time after X is found. If a DAS generates timestamps way in the \
future, and then at some point jumps back to the correct time, then it \
is possible that the program may skip all lines from the wrong time \
point on. The file may need to be manually edited to get the program \
to plot anything.\n\
\n\
Because of the way lines are rejected above, it is possible that a few \
data points from the beginning of a new year may be lost. Most lines \
do not know what year it is, and the first lines of a new year will be \
evaluated as being recorded on day 001 of the 'old' year until the next \
\"State of Health\" line is found (usually no more that every 20th \
line of SOH messages) which will then set the internal year value to the \
new year. Only three lines were skipped in a test log file that was \
produced during the 2001-2002 year change, and of the three lines only \
one contained information that would have been recorded and plotted.\n\
\n\
Log file lines that ignore the skipping convention are the lines that \
signifiy the start of an event. Basically, the information from these \
lines is always plotted. No matter how the state of health messages are \
produced these lines will always not quite be in the right place in time \
with respect to the normal SOH messages. The worst case is when reading \
.cf or .cf.zip files when these lines will always follow ALL of the SOH \
messages for a given UT day, because of the way the raw data is stored. \
For this reason they will always be susceptible to being skipped under \
certain conditions, because their 'time' will be less than the last \
good time from a \"State of Health\" line. To keep that from happening \
they are just always plotted. Any actual timing errors will show up \
in other places.\n\
\n\
Internally all dates/times are converted to the number of seconds \
since Jan 1, 1970. If you have information source files with times before \
1970 there's no telling what will happen.\n\
\n\
The Options|Ignore Timing Errors checkbutton may be checked which will \
plot everything no matter how bad any of the timestamps are. The \
first lines of the file (usually only two) before the first State \
of Health line will still be skipped.\n\
\n\
When a source information file is read and the information plotted the \
status message area at the bottom of the display will be yellow, and \
the message \"Possible timing problems\" will appear. This may or may \
not be true. That message will not be displayed again if zooming in or \
out is done.\n\
\n\
\n\
OTHER STUFF\n\
===========\n\
SOH message lines that are \"scrambled\" in some way and that contain \
non-printable characters will be displayed in red, and the bad characters \
will be replaced with a _ (underscore) character. These lines will also \
not be processed in any way, but will just be skipped.\n\
\n\
\n\
SOURCE FILE FORMATS\n\
===================\n\
LOGPEEK will read several different types of sources looking for SOH \
information. The program is not very smart, but instead decides what \
type of file it is reading by the file name extension of the selected \
file.\n\
\n\
.log\n\
----\n\
These are ASCII text files of the State Of Health messages extracted \
by PASSCAL programs such as ref2segy or ref2log. Each .log file may only \
contain the SOH messages from one recorder.\n\
\n\
.ref\n\
----\n\
These are binary files created by PASSCAL programs such as Neo or \
rt130Cut from the contents of RT130 recorder CompactFlash cards. These \
are also the native file format of Reftek 72A recorders. Each .ref \
file may only contain the data from one recorder.\n\
\n\
.zip\n\
----\n\
The RT130 recorders record their data to CompactFlash cards in a Reftek \
created format of directories and data files (one file for each event and \
data stream). This whole whole directory and file structure can be copied \
by Neo/rt130Cut and placed into one zipped file. LOGPEEK can read these \
.zip files if the first directories in the archive are the day directories \
named something like \"2008145\", which is usually the case. Each .zip \
file may only contain the data from one recorder. Event Header packets \
will not be searched for in this data source, so the 'EVENT' line will \
always be empty.\n\
\n\
.cf\n\
---\n\
Sources ending in .cf are really (read: need to be) directories that \
are copies of the directories, files and the structure of an RT130 \
CompactFlash card. Like the .zip files the first sub-directory in the \
\"file\" must be the day directories. Because of the structure of \
the directories data from more than one RT130 in may be in a .cf \
\"file\". LOGPEEK lists these file names as '<name>.cf/<RT130 ID>' \
in the list of files.\n\
\n\
The current working directory may be changed (using the Browse button, \
for example) to the 'root' directory of a directory that has the same \
structure as an RT130 CompactFlash card. If this directory only \
contains YYYYDDD-named day directories LOGPEEK will consider it a .cf-like \
directory and display all of the DAS IDs found in the directory. This \
could be used, for example, to look at the archive directory of an \
RTCC installation.\n\
\n\
\n\
COMMAND LINE ARGUMENTS\n\
======================\n\
-c\n\
--\n\
Tells LOGPEEK to use the current working directory path as the initial \
path for the program's various directory path values, like the work \
directory.\n\
\n\
\n\
MENU COMMANDS\n\
=============\n\
FILE MENU\n\
---------\n\
----- Delete Setups File -----\n\
Sometimes a bad setups file can cause the program to misbehave. This can \
be caused by upgrading the program, but reading the setups file created \
by an earlier version of the program. This function will delete the \
current setups file (which can be found in the About box) and then quit \
the program without saving the current parameters. This will reset \
all parameters to their default values. When the program is restarted \
a dialog box should appear saying that the setups file could not be found. \
If this does not happen the Delete Setups File function may need to be \
run again.\n\
\n\
\n\
COMMANDS MENU\n\
-------------\n\
----- GPS Information -----\n\
Displays a window that shows information about the DAS's position. \
The GPS Plot display plots all of the Latitude and Longitude values \
found in \"GPS POSITION\" SOH messages, after a bit of massaging to \
prevent bad location readings from corrupting the results. To arrive \
at the average location and plot a sensible group of points, the \
program first calculates the standard deviation of all of the points \
found in the file. It then throws out any points with a greater than \
1 sigma error. It then recalculates the standard deviation of the \
remaining points and throws out any points with a greater than 3 sigma \
error. It then recalculates the average position of the remaining \
points and draws the plot. The elevation value is a simple average of \
the elevation values from the last group of points.\n\
\n\
----- Log Search -----\n\
Displays a window where a string of text may be entered. The currently \
plotted SOH messages will be searched for lines containing the \
string. The searching is not case-sensitive.\n\
\n\
----- Plot Time Ranges Of Sources -----\n\
This form allows the user to select any combination of the information \
source files and produce a plot showing the time range covered by each \
file. This can be useful when sorting files to, for example, find which \
files belong to which service run.\n\
\n\
Date Limit fields -----\n\
The Date Limits fields can be used to limit the starting and ending times \
of all of the plots. This can be used in cases where one or more of the \
plotted information sorce files start way before, or extend way after \
the other files, because of something like an internal clock timing \
error.\n\
\n\
Sort button -----\n\
The Sort button rearranges the listed files in alphabetical order.\n\
\n\
Rename button -----\n\
This function renames files selected in the list inserting the start \
year and day of year (YYYYDDD) and the DAS ID into the file name in the \
following manner:\b\
\n\
   The filename will be broken up into items separated by dashes\n\
   (\"-\"). When it is rebuilt the new filename will always have\n\
   YYYYDDD-DDDD.<EXT> as the last items in the new filename. DDDD is\n\
   the DAS ID taken from the file's information and <EXT> will be\n\
   the same extension as in the original filename (.log, .cf, etc.).\n\
   Only the first item from the initial breakup of the file name\n\
   will be retained. The other items will be replaced. The new filename\n\
   will also be all upper case. Examples:\n\
\n\
   1. A file name like XXXX.cf will be changed to XXXX-YYYYDDD-DDDD.CF\n\
   if XXXX is not the DAS ID (maybe it is the station ID). If it is\n\
   the DAS ID then the resulting file name will be YYYYDDD-DDDD.CF.\n\
   2. XXXX-WWWW.cf will be changed to XXXX-YYYYDDD-DDDD.CF.\n\
\n\
From the above you can see that you may want to name the files something \
like <station>-<DAS ID>-<1,2,3, etc>.cf, then use the Rename function.\n\
\n\
The format of <station>-<date>-<DAS>.CF makes sorting and verifying that \
all files from, for example, a service run have been obtained once all \
of the files from the different servicing teams have been combined.\n\
\n\
----- Export TT Times For RAWMEET (Line Format) -----\n\
----- Export TT Times For RAWMEET (Block Format) -----\n\
This command will scan through the current log messages looking for the \
lines generated by programs like ref2log that indicate the beginning of \
each event. These lines contain the string \"TT = yyyy:ddd:...\" which \
is the time of the start of the event. These are collected for each \
data stream and written to a user-selected file in the PASSCAL program \
RAWMEET Shot Line or Block information format.\n\
\n\
----- Export TT Times For TSP -----\n\
This command performs the same action as the Extract TT Times For RAWMEET \
options, except the output format is close to the shot file format \
required by UTEP's TSP program. The file must have the FFID and length \
(of time) fields edited by the user.\n\
\n\
----- Export TT Times As YYYY:DDD:HH:MM:SS.sss -----\n\
Same as above options, but a single event time is listed on each line \
in the simple YYYY:DDD:HH:MM:SS.sss format.\n\
\n\
\n\
PLOTS MENU\n\
----------\n\
----- All of those items -----\n\
Use these items to turn individual item plots on and off.\n\
\n\
----- All Plots On -----\n\
Simply turns all of the checkbuttons for the individual plots in the \
menu on, with the exception of the Mass Position checkbuttons.\n\
\n\
\n\
OPTIONS MENU\n\
------------\n\
----- Ignore Timing Errors -----\n\
Normally the program will read the SOH messages until it finds the line \
identifying the first State Of Health (SOH) block of messages. It \
will obtain the date and time from that line. All lines read before \
that first SOH block will be skipped. Lines will continue to be read \
and as long as a line's time is later than the line preceeding it. If \
there was a timing problem with the DAS, and the timestamps in the log \
file are really messed up (e.g. the time jumps forward several years \
and then jumps back to the current year, thus causing the program to \
not process the remainder of the file after the time jumps back) then \
the program can be forced to process all of the lines in the file that \
are readable by checking the Ignore Timing Errors option.\n\
\n\
----- Add Mass Position Messages -----\n\
The mass position voltages are recorded in data stream 9 of the RT130 \
raw data if reqested in the RT130 parameters. There is no mass position \
information in the state of health messages. If the voltages were being \
written to data stream 9, the Include Non-SOH Items checkbutton is \
selected, either of the Mass Pos 123 or 456 checkbuttons are selected, \
this Option menu item is selected, and a raw data source file (.ref, .cf \
or zipped CF file) is read then lines of information about the mass \
positions will be written to the SOH Messages window following all of \
the normal SOH messages extracted from the source file.\n\
\n\
With the mass position messages in with the rest of the SOH messages \
writing the messages to a .log file using the SOH Messages window's \
Write To File button will make it so that when the saved file is read \
by LOGPEEK the mass position voltages will be plotted. The mass position \
messages will start with \"LPMP\" and will be the last items listed.\n\
\n\
This is all a small kludge until the mass position information is \
written to the SOH messages by the RT130.\n\
\n\
----- Read qlog-ref2mseed Output Files ----\n\
SOH messages extracted from an Antelope database using qlog, which were \
originally the .log files produced by the program ref2mseed (or ref2log, \
or possibily others) that were imported into the database may be read \
by selecting this option. These files basically just have information \
from Antelope placed at the beginning of each SOH message line. This \
simply tells LOGPEEK to strip that information off before beginning to \
process the SOH message lines.\n\
\n\
A couple of checks are made of the lines from the file before the SOH \
lines may be used.\n\
\n\
The first one is that the SOH timestamp (DDD:HH:MM:SS) must be the 6th \
\"word\" in the SOH message lines. LOGPEEK looks for this to be true \
to try and make sure that it is reading a qlog file that has the correct \
information in the correct places and that the SOH messages came from \
a RT130 recorder.\n\
\n\
The second check is that there must be message lines that contain the text \
'State of Health' (written exactly that way). These lines are where \
LOGPEEK derives the year the data was collected and are needed in any \
qlog file read by LOGPEEK. LOGPEEK creates these lines when reading \
.ref, .cf or .zip files.\n\
\n\
The option must be unselected when not reading log files produced by \
qlog.\n\
\n\
----- Show YYYY:DDD Dates ----\n\
----- Show YYYYMMMDD Dates -----\n\
----- Show YYYY-MM-DD Dates -----\n\
Selecting one of these menu items will tell LOGPEEK to display all of \
the dates in the selected format, except for the log source lines. They \
will always be in the DDD:HH:MM:SS format.\n\
\n\
FORMS MENU\n\
----------\n\
The currently open forms of the program will show up here. Selecting one \
will bring that form to the foreground.\n\
\n\
\n\
HELP MENU\n\
---------\n\
----- Calendar -----\n\
Just a built-in calendar that shows dates or DOY values for three months \
in a row. Of course the control computer's clock must be correct for this \
to show the right date.\n\
\n\
----- Check For Updates -----\n\
If the control computer is connected to the Internet this function will \
contact PASSCAL's website and check the version of the program against \
a list of version numbers. Appropriate dialog boxes will be shown \
depending on the result of the check.\n\
\n\
If the current version is old the Download button may be clicked to \
obtain the new version. The new version will be a zipped file and the \
name of the program will be preceeded by \"new\". A dialog box indicating \
the location of the downloaded file will be shown after the downloading \
finishes. Once it has been confirmed that the \"new\" program file is OK, \
it should be renamed and placed in the proper location.\n\
\n\
\n\
BUTTONS AND FIELDS\n\
==================\n\
----- Browse button -----\n\
This button may be used to navigate to the directory in which to look \
for SOH information sources. When the OK button is selected in the file \
picker that directory will be read.\n\
\n\
---- The Current Working Directory field ----\n\
The directory to look for information in may be entered directly into \
this field. Pressing the Return key afterwards will read the entered \
directory. All directory paths are absolute verses relative.\n\
\n\
----- From/To fields and C buttons -----\n\
When reading a large source of SOH information, like a .ref file that \
spans months or more, the from and to date range may be entered into \
these fields to restrict how much of the SOH information gets plotted. \
The date format may be YYYYMMMDD, YYYY:DDD or YYYY-MM-DD. To read and \
plot everything in the selected source just clear the date from both \
fields.\n\
\n\
Entering just a From date will tell LOGPEEK to plot from that date \
to the end of the selected source, and likewise, just entering a To \
date will plot from the beginning of the selected source to the To date. \
The plotted times are from 00:00 on the from date to 24:00 on the to \
date.\n\
\n\
The C buttons bring up date pickers that fill in their associated date \
field by clicking on the desired date.\n\
\n\
----- .log .ref. .zip .cf checkbuttons -----\n\
These control the different types of state of heath information sources \
that will show up in the list of data source files. The Reload button just \
refreshes the list.\n\
\n\
The .cf checkbutton must be selected when trying to read directly from a \
mounted CF card.\n\
\n\
----- Mass Pos 123 and 456 checkbuttons -----\n\
When selected the mass position readings recorded in the AUX Data \
will be plotted for the selected channel group. The color scheme is\n\
   +/-.5V will be cyan (black background) or light\n\
           grey (white background)\n\
   +/-2.0V green or grey\n\
   +/-4.0V yellow or dark grey\n\
   +/-7.0V red or dark blue\n\
   >8.0V magenta or black\n\
\n\
Only about every 500th data point is plotted since the position is \
normally recorded every 10 seconds, which is way too often.\n\
\n\
----- Include Non-SOH Items checkbutton -----\n\
Normally LOGPEEK will only look for state of health information. If this \
checkbutton is checked LOGPEEK will additionally examine some of the other \
binary information in .ref, .zip and .cf information sources. This will \
give LOGPEEK enough information to fill in plots like the EVENT lines. \
Using this feature may significantly increase the amount of time required \
to read an information source. It has no effect when reading .log files, \
and has little effect when reading .ref files.\n\
\n\
----- DSs checkbuttons -----\n\
Checking any of these checkbuttons, IN ADDITION TO the Include Non-SOH \
Items checkbutton, will tell LOGPEEK to additionally decode raw seismic \
data and display a plot for all channels in each data stream selected in \
an additional window. See DAS checkbutton below.\n\
\n\
----- RAW checkbutton -----\n\
This will control whether or not the RAW Data Plot window appears. The \
data displayed will cover the same timerange as the main display plots. \
Nothing beyond just displying the data is supported (no zooming or \
picking times). The quality of the plots will vary depending on the \
data format/recording mode, and the amount of compression when \
recording using compressed modes. LOGPEEK does not read all of the data \
points, but only a subset of them, otherwise it would take way too long to \
read large data files.\n\
\n\
Currently only Steim 1 compressed data decoding is supported until I \
can generate some test data in the other recording modes.\n\
\n\
For Steim 1 (Reftek modes C0 and C1) compressed data format only the first \
value from each 1024-byte packet is plotted. Depending on the compression \
factor that could mean that as few as one of every 892 samples will be \
plotted, which could mean that whole events may be missed. The raw data \
display function is not for analyzing data, but just for checking to see \
if the station is functioning.\n\
\n\
If selected the mass position information for each channel will also be \
plotted on the RAW Data Plot display below each channel's raw data.\n\
\n\
----- T-P-S checkbutton -----\n\
This will control whether or not the Time-Power-Squared window appears. \
The Time-Power-Squared plot displays the average of the sqared amplitudes \
over every 5-minute period covering the time range of the main plot. Each \
line of the display contains one whole day of data from 0000 to 2400 GMT. \
Each 5-minute block is color-coded according to the average amplitude \
during the period. There are three ranges, High, Medium and Low.\n\
Low:\n\
    Dark Grey/Black - there was no data for that period or the\n\
                      average really was 0.0 (not likely)\n\
          Dark blue - the average was +/-20 counts\n\
               Cyan - +/-200 counts\n\
              Green - +/-2,000 counts\n\
             Yellow - +/-20,000 counts\n\
                Red - +/-200,000 counts\n\
            Magenta - +/-2,000,000 counts\n\
   Light Grey/White - > +/-2,000,000 counts\n\
Medium:\n\
    Dark Grey/Black - there was no data for that period or the\n\
                      average really was 0.0 (not likely)\n\
          Dark blue - the average was +/-50 counts\n\
               Cyan - +/-500 counts\n\
              Green - +/-5,000 counts\n\
             Yellow - +/-50,000 counts\n\
                Red - +/-500,000 counts\n\
            Magenta - +/-5,000,000 counts\n\
   Light Grey/White - > +/-5,000,000 counts\n\
High:\n\
    Dark Grey/Black - there was no data for that period or the\n\
                      average really was 0.0 (not likely)\n\
          Dark blue - the average was +/-80 counts\n\
               Cyan - +/-800 counts\n\
              Green - +/-8,000 counts\n\
             Yellow - +/-80,000 counts\n\
                Red - +/-800,000 counts\n\
            Magenta - +/-8,000,000 counts\n\
   Light Grey/White - > +/-8,000,000 counts\n\
\n\
The ranges are selected by using the \"L\", \"M\" and \"H\" radiobuttons \
on the plot window.\n\
\n\
Control-clicking on any part of the plots will display the 'center' time \
of the 5-minute block that was clicked on. Clock rules and the time will \
also be drawn on the Raw Data and the main plots at the same time point. \
Control-clicking to the left of the plots will remove the times and time \
indicators.\n\
\n\
----- Replot button -----\n\
This will clear and redraw all of the current plots. This will only work \
for bringing up the RAW or T-P-S plot windows if they were not previously \
created, or for changing background colors. It will not, for example, \
make bringing up and plotting the raw data if the Include Non-SOH Items \
checkbutton and one of the DS checkbuttons were not initially selected. \
In that case the file will have to be re-read using the Read button.\n\
\n\
----- Background B and W radiobuttons -----\n\
The B button will make the background of the main plotting area black \
and the W button white. The white background should be used if the plots \
are going to be printed to use less ink/toner.\n\
\n\
----- Read/Stop buttons -----\n\
The Read button starts the reading of the selected source file, and \
the Stop button halts the reading of a source file. This may be \
used if it is decided that the file selected is not the correct one, \
or is too long to wait to be read. The button will only stop LOGPEEK \
while reading the SOH information. Once that point has been passed \
LOGPEEK will not stop until after the information has been plotted.\n\
\n\
----- Write .ps button -----\n\
This creates a PostScript file of the the contents of the plot area. \
When selected a dialog box will allow the name of the file to be selected \
or entered.\n\
\n\
----- Redraw button -----\n\
Use this button after changing the size of the window to command LOGPEEK \
to redraw the plots. There is too much inconsistancy between installations \
and versions of operating systems for this to be done automatically. Some \
systems command LOGPEEK to redraw the plots after the resizing of the \
window is finished, and some send the command many times WHILE resizing \
the window. On some systems it is easy to change this behavior, and on \
some systems it isn't. This button makes it the responsibility of the \
user to click the Redraw button when they are finished resizing the \
window.\n\
\n\
\n\
PLOTTED ITEMS\n\
=============\n\
Below is an explanation of each plot and the kinds of SOH messages \
whose information make up the plotting information.\n\
\n\
DSP-CLK DIFF\n\
Points on this plot are generated by SOH lines like:\n\
\n\
172:01:41:21 DSP CLOCK DIFFERENCE: 0 SECS AND -989 MSECS\n\
\n\
This plot will only be displayed if these SOH messages are in the file.\n\
\n\
PHASE ERROR\n\
Points on this plot are generated by SOH lines like:\n\
\n\
172:02:41:19 INTERNAL CLOCK PHASE ERROR OF 3526 USECONDS\n\
\n\
JERKS/DSP SETS\n\
Points on this line are generated by lines like:\n\
\n\
172:23:41:44 INTERNAL CLOCK TIME JERK # 11 OCCURRED AT 23:41:44.994\n\
\n\
172:23:41:45 DSP CLOCK SET: OLD=01:172:23:41:45.996, NEW=01:172:23:41:45.007\n\
\n\
GPS ON-OFF\n\
Points on this line are generated by lines like:\n\
\n\
173:00:39:58 GPS: POWER IS TURNED ON  (72-series instruments)\n\
.\n\
173:00:39:58 EXTERNAL CLOCK WAKEUP  (RT130-series instruments)\n\
\n\
GPS LK-UNLK\n\
Points on this plot are generated by lines like:\n\
\n\
173:00:41:53 EXTERNAL CLOCK IS LOCKED\n\
\n\
173:00:46:53 EXTERNAL CLOCK IS UNLOCKED\n\
\n\
CLOCK POWER STATE MESSAGES\n\
These only show up as yellow dots across the middle of the GPS LK-UNLK \
plot. They indicate a change in the power state of the GPS clock.\n\
\n\
196:20:59:38 CLK: EXTERNAL CLOCK CYCLE IS NORMAL\n\
197:14:45:12 CLK: EXTERNAL CLOCK CYCLE IS CONTINUOUS\n\
\n\
DUMP CALL\n\
Points on this line are generated by lines like:\n\
\n\
173:01:17:25 AUTO DUMP CALLED\n\
\n\
173:01:18:03 AUTO DUMP COMPLETE\n\
\n\
EVENTS DSx\n\
Points on these lines are generated by lines like:\n\
\n\
DAS: 0108  EV: 0377  DS: 2  FST = 2001:173:01:09:51:447  TT = 2001:173:01:09:51:447  NS: 144005  SPS: 40  ETO: 0\n\
\n\
Which line a point is plotted on is determined by the data stream \
value following \"DS:\" in the SOH message.\n\
When reading .ref, .zip and .cf information source files these lines \
are generated by LOGPEEK when the Include Non-SOH Items checkbutton \
is selected.\n\
The plot time of the points are actually the TT (Trigger Time) and not \
the FST time.\n\
\n\
DAS TEMP and BATTERY VOLTS\n\
Points on these two plots are generated by lines like:\n\
\n\
173:02:17:04 BATTERY VOLTAGE = 13.5V, TEMPERATURE = 28C\n\
\n\
ERR CHx\n\
Data from an error file. Each line corresponds to a data channel. \
Represented are the overlaps and gaps in the timing information. The \
length of the line indicates the amount of the time jump. A red line \
indicates that there was a correction made to the system clock which \
changed the time backwards (overlap), but the value in the .err file \
will be a positive number. A green line indicates that the time was \
jumped forward (gap). Areas on the plots are generated by lines like:\n\
\n\
Time jump: R353.01/01.353.00.19.11.0394.6 obs 00:21:38.031  corr +1 ms\n\
\n\
The error files are created by programs like ref2mseed.\n\
\n\
RESET/POWERUP\n\
Points on this line are generated by lines like:\n\
\n\
159:15:08:57 SYSTEM POWERUP 2: UNIT 108, CPU VER 03.00A\n\
\n\
DISCREPANCIES\n\
These points are plotted when lines with \"DISCREPANCY\" are found. These \
are some test lines that have been put in by Reftek (2005SEP22).\n\
\n\
ERROR/WARNING\n\
Lines placed into the SOH messages by programs like ref2segy that have \
the word \"ERROR\" or \"WARNING\" in them. The position of the dots on \
the plot for these messages may, at times, not make any sense. These \
message lines in the log files do not have a timestamp, so the \
program just uses the time from the last line that had a timestamp, \
which, since a lot of the warning messages have to do with clock \
problems, means that the dots may show up in the wrong place.\n\
\n\
RE-CENTER\n\
Generated by SOH messages like:\n\
\n\
086:16:04:36 SENSOR 1 MASS RE-CENTER: MANUAL\n\
\n\
ACQ ON-OFF\n\
Points on this line are generated by lines like:\n\
\n\
159:15:09:11 ACQUISITION STARTED\n\
253:22:57:43 ACQUISITION STOP REQUESTED\n\
\n\
SOH/DATA DEFS\n\
SOH points on this line are generated by lines like:\n\
\n\
State of Health 01:159:15:06:02:839 ST: 0108\n\
\n\
Data Definition points on this line are generated by lines like:\n\
\n\
Data Stream Definition 01:159:15:08:59:392 ST: 0108\n\
\n\
This block of information is normally followed by lines for the other \
parameter blocks such as:\n\
\n\
Station Channel Definition 01:159:15:08:59:392 ST: 0108\n\
\n\
Calibration Definition 01:159:15:08:59:392 ST: 0108\n\
\n\
etc.\n\
\n\
NET UP-DOWN\n\
The plot points out when the 130 is either first sync'ing up with \
Reftek's RTPD product, re-sync'ing with RTPD, or also if the 130 is \
having trouble maintaining it's communication with RTPD. These \
messages are not the Ethernet Stack itself going up or down, but \
rather one of the layer's built into the RTP thread of the 130. The \
SOH messages will look like:\n\
\n\
    NETWORK LAYER IS UP\n\
    NETWORK LAYER IS DOWN\n\
\n\
END\n"




#########################
# BEGIN: formHELP(Parent)
# LIB:formHELP():2010.284
#   Put the help contents in global variable HELPText somewhere in the
#   program.
Frm["HELP"] = None
HELPFindLookForVar = StringVar()
HELPFindLastLookForVar = StringVar()
HELPFindLinesVar = StringVar()
HELPFindIndexVar = IntVar()
PROGSetups += ("HELPFindLookForVar", )
HELPHeight = 25
HELPWidth = 80
HELPFont = PROGMonoFont

def formHELP(Parent):
    if Frm["HELP"] != None:
        Frm["HELP"].deiconify()
        Frm["HELP"].lift()
        return
    LFrm = Frm["HELP"] = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "HELP"))
    LFrm.title("Help - %s"%PROG_NAME)
    LFrm.iconname("Help")
    Sub = Frame(LFrm)
    LTxt = Txt["HELP"] = Text(Sub, width = HELPWidth, height = HELPHeight, \
            wrap = WORD, font = HELPFont, relief = SUNKEN)
    LTxt.pack(side = LEFT, expand = YES, fill = BOTH)
    LSb = Scrollbar(Sub, orient = VERTICAL, command = LTxt.yview)
    LSb.pack(side = RIGHT, fill = Y)
    LTxt.configure(yscrollcommand = LSb.set)
    Sub.pack(side = TOP, expand = YES, fill = BOTH)
    Sub = Frame(LFrm)
    labelTip(Sub, "Find:=", LEFT, 30, "[Find]")
    LEnt = Entry(Sub, width = 20, textvariable = HELPFindLookForVar)
    LEnt.pack(side = LEFT)
    LEnt.bind("<Double-Button-1>", Command(formKB, "HELP", "Find", \
            HELPFindLookForVar))
    LEnt.bind("<Return>", Command(formFind, "HELP", "HELP"))
    LEnt.bind("<KP_Enter>", Command(formFind, "HELP", "HELP"))
    BButton(Sub, text = "Find", command = Command(formFind, \
            "HELP", "HELP")).pack(side = LEFT)
    BButton(Sub, text = "Next", command = Command(formFindNext, \
            "HELP", "HELP")).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Write To "+PROG_NAMELC+".doc", \
            command = Command(formHELPWrite, LTxt)).pack(side = LEFT)
    Label(Sub, text = " ").pack(side = LEFT)
    BButton(Sub, text = "Close", fg = Clr["R"], \
            command = Command(closeForm, "HELP")).pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3, pady = 3)
    Msg["HELP"] = Text(LFrm, font = PROGMsgFont, height = 3, wrap = WORD)
    Msg["HELP"].pack(side = TOP, fill = X)
    LTxt.insert(END, HELPText)
# Clear this so the formFind() routine does the right thing if this form was
# brought up previously.
    HELPFindLinesVar.set("")
    center(Parent, LFrm, "C", "I", True)
    return
#####################################
# BEGIN: formHELPWrite(Who, e = None)
# FUNC:formHELPWrite():2010.177
def formHELPWrite(Who, e = None):
    Filespec = PROGWorkDirVar.get()+PROG_NAMELC+PROG_VERSION+".doc"
    try:
        Fp = open(Filespec, "wb")
    except Exception, e:
        msgLn(0, "M", "Error opening help file\n   %s\n   %s"%(Filespec, e), \
                True, 3)
        return
    Fp.write("Help for %s version %s\n\n"%(PROG_NAME, PROG_VERSION))
    N = 1
    while 1:
        if Who.get("%d.0"%N) == "":
            break
# The lines from the Text field do not come with a \n after each screen line,
# so we'll have to split the lines up ourselves.
        Line = Who.get("%d.0"%N, "%d.0"%(N+1))
        N += 1
        if len(Line) < 65:
            Fp.write(Line)
            continue
        Out = ""
        for c in Line:
            if c == " " and len(Out) > 60:
                Fp.write(Out+"\n")
                Out = ""
            elif c == "\n":
                Fp.write(Out+"\n")
                Out == ""
            else:
                Out += c
    Fp.close()
    setMsg("HELP", "", "Help written to\n   %s"%Filespec)
    return
# END: formHELP




##########################
# BEGIN: formRTIME(Parent)
# LIB:formRTIME():2011.080
#   Needs an OPTDateFormatRVar with "YYYY:DDD", "YYYYMMMDD" or "YYYY-MM-DD"
#   in it.
Frm["RTIME"] = None
Can["RTIME"] = None
RTIMERunning = IntVar()
RTIMEFiles = None
RTIMEShowLogsCVar = IntVar()
RTIMEShowLogsCVar.set(1)
RTIMEShowZCFCVar = IntVar()
RTIMEShowZCFCVar.set(1)
RTIMEShowRefsCVar = IntVar()
RTIMEShowRefsCVar.set(1)
RTIMEShowUCFDCVar = IntVar()
RTIMEShowUCFDCVar.set(1)
RTIMEFromVar = StringVar()
RTIMEToVar = StringVar()
RTIMEEraseCVar = IntVar()
RTIMEEraseCVar.set(1)
PROGSetups += ("RTIMEShowLogsCVar", "RTIMEShowZCFCVar", "RTIMEShowRefsCVar", \
        "RTIMEShowUCFDCVar", "RTIMEFromVar", "RTIMEToVar", "RTIMEEraseCVar")
RTIMETimesInfo = []
RTIMEReadBut = None
RTIMEStopBut = None
RTIME_ERROR = 0
RTIME_FILE = 1
RTIME_COLOR = 1
RTIME_SOHS = 2
RTIME_MSG = 2
RTIME_SOHE = 3
RTIME_BEEP = 3

def formRTIME(Parent):
    global RTIMEFiles
    global RTIMEReadBut
    global RTIMEStopBut
    if showUp("RTIME"):
        return
    LFrm = Frm["RTIME"] = Toplevel(Parent)
    LFrm.withdraw()
    LFrm.protocol("WM_DELETE_WINDOW", Command(formRTIMEControl, "close"))
    LFrm.title("Plot Time Ranges Of Sources")
    LFrm.iconname("SourceRange")
# List the current directory(s) that apply to this form.
    Sub = Frame(LFrm)
    LLb = Label(Sub, text = "Data Directory:", relief = GROOVE, bd = 2)
    LLb.pack(side = LEFT)
    ToolTip(LLb, 30, "Right-click to change the directory.")
# formRTIME() started in LOGPEEK which had a different needs for handling
# directories. It only used one.
    if PROG_NAME == "LOGPEEK":
        LLb.bind("<Button-3>", formRTIMEpopDirFID)
    else:
        LLb.bind("<Button-3>", Command(popDirFID, "RTIME", "thedata", \
                PROGDataDirVar))
    Entry(Sub, width = 1, textvariable = PROGDataDirVar, state = DISABLED, \
            relief = FLAT, bd = 0, bg = Clr["D"], \
            fg = Clr["B"]).pack(side = LEFT, expand = YES, fill = X)
    labelTip(Sub, "Hints", LEFT, 45, \
            "PLOT AREA HINTS:\n--Click: Clicking on a plot will display an information flag for that plot.\n--Click on flag: Clicking on an information flag will make it disappear.\n--Right-click on file: Right-clicking on a file name will show a popup menu with an item for plotting that file on the main display.")
    Sub.pack(side = TOP, anchor = "w", expand = NO, fill = X, padx = 3)
    Sub = Frame(LFrm)
# Listbox and controls.
    SSub = Frame(Sub)
    SSSub = Frame(SSub)
    RTIMEFiles = Listbox(SSSub, relief = SUNKEN, bd = 2, height = 1, \
            width = 25, selectmode = EXTENDED)
    RTIMEFiles.pack(side = LEFT, expand = YES, fill = Y)
    RTIMEFiles.bind("<Double-Button-1>", formRTIMEGo)
    Scroll = Scrollbar(SSSub, command = RTIMEFiles.yview, orient = VERTICAL)
    Scroll.pack(side = RIGHT, fill = Y)
    RTIMEFiles.configure(yscrollcommand = Scroll.set)
    SSSub.pack(side = TOP, expand = YES, fill = Y)
    SSSub = Frame(SSub)
    Scroll = Scrollbar(SSSub, command = RTIMEFiles.xview, orient = HORIZONTAL)
    Scroll.pack(side = BOTTOM, expand = YES, fill = X)
    RTIMEFiles.configure(xscrollcommand = Scroll.set)
    SSSub.pack(side = TOP, fill = X, expand = NO)
    SSSub = Frame(SSub)
    BButton(SSSub, text = "Reload", command = Command(loadRTFilesCmd, \
            RTIMEFiles, "RTIME")).pack(side = LEFT)
    BButton(SSSub, text = "Select All", \
            command = Command(loadRTFilesSelectAll, \
                    RTIMEFiles)).pack(side = LEFT)
    SSSub.pack(side = TOP)
    SSSub = Frame(SSub)
    LLb = Label(SSSub, text = "List:")
    LLb.pack(side = LEFT)
    ToolTip(LLb, 35, \
        "The types of data sources that should be displayed in the file list.")
    SSSSub = Frame(SSSub)
    SSSSSub = Frame(SSSSub)
    LCb = Checkbutton(SSSSSub, text = ".log", variable = RTIMEShowLogsCVar)
    LCb.pack(side = TOP, anchor = "w")
    ToolTip(LCb, 30, "RT130 text log files.")
    LCb = Checkbutton(SSSSSub, text = ".cf", variable = RTIMEShowUCFDCVar)
    LCb.pack(side = TOP, anchor = "w")
    ToolTip(LCb, 30, "RT130 CompactFlash card images (not zipped).")
    SSSSSub.pack(side = LEFT)
    SSSSSub = Frame(SSSSub)
    LCb = Checkbutton(SSSSSub, text = ".ref", variable = RTIMEShowRefsCVar)
    LCb.pack(side = TOP, anchor = "w")
    ToolTip(LCb, 30, "RT130 all-in-one raw data files.")
    LCb = Checkbutton(SSSSSub, text = ".zip", variable = RTIMEShowZCFCVar)
    LCb.pack(side = TOP, anchor = "w")
    ToolTip(LCb, 30, "RT130 zipped CompactFlash card images.")
    SSSSSub.pack(side = LEFT)
    SSSSub.pack(side = LEFT)
    SSSub.pack(side = TOP)
    BButton(SSub, text = "Sort", command = formRTIMESort).pack(side = TOP)
    Frame(SSub, height = 1, bg = Clr["B"], relief = GROOVE).pack(side = TOP, \
            fill = X, padx = 10, pady = 3)
    LCb = Checkbutton(SSub, text = "Erase?", variable = RTIMEEraseCVar)
    LCb.pack(side = TOP)
    ToolTip(LCb, 30, \
            "Should the text area be erased before reading more files or not?")
    SSSub = Frame(SSub)
    RTIMEReadBut = BButton(SSSub, text = "Read", command = formRTIMEGo)
    RTIMEReadBut.pack(side = LEFT)
    RTIMEStopBut = BButton(SSSub, text = "Stop", state = DISABLED, \
            command = Command(formRTIMEControl, "stopping"))
    RTIMEStopBut.pack(side = LEFT)
    SSSub.pack(side = TOP)
    Frame(SSub, height = 1, bg = Clr["B"], relief = GROOVE).pack(side = TOP, \
            fill = X, padx = 10, pady = 3)
    BButton(SSub, text = "Rename", command = formRTIMERename).pack(side = TOP)
    Frame(SSub, height = 1, bg = Clr["B"], relief = GROOVE).pack(side = TOP, \
            fill = X, padx = 10, pady = 3)
    BButton(SSub, text = "Close", fg = Clr["R"], \
            command = Command(formRTIMEControl, "close")).pack(side = TOP)
    SSSub.pack(side = TOP)
    SSub.pack(side = LEFT, padx = 3, pady = 3, anchor = "n", expand = NO, \
           fill = Y)
    SSub = Frame(Sub)
    SSSub = Frame(SSub)
    labelTip(SSSub, "Date Limits: From:", LEFT, 30, \
            "The date range to use to limit the plotting in the event that there is a data source that starts way earlier or later than the rest. Format can be YYYY:DDD, YYYYMMMDD or YYYY-MM-DD.")
    Entry(SSSub, width = 10, textvariable = RTIMEFromVar).pack(side = LEFT)
    BButton(SSSub, text = "C", command = Command(formPCAL, "RTIME", "C", \
            "RTIME", RTIMEFromVar, False, \
            OPTDateFormatRVar)).pack(side = LEFT)
    Label(SSSub, text = " to ").pack(side = LEFT)
    Entry(SSSub, width = 10, textvariable = RTIMEToVar).pack(side = LEFT)
    BButton(SSSub, text = "C", command = Command(formPCAL, "RTIME", "C", \
            "RTIME", RTIMEToVar, False, OPTDateFormatRVar)).pack(side = LEFT)
    SSSub.pack(side = TOP)
# The plotting area.
    SSSub = Frame(SSub, bd = 2, relief = SUNKEN)
    LCan = Can["RTIME"] = Canvas(SSSub, bd = 0, bg = Clr["W"], height = 500, \
            width = 700, highlightthickness = 0)
    LCan.pack(side = LEFT, expand = YES, fill = BOTH)
    LSb = Scrollbar(SSSub, orient = VERTICAL, command = LCan.yview)
    LSb.pack(side = RIGHT, fill = Y)
    LCan.configure(yscrollcommand = LSb.set)
    SSSub.pack(side = TOP, expand = YES, fill = BOTH)
    SSub.pack(side = LEFT, expand = YES, fill = BOTH)
    Sub.pack(side = TOP, expand = YES, fill = BOTH)
    Msg["RTIME"] = Text(LFrm, font = PROGMsgFont, height = 3, wrap = WORD)
    Msg["RTIME"].pack(side = TOP, fill = X)
    center(Parent, LFrm, "C", "I", True)
    loadRTFilesCmd(RTIMEFiles, "RTIME")
    return
##############################
# BEGIN: formRTIMEGo(e = None)
# FUNC:formRTIMEGo():2011.037
def formRTIMEGo(e = None):
    global RTIMETimesInfo
    if RTIMERunning.get() == 1:
        setMsg("RTIME", "YB", "I'm busy...", 2)
        sleep(.5)
        return
    setMsg("RTIME", "", "")
    Sel = RTIMEFiles.curselection()
    if len(Sel) == 0:
        setMsg("RTIME", "RW", "No files have been selected.", 2)
        return
    DateFormat = OPTDateFormatRVar.get()
# Check out any limits the user wants to use.
    FromEpoch = 0
    ToEpoch = maxint
    for F in ("From", "To"):
        eval("RTIME%sVar"%F).set(eval("RTIME%sVar"%F).get().strip().upper())
        if eval("RTIME%sVar"%F).get() != "":
            Ret = convertDate(DateFormat, eval("RTIME%sVar"%F).get())
            if Ret[0] != 0:
                setMsg("RTIME", "RW", "%s field value bad."%F, 2)
                return
            eval("RTIME%sVar"%F).set(Ret[1])
# We shouldn't need to check this here since it was just done above.
            Ret = convertDate("yd", eval("RTIME%sVar"%F).get())
            if F == "From":
                FromEpoch = ydhms2Epoch(int(Ret[1]), int(Ret[2]), 0, 0, 0)
            elif F == "To":
# +1 to get to 24:00 of the entered date.
                ToEpoch = ydhms2Epoch(int(Ret[1]), int(Ret[2])+1, 0, 0, 0)
# In case someone tries to be funny.
    if FromEpoch >= ToEpoch:
        setMsg("RTIME", "RW", \
          "From field date is the same as or later than the To field date.", 2)
    setMsg("RTIME", "CB", "Working...")
    LCan = Can["RTIME"]
    CWIDTH = LCan.winfo_width()
    GMARGIN = 10
    LFH = PROGLabelFontHeight
    if RTIMEEraseCVar.get() == 1:
        LCan.delete(ALL)
        LCan.yview_moveto(0.0)
        LCan.update()
        YTop = LFH
    else:
# There may not be anything plotted, so try.
        try:
            YTop = LCan.bbox(ALL)[3]
            YTop += LFH*2.0
        except TypeError:
            YTop = LFH
# Always check the directory entry in case the user messed with it.
    PROGDataDirVar.set(PROGDataDirVar.get().strip())
    if PROGDataDirVar.get().endswith(sep) == False:
        PROGDataDirVar.set(PROGDataDirVar.get()+sep)
# Keep these in sync.
        PROGMsgsDirVar.set(PROGDataDirVar.get())
        PROGWorkDirVar.set(PROGDataDirVar.get())
    TheDataDir = PROGDataDirVar.get()
    canText(LCan, 5, YTop, "B", "Plot of source file times in directory")
    YTop += LFH
    canText(LCan, 5, YTop, "B", "   "+TheDataDir)
    YTop += LFH*2
    formRTIMEControl("go")
# Where we'll store the values for each file until all of the files have been
# read.
    RTIMETimesInfo = []
    FileCount = 0
    for Index in Sel:
        if RTIMERunning.get() == 0:
            setMsg("RTIME", "YB", "Stopped.", 2)
            formRTIMEControl("stopped")
            return
        Selected = RTIMEFiles.get(Index)
# Skip over the blank lines.
        if Selected == "":
            continue
        FileCount += 1
        setMsg("RTIME", "CB", "Working on file %d of %d..."%(FileCount, \
                len(Sel)))
# The entry will probably be something like "Filename (x bytes or lines)" so
# just get the Filename.
        Parts = Selected.split()
        Filename = Parts[0]
        FilenameLC = Filename.lower()
        Filespec = "%s%s"%(PROGDataDirVar.get(), Filename)
# This check is a little complicated because of the way .cf's are listed in
# the Listbox (e.g. 9BA6.cf/9BA6).
        if FilenameLC.find(".cf"+sep) != -1:
            try:
                I = Filespec.index(".cf"+sep)
            except:
                I = Filespec.index(".CF"+sep)
            Filecheck = Filespec[:I+3]
            if exists(Filecheck) == False:
                setMsg("RTIME", "RW", \
                       "%s: .cf directory not found. Use the Reload button?"% \
                        Filename, 2)
                formRTIMEControl("stopped")
                return
        else:
            if exists(Filespec) == False:
                setMsg("RTIME", "RW", \
                       "%s: File not found. Use the Reload button?"%Filename, \
                        2)
                formRTIMEControl("stopped")
                return
        if FilenameLC.endswith(".log"):
            Ret = rt72130logTimeRange(Filespec, "", RTIMEStopBut, \
                    RTIMERunning)
        elif FilenameLC.endswith(".ref"):
            Ret = rt72130refTimeRange(Filespec, RTIMEStopBut, RTIMERunning)
# Look for these before .cf's since the names may be like 123456.cf.zip.
        elif FilenameLC.endswith(".zip"):
            Ret = rt130zcfTimeRange(Filespec, RTIMEStopBut, RTIMERunning, \
                    "RTIME")
        elif FilenameLC.find(".cf") != -1:
            Ret = rt130cfTimeRange(Filespec, RTIMEStopBut, RTIMERunning, \
                    "RTIME")
# Something fatal this way comes (or we are just stopping).
        if Ret[0] == 2:
            setMsg("RTIME", Ret[1], Ret[2], Ret[3])
            formRTIMEControl("stopped")
            return
# RTIMETimesInfo will be:
#    [(0, Filename, SOHStart, SOHEnd, DAS ID), ...]
# For files that have trouble:
#    [..., (1, Color, Message, Beep), ...]
        RTIMETimesInfo.append(Ret)
# I'm not sure how this could ever happen.
    if len(RTIMETimesInfo) == 0:
        setMsg("RTIME", "YB", "No times found.", 2)
        formRTIMEControl("stopped")
        return
# Determine the earliest and latest times and start graphing.
    SOHStart = maxint
    SOHEnd = -maxint
    Earliest = maxint
    Latest = -maxint
# Get the longest filename while we're going through the files.
    LongestFileName = ""
    LongestFileNameLen = 0
    for Info in RTIMETimesInfo:
        Len = len(Info[RTIME_FILE])
        if Len > LongestFileNameLen:
            LongestFileName = Info[RTIME_FILE]
            LongestFileNameLen = Len
# We just want the times from the files that were successfully processed.
        if Info[RTIME_ERROR] == 0:
            if Info[RTIME_SOHS] < SOHStart:
                SOHStart = Info[RTIME_SOHS]
                if SOHStart != 0 and SOHStart < Earliest:
                    Earliest = SOHStart
            if Info[RTIME_SOHE] > SOHEnd:
                SOHEnd = Info[RTIME_SOHE]
                if SOHEnd != 0 and SOHEnd > Latest:
                    Latest = SOHEnd
# Doing a .measure() on each file name and keeping the longest number in the
# above loops was taking a LONG time, so I changed to this slight convolution
# of just keeping the name with the most number of characters and then getting
# the .measure() length here. That might screw up the plotting at some point
# since the individual character widths are different, but it makes things way
# way faster.
    LongestFileNameLen = PROGLabelFontFont.measure(LongestFileName)+15
# Now apply any user date limits.
    if Earliest < FromEpoch:
        Earliest = FromEpoch
# This may happen since the user may not have known what the time range of the
# files were when the date was entered.
    if FromEpoch > Latest:
        if DateFormat == "YYYY:DDD":
            setMsg("RTIME", "RW", \
               "The From date (%s) is later than the latest file time (%s)."% \
                    (epoch2Str(FromEpoch), epoch2Str(Latest)), 2)
        elif DateFormat == "YYYYMMMDD":
            setMsg("RTIME", "RW", \
               "The From date (%s) is later than the latest file time (%s)."% \
                    (ydhms2ymdhms(epoch2Str(FromEpoch)), \
                    ydhms2ymdhms(epoch2Str(Latest))), 2)
        elif DateFormat == "YYYY-MM-DD":
            setMsg("RTIME", "RW", \
               "The From date (%s) is later than the latest file time (%s)."% \
                    (ydhms2ymdhmsDash(epoch2Str(FromEpoch)), \
                    ydhms2ymdhmsDash(epoch2Str(Latest))), 2)
        elif DateFormat == "":
            setMsg("RTIME", "RW", \
               "The From date (%s) is later than the latest file time (%s)."% \
                    (str(FromEpoch), str(Latest)), 2)
        formRTIMEControl("stopped")
        return
    if Latest > ToEpoch:
        Latest = ToEpoch
    if Earliest > Latest:
        if DateFormat == "YYYY:DDD":
            setMsg("RTIME", "RW", \
           "The earliest date/time (%s) is after the latest date/time (%s)."% \
                    (epoch2Str(Earliest), epoch2Str(Latest)))
        elif DateFormat == "YYYYMMMDD":
            setMsg("RTIME", "RW", \
           "The earliest date/time (%s) is after the latest date/time (%s)."% \
                    (ydhms2ymdhms(epoch2Str(Earliest)), \
                    ydhms2ymdhms(epoch2Str(Latest))), 2)
        elif DateFormat == "YYYY-MM-DD":
            setMsg("RTIME", "RW", \
           "The earliest date/time (%s) is after the latest date/time (%s)."% \
                    (ydhms2ymdhmsDate(epoch2Str(Earliest)), \
                    ydhms2ymdhmsDate(epoch2Str(Latest))), 2)
        elif DateFormat == "":
            setMsg("RTIME", "RW", \
           "The earliest date/time (%s) is after the latest date/time (%s)."% \
                    (str(Earliest), str(Latest)), 2)
        formRTIMEControl("stopped")
        return
    if Earliest == Latest:
        if DateFormat == "YYYY:DDD":
            setMsg("RTIME", "RW", \
   "The earliest date/time and the latest date/time are both the same (%s)."% \
                    epoch2Str(Earliest), 2)
        elif DateFormat == "YYYYMMMDD":
            setMsg("RTIME", "RW", \
   "The earliest date/time and the latest date/time are both the same (%s)."% \
                    ydhms2ymdhms(epoch2Str(Earliest)), 2)
        elif DateFormat == "YYYY-MM-DD":
            setMsg("RTIME", "RW", \
   "The earliest date/time and the latest date/time are both the same (%s)."% \
                    ydhms2ymdhmsDate(epoch2Str(Earliest)), 2)
        elif DateFormat == "":
            setMsg("RTIME", "RW", \
   "The earliest date/time and the latest date/time are both the same (%s)."% \
                    str(Earliest), 2)
        formRTIMEControl("stopped")
        return
    setMsg("RTIME", "CB", "Plotting...")
# Get the epoch of the earliest day at 00:00 and the epoch of the latest day
# at 23:59:59 for the PlotRange.
    TheEarliestTime = epoch2Str(Earliest)
    PlotEarliestEpoch = float(str2Epoch(None, TheEarliestTime[:8]+":00:00:00"))
    TheLatestTime = epoch2Str(Latest)
# We need to add one day to the end YYYY:DDD because the loop below will plot
# a FENCE POST at the last day plus 1 second (i.e. then next day).
    YYYY, DDD, HH, MM, SS = map(intt, TheLatestTime.split(":"))
    YYYY, DDD = ydoyMath(1, YYYY, DDD)
    TheLatestNextTime = "%s:%03d"%(YYYY, DDD)
    PlotLatestEpoch = float(str2Epoch(None, TheLatestTime[:8]+":23:59:59"))
    PlotRange = PlotLatestEpoch-PlotEarliestEpoch
    LFH2 = LFH/2
    LFH4 = LFH/4
    PlotML = LongestFileNameLen+5
    PlotMR = PROGLabelFontFont.measure(DateFormat)/2+5
    PlotW = CWIDTH-PlotML-PlotMR
# Draw the day tick marks (the plot will always be at least 1 day long).
    if DateFormat == "YYYY:DDD":
        Earliest = TheEarliestTime[:8]
    elif DateFormat == "YYYYMMMDD":
        Parts = TheEarliestTime.split(":")
        MM, DD = ydoy2md(intt(Parts[0]), intt(Parts[1]))
        Earliest = "%s%s%02d"%(Parts[0], m2MMM(MM), DD)
    elif DateFormat == "YYYY-MM-DD":
        Parts = TheEarliestTime.split(":")
        MM, DD = ydoy2md(intt(Parts[0]), intt(Parts[1]))
        Earliest = "%s-%02d-%02d"%(Parts[0], MM, DD)
    canText(LCan, PlotML, YTop, "B", Earliest, "center")
    LCan.create_line(PlotML, YTop+LFH-LFH2, PlotML, YTop+LFH+LFH2, \
            fill = Clr["B"])
    if DateFormat == "YYYY:DDD":
        Latest = TheLatestNextTime[:8]
    elif DateFormat == "YYYYMMMDD":
        Parts = TheLatestNextTime.split(":")
        MM, DD = ydoy2md(intt(Parts[0]), intt(Parts[1]))
        Latest = "%s%s%02d"%(Parts[0], m2MMM(MM), DD)
    elif DateFormat == "YYYY-MM-DD":
        Parts = TheLatestNextTime.split(":")
        MM, DD = ydoy2md(intt(Parts[0]), intt(Parts[1]))
        Latest = "%s-%02d-%02d"%(Parts[0], MM, DD)
    canText(LCan, PlotML+PlotW, YTop, "B", Latest, "center")
    LCan.create_line(PlotML+PlotW, YTop+LFH-LFH2, PlotML+PlotW, \
            YTop+LFH+LFH2, fill = Clr["B"])
    YTop += LFH
# +2 to get the next day to plot.
    LastX1 = PlotML
    for i in xrange(PlotEarliestEpoch, PlotLatestEpoch+2, 86400):
        X1 = PlotML+((i-PlotEarliestEpoch)/PlotRange*PlotW)
        if X1 >= LastX1+50:
            LCan.create_line(X1, YTop-LFH2, X1, YTop+LFH2, fill = Clr["B"])
            LastX1 = X1
    YTop += LFH*2.0
    PlotCount = 0
    StationColor = "U"
    LastStation = ""
#    [(0, Filename, SOHStart, SOHEnd), ...]
# For files that have trouble:
#    [(1, Color, Message, Beep), ...]
    for Info in RTIMETimesInfo:
        if Info[RTIME_ERROR] == 0:
# Info = (0, Filespec, SOHStart, SOHEnd)
            Start = Info[RTIME_SOHS]
            End = Info[RTIME_SOHE]
# The file ends before the date limit.
            if End < FromEpoch:
                if DateFormat == "YYYY:DDD":
                    canText(LCan, 5, YTop, "O", \
                            "%s: File ends too early (%s)."% \
                            (Info[RTIME_FILE], epoch2Str(End)))
                elif DateFormat == "YYYYMMMDD":
                    canText(LCan, 5, YTop, "O", \
                            "%s: File ends too early (%s)."% \
                            (Info[RTIME_FILE], ydhms2ymdhms(epoch2Str(End))))
                elif DateFormat == "YYYY-MM-DD":
                    canText(LCan, 5, YTop, "O", \
                            "%s: File ends too early (%s)."% \
                            (Info[RTIME_FILE], \
                            ydhms2ymdhmsDash(epoch2Str(End))))
                elif DateFormat == "":
                    canText(LCan, 5, YTop, "O", \
                            "%s: File ends too early (%s)."%str(End))
# File starts after the date limit.
            elif Start > ToEpoch:
                if DateFormat == "YYYY:DDD":
                    canText(LCan, 5, YTop, "O", \
                            "%s: File starts too late (%s)."% \
                            (Info[RTIME_FILE], epoch2Str(Start)))
                elif DateFormat == "YYYYMMMDD":
                    canText(LCan, 5, YTop, "O", \
                            "%s: File starts too late (%s)."% \
                            (Info[RTIME_FILE], ydhms2ymdhms(epoch2Str(Start))))
                elif DateFormat == "YYYY-MM-DD":
                    canText(LCan, 5, YTop, "O", \
                            "%s: File starts too late (%s)."% \
                            (Info[RTIME_FILE], \
                            ydhms2ymdhmsDash(epoch2Str(Start))))
                elif DateFormat == "":
                    canText(LCan, 5, YTop, "O", \
                            "%s: File starts too late (%s)."%str(Start))
            else:
# File starts before date limit.
                if Start < FromEpoch:
                    Start = FromEpoch
                elif End > ToEpoch:
                    End = ToEpoch
                ID = canText(LCan, 5, YTop, "B", Info[RTIME_FILE])
                LCan.tag_bind(ID, "<Button-3>", Command(formRTIMEPopup, \
                        basename(Info[RTIME_FILE])))
                X1 = PlotML+((Start-PlotEarliestEpoch)/PlotRange*PlotW)
                X2 = PlotML+((End-PlotEarliestEpoch)/PlotRange*PlotW)
# If the file name has a - in it then pretend that the characters before the
# first - is the station name. Alternate plot colors as the station name
# changes.
                if Info[RTIME_FILE].find("-") != -1:
                    Station = Info[RTIME_FILE].split("-")[0]
                    if Station != LastStation:
                        if StationColor == "N":
                            StationColor = "U"
                        elif StationColor == "U":
                            StationColor = "N"
                        LastStation = Station
# Use the file name as the tag then the show routine will just go through the
# Info and find the entry to make the text of the flag.
                ID = LCan.create_rectangle(X1, YTop-LFH4, X2, YTop+LFH4, \
                        fill = Clr[StationColor], \
                        outline = Clr[StationColor], tags = "T"+ \
                        Info[RTIME_FILE])
                LCan.tag_bind(ID, "<Button-1>", Command(formRTIMEShowFlag, \
                        Info[RTIME_FILE]))
        else:
            C = Info[RTIME_COLOR]
            if C[0] == "Y":
                C = "O"
            Msg = Info[RTIME_MSG]
            canText(LCan, 5, YTop, C, Msg)
        YTop += LFH*2.0
        PlotCount += 1
# Date scale every 10 plots.
        if PlotCount%10 == 0:
            if DateFormat == "YYYY:DDD":
                Earliest = TheEarliestTime[:8]
            elif DateFormat == "YYYYMMMDD":
                Parts = TheEarliestTime.split(":")
                MM, DD = ydoy2md(intt(Parts[0]), intt(Parts[1]))
                Earliest = "%s%s%02d"%(Parts[0], m2MMM(MM), DD)
            elif DateFormat == "YYYY-MM-DD":
                Parts = TheEarliestTime.split(":")
                MM, DD = ydoy2md(intt(Parts[0]), intt(Parts[1]))
                Earliest = "%s-%02d-%02d"%(Parts[0], MM, DD)
            canText(LCan, PlotML, YTop, "B", Earliest, "center")
            LCan.create_line(PlotML, YTop+LFH-LFH2, PlotML, YTop+LFH+LFH2, \
                    fill = Clr["B"])
            if DateFormat == "YYYY:DDD":
                Latest = TheLatestNextTime[:8]
            elif DateFormat == "YYYYMMMDD":
                Parts = TheLatestNextTime.split(":")
                MM, DD = ydoy2md(intt(Parts[0]), intt(Parts[1]))
                Latest = "%s%s%02d"%(Parts[0], m2MMM(MM), DD)
            elif DateFormat == "YYYY-MM-DD":
                Parts = TheLatestNextTime.split(":")
                MM, DD = ydoy2md(intt(Parts[0]), intt(Parts[1]))
                Latest = "%s-%02d-%02d"%(Parts[0], MM, DD)
            canText(LCan, PlotML+PlotW, YTop, "B", Latest, "center")
            LCan.create_line(PlotML+PlotW, YTop+LFH-LFH2, PlotML+PlotW, \
                    YTop+LFH+LFH2, fill = Clr["B"])
            YTop += LFH
            LastX1 = PlotML
            for i in xrange(int(PlotEarliestEpoch), int(PlotLatestEpoch+2), \
                    86400):
                X1 = PlotML+((i-PlotEarliestEpoch)/PlotRange*PlotW)
                if X1 >= LastX1+50:
                    LCan.create_line(X1, YTop-LFH2, X1, YTop+LFH2, \
                            fill = Clr["B"])
                    LastX1 = X1
            YTop += LFH*2.0
# Set the scrollregion to encompass all of the items created.
    LCan.configure(scrollregion = (0, 0, CWIDTH, (LCan.bbox(ALL)[3]+5)))
    setMsg("RTIME", "", "Done.")
    formRTIMEControl("stopped")
    return
#########################################
# BEGIN: formRTIMEShowFlag(Tag, e = None)
# FUNC:formRTIMEShowFlag():2010.195
def formRTIMEShowFlag(Tag, e = None):
    LCan = Can["RTIME"]
    Cx = LCan.canvasx(e.x)
    Cy = LCan.canvasy(e.y)
# If there already is a flag for this item then turn it off.
    LCan.delete(Tag)
    DateFormat = OPTDateFormatRVar.get()
# Make the text of the flag. Just brute force the way through the file info.
    for Info in RTIMETimesInfo:
        if Info[RTIME_FILE].endswith(Tag):
# The text has to be made before the box so we know how big to make the box.
            TLength = Info[RTIME_SOHE]-Info[RTIME_SOHS]
            if DateFormat == "YYYY:DDD":
                Start = epoch2Str(Info[RTIME_SOHS])
                End = epoch2Str(Info[RTIME_SOHE])
            elif DateFormat == "YYYYMMMDD":
                Start = ydhms2ymdhms(epoch2Str(Info[RTIME_SOHS]))
                End = ydhms2ymdhms(epoch2Str(Info[RTIME_SOHE]))
            elif DateFormat == "YYYY-MM-DD":
                Start = ydhms2ymdhmsDash(epoch2Str(Info[RTIME_SOHS]))
                End = ydhms2ymdhmsDash(epoch2Str(Info[RTIME_SOHE]))
            elif DateFormat == "":
                Start = str(Info[RTIME_SOHS])
                End = str(Info[RTIME_SOHE])
            ID = LCan.create_text(Cx, Cy, \
            text = " %s \n Start: %s \n End: %s \n (%.2f days, %.2f hours) "% \
                    (Info[RTIME_FILE], Start, End, TLength/86400.0, \
                    TLength/3600.0), font = PROGLabelFont, fill = Clr["B"], \
                    justify = CENTER, anchor = "s", tags = Tag)
            break
# Check where the text is going to be and move it if it is going to be off the
# top or right edge of the canvas (it can't be off the other two).
    L, T, R, B = LCan.bbox(ID)
    Ww = LCan.winfo_width()
    Corr = "s"
    if T < 5:
        Corr = "n"
    if R > (Ww-5):
        Corr += "e"
# If it is other than the default move it and get the coordinates again for
# the box.
    if Corr != "s":
        LCan.itemconfigure(ID, anchor = Corr)
        L, T, R, B = LCan.bbox(ID)
# Naturally, the box needs to be ONE PIXEL taller to make it look right and one
# pixel longer to clear the ()'s.
    ID2 = LCan.create_rectangle((L, T-1, R, B+1), fill = Clr["E"], \
           outline = Clr["B"], tags = Tag)
# Since the text was made first we now have to raise it above the box.
    LCan.tag_raise(ID, ID2)
# The user might click on the text or the background so do both.
    LCan.tag_bind(ID, "<Button-1>", Command(formRTIMEFlagOff, Tag))
    LCan.tag_bind(ID2, "<Button-1>", Command(formRTIMEFlagOff, Tag))
    return
########################################
# BEGIN: formRTIMEFlagOff(Tag, e = None)
# FUNC:formRTIMEFlagOff():2008.093
def formRTIMEFlagOff(Tag, e = None):
    Can["RTIME"].delete(Tag)
    return
#####################################
# BEGIN: formRTIMEpopDirFID(e = None)
# FUNC:formRTIMEpopDirFID():2010.174
#   Just for LOGPEEK which always keeps everything set to the same thing.
def formRTIMEpopDirFID(e = None):
    popDirFID("RTIME", "thedata", PROGDataDirVar)
    PROGMsgsDirVar.set(PROGDataDirVar.get())
    PROGWorkDirVar.set(PROGDataDirVar.get())
    return
###########################################
# BEGIN: formRTIMEPopup(Filespec, e = None)
# FUNC:formRTIMEPopup():2010.247
def formRTIMEPopup(File, e = None):
    Xx = Root.winfo_pointerx()
    Yy = Root.winfo_pointery()
    PMenu = Menu(Can["RTIME"], tearoff = 0, bg = Clr["D"])
    PMenu.add_command(label = "Plot This File", \
            command = Command(formRTIMEPlotMain, File))
    PMenu.tk_popup(Xx, Yy)
    return
####################################
# BEGIN: formRTIMEPlotMain(Filespec)
# FUNC:formRTIMEPlotMain():2010.252
#   Lets the user click on a plotted file's name and gets that file read and
#   plotted in the main display.
def formRTIMEPlotMain(File):
    setMsg("RTIME", "", "")
# The file has to appear in the current mail list of files.
    for Index in xrange(0, MFFiles.size()):
        MFFile = MFFiles.get(Index)
        if MFFile.startswith(File):
            MFFiles.selection_clear(0, END)
            MFFiles.selection_set(Index)
            fileSelected()
    return
##########################
# BEGIN: formRTIMERename()
# FUNC:formRTIMERename():2010.282
def formRTIMERename():
    if RTIMERunning.get() == 1:
        setMsg("RTIME", "YB", "I'm busy...", 2)
        sleep(.5)
        return
    LCan = Can["RTIME"]
    LCan.delete(ALL)
    LCan.yview_moveto(0.0)
    GY = PROGLabelFontHeight
    updateMe(0)
    setMsg("RTIME", "", "")
    Answer = formMYD("RTIME", (("Continue", LEFT, "cont"), ("Cancel", LEFT, \
            "cancel")), "cancel", "WB", "A Rose By Any Other Name...", \
            "This will rename the selected files so the names include the start date (YYYYDDD) of the file and the DAS ID number.\n\nThe current file names must fit a certain pattern for this to work well. READ THE HELP.\n\nDo you want to continue or cancel?")
    if Answer == "cancel":
        setMsg("RTIME", "", "Nothing done.")
        return
    Sel = RTIMEFiles.curselection()
    if len(Sel) == 0:
        setMsg("RTIME", "RW", "No files have been selected.", 2)
        return
    SelCount = len(Sel)
    formRTIMEControl("go")
    RenamedCount = 0
    FileCount = 0
    for Index in Sel:
        if RTIMERunning.get() == 0:
            setMsg("RTIME", "YB", "Stopped.", 2)
            formRTIMEControl("stopped")
            return
        Selected = RTIMEFiles.get(Index)
# Skip over the blank lines.
        if Selected == "":
            SelCount -= 1
# Clear the selections as we go.
            RTIMEFiles.selection_clear(Index)
            continue
        FileCount += 1
        setMsg("RTIME", "CB", "Working on file %d of %d..."%(FileCount, \
                SelCount))
# The entry will probably be something like "Filename (x bytes or lines)" so
# just get the Filename.
        Parts = Selected.split()
        Filename = Parts[0]
        FilenameUC = Filename.upper()
        Filespec = "%s%s"%(PROGDataDirVar.get(), Filename)
        FilespecUC = Filespec.upper()
# This check is a little complicated because of the way .cf's are listed in
# the Listbox (e.g. 9BA6.cf/9BA6).
        try:
            I = FilespecUC.index(".CF"+sep)
            Filecheck = Filespec[:I+3]
            if exists(Filecheck) == False:
                setMsg("RTIME", "RW", \
                       "%s: .cf directory not found. Use the Reload button?"% \
                        Filename, 2)
                formRTIMEControl("stopped")
                return
        except ValueError:
            if exists(Filespec) == False:
                setMsg("RTIME", "RW", \
                       "%s: File not found. Use the Reload button?"%Filename, \
                        2)
                formRTIMEControl("stopped")
                return
        ErrFileExists = False
        if FilenameUC.endswith(".LOG"):
# Ret will be (x, File, Earliest, Latest, DAS ID).
            Ret = rt72130logTimeRange(Filespec, "", RTIMEStopBut, \
                    RTIMERunning)
# WARNING: This will only detect .err files where the .err is all upper or
# lower case.
            ErrFilespec = Filespec[:-4]+".err"
            if exists(ErrFilespec):
                ErrFileExists = True
            else:
                ErrFilespec = Filespec[:-4]+".ERR"
                if exists(ErrFilespec):
                    ErrFileExists = True
        elif FilenameUC.endswith(".REF"):
            Ret = rt72130refTimeRange(Filespec, RTIMEStopBut, RTIMERunning)
# Look for these before .cf's since the names may be like 123456.cf.zip.
        elif FilenameUC.endswith(".ZIP"):
            Ret = rt130zcfTimeRange(Filespec, RTIMEStopBut, RTIMERunning, \
                    "RTIME")
        elif FilenameUC.find(".CF") != -1:
            Ret = rt130cfTimeRange(Filespec, RTIMEStopBut, RTIMERunning, \
                    "RTIME")
# These will be <path>/file/DAS, so we just want the <path>/file from here on.
            Filespec = dirname(Filespec)
# I think dirname returns a sep at the end on some systems/versions.
            if Filespec.endswith(sep):
                Filespec = Filespec[:-1]
# If anything is wrong with a file print the error message and stop to let the
# user decide what to do.
        if Ret[0] != 0:
            setMsg("RTIME", Ret[1], Ret[2], Ret[3])
            formRTIMEControl("stopped")
            return
# Ret will be
#    (0, Filename, SOHStart, SOHEnd, DASID)
        Time = epoch2Str(Ret[2])
        YD = "%s%s"%(Time[:4], Time[5:5+3])
        DASID = Ret[4]
# Get everything from the original Filespec.
        Dir = dirname(Filespec)
        if Dir.endswith(sep) == False:
            Dir += sep
# The file name will be all upper case when we finish renaming.
        File = basename(Filespec).upper()
        Parts = File.split("-")
# Figure out what the extension is.
        if File.endswith(".LOG"):
            Extension = ".LOG"
        elif File.endswith(".REF"):
            Extension = ".REF"
        elif File.endswith(".CF.ZIP"):
            Extension = ".CF.ZIP"
        elif File.endswith(".CF"):
            Extension = ".CF"
        else:
            setMsg("RTIME", "RW", \
                    "File extensions must be .LOG, .REF, .CF.ZIP or .CF", 2)
            return
# Now get rid of the extension on the last part.
        Parts[-1] = Parts[-1].replace(Extension, "")
# SSSS.cf -> SSSS-YYYYDDD-DDDD.CF or DDDD.CF -> YYYYDDD-DDDD.CF
# Check the one item. If it is not the DASID then keep it. It might be the
# station ID.
        if len(Parts) == 1:
            if Parts[0] != DASID:
                NewFilespec = "%s%s-%s-%s%s"%(Dir, Parts[0], YD, DASID, \
                        Extension)
                if ErrFileExists == True:
                    NewErrFilespec = "%s%s-%s-%s.ERR"%(Dir, Parts[0], YD, \
                            DASID)
            else:
                NewFilespec = "%s%s-%s%s"%(Dir, YD, DASID, Extension)
                if ErrFileExists == True:
                    NewErrFilespec = "%s%s-%s.ERR"%(Dir, YD, DASID)
# SSSSS-ZZZZZ....cf -> SSSSS-YYYYDDD-DDDD.CF
# Keep the first part and throw out everything else.
        else:
            NewFilespec = "%s%s-%s-%s%s"%(Dir, Parts[0], YD, DASID, Extension)
            if ErrFileExists == True:
                NewErrFilespec = "%s%s-%s-%s.ERR"%(Dir, Parts[0], YD, DASID)
# If it has already been done...maybe.
        if NewFilespec == Filespec:
            LCan.create_text(10, GY, anchor = "w", font = PROGLabelFont, \
                    text = "%d. %s -> %s (already done?)"%(FileCount, \
                    basename(Filespec), basename(NewFilespec)), \
                    fill = Clr["B"])
            GY += PROGLabelFontHeight
            RTIMEFiles.selection_clear(Index)
            RenamedCount += 1
            continue
# We may be renaming into a file that already exists.
        if exists(NewFilespec):
            setMsg("RTIME", "YB", "This file already exists\n   %s"% \
                    NewFilespec, 2)
            formRTIMEControl("stopped")
            return
        try:
            renames(Filespec, NewFilespec)
        except Exception, e:
            setMsg("RTIME", "MW", "Error while renaming file %s\n   %s"% \
                    (basename(Filespec), e), 3)
            formRTIMEControl("stopped")
            return
        if ErrFileExists == True:
            try:
                renames(ErrFilespec, NewErrFilespec)
            except Exception, e:
                setMsg("RTIME", "MW", \
                        "Error while renaming .err file %s\n   %s"% \
                        (basename(ErrFilespec), e), 3)
                formRTIMEControl("stopped")
                return
        LCan.create_text(10, GY, anchor = "w", font = PROGLabelFont, \
                text = "%d. %s -> %s"%(FileCount, basename(Filespec), \
                basename(NewFilespec)), fill = Clr["B"])
        GY += PROGLabelFontHeight
        L, T, R, B = LCan.bbox(ALL)
        LCan.configure(scrollregion = (0, 0, R, (B+15)))
        updateMe(0)
        RTIMEFiles.selection_clear(Index)
        RenamedCount += 1
    setMsg("RTIME", "", \
            "Renamed %d of %d. Don't forget to Reload the file list."% \
            (RenamedCount, SelCount))
    formRTIMEControl("stopped")
    return
########################
# BEGIN: formRTIMESort()
# FUNC:formRTIMESort():2010.195
#   Sorts the entires in the Listbox alphbetically.
def formRTIMESort():
    Items = []
    for I in xrange(0, RTIMEFiles.size()):
        Item = RTIMEFiles.get(I)
        if Item != "":
            Items.append(Item)
    Items.sort()
    RTIMEFiles.delete(0, END)
    for Item in Items:
        RTIMEFiles.insert(END, Item)
    return
##########################################
# BEGIN: formRTIMEControl(Which, e = None)
# FUNC:formRTIMEControl():2010.201
def formRTIMEControl(Which, e = None):
    global RTIMETimesInfo
    if Which == "go":
        Frm["RTIME"].focus_set()
        buttonBG(RTIMEReadBut, "G")
        buttonBG(RTIMEStopBut, "R", NORMAL)
        RTIMERunning.set(1)
        return (0, )
    elif Which == "stopping":
        buttonBG(RTIMEStopBut, "Y")
    elif Which == "stopped":
        buttonBG(RTIMEReadBut, "D")
        buttonBG(RTIMEStopBut, "D", DISABLED)
    elif Which == "close":
        if RTIMERunning.get() == 1:
            beep(2)
            return (1, "YB", \
                    "Plot Time Ranges Of Sources cannot be closed.", 2)
        RTIMETimesInfo = []
        closeForm("RTIME")
    RTIMERunning.set(0)
    return (0, )
# END: formRTIME




#####################
# BEGIN: formSEARCH()
# FUNC:formSEARCH():2010.212
Frm["SEARCH"] = None
Txt["SEARCH"] = None
Msg["SEARCH"] = None

def formSEARCH():
    if MFGraphed == False:
        beep(1)
        return
    if Frm["SEARCH"] != None:
        Frm["SEARCH"].deiconify()
        Frm["SEARCH"].lift()
        return
# Create the window and put it in the middle of the screen
    LFrm = Frm["SEARCH"] = Toplevel(Root)
    LFrm.withdraw()
    LFrm.title("Log Search")
    LFrm.protocol("WM_DELETE_WINDOW", Command(closeForm, "SEARCH"))
# Where the user will enter the search string
    LEnt = Ent["SEARCH"] = Entry(LFrm, textvariable = SearchVar)
    LEnt.pack(side = TOP, fill = X)
    LEnt.bind('<Return>', formSEARCHReturn)
    LEnt.bind("<Double-Button-1>", Command(formKB, Frm["SEARCH"], \
            "Search For", SearchVar))
    LEnt.focus_set()
    LEnt.icursor(END)
# Where the search results will be
    Sub = Frame(LFrm)
    Txt["SEARCH"] = Text(Sub, width = 80, height = 20, wrap = NONE, \
             relief = SUNKEN)
    Txt["SEARCH"].pack(side = LEFT, expand = YES, fill = BOTH)
    Scroll = Scrollbar(Sub, orient = VERTICAL, command = Txt["SEARCH"].yview)
    Scroll.pack(side = RIGHT, fill = Y)
    Txt["SEARCH"].configure(yscrollcommand = Scroll.set)
    Sub.pack(side = TOP, fill = BOTH, expand = YES)
    Sub = Frame(LFrm)
    BButton(Sub, text = "Close", fg = Clr["R"], command = Command(closeForm, \
            "SEARCH")).pack(side = LEFT)
    Sub.pack(side = TOP, padx = 3, pady = 3)
# Status messages
    Msg["SEARCH"] = Text(LFrm, font = PROGMsgFont, height = 1)
    Msg["SEARCH"].pack(side = TOP, fill = X)
    setMsg("SEARCH", "WB", \
            "Enter what to search for in the field at the top of the window.")
    center(Root, "SEARCH", "C", "I", True)
    return
############################
# BEGIN: formSEARCHReturn(e)
# FUNC:formSEARCHReturn():2008.285
def formSEARCHReturn(e):
    Txt["SEARCH"].delete(0.0, END)
    updateMe(0)
    LookFor = SearchVar.get().lower()
    setMsg("SEARCH", "CB", "Searching...")
    busyCursor(1)
    Found = 0
    for Line in LOGLines:
        LLine = Line.lower()
        if LLine.find(LookFor) != -1:
            Txt["SEARCH"].insert(END, Line+"\n")
            Found += 1
    if Found == 0:
        setMsg("SEARCH", "WB", "No matches found.")
    elif Found == 1:
        setMsg("SEARCH", "WB", str(Found)+" matching line found.")
    else:
        setMsg("SEARCH", "WB", str(Found)+" matching lines found.")
    busyCursor(0)
    return
# END: formSEARCH




#################
# BEGIN: m2MMM(m)
# LIB:m2MMM():2010.239
def m2MMM(m):
    try:
        M = int(m)
    except:
        return "ERR"
    if M == 1:
        return "JAN"
    elif M == 2:
        return "FEB"
    elif M == 3:
        return "MAR"
    elif M == 4:
        return "APR"
    elif M == 5:
        return "MAY"
    elif M == 6:
        return "JUN"
    elif M == 7:
        return "JUL"
    elif M == 8:
        return "AUG"
    elif M == 9:
        return "SEP"
    elif M == 10:
        return "OCT"
    elif M == 11:
        return "NOV"
    elif M == 12:
        return "DEC"
    return "ERR"
#################
# BEGIN: MMM2m(M)
# FUNC:MMM2m():2010.239
def MMM2m(M):
    M = M.upper()
    if M.startswith("JAN"):
        return 1
    elif M.startswith("FEB"):
        return 2
    elif M.startswith("MAR"):
        return 3
    elif M.startswith("APR"):
        return 4
    elif M.startswith("MAY"):
        return 5
    elif M.startswith("JUN"):
        return 6
    elif M.startswith("JUL"):
        return 7
    elif M.startswith("AUG"):
        return 8
    elif M.startswith("SEP"):
        return 9
    elif M.startswith("OCT"):
        return 10
    elif M.startswith("NOV"):
        return 11
    elif M.startswith("DEC"):
        return 12
    return 0
# END: m2MMM




##########################
# BEGIN: progControl(What)
# FUNC:progControl():2008.145
def progControl(What):
    if What == "go":
        buttonBG(PROGReadBut, "G", NORMAL)
        buttonBG(PROGStopBut, "R", NORMAL)
        PROGRunning.set(1)
        busyCursor(1)
        return
    elif What == "gozoom":
        buttonBG(PROGStopBut, "R", NORMAL)
        PROGRunning.set(1)
        busyCursor(1)
        return
    elif What == "stop":
        if PROGRunning.get() == 0:
            beep(1)
        else:
            buttonBG(PROGStopBut, "Y", NORMAL)
    elif What == "stopped":
        buttonBG(PROGReadBut, "D", NORMAL)
        buttonBG(PROGStopBut, "D", DISABLED)
    PROGRunning.set(0)
    busyCursor(0)
    return
# END: progControl




#####################
# BEGIN: pushBrowse()
# FUNC:pushBrowse():2010.251
#  Needed to handle the Browse button press.
def pushBrowse():
    setMsg("MF", "", "")
    Answer = formMYDF(Root, 2, "Pick A Directory...", PROGDataDirVar.get(), "")
    if Answer != "":
# Clears the screen off and sets things up for the next graph.
        plotMFClear("all")
        plotRAWClear()
        plotTPSClear()
        PROGDataDirVar.set(Answer)
# Keeping them in sync.
        PROGMsgsDirVar.set(Answer)
        PROGWorkDirVar.set(Answer)
        loadRTFilesCmd(MFFiles, "MF")
        Ent["DATA"].icursor(END)
    return
# END: pushBrowse




#########################
# BEGIN: returnReadDir(e)
# FUNC:returnReadDir():2010.251
#   Needed to handle the Return key press in the CWD field.
def returnReadDir(e):
    setMsg("MF", "", "")
    PROGDataDirVar.set(PROGDataDirVar.get().strip())
    if PROGDataDirVar.get() == "":
        if PROGSystem == "dar" or PROGSystem == "lin" or PROGSystem == "sun":
            PROGDataDirVar.set(sep)
        elif PROGSystem == "win":
# For a lack of anyplace else.
            PROGDataDirVar.set("C:\\")
    if PROGDataDirVar.get().endswith(sep) == False:
        PROGDataDirVar.set(PROGDataDirVar.get()+sep)
# Sync sync sync.
    PROGMsgsDirVar.set(PROGDataDirVar.get())
    PROGWorkDirVar.set(PROGDataDirVar.get())
    plotMFClear("all")
    plotRAWClear()
    plotTPSClear()
    loadRTFilesCmd(MFFiles, "MF")
    Ent["DATA"].icursor(END)
    return
# END: returnReadDir




# ============================================
# BEGIN: =============== SETUP ===============
# ============================================


######################
# BEGIN: menuMake(Win)
# FUNC:makeMenu():2010.249
OPTIgTECVar = IntVar()
OPTIgTECVar.set(0)
OPTAddMPMsgsCVar = IntVar()
OPTDateFormatRVar = StringVar()
OPTDateFormatRVar.set("YYYY:DDD")
OPTQLogCVar = IntVar()
PROGSetups += ("OPTIgTECVar", "OPTAddMPMsgsCVar", "OPTDateFormatRVar", \
        "OPTQLogCVar")
MENUMenus = {}

def menuMake(Win):
    global MENUMenus
    MENUMenus.clear()
    Top = Menu(Win)
    Win.configure(menu = Top)
    Fi = Menu(Top, tearoff = 0)
    MENUMenus["File"] = Fi
    Top.add_cascade(label = "File", menu = Fi, font = PROGCascadeFont)
    Fi.add_command(label = "Delete Setups File", command = deletePROGSetups)
    Fi.add_separator()
    Fi.add_command(label = "Quit", command = Command(progQuitter, True))
    Co = Menu(Top, tearoff = 0)
    MENUMenus["Commands"] = Co
    Top.add_cascade(label = "Commands", menu = Co, font = PROGCascadeFont)
    Co.add_command(label = "GPS Information", command = formGPS)
    Co.add_command(label = "Log Search", command = formSEARCH)
    Co.add_command(label = "Plot Time Ranges Of Sources", \
            command = Command(formRTIME, Root))
    Co.add_separator()
    Co.add_command(label = "Export TT Times For RAWMEET (Line Format)", \
            command = Command(exportTT, "depl"))
    Co.add_command(label = "Export TT Times For RAWMEET (Block Format)", \
            command = Command(exportTT, "depb"))
    Co.add_command(label = "Export TT Times For TSP", \
            command = Command(exportTT, "tsp"))
    Co.add_command(label = "Export TT Times As YYYY:DDD:HH:MM:SS", \
            command = Command(exportTT, "ydhms"))
    Gr = Menu(Top, tearoff = 0)
    MENUMenus["Plots"] = Gr
    Top.add_cascade(label = "Plots", menu = Gr, font = PROGCascadeFont)
    Gr.add_checkbutton(label = "DSP-Clk Difference", \
            variable = DGrf["DCDIFF"], command = reconfigDisplay)
    Gr.add_checkbutton(label = "Phase Error", variable = DGrf["ICPE"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Jerk/DSP Sets", variable = DGrf["JERK"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Errors", variable = DGrf["ERR"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "GPS On-Off", variable = DGrf["GPSON"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "GPS Lk-Unlk", variable = DGrf["GPSLK"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Temperature", variable = DGrf["TEMP"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Volts", variable = DGrf["VOLT"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Backup Volts", variable = DGrf["BKUP"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Dump Call", variable = DGrf["DUMP"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Acquisition On-Off", variable = DGrf["ACQ"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Reset/Powerup", variable = DGrf["RESET"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Error/Warning", variable = DGrf["ERRWARN"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Discrepancies", variable = DGrf["DISCREP"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "SOH/Data Definitions", \
            variable = DGrf["SOHDEF"], command = reconfigDisplay)
    Gr.add_checkbutton(label = "Network Up-Down", variable = DGrf["NET"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Events", variable = DGrf["EVT"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Re-center", variable = DGrf["MRC"], \
            command = reconfigDisplay)
    Gr.add_checkbutton(label = "Mass Positions 123", \
            variable = DGrf["MP123"], command = reconfigDisplay)
    Gr.add_checkbutton(label = "Mass Positions 456", \
            variable = DGrf["MP456"], command = reconfigDisplay)
    Gr.add_separator()
    Gr.add_command(label = "All Plots On", command = allPlotsOn)
    Op = Menu(Top, tearoff = 0)
    MENUMenus["Options"] = Op
    Top.add_cascade(label = "Options", menu = Op, font = PROGCascadeFont)
    Op.add_checkbutton(label = "Ignore Timing Errors", \
            variable = OPTIgTECVar, command = fileSelected)
    Op.add_separator()
    Op.add_checkbutton(label = "Add Mass Position Messages", \
            variable = OPTAddMPMsgsCVar)
    Op.add_separator()
    Op.add_checkbutton(label = "Read qlog-ref2mseed Output Files", \
            variable = OPTQLogCVar)
    Op.add_separator()
    Op.add_radiobutton(label = "Show YYYY:DDD Dates", \
            command = changeDateFormat, variable = OPTDateFormatRVar, \
            value = "YYYY:DDD")
    Op.add_radiobutton(label = "Show YYYYMMMDD Dates", \
            command = changeDateFormat, variable = OPTDateFormatRVar, \
            value = "YYYYMMMDD")
    Op.add_radiobutton(label = "Show YYYY-MM-DD Dates", \
            command = changeDateFormat, variable = OPTDateFormatRVar, \
            value = "YYYY-MM-DD")
    Fo = Menu(Top, tearoff = 0, postcommand = menuMakeForms)
    MENUMenus["Forms"] = Fo
    Top.add_cascade(label = "Forms", menu = Fo, font = PROGCascadeFont)
    Hp = Menu(Top, tearoff = 0)
    MENUMenus["Help"] = Hp
    Top.add_cascade(label = "Help", menu = Hp, font = PROGCascadeFont)
    Hp.add_command(label = "Help", command = Command(formHELP, Root))
    Hp.add_command(label = "Calendar", command = Command(formCAL, Root))
    Hp.add_command(label = "Check For Updates", command = checkForUpdates)
    Hp.add_command(label = "About", command = about)
    return
###############################################
# BEGIN: menuMakeSet(MenuText, ItemText, State)
# FUNC:menuMakeSet():2010.202
def menuMakeSet(MenuText, ItemText, State):
    Found = False
    try:
        Menu = MENUMenus[MenuText]
        for Item in range(Menu.index("end")+1):
            Type = Menu.type(Item)
            if Type in ("tearoff", "separator"):
                continue
            if Menu.entrycget(Item, "label") == ItemText:
                Found = True
                Menu.entryconfigure(Item, state = State)
                break
# Just in case. This should never go off if I've done my job.
    except:
        print("menuMakeSet: %s, %s\a"%(MenuText, ItemText))
    return
################################
# BEGIN: menuMakeForms(e = None)
# FUNC:menuMakeForms():2010.249
def menuMakeForms(e = None):
    FMenu = MENUMenus["Forms"]
    FMenu.delete(0, END)
# Build the list of forms so they can be sorted alphabetically.
    Forms = []
    for Frmm in Frm.keys():
        try:
            if Frm[Frmm] != None:
                Forms.append([Frm[Frmm].title(), Frmm])
        except TclError:
            print Frmm
            closeForm(Frmm)
    if len(Forms) == 0:
        FMenu.add_command(label = "No Forms Are Open")
    else:
        Forms.sort()
        for Title, Frmm in Forms:
            FMenu.add_command(label = Title, command = Command(showUp, Frmm))
        FMenu.add_separator()
        FMenu.add_command(label = "Close All Forms", command = closeFormAll)
    return
# END: menuMake




###############
# BEGIN: main()
# FUNC:main():2010.249
PROGMsgsDirVar = StringVar()
PROGDataDirVar = StringVar()
PROGWorkDirVar = StringVar()
PROGWhoAmILCVar = StringVar()
PROGWhoAmIUCVar = StringVar()
PROGSetups += ("PROGMsgsDirVar", "PROGDataDirVar", "PROGWorkDirVar", \
        "PROGWhoAmILCVar", "PROGWhoAmIUCVar")
# These are linked to the Graph menu checkbuttons.
DGrf = {"DCDIFF":IntVar(), "ICPE":IntVar(), "JERK":IntVar(), \
        "GPSON":IntVar(), "GPSLK":IntVar(), "CLKPWR":IntVar(), \
        "DUMP":IntVar(), "EVT":IntVar(), "TEMP":IntVar(), "VOLT":IntVar(), \
        "BKUP":IntVar(), "MP123":IntVar(), "MP456":IntVar(), "ERR":IntVar(), \
        "RESET":IntVar(), "MRC":IntVar(), "DISCREP":IntVar(), \
        "ERRWARN":IntVar(), "ACQ":IntVar(), "SOHDEF":IntVar(), "NET":IntVar()}
# These are the relative "weights" given to each graph that controls how much
# of the total graph space each graph will receive. Graphs that show states
# like "on/off" should have a minimum weight of 2, single item graphs 1, and
# graphs that actually plot varing things like voltages 3 or above.
# These will be totaled up and then divied by that total, so they don't have
# to add up to 100 (like percent) or anything. The total will be based on
# which graphs the user wants to plot according to selections in the Graphs
# menu..
DPlotWts = {"DCDIFF":5, "ICPE":5, "JERK":2, "GPSON":2, "GPSLK":3, "CLKPWR":1, \
        "DUMP":2, "EVT":1, "TEMP":3, "VOLT":3, "BKUP":1, "MP123":1, \
        "MP456":1, "ERR":1, "RESET":2, "MRC":1, "DISCREP":1, "ERRWARN":2, \
        "ACQ":2, "SOHDEF":2, "NET":2}
SearchVar = StringVar()
FromDateVar = StringVar()
ToDateVar = StringVar()
MFShowLogsCVar = IntVar()
MFShowLogsCVar.set(1)
MFShowRefsCVar = IntVar()
MFShowRefsCVar.set(1)
MFShowZCFCVar = IntVar()
MFShowZCFCVar.set(1)
MFShowUCFDCVar = IntVar()
MFShowUCFDCVar.set(1)
LOGLastFilespecVar = StringVar()
LastMFPSFilespecVar = StringVar()
LastRAWPSFilespecVar = StringVar()
LastTPSPSFilespecVar = StringVar()
OPTIncNonSOHCVar = IntVar()
Stream1Var = IntVar()
Stream2Var = IntVar()
Stream3Var = IntVar()
Stream4Var = IntVar()
Stream5Var = IntVar()
Stream6Var = IntVar()
Stream7Var = IntVar()
Stream8Var = IntVar()
OPTPlotRAWCVar = IntVar()
OPTPlotTPSCVar = IntVar()
PROGSetups += ("SearchVar", "FromDateVar", "ToDateVar", "MFShowLogsCVar", \
        "MFShowRefsCVar", "MFShowZCFCVar", "MFShowUCFDCVar", \
        "LOGLastFilespecVar", "LastMFPSFilespecVar", "LastRAWPSFilespecVar", \
        "LastTPSPSFilespecVar", "OPTIncNonSOHCVar", "Stream1Var", \
        "Stream2Var", "Stream3Var", "Stream4Var", "Stream5Var", \
        "Stream6Var", "Stream7Var", "Stream8Var", "OPTPlotRAWCVar", \
        "OPTPlotTPSCVar")
GFontH12 = GFontH/2
FirstSelRule = None
FirstSelRuleX = 0
SecondSelRule = None
SecondSelRuleX = 0
MFTKGraph = None
MFTimeMode = ""
MFZapped = 0
PROGRunning = IntVar()
StartEndRecord = []
MFGraphed = False
FStart = 0.0
FEnd = 0.0
# The current start and end times of the main plot display.
CurMainStart = 0.0
CurMainEnd = 0.0
RTModel = "72A"
MainFilename = ""
MainFilespec = ""
# All of the lists where data points end up being kept.
ACQ = []
ACQxy = []
BKUP = []
BKUPxy = []
CLKPWR = []
CLKPWRxy = []
DCDIFF = []
DCDIFFxy = []
DEFS = []
DEFSxy = []
DISCREP = []
DISCREPxy = []
# DSP resets use JERK
DRSETxy = []
DUMP = []
DUMPxy = []
ERROR = []
ERRORxy = []
EVT = []
EVTxy = []
GPOSd = []
GPOSr = []
GPOSe = []
GPS = []
GPSxy = []
GPSLK = []
GPSLKxy = []
ICPE = []
ICPExy = []
JERK = []
JERKxy = []
MP1 = []
MP1xy = []
MP2 = []
MP2xy = []
MP3 = []
MP3xy = []
MP4 = []
MP4xy = []
MP5 = []
MP5xy = []
MP6 = []
MP6xy = []
MRC = []
MRCxy = []
NET = []
NETxy = []
PWRUP = []
PWRUPxy = []
RESET = []
RESETxy = []
SOH = []
SOHxy = []
TEMP = []
TEMPxy = []
TMJMP = []
TMJMPxy = []
VOLT = []
VOLTxy = []
WARN = []
WARNxy = []
allPlotsOn()
# Start creating the display.
Root.title(PROG_NAME+" - "+PROG_VERSION)
Root.protocol("WM_DELETE_WINDOW", Command(progQuitter, True))
menuMake(Root)
# If I don't create a sub-frame of Root resizing the main window causes a lot
# of graph updates to be caught and executed causing the graph to be redrawn
# a number of times before reaching the new size of the window (on some OS's
# and setups)..
SubRoot = Frame(Root)
SubRoot.pack(fill = BOTH, expand = YES)
# ----- Current directory area -----
Sub = Frame(SubRoot)
BButton(Sub, text = "Browse", command = pushBrowse).pack(side = LEFT)
#BButton(Sub, text = "Read Directory", command = pushReadDir).pack(side = LEFT)
LEnt = Ent["DATA"] = Entry(Sub, textvariable = PROGDataDirVar)
LEnt.pack(side = LEFT, fill = X, expand = YES)
compFsSetup(Root, LEnt, PROGDataDirVar, None, "MF")
LEnt.bind('<Return>', returnReadDir)
LEnt.bind("<Double-Button-1>", Command(formKB, Root, "Directory", \
        PROGDataDirVar))
Lb = Label(Sub, text = "From:")
Lb.pack(side = LEFT)
ToolTip(Lb, 30, \
        "Fill in the 'From' and 'To' fields to the right with start and end dates to display.")
Entry(Sub, width = 11, textvariable = FromDateVar).pack(side = LEFT)
BButton(Sub, text = "C", command = Command(formPCAL, Root, "C", "MF", \
        FromDateVar, False, OPTDateFormatRVar)).pack(side = LEFT)
Label(Sub, text = " To ").pack(side = LEFT)
Entry(Sub, width = 11, textvariable = ToDateVar).pack(side = LEFT)
BButton(Sub, text = "C", command = Command(formPCAL, Root, "C", "MF", \
        ToDateVar, False, OPTDateFormatRVar)).pack(side = LEFT)
LLb = Label(Sub, text = "Hints")
LLb.pack(side = LEFT)
ToolTip(LLb, 45, \
        "GRAPH AREA HINTS:\n--Shift-click: Shift-clicking in the graphing area the first time will display a vertical selection rule at that point. Shift-clicking again will display a second selection rule at the new point, then LOGPEEK will zoom in on the area selected. Shift-clicking in the area of the graph labels when the first selection rule is visible will cancel the selection operation.\n--Shift-click on labels: If zoomed in (described above) shift-clicking in the area of the graph labels will zoom back out. Each step when zooming in will be repeated when zooming out.\n--Clicking on a point: Clicking on a graph point will bring up the SOH Messages window and highlight the line in the log messages that go with the point that was clicked.\n--Clicking on times: Clicking in the left side of the area at the bottom of the graphing area where the X-axis dates/times are located will 'scroll' the display earlier in time, and clicking on the right side will 'scroll' the display forward in time, but only if the display is zoomed in.\n--Control-click on times: Control-clicking in the area at the bottom of the graphs where the date/times are located will extend the X-axis tick marks to the top of the graphing area.\n--Right-click on dots: Right-clicking on a dot will 'zap' that dot and redraw the graphs without it. The only way to recover them is to re-read the source file.")
Sub.pack(side = TOP, fill = X, expand = NO, padx = 3)
# Files list and graphing area.
Sub = Frame(SubRoot)
# ----- File list, scroll bar and text area -----
SSub = Frame(Sub)
# ----- File list and the scroll bars -----
SSSub = Frame(SSub)
if PROGMultiMode == False:
    MFFiles = Listbox(SSSub, relief = SUNKEN, bd = 2, width = 25, height = 1, \
            selectmode = SINGLE)
else:
    MFFiles = Listbox(SSSub, relief = SUNKEN, bd = 2, width = 25, height = 1, \
            selectmode = EXTENDED)
MFFiles.pack(side = LEFT, fill = Y, expand = YES)
MFFiles.bind("<Double-Button-1>", fileSelected)
LSb = Scrollbar(SSSub, command = MFFiles.yview)
LSb.pack(side = RIGHT, fill = Y, expand = YES)
MFFiles.configure(yscrollcommand = LSb.set)
SSSub.pack(side = TOP, fill = Y, expand = YES)
SSSub = Frame(SSub)
LSb = Scrollbar(SSSub, command = MFFiles.xview, orient = HORIZONTAL)
LSb.pack(side = BOTTOM, fill = X, expand = YES)
MFFiles.configure(xscrollcommand = LSb.set)
SSSub.pack(side = TOP, fill = X, expand = NO)
# ----- What-to-show buttons -----
SSSub = Frame(SSub)
LLb = Label(SSSub, text = "List:")
LLb.pack(side = LEFT)
ToolTip(LLb, 35, \
        "The types of data sources that should be displayed in the file list.")
SSSSub = Frame(SSSub)
SSSSSub = Frame(SSSSub)
LCb = Checkbutton(SSSSSub, text = ".log", variable = MFShowLogsCVar)
LCb.pack(side = TOP, anchor = "w")
ToolTip(LCb, 30, "RT130 text log files.")
LCb = Checkbutton(SSSSSub, text = ".cf", variable = MFShowUCFDCVar)
LCb.pack(side = TOP, anchor = "w")
ToolTip(LCb, 30, "RT130 CompactFlash card images (not zipped).")
SSSSSub.pack(side = LEFT)
SSSSSub = Frame(SSSSub)
LCb = Checkbutton(SSSSSub, text = ".ref", variable = MFShowRefsCVar)
LCb.pack(side = TOP, anchor = "w")
ToolTip(LCb, 30, "RT130 all-in-one raw data files.")
LCb = Checkbutton(SSSSSub, text = ".zip", variable = MFShowZCFCVar)
LCb.pack(side = TOP, anchor = "w")
ToolTip(LCb, 30, "RT130 zipped CompactFlash card images.")
SSSSSub.pack(side = LEFT)
SSSSub.pack(side = LEFT)
Label(SSSub, text = " ").pack(side = LEFT)
BButton(SSSub, text = "Reload", command = Command(loadRTFilesCmd, MFFiles, \
        "MF")).pack(side = LEFT)
SSSub.pack(side = TOP)
Cb = Checkbutton(SSub, text = "Include Non-SOH Items", \
        variable = OPTIncNonSOHCVar)
Cb.pack(side = TOP)
ToolTip(Cb, 30, \
        "With this item selected LOGPEEK, in addition to just looking for SOH packets in .ref, .zip and .cf sources, will also look for other packet types to use in generating SOH messages and plot points. Selecting this option may greatly increase the time required to read the selected source.")
SSSub = Frame(SSub)
LLb = Label(SSSub, text = "Mass Pos:")
LLb.pack(side = LEFT)
ToolTip(LLb, 30, \
        "Select which channel set of mass positions to plot. The 'Include Non-SOH Items' option must also be selected for these to function.")
Cb = Checkbutton(SSSub, text = "123", \
        variable = DGrf["MP123"]).pack(side = LEFT)
Cb = Checkbutton(SSSub, text = "456", \
        variable = DGrf["MP456"]).pack(side = LEFT)
SSSub.pack(side = TOP)
# Set this to the number of DSs buttons below.
PROG_DSS = 4
SSSub = Frame(SSub)
LLb = Label(SSSub, text = "DSs:")
LLb.pack(side = LEFT)
ToolTip(LLb, 30, \
        "The data stream(s) to plot. The Include Non-SOH Items checkbutton must also be selected for these to function. Selecting these may greatly increase the time required to read the selected source.")
SSSSub = Frame(SSSub)
SSSSSub = Frame(SSSSub)
Checkbutton(SSSSSub, text = "1", variable = Stream1Var).pack(side = LEFT)
Checkbutton(SSSSSub, text = "2", variable = Stream2Var).pack(side = LEFT)
Checkbutton(SSSSSub, text = "3", variable = Stream3Var).pack(side = LEFT)
Checkbutton(SSSSSub, text = "4", variable = Stream4Var).pack(side = LEFT)
SSSSSub.pack(side = TOP)
#SSSSSub = Frame(SSSSub)
#Checkbutton(SSSSSub, text = "5", variable = Stream5Var).pack(side = LEFT)
#Checkbutton(SSSSSub, text = "6", variable = Stream6Var).pack(side = LEFT)
#Checkbutton(SSSSSub, text = "7", variable = Stream7Var).pack(side = LEFT)
#Checkbutton(SSSSSub, text = "8", variable = Stream8Var).pack(side = LEFT)
#SSSSSub.pack(side = TOP)
SSSSub.pack(side = LEFT)
SSSub.pack(side = TOP)
SSSub = Frame(SSub)
SSSSub = Frame(SSSub)
SSSSSub = Frame(SSSSub)
LCb = Checkbutton(SSSSSub, text = "RAW", variable = OPTPlotRAWCVar)
LCb.pack(side = LEFT)
ToolTip(LCb, 40, "Open a form and plot the raw data information. The Include Non-SOH Items checkbutton, and at least one data stream with data must also be selected.")
LCb = Checkbutton(SSSSSub, text = "T-P-S", variable = OPTPlotTPSCVar)
LCb.pack(side = LEFT)
ToolTip(LCb, 40, "Open a form and plot the Time-Power-Squared information. The Include Non-SOH Items checkbutton, and at least one data stream with data must also be selected.")
SSSSSub.pack(side = TOP)
SSSSSub = Frame(SSSSub)
labelTip(SSSSSub, "Bkgrnd:", LEFT, 30, \
        "B = Black plot area background for main, RAW and TPS plot areas\nW = White plot area background")
Radiobutton(SSSSSub, text = "B", variable = PROGColorModeRVar, \
        value = "B").pack(side = LEFT)
Radiobutton(SSSSSub, text = "W", variable = PROGColorModeRVar, \
        value = "W").pack(side = LEFT)
SSSSSub.pack(side = TOP)
SSSSub.pack(side = LEFT, padx = 3)
BButton(SSSub, text = "Replot", command = plotMFReplot).pack(side = LEFT)
SSSub.pack(side = TOP)
SSSub = Frame(SSub)
PROGReadBut = BButton(SSSub, text = "Read", command = fileSelected)
PROGReadBut.pack(side = LEFT)
PROGStopBut = BButton(SSSub, text = "Stop", state = DISABLED, \
        command = Command(progControl, "stop"))
PROGStopBut.pack(side = LEFT)
BButton(SSSub, text = "Write .ps", command = Command(formWritePS, \
        Root, "MF", LastMFPSFilespecVar)).pack(side = LEFT)
SSSub.pack(side = TOP, pady = 3)
# ----- Information area -----
SSSub = Frame(SSub)
Info = Text(SSSub, cursor = "", font = PROGMsgFont, height = 11, wrap = WORD)
Info.pack(side = TOP, fill = X, expand = YES)
SSSub.pack(side = TOP, fill = X, expand = NO)
SSub.pack(side = LEFT, fill = Y, expand = NO, padx = 3, pady = 3)
# ----- The graph -----
SSub = Frame(Sub, bd = 2, relief = SUNKEN)
# Don't specify the color here.
LCan = Can["MF"] = Canvas(SSub, bd = 0)
LCan.pack(side = TOP, expand = YES, fill = BOTH)
LCan.bind("<Button-1>", plotMFPointClick)
LCan.bind("<Shift-Button-1>", plotMFShiftClick)
LCan.bind("<Control-Button-1>", plotMFTimeClick)
LCan.bind("<Button-3>", plotMFZapClick)
SSub.pack(side = RIGHT, expand = YES, fill = BOTH)
Sub.pack(side = TOP, expand = YES, fill = BOTH)
# ----- Status message field -----
Sub = Frame(SubRoot)
Msg["MF"] = Text(Sub, cursor = "", font = PROGMsgFont, height = 3, \
        wrap = WORD)
Msg["MF"].pack(side = LEFT, fill = X, expand = YES)
Button(Sub, text = "Redraw", command = reconfigDisplay).pack(side = LEFT)
Sub.pack(side = TOP, fill = X, expand = NO)
# We don't use center() here to keep center() simple.
# For people with two monitors, which are usually with Macs, which usually
# have a smaller screen than their external monitor, so change the height too.
if PROGScreenWidth > 1920:
    PROGScreenWidth = 1280
    PROGScreenHeight = 800
FW = PROGScreenWidth*.80
# Don't let the form get gigantic.
if FW > 1200:
    FW = 1200
FH = PROGScreenHeight*.80
FX = PROGScreenWidth/2-FW/2
FY = PROGScreenHeight/2-FH/2
# I don't think measurements include the size of the title bar, so the -20
# compensates for that a bit. Set this, but don't make it show up until we've
# checked PROGGeometryVar below, unless there is an error to display.
Root.geometry("%ix%i+%i+%i"%(FW, FH, FX, FY-20))
# Begin startup sequence.
Ret = getPROGStarted()
if Ret[0] == 1:
    Root.deiconify()
    Root.lift()
    formMYD(Root, (("(OK)", TOP, "ok"), ), "ok", Ret[1], "Really?", Ret[2])
# Clear this so the display doesn't change shape on the user.
    PROGGeometryVar.set("")
elif Ret[0] == 2:
    Root.deiconify()
    Root.lift()
    formMYD(Root, (("(OK)", TOP, "ok"), ), "ok", Ret[1], "Oh Oh.", Ret[2])
# Something is wrong so don't save the setups.
    progQuitter(False)
# Check to make sure the display is not going to come up somehwere where the
# user can't get at it (like they used it on a dual monitor system, but are
# now going to run it on a single monitor system).
# This is all overridden with the -g command line argument.
if PROGIgnoreGeometry == 0:
    if PROGGeometryVar.get() != "":
        LastGeometry = PROGGeometryVar.get()
        A, B = LastGeometry.split("+", 1)
        LFW, LFH = map(int, A.split("x"))
        LFX, LFY = map(int, B.split("+"))
# These two should at least keep the display on the screen so the user can
# manually resize it if needed when the number of monitors changes.
        if LFX > PROGScreenWidth:
            LFX = FX
        if LFY > PROGScreenHeight:
            LFY = FY
        PROGGeometryVar.set("%ix%i+%i+%i"%(LFW, LFH, LFX, LFY))
        Root.geometry(PROGGeometryVar.get())
# If these got done above they will have no effect here.
Root.deiconify()
Root.lift()
setColors()
changeDateFormat()
Can["MF"].configure(bg = DClr["MFCAN"])
# How things get set up differ depending on if the user has told the program
# that they are running it from the command line. In that case take a chance
# and get the Msgs and Work dirs from the getcwd() command.
if PROGCLRunning == 0:
# This will be true if there is no setups file.
    if PROGDataDirVar.get() == "":
        Ret = getPROGStartDir(2)
        if Ret != "":
# All three of these will always be kept set to the same thing in LOGPEEK.
            PROGDataDirVar.set(Ret)
            PROGMsgsDirVar.set(Ret)
            PROGWorkDirVar.set(Ret)
# If the user doesn't pick any place.
    if PROGDataDirVar.get() == "":
        PROGDataDirVar.set(PROGSetupsDirVar.get())
    if PROGMsgsDirVar.get() == "":
        PROGMsgsDirVar.set(PROGDataDirVar.get())
    if PROGWorkDirVar.get() == "":
        PROGWorkDirVar.set(PROGDataDirVar.get())
    if LOGLastFilespecVar.get() == "":
        LOGLastFilespecVar.set(PROGDataDirVar.get())
# This really isn't necessary since the file name gets set when a file is
# selected, but it will keep the user out of trouble before anything is
# plotted.
    if LastMFPSFilespecVar.get() == "":
        LastMFPSFilespecVar.set(PROGDataDirVar.get())
    if LastRAWPSFilespecVar.get() == "":
        LastRAWPSFilespecVar.set(PROGDataDirVar.get())
    if LastTPSPSFilespecVar.get() == "":
        LastTPSPSFilespecVar.set(PROGDataDirVar.get())
elif PROGCLRunning == 1:
    CWD = getCWD()
    PROGDataDirVar.set(CWD)
    PROGMsgsDirVar.set(CWD)
    PROGWorkDirVar.set(CWD)
    LOGLastFilespecVar.set(CWD)
    LastMFPSFilespecVar.set(CWD)
    LastRAWPSFilespecVar.set(CWD)
    LastTPSPSFilespecVar.set(CWD)
if CLAFile == "":
    loadRTFilesCmd(MFFiles, "MF")
# If there was a passed path/filename then we now need to get the program to
# "select" and read the file.
elif CLAFile != "":
    CLAFileLC = CLAFile.lower()
    if CLAFile.endswith(".log") == False and \
            CLAFile.endswith(".ref") == False and \
            CLAFile.endswith(".zip") == False and \
            CLAFile.endswith(".cf") == False:
        formMYD(Root, (("OK", TOP, "ok"), ), "ok", "RW", "No Good.", \
                "The passed file\n\n%s\n\ndoes not end with .log, .ref, .zip or .cf"% \
                CLAFile)
        progQuitter(False)
    Dir = abspath(dirname(CLAFile))
    if Dir.endswith(sep) == False:
        Dir += sep
    PROGDataDirVar.set(Dir)
    PROGMsgsDirVar.set(Dir)
    PROGWorkDirVar.set(Dir)
    CLAFile = basename(CLAFile)
    MFFiles.insert(END, CLAFile)
    fileSelected()
# PROFILE
#profile.run("Root.mainloop()")
# Turns on epoch time displaying for troubleshooting.
#OPTDateFormatRVar.set("")
Root.mainloop()
# END: main

# Can len(RawData) ever be 0?
