#! /usr/bin/env picpython
# BEGIN PROGRAM: SETOSC
# Started: <2007.259
# By: Bob Greschke
#   Texan RT125/RT125A Setter of Oscillators program.

from sys import argv, exit, platform
PROGSystem = platform[:3].lower()
PROG_NAME = "SETOSC"
PROG_NAMELC = "setosc"
PROG_VERSION = "2009.090"
PROG_LONGNAME = "Texan RT125/RT125A Setter of Oscillators"

from Tkinter import *
from sys import exit

Root = Tk()
Root.withdraw()

PROGLang = "-LE"
PROGKiosk = False
for Arg in argv[1:]:
    if Arg == "-#":
        print PROG_VERSION
        exit()
    elif Arg == "-LE":
        PROGLang = "-LE"
    elif Arg == "-LS":
        PROGLang = "-LS"


###############################################################################
# BEGIN: center(Parent, TheFrame, Where, InOut, Show, CenterX = 0, CenterY = 0)
# LIB:center():2009.157
#   Where tells the function where in relation to the Parent TheFrame should
#   show up.  Use the diagram below to figure out where things will end up.
#
#      +---------------+
#      | NW    N    NE |
#      |               |
#      | W     C     E |
#      |               |
#      | SW    S    SE |
#      +---------------+
#
#   Set Parent to None to use the whole display as the parent.
#   Set InOut to "I" or "O" to control if TheFrame shows "I"nside or "O"outside
#   the Parent (does not apply if the Parent is None).
#
#   CenterX and CenterY not equal to zero overrides everything.
#
def center(Parent, TheFrame, Where, InOut, Show, CenterX = 0, CenterY = 0):
    if isinstance(Parent, str):
        Parent = Frm[Parent]
# Kiosk mode. Just take over the whole screen. Doesn't check for, but only
# works for Root.
    if Where == "K":
        Root.geometry("%dx%d+0+0"%(Root.winfo_screenwidth(), \
                Root.winfo_screenheight()-30))
        Root.lift()
        Root.deiconify()
        return
# So all of the dimensions get updated.
    updateMe(0)
    FW = TheFrame.winfo_reqwidth()
    if TheFrame == Root:
# Different systems have to be compensated for a little because of differences
# in the reported heights (mostly title and menu bar heights).
        if PROGSystem == "dar" or PROGSystem == "win":
            FH = TheFrame.winfo_reqheight()
        else:
            FH = TheFrame.winfo_reqheight()+50
    else:
        FH = TheFrame.winfo_reqheight()
# Find the center of the Parent.
    if CenterX == 0 and CenterY == 0:
        if Parent == None:
            PX = 0
            PY = 0
            PW = Root.winfo_screenwidth()
            PH = Root.winfo_screenheight()
# A PW of >1920 (the width of a 24" iMac) probably means the user has two
# monitors. Tkinter just gets fed the total width and the smallest display's
# height, so just set the size to 1024x768 and then let the user resize and
# reposition as needed. It's what they get for being so lucky.
            if PW > 1920:
                PW = 1024
                PH = 768
            CenterX = PW/2
            CenterY = PH/2-25
        elif Parent == Root:
            PX = Parent.winfo_x()
            PW = Parent.winfo_width()
            CenterX = PX+PW/2
# Macs, Linux and Suns think the top of the Root window is below the title
# and menu bars.  Windows thinks the top of the window is the top of the
# window, so adjust the window heights accordingly to try and cover that up.
            if PROGSystem == "win":
                PY = Parent.winfo_y()
                PH = Parent.winfo_height()
            else:
                PY = Parent.winfo_y()-50
                PH = Parent.winfo_height()+50
            CenterY = PY+PH/2
        else:
            PX = Parent.winfo_x()
            PW = Parent.winfo_width()
            CenterX = PX+PW/2
            PY = Parent.winfo_y()
            PH = Parent.winfo_height()
            CenterY = PY+PH/2
# Can't put forms outside the whole display.
        if Parent == None or InOut == "I":
            InOut = 1
        else:
            InOut = -1
        if Where == "C":
            TheFrame.geometry("+%i+%i"%(CenterX-FW/2, CenterY-FH/2))
        elif Where == "N":
            TheFrame.geometry("+%i+%i"%(CenterX-FW/2, PY+(25*InOut)))
        elif Where == "NE":
            TheFrame.geometry("+%i+%i"%(PX+PW-FW-(25*InOut), PY+(25*InOut)))
        elif Where == "E":
            TheFrame.geometry("+%i+%i"%(PX+PW-FW-(25*InOut), \
                    CenterY-TheFrame.winfo_reqheight()/2))
        elif Where == "SE":
            TheFrame.geometry("+%i+%i"%(PX+PW-FW-(25*InOut), \
                    PY+PH-FH-(25*InOut)))
        elif Where == "S":
            TheFrame.geometry("+%i+%i"%(CenterX-TheFrame.winfo_reqwidth()/2, \
                    PY+PH-FH-(25*InOut)))
        elif Where == "SW":
            TheFrame.geometry("+%i+%i"%(PX+(25*InOut), PY+PH-FH-(25*InOut)))
        elif Where == "W":
            TheFrame.geometry("+%i+%i"%(PX+(25*InOut), \
                    CenterY-TheFrame.winfo_reqheight()/2))
        elif Where == "NW":
            TheFrame.geometry("+%i+%i"%(PX+(25*InOut), PY+(25*InOut)))
    else:
        TheFrame.geometry("+%i+%i"%(CenterX-FW/2, CenterY-FH/2))
    if Show == True:
        TheFrame.lift()
        TheFrame.deiconify()
    updateMe(0)
    return
# END: center



Root.title("Good to know.")
Label(Root, text = "This program has been replaced by the\nSet Oscillator Frequencies command\nin POCUS." \
        ).pack(side = TOP)
Button(Root, text = "OK", command = exit).pack(side = TOP)
center(None, Root, "C", "I", True)
Root.mainloop()
