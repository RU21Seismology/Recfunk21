#!/usr/bin/env python

#
#    A simple clock
#
#    Steve Azevedo, Oct. 2000
#

from Tkinter import *
from time import gmtime, time, tzname, sleep
from sys import argv
from os import popen

colors = [('black', 'white'),
          ('red', 'black'),
          ('green', 'black'),
          ('yellow', 'black'),
          ('blue', 'white'),
          ('magenta', 'black'),
          ('cyan', 'black'),
          ('white', 'black')]

fontsizes = [24, 36, 48, 64, 72, 96]

def getHostname () :
    fh = popen ('hostname')
    name = fh.readline ()
    fh.close ()
    name = name[:-1]
    return (name)

class Pclock (Frame) :
    def __init__ (self, root, **kw) :
        apply (Frame.__init__, (self, root), kw)
        self.getTime ()
        tzname = ('GMT', 'GMT')
	root.resizable (0, 0)
        self.configure (relief = GROOVE, borderwidth = 2)
        self.icolor = 0
        self.ifont = 0
        self.label = Label (self, text = self.time,
                            background = colors[self.icolor][0],
                            foreground = colors[self.icolor][1])
        self.label.bind ("<Button-1>", self.showDate)
        self.label.bind ("<Button-2>", self.changeColor)
        self.label.bind ("<Button-3>", self.changeSize)
        self.label.pack ()

    def start (self) :
        self.afterId = self.after (200, self.update)

    def getTime (self) :
        t = time () + 0.5
        ttuple = gmtime (int (t))
        self.ttuple = ttuple
        self.time = ("%4d:%03d:%02d:%02d:%02d" % (int (ttuple[0]),
                                                  int (ttuple[7]),
                                                  int (ttuple[3]),
                                                  int (ttuple[4]),
                                                  int (ttuple[5])))

    def update (self) :
        self.getTime ()
        self.label.configure (text = self.time)
        self.update_idletasks ()
        self.afterId = self.after (200, self.update)

    def showDate (self, e) :
        self.after_cancel (self.afterId)
        date = ("    %d/%02d/%02d   " % (int (self.ttuple[0]),
                                         int (self.ttuple[1]),
                                         int (self.ttuple[2])))
        self.label.configure (text = date)
        self.update_idletasks ()
        sleep (3)
        self.start ()

    def changeSize (self, e) :
        self.after_cancel (self.afterId)
        self.ifont = (self.ifont + 1) % 6
        self.label.configure (font = ('Courier',
                                      fontsizes[self.ifont],
                                      'bold'))
        self.update_idletasks ()
        self.start ()

    def changeColor (self, e) :
        self.after_cancel (self.afterId)
        self.icolor = (self.icolor + 1) % 8
        self.label.configure (background = colors[self.icolor][0],
                              foreground = colors[self.icolor][1])
        self.update_idletasks ()
        self.start ()


if __name__ == "__main__" :
    root = Tk ()
    hostname = getHostname ()
    root.title ("Livin' on PASSCAL Time: " + hostname)
    optionsDB = argv[1]
    #print optionsDB
    try :
        root.option_readfile (optionsDB)
    except :
        sys.stderror.write ("Error: Failed to open options database!\n")
    p = Pclock (root, background = 'white')
    p.pack ()
    p.start ()
    root.mainloop ()






