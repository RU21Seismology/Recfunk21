#!/usr/bin/env python
'''
Fix Sirf Problem starting on July 31 
where gps is -1 sec off on a cycle
IRIS/PASSCAL
Lloyd Carothers lloyd@passcal.nmt.edu
'''

DESCRIPTION = \
''' Finds and corrects -1 second time jumps caused my malfunctioning SiRF GPS \
clocks used with Reftek RT-130 model recorders that started on \
July 31 2008 (hence the name), and has seemed to stop on January 1 2009. \
. Operates on .ref files generated \
by programs such as neo, rt130cut, and unchunky. Does not replace original \
files, but creates new corrected files. \
Corrected files are prepended with series of SH packets that describe \
the modifications, and the file name extentions are changed from \
.ref to .cor.ref. It also moves the original files that have corresponding \
.cor.ref files to a directory 'orignals' such that all files in the directory \
of ref files contains 'good' files (unmodified files that don't need \
corrections OR corrected files.
 Due to the nature of this problem and timing in general, refj31fix may not be \
able to correct all problems related to this bug. Email software@passcal.nmt.edu \
for help, bug reports, or suggestions.'''

VERSION = '2009.233'

#Setup timezone
import os
os.environ['TZ'] = '0'
import time
time.tzset()
from decimal import *
import optparse
ORIGDIR = 'originals'

############################
#Time handling
############################
class Ltime(object):
    ''' An upgraded time object with milliseconds
    stores time in epoch for slow creation but faster comparison
    May need to turn epoch and milli into ints to prevent rounding problems
    self.epoch :: float
    refpktstamp ::  YY:DDD:HH:MM:SS.MIL
    epoch ::        float
    shstamp ::      deal with this later
    '''
    #reftek packet time format for strptime
    PKTFMT = "%y:%j:%H:%M:%S"
    SECperDAY = 86400
    SECperHOUR = 3600
    def __init__(self, pktstamp=None, epoch=None, shstamp=None):
        if not (pktstamp or epoch or shstamp):
            raise RuntimeError, "Must provide 1 form of time"
        if epoch is not None:
            self.epoch = epoch
        if pktstamp is not None:
            self.set_pktstamp(pktstamp)
        if shstamp is not None:
            self.set_shstamp(shstamp)
            
    def set_pktstamp(self, pktstamp):
        self.epoch = time.mktime( time.strptime(pktstamp[:-4], Ltime.PKTFMT) ) + float( pktstamp[-4:] ) 
    def get_pktstamp(self):
        #time should be instance of Ltime
        st = self.get_struct_time()
        styear = str(st.tm_year)[-2:]
        pyear = pack('1B', int(styear))
        mils = "%0.3f" % self.get_milisec() 
        mils = mils[-3:]
        ts = "%0.3d"% st.tm_yday + "%0.2d" % st.tm_hour + '%0.2d'%st.tm_min + '%0.2d'%st.tm_sec + mils
        ptime = pack('6B', int(ts[:2],16), int(ts[2:4],16), int(ts[4:6],16), int(ts[6:8],16), int(ts[8:10],16), int(ts[10:12],16) )
        return pyear, ptime
    def set_shstamp(self, shstamp):
        self.epoch = time.mktime( time.strptime(shstamp, Ltime.PKTFMT) ) 
    def get_shstamp(self):
        st = self.get_struct_time()
        return "%0.3d:%0.2d:%0.2d:%0.2d" % (st.tm_yday, st.tm_hour, st.tm_min, st.tm_sec)
    def get_epoch(self):
        #includes milisecs
        return self.epoch
    def get_milisec(self):
        r =  self.epoch % 1.0 
        return r
    def get_struct_time(self):
        t = time.gmtime(self.epoch)
        return t
    def add_hours(self, hours):
        return Ltime( epoch = self.epoch + hours * Ltime.SECperHOUR )
    def add_days(self, days):
        return Ltime( epoch = self.epoch + days * Ltime.SECperDAY )
    def __str__(self):
        #s = "Time struct: " + str(self.timetup) + " Milisec: " + str(self.milisec)
        #s += " Epoch: "  + str( self.get_epoch() )
        s = time.strftime(Ltime.PKTFMT, self.get_struct_time())
        ms = "%0.3f" % self.get_milisec()
        s = '20' + s +  '.' + ms[-3:] 
        return s
    def calday_str(self):
        #returns a string in calendar day format
        return  time.asctime(self.get_struct_time())
    def __add__(self, seconds):
        #other must be seconds 
        return Ltime(epoch= self.epoch + seconds)
    def __eq__(self, other):
        return "%0.3f" % self.epoch == "%0.3f" % other.epoch
    def __ne__(self, other):
        return "%0.3f" % self.epoch != "%0.3f" % other.epoch
    def __lt__(self, other):
        return self.epoch < other.epoch
    def __le__(self, other):
        return self.epoch <= other.epoch
    def __gt__(self, other):
        return self.epoch > other.epoch
    def __ge__(self, other):
        return self.epoch >= other.epoch
    def __sub__(self, other):
        if isinstance( other, Ltime):
            return self.epoch - other.epoch
        if isinstance(other, int):
            return Ltime(epoch= self.epoch - other)
        
class Ltimespan(object):
    '''
    time span class
    start and end are of type Ltime
    '''
    def __init__(self, t1, t2):
        if not ( isinstance(t1,Ltime) and isinstance(t2,Ltime) ):
            raise Exception, 'Arguments must both be of type Ltime'
        if t1 < t2:
            self.start = t1
            self.end = t2
        else:
            self.start = t2
            self.end = t1
    def __str__(self):
        return str(self.start) + " - " + str(self.end)
    def calday_str(self):
        return self.start.calday_str() + " - " + self.end.calday_str()
    def has(self, t):
        # returns true if t is in time span inclusive on start not inclusive on end
        if self.start <= t and t < self.end:
            return True
        else:
            return False
class BadSirfTimespans(object):
    '''
    sequence of timespans during which a sirf lock will give bad time
    '''
    # July 31 2008 the beginging of j31 bug
    START = '08:213:00:00:00.000'
    END =   '08:363:00:00:00.000'
    def __init__(self):
        #Creates a list of spans up to time until (in days from now)
        self.spans = list()
        i = Ltime(pktstamp = BadSirfTimespans.START)
        now =  Ltime(epoch = time.time())
        later = Ltime(pktstamp = BadSirfTimespans.END)
        while ( i < later):
            self.spans.append( Ltimespan( i, i.add_hours(18) ) )
            self.spans.append( Ltimespan( i.add_days(1), i.add_days(3) ) )
            i = i.add_days(7)
    @staticmethod
    def before_j31(ltime):
        if not isinstance(ltime, Ltime):
            raise RuntimeError('function needs instance of Ltime type')
        if ltime < Ltime(pktstamp=BadSirfTimespans.START):
            return True
        else:
            return False
    @staticmethod
    def after_ny2009(ltime):
        if not isinstance(ltime, Ltime):
            raise RuntimeError('function needs instance of Ltime type')
        if ltime > Ltime(pktstamp=BadSirfTimespans.END):
            return True
        else:
            return False
    def __str__ (self):
        s = ''
        for span in self.spans:
            s += str(span) + '\n'
        return  s
    def calday_str (self):
        s = ''
        for span in self.spans:
            s += str(span) + '  OR  '
            s += span.calday_str() + '\n'
            
        return  s
    def has(self, time):
        #Given time should be of Ltime type
        #returns True if time is in a bad span true if not
        inspan = [span for span in self.spans if span.has(time) ]
        if len(inspan) > 0 :
            return True
        return False
            
def timetest():
    sws = time.time()
    bst = BadSirfTimespans()
    print bst
    iters = 10000
    first = Ltime(pktstamp=BadSirfTimespans.START)
    last = Ltime(epoch=sws)
    step = (last.epoch - first.epoch) / iters
    swm = time.time()
    bad = [ lt for lt in [Ltime(epoch = t) for t in range(first.epoch, last.epoch, step)] if bst.has(lt) ]
    print "bad"
    for b in bad:
        print b
    swe = time.time()
    print "overhead: %f  inter: %f" % ( swm-sws, swe-swm)
    print sws, swm, swe
###########################
#End Time handling
###########################
    
import sys
from stat import ST_SIZE 
from struct import *
from itertools import *
import re

##########################
#Reftek packets
##########################
class Packet (object):
    packetHdrFmt = '2c1B1B2B6B2B2B'
    reDSPDIFF = re.compile(r'(\d{3}:\d{2}:\d{2}:\d{2})\sDSP CLOCK DIFFERENCE:\s+(-?\d+)\s+SECS')
    reSIRF = re.compile(r'EXTERNAL CLOCK TYPE: NMEA\r\n')
    reGARMIN = re.compile(r'EXTERNAL CLOCK TYPE: NMEA-Garmin\r\n')
    CORRECTED =               ' PASSCAL J31BUG v%s CORRECTION (+1sec) APPLIED:\r\n' % VERSION 
    reCORRECTED = re.compile(r' PASSCAL J31BUG .*CORRECTION .*APPLIED:\r\n')

    def __init__(self, index, buffer):
        self.index = index
        self.buffer = buffer
        self.unpack()
        self.set_SHstring()
        self.set_EH()
        self.set_DT()
    @staticmethod
    def gen_packets(fh, start=0, count=0):
        '''Returns a generator which will yield 1 packet at a time
        '''
        if start < 0:
            start = 0
        head = start
        #read forever
        if count == 0: 
            while True:
                fh.seek(head)
                index = fh.tell()
                data = fh.read(1024)
                if data == '': return
                yield index, data
                head = head + 1024
        #read count packets
        else:
            i = 0
            while i < count:
                fh.seek(head)
                index = fh.tell()
                data = fh.read(1024)
                if data == '': return
                yield index, data
                head = head + 1024
                i += 1
    @staticmethod
    def gen_reverse_packets(fh, start, count=0):
        '''Returns a generator which will yeild 1 packet at a time
        starting with the packet before start
        '''
        head = start - 1024
        #read forever
        if count == 0:
            while head >= 0:
                fh.seek(head)
                index = fh.tell()
                data = fh.read(1024)
                yield index, data
                head = head - 1024
        #read count packets
        else:
            i = 0
            while head >= 0 and i < count:
                fh.seek(head)
                index = fh.tell()
                data = fh.read(1024)
                yield index, data
                head = head - 1024
                i += 1
    @staticmethod
    def isSH(buffer):
        if buffer[:2] == 'SH':
            return True
        else:
            return False
    @staticmethod
    def isEH(buffer):
        if buffer[:2] == 'EH':
            return True
        else:
            return False
    @staticmethod
    def isDT(buffer):
        if buffer[:2] == 'DT':
            return True
        else:
            return False
    @staticmethod
    def has_DSP(buffer):
        '''
        Returns True if buffer is a packet of type SH AND
        has a DSP clock difference 
        '''
        if buffer[:2] != 'SH':
            return False
        bytecount = int("%0.2X%0.2X" % unpack('2B',buffer[12:14]) )
        shstring = buffer[24:bytecount]
        dspmatch =  Packet.reDSPDIFF.findall(shstring)
        if len(dspmatch) > 0:
            return True
        return False
    def is_j31SH(self):
        if self.ptype != 'SH':
            return False
        if Packet.reCORRECTED.search(self.SHstring):
            return True
    @staticmethod
    def j31SH(payload, seq_num = 0, ltime = None, unitID= '0000', exp_num = 0):
        #returns a 1 or more packets suitable to be written to a .ref file
        #seq_num is the seq num after the last packet returned here (for prepending)
        payload = payload.replace('\n','\r\n')
        if ltime is None:
            ltime = Ltime( epoch = time.time() )
        #1000 - 42
        MAXLOAD = 1000 - 12 - len(Packet.CORRECTED) - 2
        numPneeded = len(payload) / MAXLOAD + 1
        seqlist = [x%1000 for x in range(seq_num - numPneeded, seq_num)]
        #common stuff
        ptype = 'SH'
        exp_num = int('%0.2d' % exp_num, 16)
        unitID = int(unitID[:2],16), int(unitID[2:],16)
        pyear, ptime = ltime.get_pktstamp()
        frontload = ltime.get_shstamp() + Packet.CORRECTED
        ret = ''
        for i in range(len(seqlist)):
            packetload = payload[i*MAXLOAD:(i+1)*MAXLOAD]
            seq_num = "%0.4d" % (seqlist[i])
            seq_num = int(seq_num[:2],16), int(seq_num[2:],16)
            byte_count = '%0.4d' % (len(packetload) +66)
            byte_count = int(byte_count[:2],16), int(byte_count[2:],16)
            phdr = pack('2sBs2B6s2B2B8s',
                            ptype,                      # packet type
                            exp_num,                    # exp num 0 ,
                            pyear,                      # year
                            unitID[0], unitID[1],       # unit id
                            ptime,                      # time dddhhmmssTTT
                            byte_count[0], byte_count[1],
                            seq_num[0], seq_num[1],                 #packet seq
                            8*' '
                            )
            outload = phdr + frontload + packetload + '\r\n'
            ret += outload + pack('%dx' % ((1024-len(outload))))
        return ret
                   
                        
    def __str__(self):
        tup = (self.index, self.ptype, self.expnum, self.sn, self.year,\
               self.day, self.hour, self.minute, self.sec, self.millisec,\
               self.bytecount, self.sequence)
        s = 'I: %9d PT: %s %02d %s 20%02d:%03d:%02d:%02d:%02d.%03d %04d %04d'
        if self.isSH(self.buffer):
            s += '\n' + self.SHstring
        return s % tup
    def print_ptype(self):
        print self.ptype
    def get_type(self):
        self.ptype = self.buffer[:2]
    def set_SHstring(self):
        if self.ptype == 'SH':
            self.SHstring = self.buffer[24:self.bytecount]
    def set_EH(self):
        if self.ptype != 'EH':
            return False
        self.event_num = "%0.2X%0.2X" % unpack( '2B', self.buffer[16:18] )
        self.ds = "%0.1X" % unpack('B', self.buffer[18] )
        self.samplerate = self.buffer[88:92]
    def set_DT(self):
        if self.ptype != 'DT':
            return False
        self.ds = '%0.1X' % unpack('B', self.buffer[18])
        self.chan = '%0.1X' % unpack('B', self.buffer[19])
        self.num_samp = int( "%0.2X%0.2X" % unpack( '2B', self.buffer[20:22] ) )
        self.data_format = '%0.1X' % unpack('B', self.buffer[23])
                                   
    def set_DSP_diff(self):
        if self.ptype == 'SH':
            match =  reDSPDIFF.findall(p.SHstring)
            self.DSP_diff = match
    def unpack(self):
        '''parses a 1024 byte reftek packet header'''
        if len(self.buffer) != 1024:
            raise RuntimeError, "Packet not 1024 bytes!"
        tup = unpack(self.packetHdrFmt, self.buffer[:16])
        self.ptype = tup[0] + tup[1]
        self.expnum = int("%0.2X" % tup[2])
        self.year = int("%0.2X" %tup[3])
        self.sn = "%0.2X%0.2X" % (tup[4] , tup[5] )
        self.time = "%0.2X%0.2X%0.2X%0.2X%0.2X%0.2X" % tup[6:12]
        self.day, self.hour, self.minute, self.sec, self.millisec = \
            int(self.time[:3]),int(self.time[3:5]),int(self.time[5:7]),int(self.time[7:9]),int(self.time[9:])
        self.bytecount = int("%0.2X%0.2X" % tup[12:14])
        self.sequence = int("%0.2X%0.2X" % tup[14:16])
        self.Ltime = Ltime('%02d:%03d:%02d:%02d:%02d.%03d' % (
            self.year, self.day, self.hour, self.minute, self.sec, self.millisec))
    def pack_plus_1(self):
        newtime = self.Ltime + 1
        #st = newtime.get_struct_time()
        #styear = str(st.tm_year)[-2:]
        #pyear = pack('1B', int(styear))
        #mils = "%0.3f" % newtime.get_milisec() 
        #mils = mils[-3:]
        #time = "%0.3d"% st.tm_yday + "%0.2d" % st.tm_hour + '%0.2d'%st.tm_min + '%0.2d'%st.tm_sec + mils
        #ptime = pack('6B', int(time[:2],16), int(time[2:4],16), int(time[4:6],16), int(time[6:8],16), int(time[8:10],16), int(time[10:12],16) )
        #print self.buffer
        #print
        pyear, ptime = newtime.get_pktstamp()
        newbuf = self.buffer[:3] + pyear + self.buffer[4:6] + ptime + self.buffer[12:]
        #print newbuf
        #print
        return newbuf
        
    def has_sirf_lock(self):
        '''Returns True if buffer has a sirf lock
        '''
        if self.ptype != 'SH':
            return False
        sirfmatch = self.reSIRF.search(self.SHstring)
        if sirfmatch is None:
            return False
        else:
            return True
    def has_garmin_lock(self):
        if self.ptype != 'SH':
            return False
        gmatch = self.reGARMIN.search(self.SHstring)
        if gmatch is None:
            return False
        else:
            return True
    def jerk_size(self):
        '''
        SH that has a DSP CLOCK DIFFERENCE line
        returns (size of jerk , timestamp)
        '''
        if not self.ptype == 'SH':
            return False
        match =  self.reDSPDIFF.findall(self.SHstring)
        return ( int(match[-1][1]), Ltime(shstamp="%0.2d:%s" % (self.year, match[-1][0]) ) )
##########################
#End Reftek packets
##########################
###########################
#Data Stream stuff
###########################
class DSs (object):
    ''' Multiple DSs'''
    def __init__(self):
        self.dss = dict()
    def __str__(self):
        ret = ''
        for ds in self.dss.itervalues():
            ret += str(ds) + "\n"
        return ret
    def get_num_channels(self):
        #we assume there are 3 chans per stream
        return (len(self.dss) * 3)
    def populate(self, iterator):
        '''iterator = (ds, sr, index) in order found in file'''
        for ds, sr, index in iterator:
            if float(sr) < 1:
                continue
            if not self.dss.has_key(ds):
                self.dss[ds] = DS(ds)
            self.dss[ds].add_index(index, sr)
class DS (object):
    def __init__(self, stream):
        self.stream = int(stream)
        self.index_rate = list()
    def __str__(self):
        ret = str(self.stream) + '\n'
        for index, rate in self.index_rate:
            ret += '\t' + str(index) + '\t' + str(rate) + '\n'
        return ret
    def add_index(self, index, rate):
        rate = int(rate)
        self.index_rate.append((index, rate))
    def get_rate(self, position):
        for index, rate in self.index_rate:
            if position >= index:
                return rate
        #fall back
        return self.index_rate[0][1]

class DS2correct(object):
    def __init__ (self):
        #dsdict :: {(ds,chan) : [(start,end),(start,end)...] }
        # where start and end are indexs for the begining and end of correction
        self.dsdict = dict()
        #starts :: {(ds,chan) : start}
        self.starts = dict()
    def __str__(self):
        s = ''
        for key, spans in self.dsdict.iteritems():
            s += "DS: %s CHAN: %s\n" % key
            for span in spans:
                s += ' %s - %s\n' % (str(span[0].Ltime), str(span[1].Ltime))
        return s
    def __len__(self):
        return len( self.dsdict)
    def add (self, ds, chan, start, stop):
        key = (ds,chan)
        if self.dsdict.has_key(key):
            self.dsdict[key].append((start, stop))
        else:
            self.dsdict[key] = [(start,stop)]
    def add_start(self, ds, chan, start):
        key = (ds, chan)
        if self.starts.has_key(key):
            raise RuntimeError, "Started a correcting sequence twice!"
        else:
            self.starts[key] = start
    def end(self, ds, chan, end):
        key = (ds, chan)
        if self.starts.has_key(key):
            self.add(ds, chan, self.starts[key], end)
            del self.starts[key]
        else:
            raise RuntimeError, "Ended a correcting sequence not started!"
    def close(self, lastindex):
        #Call this at the end to add all the partials
        # last index is the end of file
        for key, start in self.starts.iteritems():
            ds, chan = key
            self.add(ds, chan, start, lastindex)
            #del self.starts[key]
            
    def has (self, ds, chan, index):
        key = (ds, chan)
        if self.dsdict.has_key(key):
            for start, stop in self.dsdict[key]:
                if start.index <=index and index < stop.index:
                    return True
        return False
                
                
#############################        
#End Data Stream
#############################
def ends_before_j31(fh):
    file_size = os.fstat(fh.fileno())[ST_SIZE]
    last_pkt = [ Packet(i,buf) for i,buf in Packet.gen_reverse_packets(fh, file_size, 1) ][0]
    if BadSirfTimespans.before_j31(last_pkt.Ltime):
        return True
    else:
        return False
    
def starts_after_ny2009(fh):
    #last_pkt = [ Packet(i,buf) for i,buf in Packet.gen_reverse_packets(fh, file_size, 1) ][0]
    first_pkt = [ Packet(i,buf) for i,buf in Packet.gen_packets(fh,0,1) ][0]
    if BadSirfTimespans.after_ny2009(first_pkt.Ltime):
        return True
    else:
        return False

def fixable(fh,bsts):
    #returns true if finds a bad sirf lock and no subsequent garmin locks
    shpackets = ( Packet(i,buf) for i, buf in Packet.gen_packets(fh) if Packet.isSH(buf) )
    badsirflock = False
    for shp in shpackets:
        if shp.has_sirf_lock() and bsts.has(shp.Ltime):
            badsirflock = True
            break
    if not badsirflock:
        return False
    for shp in shpackets:
        if shp.has_garmin_lock():
            return False
    return True

def print_packets(fh, index=0, count=0):
    #just print all the packet in a file
    packets = ( Packet(i,buf) for i, buf in Packet.gen_packets(fh, index, count) )
    for p in packets:
        print p
    
def find_bad_packets(fh, start_index, badsirftimes, dss):
    '''Returns a DS2correct object of indexes of dt packets that need a +1 shift
    '''
    #List of indexes need to get fixed
    need_fix = DS2correct()
    #First packet in file, time needed for start to first good jerk
    firstpacket = [ Packet(i,buf) for i, buf in Packet.gen_packets(fh, 0, 1) ][0]
    #generator for all dsp jerks
    dsps = ( Packet(i,buf) for i,buf in Packet.gen_packets(fh,start = start_index) if Packet.has_DSP(buf) )
    
    #Check first dsp for correction from start of file
    if not badsirftimes.before_j31(firstpacket.Ltime):
        #File starts after july 31 2008
        print "File starts after July 31 2008..."
        sys.stdout.flush()
        try:
            firstdsp = dsps.next()
        except StopIteration:
            print "No DSP's found."
            return need_fix
        #print firstdsp
        jerk_size , jerk_time = firstdsp.jerk_size()
        #print jerk_size, jerk_time
        if not badsirftimes.has(firstdsp.Ltime) and Decimal('%0.3f' % jerk_size) == 1:
            #First dsp is in good sirf time and +1: we need to correct data from begining to here
            print "Correcting from begining of file to here"
            sys.stdout.flush()
            tears = find_tear( fh, firstdsp.index, jerk_size, dss, jerk_time)
            if tears is False:
                print "  Tears not found. Broadening search"
                tears =  find_tear(fh, firstdsp.index, jerk_size, dss, jerk_time,seek_back=30000, seek_forward=60000)
            if tears is False:
                print "\tTears really not found. Cannot fix start of file..."
            else:
                for p, jerk_size in tears.itervalues():
                    print "  DS:%s CH:%s\t%0.1f\t%s " % (p.ds, p.chan, jerk_size, str(p.Ltime))
                    sys.stdout.flush()
                    need_fix.add(p.ds, p.chan, firstpacket, p)
                
    #generator for all dsp jerks reset here to grab first again
    dsps = ( Packet(i,buf) for i,buf in Packet.gen_packets(fh,start = start_index) if Packet.has_DSP(buf) )
    # correcting is False we are looking for a bad jerk to start correcting
    # correcting is True we are looking for a good jerk to stop correcting
    correcting = False
    for packet in dsps:
        jerk_size, jerk_time = packet.jerk_size()
        if packet.jerk_size()[0] == 0:
            continue
        #print jerk_size, jerk_time ,'\t',  packet.index, '\t', packet.Ltime, '\t', 
        if  badsirftimes.has(packet.Ltime):
            sirf_status =  'BAD'
        else:
            sirf_status =  'GOOD'
        print '<< %s JERK\t%0.1f\t%s >>' % (sirf_status, jerk_size, jerk_time)
        sys.stdout.flush()
        if ( not correcting and sirf_status == 'GOOD') or ( correcting and sirf_status == 'BAD' ):
            continue
        tears =  find_tear(fh, packet.index, jerk_size, dss, jerk_time)
        if tears is False:
            print "  Tears not found. Broadening search"
            tears =  find_tear(fh, packet.index, jerk_size, dss, jerk_time,seek_back=30000, seek_forward=60000)
        if tears is False:
            print "\tTears really not found..."
        if  tears is not False:
            if not correcting:
                print "Start correcting here..."
                for p, jerk_size in tears.itervalues():
                    need_fix.add_start(p.ds, p.chan, p)
                    print "  DS:%s CH:%s\t%0.1f\t%s " % (p.ds, p.chan, jerk_size, str(p.Ltime))
                    sys.stdout.flush()
                correcting = True
            elif correcting:
                print "End correcting here"
                for p, jerk_size in tears.itervalues():
                    need_fix.end(p.ds, p.chan, p)
                    print "  DS:%s CH:%s\t%0.1f\t%s " % (p.ds, p.chan, jerk_size, str(p.Ltime))
                    sys.stdout.flush()
                correcting = False
    if correcting:
        print 'Correcting to end of file...'
        last_pkt = [ Packet(i,buf) for i,buf in Packet.gen_reverse_packets(fh, os.fstat(fh.fileno())[ST_SIZE], 1) ][0]
        need_fix.close(last_pkt)
    return need_fix

def correct(infh, need_fix):
    origname = infh.name
    if origname[-4:] == '.ref':
        outfh = open( origname[:-4] + '.cor.ref.incomplete', 'w')
    else:
        outfh = open( origname.name + '.cor.incomplete', 'w')
    print "Writing corrected file: %s" % outfh.name
    #snag first packet for prepend header fields
    fp = [ Packet(i,buf) for i, buf in Packet.gen_packets(infh, 0, 1) ][0]
    prepend = Packet.j31SH(str(need_fix), fp.sequence, fp.Ltime, fp.sn, fp.expnum)
    outfh.write(prepend)
    sys.stdout.flush()
    for i,buf in Packet.gen_packets(infh):
        if Packet.isDT(buf):
            p = Packet(i,buf)
            if need_fix.has(p.ds, p.chan, i):
                #write corrected packet
                outfh.write(p.pack_plus_1())
            else:
                outfh.write(buf)
        else:
            outfh.write(buf)
    outfh.close()
    print "Correction complete"
    print "Renaming %s to %s" % ( outfh.name, outfh.name[:-11] )
    sys.stdout.flush()
    os.rename(outfh.name, outfh.name[:-11])
    toput = os.path.join(os.path.dirname(origname), ORIGDIR)
    if not os.path.isdir(toput):
        print "Creating directory %s" % toput
        sys.stdout.flush()
        os.mkdir(toput)
    print "Moving %s to %s" % ( origname, toput )
    sys.stdout.flush()
    os.rename(origname, os.path.join(toput, os.path.basename(origname)))
        
def test_endtime(fh):
    print ends_before_j31(fh)

def find_all_tears(fh, dss):
    '''Scans through the file reporting tears'''
    packets = ( Packet(i,buf) for i, buf in Packet.gen_packets(fh) if Packet.isDT(buf) )
    chans = dict()
    for p in packets:
        if not dss.dss.has_key(p.ds):
            continue
        srate = dss.dss[p.ds].get_rate(p.index)
        pktlength = p.num_samp / float(srate)
        nextpstart = p.Ltime + pktlength
        key = (p.ds, p.chan)
        #This is the first packet for the ds/chan add it and move on
        if not chans.has_key( (p.ds, p.chan) ):
            chans[key] = nextpstart
        #We have an expected start time compare.
        else:
            #print chans[(p.ds, p.chan)] , p.Ltime 
            should_start = chans[key]
            chans[key] = nextpstart
            if should_start != p.Ltime :
                jerk_size = p.Ltime - should_start
                print "DS:%s CHAN:%s %0.3f %s" % ( key[0], key[1], jerk_size, should_start)
                sys.stdout.flush()
    
def find_tear( fh, index , dsp_size, dss, dsp_time, seek_back = 200, seek_forward = 1000):
    #itr should be a packet iterator of only dt packets
    #will find the first tear
    #packets = ( Packet(i,buf) for i, buf in Packet.gen_packets(fh,index - (100*1024), 10000) if Packet.isDT(buf) )
    #packets = ( Packet(i,buf) for i, buf in Packet.gen_packets(fh, index - (1024*500) , 2000) if Packet.isDT(buf) )
    packets = ( Packet(i,buf) for i, buf in Packet.gen_packets(fh, index - (1024*seek_back) , seek_forward) if Packet.isDT(buf) )
    chans = dict()
    tears = dict()
    num_chans = dss.get_num_channels()
    for p in packets:
        if not dss.dss.has_key(p.ds):
            continue
        srate = dss.dss[p.ds].get_rate(p.index)
        pktlength = p.num_samp / float(srate)
        nextpstart = p.Ltime + pktlength
        key = (p.ds, p.chan)
        #This is the first packet for the ds/chan add it and move on
        if not chans.has_key( (p.ds, p.chan) ):
            chans[key] = nextpstart
        #We have an expected start time compare.
        else:
            #print chans[(p.ds, p.chan)] , p.Ltime 
            should_start = chans[key]
            chans[key] = nextpstart
            if should_start != p.Ltime :
                jerk_size = p.Ltime - should_start
                #print jerk_size
                #print "found", jerk_size, dsp_size, p.Ltime
                if Decimal("%0.3f" %jerk_size) != Decimal("%0.3f" % dsp_size) or dsp_time - (2*60) > p.Ltime or dsp_time + (15*60) < p.Ltime:
                    #print '\t', p.Ltime, jerk_size
                    #print '\t', should_start
                    continue
                #print '+++++++++DT+++++++++++++' 
                tears[key] = (p,jerk_size)
                #print "Srate", srate
                #print p
                #print 'DS', p.ds, 'CHAN', p.chan, 'SAMPS',  p.num_samp, 'FRMT', p.data_format
                #print "Next start", nextpstart
                #print
                #print "!!!!!!!Tear", p.index
                #print "\t%0.3f" % jerk_size
                #print
        if len(tears) >= num_chans:
            return tears
    return False
        
        
def get_ds(fh,start_index):
    print "Finding sample rates for data streams"
    ratetuples = [ (p.ds, p.samplerate, p.index) for p in [ Packet(i,buf) for i, buf in Packet.gen_packets(fh, start = start_index) if Packet.isEH(buf) ] ]
    dstreams = DSs()
    dstreams.populate(ratetuples)
    return dstreams      

def fix_files(files, showonly):
    bsts = BadSirfTimespans()
    for file in files:
        print
        print "<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>"
        print file
        fh = open(file, 'r')
        print "Checking if file has already had corrections applied...",
        sys.stdout.flush()
        if already_corrected(fh):
            print "File has already been corrected for j31 bug."
            sys.stdout.flush()
            fh.close()
            continue
        print "Checking end time...",
        sys.stdout.flush()
        if ends_before_j31(fh):
            print "File ends before j31. Skipping..."
            fh.close()
            continue
        print "File ends after July 31, 2008"
        #check if starts after ny 2009
        if starts_after_ny2009(fh):
            print "File starts after 2009.363, when bug stopped. Skipping..."
            fh.close()
            continue
        print "File Starts before 2009.363"
        print "Checking for bad Sirf and Garmin locks...",
        sys.stdout.flush()
        if not fixable(fh, bsts):
            print "No bad Sirf locks or a mix with Garmin locks. Skipping..."
            fh.close()
            continue
        print "File has bad sirf locks. Will operate..."
        sys.stdout.flush()
        need2correct = find_bad_packets(fh, 0, bsts, get_ds(fh, 0) )
        sys.stdout.flush()
        if len( need2correct) > 0:
            print "Corrections needed (+1):"
            print need2correct
            sys.stdout.flush()
            if showonly:
                print "Show only mode. Not applying corrections"
                sys.stdout.flush()
            else:
                correct(fh, need2correct)
        else:
            print "No corrections needed. Skipping."
        fh.close()
        print "<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>"
        sys.stdout.flush()

def testj31SH():
    payload = 'Test payload'
    print Packet.j31SH(100*payload)
def show_tears(files):
    print "Anaylizing files for tears only. No files will be corrected."
    for file in files:
        print
        print "<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>"
        sys.stdout.flush()
        print file
        fh = open(file, 'r')
        find_all_tears(fh, get_ds(fh,0))
        fh.close()
        print "<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>"
        sys.stdout.flush()

def already_corrected(fh):
    firstpacket = [Packet(i,buf) for i,buf in Packet.gen_packets(fh,0,1)][0]
    if firstpacket.is_j31SH():
        return True
    else:
        return False
        
def print_already_corrected(files):
    print "Determining if files have had corrections applied. No files will be corrected."
    for file in files:
        print
        print "<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>"
        sys.stdout.flush()
        print file
        fh = open(file, 'r')
        if already_corrected(fh):
            print "File has been corrected."
        else:
            print "File has NOT been corrected."
        fh.close()
        print "<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>"
        sys.stdout.flush()
        
if __name__ == "__main__":
    parser = optparse.OptionParser()
    parser.version = VERSION
    print "v%s" % VERSION
    parser.description = DESCRIPTION
    parser.usage = '%prog [options] list_of_.ref_files'
    parser.add_option('-s', '--show', dest='show', action='store_true',
                      help='only print corrections that would be made, do not create corrected files')
    parser.add_option('-t', '--tears', dest='tears', action='store_true',
                      help='scan file for all tears (gaps (+) or overlaps (-))\
                      no corrections are made. Tears are printed to stdout')
    parser.add_option('-p', '--prevcorrection', dest='already', action='store_true',
                      help='determines if files have been corrected applied' )
    parser.add_option('-b', '--badtimes', dest='table', action = 'store_true',
                      help='print a list of time ranges during which  Sirf clocks will produce bad time' ) 
    (options, args) = parser.parse_args()
    if options.tears:
        show_tears(args)
    elif options.already:
        print_already_corrected(args)
    elif options.table:
        print "This is a list of time spans (UTC) during which Sirf clocks will report time fast (-1 sec relative to true time.)"
        bsts = BadSirfTimespans()
        print bsts.calday_str()
    else:
        fix_files(args, options.show)