#!/usr/bin/env python
'''
Fix Sirf Problem starting on July 31 
where gps is -1 sec off on a cycle
'''

#Setup timezone
from os import environ
environ['TZ'] = '0'
import time
from decimal import *
time.tzset()

############################
#Time handling
############################
class Ltime(object):
    ''' An upgraded time object with milliseconds
    stores time in epoch for slow creation but faster comparison
    May need to turn epoch and milli into ints to prevent rounding problems
    self.epoch :: float
    refpktstamp ::  YY:DDD:HH:MM:SS.MIL
    epoch ::        float
    shstamp ::      deal with this later
    '''
    #reftek packet time format for strptime
    PKTFMT = "%y:%j:%H:%M:%S"
    SECperDAY = 86400
    SECperHOUR = 3600
    def __init__(self, pktstamp=None, epoch=None, shstamp=None):
        if not (pktstamp or epoch or shstamp):
            raise RuntimeError, "Must provide 1 form of time"
        if epoch is not None:
            self.epoch = epoch
        if pktstamp is not None:
            self.set_pktstamp(pktstamp)
        if shstamp is not None:
            self.set_shstamp(shstamp)
            
    def set_pktstamp(self, pktstamp):
        self.epoch = time.mktime( time.strptime(pktstamp[:-4], Ltime.PKTFMT) ) + float( pktstamp[-4:] ) 
    def set_shstamp(self, shstamp):
        self.epoch = time.mktime( time.strptime(shstamp, Ltime.PKTFMT) ) 
    def get_epoch(self):
        #includes milisecs
        return self.epoch
    def get_milisec(self):
        r =  self.epoch % 1.0 
        return r
    def get_struct_time(self):
        t = time.gmtime(self.epoch)
        return t
    def add_hours(self, hours):
        return Ltime( epoch = self.epoch + hours * Ltime.SECperHOUR )
    def add_days(self, days):
        return Ltime( epoch = self.epoch + days * Ltime.SECperDAY )
    def __str__(self):
        #s = "Time struct: " + str(self.timetup) + " Milisec: " + str(self.milisec)
        #s += " Epoch: "  + str( self.get_epoch() )
        s = time.strftime(Ltime.PKTFMT, self.get_struct_time())
        ms = "%0.3f" % self.get_milisec()
        s = '20' + s +  '.' + ms[-3:] 
        return s
    def calday_str(self):
        #returns a string in calendar day format
        return  time.asctime(self.get_struct_time())
    def __add__(self, seconds):
        #other must be seconds 
        return Ltime(epoch= self.epoch + seconds)
    def __eq__(self, other):
        return "%0.3f" % self.epoch == "%0.3f" % other.epoch
    def __ne__(self, other):
        return "%0.3f" % self.epoch != "%0.3f" % other.epoch
    def __lt__(self, other):
        return self.epoch < other.epoch
    def __le__(self, other):
        return self.epoch <= other.epoch
    def __gt__(self, other):
        return self.epoch > other.epoch
    def __ge__(self, other):
        return self.epoch >= other.epoch
    def __sub__(self, other):
        if isinstance( other, Ltime):
            return self.epoch - other.epoch
        if isinstance(other, int):
            return Ltime(epoch= self.epoch - other)
        
class Ltimespan(object):
    '''
    time span class
    start and end are of type Ltime
    '''
    def __init__(self, t1, t2):
        if not ( isinstance(t1,Ltime) and isinstance(t2,Ltime) ):
            raise Exception, 'Arguments must both be of type Ltime'
        if t1 < t2:
            self.start = t1
            self.end = t2
        else:
            self.start = t2
            self.end = t1
    def __str__(self):
        return str(self.start) + " - " + str(self.end)
    def calday_str(self):
        return self.start.calday_str() + " - " + self.end.calday_str()
    def has(self, t):
        # returns true if t is in time span inclusive on start not inclusive on end
        if self.start <= t and t < self.end:
            return True
        else:
            return False
class BadSirfTimespans(object):
    '''
    sequence of timespans during which a sirf lock will give bad time
    '''
    # July 31 2008 the beginging of j31 bug
    START = '08:213:00:00:00.000'
    def __init__(self, until=3):
        #Creates a list of spans up to time until (in days from now)
        self.spans = list()
        i = Ltime(pktstamp = BadSirfTimespans.START)
        now =  Ltime(epoch = time.time())
        later = now.add_days(until)
        while ( i < later):
            self.spans.append( Ltimespan( i, i.add_hours(18) ) )
            self.spans.append( Ltimespan( i.add_days(1), i.add_days(3) ) )        
            i = i.add_days(7)
    @staticmethod
    def before_j31(ltime):
        if not isinstance(ltime, Ltime):
            raise RuntimeError('function needs instance of Ltime type')
        if ltime < Ltime(pktstamp=BadSirfTimespans.START):
            return True
        else:
            return False
    def __str__ (self):
        s = ''
        for span in self.spans:
            s += str(span) + '\n'
        return  s
    def calday_str (self):
        s = ''
        for span in self.spans:
            s += str(span) + '  OR  '
            s += span.calday_str() + '\n'
            
        return  s
    def has(self, time):
        #Given time should be of Ltime type
        #returns True if time is in a bad span true if not
        inspan = [span for span in self.spans if span.has(time) ]
        if len(inspan) > 0 :
            return True
        return False
            
def timetest():
    sws = time.time()
    bst = BadSirfTimespans()
    print bst
    iters = 10000
    first = Ltime(pktstamp=BadSirfTimespans.START)
    last = Ltime(epoch=sws)
    step = (last.epoch - first.epoch) / iters
    swm = time.time()
    bad = [ lt for lt in [Ltime(epoch = t) for t in range(first.epoch, last.epoch, step)] if bst.has(lt) ]
    print "bad"
    for b in bad:
        print b
    swe = time.time()
    print "overhead: %f  inter: %f" % ( swm-sws, swe-swm)
    print sws, swm, swe
###########################
#End Time handling
###########################
    
from sys import argv
from os import fstat
from stat import ST_SIZE 
from struct import *
from itertools import *
import re

##########################
#Reftek packets
##########################
class Packet (object):
    packetHdrFmt = '2c1B1B2B6B2B2B'
    reDSPDIFF = re.compile(r'(\d{3}:\d{2}:\d{2}:\d{2})\sDSP CLOCK DIFFERENCE:\s+(-?\d+)\s+SECS')
    reSIRF = re.compile(r'EXTERNAL CLOCK TYPE: NMEA\r\n')
    reGARMIN = re.compile(r'EXTERNAL CLOCK TYPE: NMEA-Garmin\r\n')
    def __init__(self, index, buffer):
        self.index = index
        self.buffer = buffer
        self.unpack()
        self.set_SHstring()
        self.set_EH()
        self.set_DT()
    @staticmethod
    def gen_packets(fh, start=0, count=0):
        '''Returns a generator which will yield 1 packet at a time
        '''
        if start < 0:
            start = 0
        head = start
        #read forever
        if count == 0: 
            while True:
                fh.seek(head)
                index = fh.tell()
                data = fh.read(1024)
                if data == '': return
                yield index, data
                head = head + 1024
        #read count packets
        else:
            i = 0
            while i < count:
                fh.seek(head)
                index = fh.tell()
                data = fh.read(1024)
                if data == '': return
                yield index, data
                head = head + 1024
                i += 1
    @staticmethod
    def gen_reverse_packets(fh, start, count=0):
        '''Returns a generator which will yeild 1 packet at a time
        starting with the packet before start
        '''
        head = start - 1024
        #read forever
        if count == 0:
            while head >= 0:
                fh.seek(head)
                index = fh.tell()
                data = fh.read(1024)
                yield index, data
                head = head - 1024
        #read count packets
        else:
            i = 0
            while head >= 0 and i < count:
                fh.seek(head)
                index = fh.tell()
                data = fh.read(1024)
                yield index, data
                head = head - 1024
                i += 1
    @staticmethod
    def isSH(buffer):
        if buffer[:2] == 'SH':
            return True
        else:
            return False
    @staticmethod
    def isEH(buffer):
        if buffer[:2] == 'EH':
            return True
        else:
            return False
    @staticmethod
    def isDT(buffer):
        if buffer[:2] == 'DT':
            return True
        else:
            return False
    @staticmethod
    def has_DSP(buffer):
        '''
        Returns True if buffer is a packet of type SH AND
        has a DSP clock difference 
        '''
        if buffer[:2] != 'SH':
            return False
        bytecount = int("%0.2X%0.2X" % unpack('2B',buffer[12:14]) )
        shstring = buffer[24:bytecount]
        dspmatch =  Packet.reDSPDIFF.findall(shstring)
        if len(dspmatch) > 0:
            return True
        return False
    def __str__(self):
        tup = (self.index, self.ptype, self.expnum, self.sn, self.year,\
               self.day, self.hour, self.minute, self.sec, self.millisec,\
               self.bytecount, self.sequence)
        s = 'I: %9d PT: %s %02d %s 20%02d:%03d:%02d:%02d:%02d.%03d %04d %04d'
        if self.isSH(self.buffer):
            s += '\n' + self.SHstring
        return s % tup
    def print_ptype(self):
        print self.ptype
    def get_type(self):
        self.ptype = self.buffer[:2]
    def set_SHstring(self):
        if self.ptype == 'SH':
            self.SHstring = self.buffer[24:self.bytecount]
    def set_EH(self):
        if self.ptype != 'EH':
            return False
        self.event_num = "%0.2X%0.2X" % unpack( '2B', self.buffer[16:18] )
        self.ds = "%0.1X" % unpack('B', self.buffer[18] )
        self.samplerate = self.buffer[88:92]
    def set_DT(self):
        if self.ptype != 'DT':
            return False
        self.ds = '%0.1X' % unpack('B', self.buffer[18])
        self.chan = '%0.1X' % unpack('B', self.buffer[19])
        self.num_samp = int( "%0.2X%0.2X" % unpack( '2B', self.buffer[20:22] ) )
        self.data_format = '%0.1X' % unpack('B', self.buffer[23])
                                   
    def set_DSP_diff(self):
        if self.ptype == 'SH':
            match =  reDSPDIFF.findall(p.SHstring)
            self.DSP_diff = match
    def unpack(self):
        '''parses a 1024 byte reftek packet header'''
        if len(self.buffer) != 1024:
            raise RuntimeError, "Packet not 1024 bytes!"
        tup = unpack(self.packetHdrFmt, self.buffer[:16])
        self.ptype = tup[0] + tup[1]
        self.expnum = int("%0.2X" % tup[2])
        self.year = int("%0.2X" %tup[3])
        self.sn = "%0.2X%0.2X" % (tup[4] , tup[5] )
        self.time = "%0.2X%0.2X%0.2X%0.2X%0.2X%0.2X" % tup[6:12]
        self.day, self.hour, self.minute, self.sec, self.millisec = \
            int(self.time[:3]),int(self.time[3:5]),int(self.time[5:7]),int(self.time[7:9]),int(self.time[9:])
        self.bytecount = int("%0.2X%0.2X" % tup[12:14])
        self.sequence = int("%0.2X%0.2X" % tup[14:16])
        self.Ltime = Ltime('%02d:%03d:%02d:%02d:%02d.%03d' % (
            self.year, self.day, self.hour, self.minute, self.sec, self.millisec))
    def has_sirf_lock(self):
        '''Returns True if buffer has a sirf lock
        '''
        if self.ptype != 'SH':
            return False
        sirfmatch = self.reSIRF.search(self.SHstring)
        if sirfmatch is None:
            return False
        else:
            return True
    def has_garmin_lock(self):
        if self.ptype != 'SH':
            return False
        gmatch = self.reGARMIN.search(self.SHstring)
        if gmatch is None:
            return False
        else:
            return True
    def jerk_size(self):
        '''
        SH that has a DSP CLOCK DIFFERENCE line
        returns (size of jerk , timestamp)
        '''
        if not self.ptype == 'SH':
            return False
        match =  self.reDSPDIFF.findall(self.SHstring)
        return ( int(match[-1][1]), Ltime(shstamp="%0.2d:%s" % (self.year, match[-1][0]) ) )
##########################
#End Reftek packets
##########################
###########################
#Data Stream stuff
###########################
class DSs (object):
    ''' Multiple DSs'''
    def __init__(self):
        self.dss = dict()
    def __str__(self):
        ret = ''
        for ds in self.dss.itervalues():
            ret += str(ds) + "\n"
        return ret
    def get_num_channels(self):
        #we assume there are 3 chans per stream
        return (len(self.dss) * 3)
    def populate(self, iterator):
        '''iterator = (ds, sr, index) in order found in file'''
        for ds, sr, index in iterator:
            if not self.dss.has_key(ds):
                self.dss[ds] = DS(ds)
            self.dss[ds].add_index(index, sr)
class DS (object):
    def __init__(self, stream):
        self.stream = int(stream)
        self.index_rate = list()
    def __str__(self):
        ret = str(self.stream) + '\n'
        for index, rate in self.index_rate:
            ret += '\t' + str(index) + '\t' + str(rate) + '\n'
        return ret
    def add_index(self, index, rate):
        rate = int(rate)
        self.index_rate.append((index, rate))
    def get_rate(self, position):
        for index, rate in self.index_rate:
            if position >= index:
                return rate
#############################        
#End Data Stream
#############################
def ends_before_j31(fh):
    file_size = fstat(fh.fileno())[ST_SIZE]
    last_pkt = [ Packet(i,buf) for i,buf in Packet.gen_reverse_packets(fh, file_size, 1) ][0]
    if BadSirfTimespans.before_j31(last_pkt.Ltime):
        return True
    else:
        return False

def fixable(fh,bsts):
    #returns true if finds a bad sirf lock and no subsequent garmin locks
    shpackets = ( Packet(i,buf) for i, buf in Packet.gen_packets(fh) if Packet.isSH(buf) )
    badsirflock = False
    for shp in shpackets:
        if shp.has_sirf_lock() and bsts.has(shp.Ltime):
            badsirflock = True
            break
    if not badsirflock:
        return False
    for shp in shpackets:
        if shp.has_garmin_lock():
            return False
    return True

def print_packets(fh, index=0, count=0):
    #just print all the packet in a file
    packets = ( Packet(i,buf) for i, buf in Packet.gen_packets(fh, index, count) )
    for p in packets:
        print p
    
def find_bad_packets(fh, start_index, badsirftimes, dss):
    '''Returns a list of indexes of dt packets that need a +1 shift
    '''
    #first find the DSPs
    dsps = ( Packet(i,buf) for i,buf in Packet.gen_packets(fh,start = start_index) if Packet.has_DSP(buf) )
    for packet in dsps:
        jerk_size, jerk_time = packet.jerk_size()
        if packet.jerk_size()[0] == 0:
            continue
        #print jerk_size, jerk_time ,'\t',  packet.index, '\t', packet.Ltime, '\t', 
        if  badsirftimes.has(packet.Ltime):
            sirf_status =  'BAD'
        else:
            sirf_status =  'GOOD'
        print '<< %s JERK\t%0.1f\t%s >>' % (sirf_status, jerk_size, jerk_time)
        tears =  find_tear(fh, packet.index, jerk_size, dss, jerk_time)
        if tears == False:
            print "  Tears not found. Broading search"
            tears =  find_tear(fh, packet.index, jerk_size, dss, jerk_time,seek_back=30000, seek_forward=60000)
        if tears == False:
            print "\tTears really not found..."
        if not tears == False:
            for p, jerk_size in tears.itervalues():
                print "  DS:%s CH:%s\t%0.1f\t%s " % (p.ds, p.chan, jerk_size, str(p.Ltime))
def test_endtime(fh):
    print ends_before_j31(fh)

def find_tear( fh, index , dsp_size, dss, dsp_time, seek_back = 200, seek_forward = 1000):
    #itr should be a packet iterator of only dt packets
    #will find the first tear
    #packets = ( Packet(i,buf) for i, buf in Packet.gen_packets(fh,index - (100*1024), 10000) if Packet.isDT(buf) )
    #packets = ( Packet(i,buf) for i, buf in Packet.gen_packets(fh, index - (1024*500) , 2000) if Packet.isDT(buf) )
    packets = ( Packet(i,buf) for i, buf in Packet.gen_packets(fh, index - (1024*seek_back) , seek_forward) if Packet.isDT(buf) )
    chans = dict()
    tears = dict()
    num_chans = dss.get_num_channels()
    for p in packets:
        srate = dss.dss[p.ds].get_rate(p.index)
        pktlength = p.num_samp / float(srate)
        nextpstart = p.Ltime + pktlength
        key = (p.ds, p.chan)
        #This is the first packet for the ds/chan add it and move on
        if not chans.has_key( (p.ds, p.chan) ):
            chans[key] = nextpstart
        #We have an expected start time compare.
        else:
            #print chans[(p.ds, p.chan)] , p.Ltime 
            should_start = chans[key]
            chans[key] = nextpstart
            if should_start != p.Ltime :
                jerk_size = p.Ltime - should_start
                #print jerk_size
                #print "found", jerk_size, dsp_size, p.Ltime
                if Decimal("%0.3f" %jerk_size) != Decimal("%0.3f" % dsp_size) or dsp_time - (2*60) > p.Ltime or dsp_time + (15*60) < p.Ltime:
                    print '\t', p.Ltime, jerk_size
                    #print '\t', should_start
                    continue
                #print '+++++++++DT+++++++++++++' 
                tears[key] = (p,jerk_size)
                #print "Srate", srate
                #print p
                #print 'DS', p.ds, 'CHAN', p.chan, 'SAMPS',  p.num_samp, 'FRMT', p.data_format
                #print "Next start", nextpstart
                #print
                #print "!!!!!!!Tear", p.index
                #print "\t%0.3f" % jerk_size
                #print
        if len(tears) >= num_chans:
            return tears
    return False
        
        
def get_ds(fh,start_index):
    print "Finding sample rates for data streams"
    ratetuples = [ (p.ds, p.samplerate, p.index) for p in [ Packet(i,buf) for i, buf in Packet.gen_packets(fh, start = start_index) if Packet.isEH(buf) ] ]
    dstreams = DSs()
    dstreams.populate(ratetuples)
    return dstreams      

if __name__ == "__main__":
    bsts = BadSirfTimespans()
    if len(argv) <= 1:
        print "No files given. Exiting"
        print "Usage: %s file1 file2 ...fileN" % argv[0]
    for file in argv[1:]:
        print
        print "<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>"
        print file
        fh = open(file, 'r')
        print "Checking end time...",
        if ends_before_j31(fh):
            print "File ends before j31. Skipping..."
            fh.close()
            continue
        print "File ends after July 31, 2008"
        print "Checking for bad Sirf and Garmin locks...",
        if not fixable(fh, bsts):
            print "No bad Sirf locks or a mix with Garmin locks. Skipping..."
            fh.close()
            continue
        print "File has bad sirf locks. Will operate..."
        find_bad_packets(fh, 0, bsts, get_ds(fh, 0) )
        fh.close()
        print "<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>"