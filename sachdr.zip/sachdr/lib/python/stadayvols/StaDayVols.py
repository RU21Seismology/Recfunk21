#!/usr/bin/env picpython
'''
Library for handling descriptions of sta day volumes for SEED

'''
import commands, os.path, re

PROG_VERSION = '2008.080'

class Net(object):
    def __init__(self, net=None, DB=None):
        self.net = net
        self.stas = {}
        if DB:
            self.popBycssDB(DB)
    def __str__(self):
        p = ''
        p += str(self.net) + '\n'
        for sta in self.stas.values():
            p += sta.__str__()
        return p
    def __len__(self):
        return len(self.stas)
    def addSta(self, staname):
        if self.stas.has_key(staname):
            pass
        else:
            self.stas[staname] = Station(staname)
    def addChan(self,sta,chan,loc,ondate,offdate):
        self.addSta(sta)
        self.stas[sta].addChan(chan,loc,ondate,offdate)
    def NumChans(self):
        n = 0
        for s in sta:
            n += s.len()
        return n
    def popBycssDB(self, DB):
        COMMAND = 'dbjoin %s.sitechan snetsta |dbjoin - :chan :sta schanloc | \
                    dbselect - snet sta fchan ondate offdate loc' % DB
        status, output = commands.getstatusoutput(COMMAND)
        if status != 0:
                raise RuntimeError, 'Command: "%s" failed with status %d' % (COMMAND,status)
        for line in output.splitlines():
            f = line.split()
            if len(f) == 6:
                net, sta, chan, ondate, offdate, loc = f
            elif len(f) == 5:
                net, sta, chan, ondate, offdate = f
                loc = ''
            else:
                raise RuntimeError, "Error parsing dbjoin/select line '%s'" % line
            self.addChan(sta,chan,loc,ondate,offdate)
        self.net = net
    def chansOfDay(self, sta, date):
        '''sta is string date is Jday object
        Returns a lis of chan objects for station day or None'''
        return self.stas[sta].chansOfDay(date)
    def filesOfDay(self, sta, date):
        ''' sta is string date is JDay object'''
        filenames = []
        chans = self.chansOfDay(sta,date)
        for chan in chans:
            filenames.append(self.genFileName(self.stas[sta],chan,date))
        return filenames
    def genFileName(self, sta, chan, date):
        '''sta.net.loc.chan.year.day'''
        s = '%s.%s.%s.%s.%s' % (sta.sta, self.net, chan.loc, chan.chan, date.__str__())
        return s
    
class Station(object):
    def __init__(self, sta):
        self.sta = sta
        # self.chans channelname : channel object
        self.chans = {}
    def __str__(self):
        p = ''
        p += '  ' + self.sta + '\n'
        for chan in self.chans.values():
            p += chan.__str__()
        return p
    def __len__(self):
        return len(self.chans)
    def addChan(self,chan,loc,ondate,offdate):
        if self.chans.has_key(chan):
            self.chans[chan].trange.addSpan(ondate,offdate)
        else:
            self.chans[chan] = Channel(chan,loc,ondate,offdate)
    def chansOfDay(self, date):
        #returns list of Channel objects for given day
        haveday = []
        for chan in self.chans:
            if self.chans[chan].hasDay(date):
                haveday.append(self.chans[chan])
        return haveday
    
class Channel(object):
    def __init__(self,chan,loc,ondate,offdate):
        self.chan = chan
        self.loc = loc
        self.trange= TimeRanges(ondate,offdate)
    def __str__(self):
        if self.loc: loc=self.loc
        else:loc=''
        return '    %3.3s.%2.2s %s\n' % (self.chan, loc, self.trange.__str__())
    def hasDay(self,date):
        if not isinstance(date,Jday): date = Jday(date)
        return self.trange.has_day(date)
        
class Jday(object):
    def __init__(self,sday=None,year=None,day=None):
        '''
        Call with either string s=YYYYDDD OR
            int year AND int day
        '''
        if sday:
            self.year = int(sday[:4])
            self.day = int(sday[4:])
        elif year and day:
            self.year = int(year)
            self.day = int(day)
        else:
            raise RuntimeError, "Could not create Jday type from %s,%d,%d" %(sday,year,day)
    def __str__(self):
        return  '%04.4d.%03.3d' % (self.year,self.day)
    def __eq__(self,other):
        if self.year == other.year and self.day == other.day: return True
        else: return False
    def __ne__(self,other):
        return not self == other
    def __lt__(self,other):
        if self.year < other.year: return True
        elif self.year == other.year and self.day < other.day: return True
        else: return False
    def __le__ (self,other):
        return self < other or self == other
    def __gt__ (self,other):
        if self.year > other.year: return True
        elif self.year == other.year and self.day > other.day: return True
        else: return False
    def __ge__(self,other):
        return self > other or self == other
                
class TimeRanges (object):
    '''List of TimeSpan objects'''
    def __init__(self, d1,d2):
        self.Rlist = []
        self.Rlist.append(TimeSpan(d1,d2))
    def __str__(self):
        p = ''
        for ts in self.Rlist:
            p += ts.__str__() + " , "
        return p[:-3]
    def addSpan(self,d1,d2):
        self.Rlist.append(TimeSpan(d1,d2))
    def has_day(self,day):
        for ts in self.Rlist:
            if ts.has_day(day):
                return True
        return False
        
        
class TimeSpan(object):
    def __init__(self,d1,d2):
        ''' d1 and d2 should be of type Jday'''
        if not isinstance(d1,Jday): d1 = Jday(d1)
        if not isinstance(d2,Jday): d2 = Jday(d2)
        if d1 < d2:
            self.start = d1
            self.end = d2
        else:
            self.start = d2
            self.end = d1
    def __str__(self):
        return '%s - %s' % (self.start.__str__(), self.end.__str__())
    def has_day(self,day):
        if not isinstance(day,Jday): day = Jday(day)
        if self.start <= day and day <= self.end:
            return True
        else:
            return False
        
class MSeedDict(dict):
    def __init__(self,**kwargs):
        #dict of MSeed objects -> basename : MSeed obj
        dict.__init__(self,kwargs)
    def __str__(self):
        return str([f.__str__() for f in self.values()])
    def popByDir(self,dir):
        os.path.walk(dir, self.walkfunc, None)
    def walkfunc(self, arg, dirname, names):
        for file in names:
            if MSeed.isMseed(file) :
                self[os.path.basename(file)] = MSeed(os.path.abspath(os.path.join(dirname,file)))
        
class MSeed(object):
    '''Basic Miniseed file metadata extracted from filename'''
    RE = re.compile(r'\A(.*)\.([A-Z][A-Z0-9])\.(.*)\.([A-Z][A-Z][A-Z])\.([0-9]{4})\.([0-9]{3})')
    @staticmethod
    def isMseed(filename):
        if MSeed.RE.match(os.path.basename(filename)):
            return True
        else:
            return False
    def __init__(self,filename):
        self.fullname = os.path.abspath(filename)
        self.dir, self.basename = os.path.split(filename)
        m = MSeed.RE.match(self.basename)
        if m is None: print "not a ms"; return None
        self.sta, self.net, self.loc, self.chan, year, day = m.groups()
        self.date = Jday(year=year, day=day)
    def __str__(self):
        return self.fullname

class StaDayVolDict(dict):
    def __init__(self,**kwargs):
        dict.__init__(self,kwargs)
    def __str__(self):
        p = ''
        tl = list(self.keys())
        tl.sort()
        for key in tl:
            p += '\t%s:\n' % self[key].name
            p += self[key].__str__()
        return p
class StaDayVol(list):
    def __init__(self,name, msfilelist):
        #list of msobj
        list.__init__(self,msfilelist)
        self.name = name
    def __str__(self):
        p = '\t\tCOMPLETE\n'
        self.sort()
        for file in self:
            p += '\t\t%s\n' % file.basename
        return p
    def write(self, outputdir, prefix=''):
        if prefix != '':
            prefix = str(prefix) + '.'
        print "Creating %s" %  prefix + self.name + '.seed'
        outputdir = os.path.abspath(outputdir)
        if not os.path.isdir(outputdir):
            os.mkdir(outputdir)
        outfilename = os.path.join(outputdir, prefix + self.name + '.seed')
        outfile = open(outfilename,'w',-1)
        for ms in self:
            print "\tadding file %s" % ms.basename
            infile = open(ms.fullname,'r',-1)
            outfile.write(infile.read())
            infile.close()
        outfile.close()
        return os.path.basename(outfilename)
            
class incompStaDayVol(object):
    def __init__(self,name, mshaslist, missinglist):
        self.name = name
        #list of msobj
        self.mshaslist = mshaslist
        #list of filename strings
        self.missinglist = missinglist
    def __str__(self):
        p = '\t\tINCOMPLETE\n\t\t  HAVE:\n'
        self.mshaslist.sort()
        for file in self.mshaslist:
            p += '\t\t%s\n' % file.basename
        p += '\t\t  MISSING:\n'
        self.missinglist.sort()
        for file in self.missinglist:
            p += '\t\t%s\n' % file
        return p
    def write(self, outputdir, prefix=''):
        if prefix != '':
            prefix = str(prefix) + '.'
        print "Creating %s" % prefix + self.name + '.seed'
        outputdir = os.path.abspath(outputdir)
        if not os.path.isdir(outputdir):
            os.mkdir(outputdir)
        outfile = open(os.path.join(outputdir, prefix + self.name + '.seed'),'w',-1)
        for ms in self.mshaslist:
            print "\tadding file %s" % ms.basename
            infile = open(ms.fullname,'r',-1)
            outfile.write(infile.read())
            infile.close()
        outfile.close()
def NetvsFiles(Net, msdict):
    Vols = StaDayVolDict()
    iVols = StaDayVolDict()
    while(True):
        try:
            msname,msobj = msdict.popitem()
        except KeyError:
            break
        try:
            volname = '%s.%s.%s' % ( msobj.net, msobj.sta, msobj.date.__str__())
        except:
            print "can't make volname from %s" % msname
        shouldfiles = Net.filesOfDay(msobj.sta,msobj.date)
        if msname not in shouldfiles:
            print "*** File %s NOT described in db ***" % msname
            continue
        has = [msobj]
        shouldfiles.remove(msname)
        missing = []
        for should in shouldfiles:
            if msdict.has_key(should):
                has.append(msdict[should])
                del msdict[should]
            else:
                missing.append(should)
        if len(missing) == 0 :
            Vols[volname] = StaDayVol(volname,has)
        else:
            iVols[volname] = incompStaDayVol(volname,has,missing)
    return Vols, iVols
            
        
if __name__ == "__main__":
    description ='%s: Determines what files in indir can create complete Station Day Volumes.\
 The channels needed for completeness are taken from the css db "db" which must\
 have sitechan, snetsta, and chanloc tables. If outdir is given; complete station day volumes will\
 be created in directory outdir. If -i is used incomplete station day volumes will be created as \
 well.' % PROG_VERSION
    import optparse
    from sys import argv
    usage = "%s [-v -o ouptdir -i] -d db -f indir" % argv[0]
    op = optparse.OptionParser(description=description)
    op.add_option('-v', action='store_true', dest='verbose', help="Verbose; will also describe complete Vols")
    op.add_option('-d', action='store', type='string', dest='db', help='CSS database to use for station description')
    op.add_option('-f', action='store', type='string', dest='indir', help="Dir to search for MSEED files")
    op.add_option('-o', action='store', type='string', dest='outdir', help="Dir to place created vols, will be created if doesn't exist")
    op.add_option('-i', action='store_true', dest='create_incomplete', help="Used with -o, will also create incomplete vols from files that exist")
    options, args = op.parse_args()
    net = Net(DB=options.db)
    print '*** db: %s describes %d stations ***' % (options.db, len(net))
    dir = options.indir
    msdict = MSeedDict()
    msdict.popByDir(dir)
    print '*** %d Files found in %s ***' % (len(msdict), options.indir)
    vols, ivols = NetvsFiles(net,msdict)
    if options.verbose:
        print "*** Full Volumes: ***"
        print vols
    print "*** Incomplete Volumes: ***"
    print ivols
    print "*** Can build %d Complete volumes ***" % len(vols)
    if options.outdir:
        #complete volumes
        print "*** Creating complete volumes in %s ***" % options.outdir
        for vol in vols.values():
            vol.write(options.outdir)
        #incomplete volumes
        if options.create_incomplete:
            print "*** Creating INcomplete volumes is %s ***" % options.outdir
            for vol in ivols.values():
                vol.write(options.outdir)
        
