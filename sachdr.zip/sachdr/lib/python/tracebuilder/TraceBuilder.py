#!/usr/bin/env python

#
#    A GUI wrapper around 125_segy.  Tested with 125_segy vdebug6
#
#    Steve Azevedo, Nov 2000
#

#   PROG_VERSION set in tracebuilder

from Tkinter import *
import string
import time
import os
import os.path
#   Caution: waitpid is unix specific
from os import popen, getcwd, fork, execvp, kill, waitpid, WNOHANG, close
from FileDialog import *
import tkMessageBox

TRUE = (1 == 1)
FALSE = (0 == 1)

#
#    Over ride some methods in FileDialog so we only select directories
#
class DirectoryDialog (FileDialog) :
    def __init__ (self, root) :
        FileDialog.__init__ (self, root)

    #   Only allow selection of directories (single click)
    def files_select_event (self, e) :
        pass
    #   Double click
    def files_double_event (self, e) :
        pass

    #   Make sure it's a directory and accessable
    def ok_command (self) :
        file = self.get_selection ()
        if not os.path.isdir (file) :
            if not os.access (file, R_OK) :
                self.root.bell ()
                file = None
        
        self.quit (file)

#
#    A simple message  bar class
#
class MessageBar (Frame) :
    def __init__ (self, root, width = 40) :
        self.root = root
        self.width = width
        apply (Frame.__init__, (self, root))
        self.message = Label (self,
                             height = 1,
                             width = self.width,
                             font = (('MS', 'Sans', 'Serif'), '10'),
                             relief = FLAT)
        self.message.pack ()

    def set (self, mes) :
        self.message.configure (text = mes)
        self.root.update_idletasks ()

#
#    The GOD class
#
class TraceBuilder (Frame) :
    def __init__ (self, root) :
        self.root = root
        apply (Frame.__init__, (self, root))
        self.root.resizable (0, 0)
        #    TRD file search path
        self.path = self.prev = None
        #    Output path
        self.out = getcwd ()
        self.havePath = FALSE
        #    List of files found at last run
        self.files = []
        #    Current PID of process spawning 125_segy
        self.curPid = None
        #    Time correction pid
        self.tcPid = None
        #self.id = None
        self.timeCorrect = 0
        self.pcfName = '125_SEGY.PCF'

        #
        #    Set up File menu
        #
        self.menuBar = Frame (self)
        self.menuBar.pack (fill = X)
        self.fileMenu = Menubutton (self.menuBar, text = 'File')
        self.fileMenu.pack (side = LEFT)
        self.fileMenu.choices = Menu (self.fileMenu)

        self.optionsMenu = Menubutton (self.menuBar, text = 'Options')
        self.optionsMenu.pack (side = LEFT)
        self.optionsMenu.choices = Menu (self.optionsMenu)

        #    Output directory structure menu
        self.structVar = IntVar ()
        self.optionsMenu.choices.outputStructure = \
                                               Menu (self.optionsMenu.choices)
        self.optionsMenu.choices.outputStructure.add_radiobutton (
            label = 'None', variable = self.structVar, value = 1)
        self.optionsMenu.choices.outputStructure.add_radiobutton (
            label = 'YYYY_DDD', variable = self.structVar, value = 2)
        self.optionsMenu.choices.outputStructure.add_radiobutton (
            label = 'YYYY_DDD/HH', variable = self.structVar, value = 3)
        self.optionsMenu.choices.outputStructure.add_radiobutton (
            label = 'YYYY_DDD/HH_MM', variable = self.structVar, value = 4)
        self.optionsMenu.choices.outputStructure.add_radiobutton (
            label = 'YYYY_DDD/HH_MM_SS', variable = self.structVar, value = 5)
        #    Default to minute sub-directories
        self.structVar.set (4)
        
        #    Output file format
        self.formatVar = IntVar ()
        self.optionsMenu.choices.outputFormat = Menu (self.optionsMenu.choices)
        self.optionsMenu.choices.outputFormat.add_radiobutton (
            label = '32 bit IEEE', variable = self.formatVar, value = 1)
        self.optionsMenu.choices.outputFormat.add_radiobutton (
            label = '32 bit INT', variable = self.formatVar, value = 2)
        #    Default to 32 bit int
        self.formatVar.set (2)

        #    Raw file search path
        self.fileMenu.choices.add_command (label = 'Input paths...',
                                           command = self.getPath)

        #    RSY file output path
        self.fileMenu.choices.add_command (label = 'Output path...',
                                           command = self.getOut)

        self.optionsMenu.choices.add_cascade (
            label = 'Output Structure',
            menu = self.optionsMenu.choices.outputStructure)

        self.optionsMenu.choices.add_cascade (
            label = 'Output Format',
            menu = self.optionsMenu.choices.outputFormat)

        self.fileMenu.choices.add ('separator')
        self.optionsMenu.choices.add ('separator')

        #   Time correction menu
        self.timeCorrectVar = IntVar ()
        self.optionsMenu.choices.add_checkbutton (label = '   Time correct',
                                                  variable = \
                                                  self.timeCorrectVar,
                                                  command = self.getCorrection)
        self.timeCorrectVar.set (0)

        self.fileMenu.choices.add_command (label = 'Quit',
                                           command = self.root.quit)

        self.fileMenu['menu'] = self.fileMenu.choices
        self.optionsMenu['menu'] = self.optionsMenu.choices

        self.menuBar.tk_menuBar (self.fileMenu)
        self.optionsMenu.tk_menuBar (self.optionsMenu)

        #
        #    Search path entry widget
        #
        self.pathFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        self.pathFrame.pack (side = TOP)
        self.searchPath = StringVar ()

        self.searchEntry = Entry (self.pathFrame,
                                  textvariable = self.searchPath,
                                  width = 40)
        self.searchEntry.bind ('<Return>', self.setPath)
        self.searchEntry.pack (side = TOP)

        Label (self.pathFrame, text = 'TRD file search path').pack (side = TOP)

        #
        #    Message bar
        #
        self.message = MessageBar (self)
        self.message.pack (side = TOP)

        #
        #    Buttons
        #
        self.buttonFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        self.buttonFrame.pack (side = TOP, fill = X)
        self.quitButton = Button (self.buttonFrame,
                                  text = 'Quit',
                                  relief = GROOVE,
                                  borderwidth = 2,
                                  command = self.goByeBye)
        self.quitButton.pack (side = LEFT)
        self.cancelButton = Button (self.buttonFrame,
                                    text = 'Cancel',
                                    relief = GROOVE,
                                    borderwidth = 2,
                                    command = self.cancel)
        
        self.runButton = Button (self.buttonFrame,
                                 text = 'Run',
                                 relief = GROOVE,
                                 borderwidth = 2,
                                 command = self.runWhat)
        self.runButton.pack (side = RIGHT)
        self.cancelButton.pack (side = RIGHT)
        
    #   Set variable that controls time corrections
    def getCorrection (self) :
        self.timeCorrect =  self.timeCorrectVar.get ()
        
    #    Set path using entry widget
    def setPath (self, e) :
        self.havePath = FALSE
        n = self.searchEntry.get ()
        flds = string.split (n, ':')
        allDir = TRUE

        for i in flds :
            if not os.path.isdir (i) :
                allDir = FALSE

        self.searchEntry.delete (0, END)
        if allDir or n == '' :
            self.path = self.prev = n
            self.searchPath.set (n)
            if n != '' :
                self.havePath = TRUE
            else :
                self.path = self.prev = None

    #    Set path using file dialog
    def getPath (self) :
        fd = DirectoryDialog (self.root)
        if self.prev != None :
            self.prev = self.path + ':'

        self.path = fd.go (dir_or_file = '/')
        if self.path != None :
            if self.prev == None :
                self.prev = ''
            self.searchEntry.delete (0, END)
            self.path = self.path[:-1]
            self.path = self.prev + self.path
            self.prev = self.path
            self.searchPath.set (self.path)
            self.havePath = TRUE
            
    #    Set out path using file dialog
    def getOut (self) :
        fd = DirectoryDialog (self.root)
        
        self.out = fd.go ()
        if self.out == None :
            self.out = getcwd ()
                        
        self.message.set ("Output path: " + self.out)

    def goByeBye (self) :
        self.cancel ()
        self.root.quit ()

    #    Kill 125_segy process
    def cancel (self) :
        if self.curPid != None :
            self.message.set ("Scheduling to kill 125_segy PID: "
                              + str (self.curPid))
            kill (int (self.curPid), 9)
            self.cirPid = None

        if self.tcPid != None :
            self.message.set ("Scheduling to kill clockcor PID: "
                              + str (self.tcPid))
            kill (int (self.tcPid), 9)
            self.tcPid = None

    #    Get command needed by execvp to run 125_segy
    def r125 (self, file) :
        p = ('-P0', '-P1', '-P2', '-P3', '-P4')
        f = ('-F0', '-F1')
        s = self.structVar.get ()
        o = self.formatVar.get ()
        command = ('125_segy',
                   str (file),
                   str (self.out),
                   str (p[int (s) - 1]),
                   str (f[int (o) - 1]))
        return ('125_segy', command)

    def doUpdate (self) :
        self.root.update_idletasks ()
        self.id = self.root.after (100, self.doUpdate)

    #    Set up and run qft and 125_segy
    def run (self) :
        if self.path == None :
            tkMessageBox.showinfo (
                message = "No search path or already running!")
            return
        self.cancel ()
        self.files = []
        #    Qft search command
        command = "qft -l -t -d " + self.path
        self.message.set (command)
        rh = popen (command)
        while 1 :
            line = rh.readline ()
            if not line :
                break
            flds = string.split (line, '\t')
            self.files.append (flds[2])

        self.message.set ("Extracting from %d files" % len (self.files))
        self.path = self.prev = None

        #    Create lock file here
        print 'Creating lock file...'
        os.open ('125_segy..LCK', os.O_CREAT)

        fpid = fork ()
        if fpid == 0 :
            #   Loop through TRD files
            for file in self.files :
                prog, com = self.r125 (file)
                #base = os.path.basename (file)
                #self.message.set ("Expanding: " + base)
                pid = fork ()
                if pid == 0 :
                    try :
                        execvp (prog, com)
                    except :
                        print "Error: 125_segy"
                        print com
                else :
                    waitpid (int (pid), 0)

            #    Remove lock file here
            print 'Removing lock file...'
            os.unlink ('125_segy..LCK')
            
            os._exit (0)
            #self.message.set ('Done!')

        else :
            self.curPid = fpid
            
    def doTimeCorrect (self) :
        filesRSY = []
        #    Qft search command (find RSY files)
        command = "qft -l -r -d " + self.out
        self.message.set (command)
        rh = popen (command)
        while 1 :
            line = rh.readline ()
            if not line :
                break
            flds = string.split (line, '\t')
            filesRSY.append (flds[2])

        rh.close ()

        blob = ''
        for file in filesRSY :
            #base = os.path.basename (file)
            blob = blob + ' ' + file

        here = os.getcwd ()
        os.chdir (self.out)
        command = "clockcor -Q " + self.pcfName
        command = command + " " + blob + " 2>&1"
        #print command
        rh = popen (command)
        wh = open ('clockcor.log', 'a')

        while 1 :
            line = rh.readline ()
            if not line :
                break
            wh.write (line)
            print line,

        rh.close ()
        wh.close ()
        os.chdir (here)

            
    def runWhat (self) :
        self.run ()

        if self.timeCorrect :
            fpid = fork ()
            if fpid == 0 :

                #    Wait for lock file here
                while os.path.exists ('125_segy..LCK') :
                    time.sleep (2)
                print 'Starting time corrections...',
                self.doTimeCorrect ()
                print 'Done'
                os._exit (0)
            else :
                self.tcPid = fpid
                self.message.set ('Extracting with time corrections...')
        else :
            self.message.set ('Extracting without time corrections...')
                

if __name__ == '__main__' :
    root = Tk ()
    root.title ('TraceBuilder')
    m = TraceBuilder (root)
    m.pack ()
    root.mainloop ()







