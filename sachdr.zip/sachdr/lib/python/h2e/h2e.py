#!/usr/bin/env python

import sys, time, string, os

class TimeDoy :
    def __init__ (self) :
        self.days_in_month = (31,28,31,30,31,30,31,31,30,31,30,31,31)
        self.days_in_month_leap = (31,29,31,30,31,30,31,31,30,31,30,31,31)

    def is_leap_year (self, year) :
        return (year % 4 == 0 and year % 100 != 0 or year % 400 == 0)

    def getMonthDay (self, year, doy) :
        if self.is_leap_year (year) :
            days_in_month = self.days_in_month_leap
        else :
            days_in_month = self.days_in_month
        totalDays = 0
        month = 0
        day = 0
        for i in range (12) :
            totalDays = totalDays + days_in_month[i]
            #print totalDays
            if totalDays > (doy - 1) :
                totalDays = totalDays - days_in_month[i]
                #   Month = 0-11
                month = i
                day = doy - totalDays
                break

        return (month, day)
        


if __name__ == "__main__" :
    if len (sys.argv) != 2 :
        print "USAGE: h2e YYYY:JJJ:HH:MM:SS"
        sys.exit ()
    os.environ['TZ'] = 'UTC'
    time.tzset ()
    s = sys.argv[1]
    s = s.replace (',', ':')
    st = s.split (':')
    tm = TimeDoy ()
    mo, da = tm.getMonthDay (int (st[0]), int (st[1]))
    #print mo, da
    epoch = time.mktime ([int (st[0]),
                          int (mo) + 1,
                          int (da),
                          int (st[2]),
                          int (st[3]),
                          int (st[4]),
                          0,
                          int (st[1]),
                          0])
    print int (epoch)
