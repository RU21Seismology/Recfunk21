#!/usr/bin/env picpython

# gui to find and review mseed files
# author: bcb
#
##########################
# modification
# author: bcb
# date 2009.188
#
# bug fix: 
# modified to no longer create threads.  Commented out all the lines with threading calls so this can
# later be noted where would be useful to add it in again.  The reason for this is because everytime a thread
# was used it was defined, started and then joined immediately.  Therefore, there was no reason for them
# to be threads at all, and it was breaking with Tk because the functions that were the targets for the threads
# weren't actually Tk/thread safe.

VERSION = "2009.188"

import Pmw
from Tkinter import *
from FileDialog import *

from operator import mod
from struct import pack
from getopt import getopt
import os, sys, string, tkFileDialog, time
from LibTrace import *
#import threading
from glob import glob

SPACE = " "
DATALOC=""

#vars used for batchmode

BATCHMODE=0

def Usage(err=''):
	print err
	print "Usage\ckMseed \nckMseed -#\nckMseed -h\nckMseed [-d DataDirs] [-s] [-v]"
	print "       -d DataDirs - colon separated list of data directories [default: cwd]"
	print "       -h Usage"
	print "       -s Simple mode. Check and report endianess of first fixed header only"
	print "       -v Check and report endianess of first fixed header and determine"
	print "           start times for first and last block of mseed file"
	print "       -V Read all header blockettes"
	print "       NOTE: -s, -v, & -V are mutually exclusive.-V supercedes -v supercedes -s"
	os._exit(0)

# get commandline args
try:
	opts, pargs = getopt(sys.argv[1:], 'hsvV#d:')
	
except:
	err="\nERROR: Invalid command line usage\n"
	Usage(err)
else:
	for flag, arg in opts:
		if flag == "-h":
			Usage()
		if flag == "-d":
			DATALOC=arg
		if flag == "-s":
			RunFlag="Simple"
		if flag == "-v":
			RunFlag="Verbose"
		if flag == "-V":
			RunFlag="Very Verbose"
		if flag == "-#":
			print VERSION
			os._exit(0)

print "\n", os.path.basename(sys.argv[0]), VERSION

#From "Python and Tkinter Programming", J.E. Grayson, pg.103
class Command:
	def __init__(self,func, *args, **kw):
		self.func = func
		self.args = args
		self.kw = kw
	def __call__(self, *args, **kw):
		args = self.args + args
		kw.update(self.kw)
		apply(self.func, args, kw)
		
#
#	Over ride some methods in FileDialog so we only select directories
#	From TraceBuilder.py, auth Steve Azevedo & Lloyd Carothers
#
class DirectoryDialog (FileDialog) :

	title="Directory Select"
	def __init__ (self, root) :
		FileDialog.__init__ (self, root)

	#Only allow selection of directories (single click)
	def files_select_event (self, e):
		pass
	#Double click
	def files_double_event (self, e):
		pass

	#Make sure it's a directory and accessable
	def ok_command (self) :
		file = self.get_selection ()
		if not os.path.isdir (file) :
			if not os.access (file, R_OK) :
				self.root.bell ()
				file = None
		self.quit (file)

# main
class MainWindow:
	def __init__(self, title='', BatchFile=''):
		
		self.root = Tk()
		Pmw.initialise(self.root)
		self.root.title(title)

		#create balloon
		self.balloon=Pmw.Balloon(self.root)
		
		#set timezone to UTC
		os.environ['TZ'] = 'GMT'
		time.tzname = ('GMT', 'GMT')
		time.timezone=0

		#Start Global Variables
		self.e_width = 24

		#Variables, lists, dictionaries associated with traces and trace headers
		self.DataDirs = StringVar()
		self.StatSel = StringVar()
		self.StatSelList = []

		self.PopUpHelp = IntVar()
		self.PopUpHelp.set(1)

		self.StatChanLocDict={}
		
		self.Savefile=StringVar()
		self.Savefile.set("")
		
		self.BigEndianKey=StringVar()
		self.BigEndianKey.set("")
		self.LittleEndianKey=StringVar()
		self.LittleEndianKey.set("")
		
		self.BigEndianDict={}
		self.LittleEndianDict={}
		self.ErrorDict={}
		self.NumLittleFiles=IntVar()
		self.NumBigFiles=IntVar()
		self.NumLittleFiles.set(0)
		self.NumBigFiles.set(0)

		self.ScanErrors=IntVar()
		self.ScanErrors.set(0)
		
		#set of vars watched for active threading event
		self.RunScan=IntVar()
		self.RunScan.set(0)

		#log vars and lists
		self.ScanType=IntVar()
		self.ScanType.set(0)
		self.ScanTypeList = [
			["Simple", 0],
			["Verbose", 1],
			["Very Verbose", 2],
		]
		
		self.ErrorType=IntVar()
		self.ErrorType.set(0)
		#log vars and lists
		self.ErrorTypeList = [
			["All", 0],
			["Read/Write", 1],
			["Size", 2],
			["Endian", 3],
			["Non-Unique", 4]
		]

		self.SaveAll=IntVar()
		self.SaveAll.set(0)
		self.SaveInfo=IntVar()
		self.SaveInfo.set(0)
		self.SaveErrors=IntVar()
		self.SaveErrors.set(0)
		self.SaveErrorTraces=IntVar()
		self.SaveErrorTraces.set(0)

		self.ErrorAll=[]
		self.ErrorRW=[]
		self.ErrorSize=[]
		self.ErrorEndian=[]
		self.ErrorUnique=[]
		self.BigEndianPageName=""
		self.LittleEndianPageName=""
		self.ScanErrorsPageName=""
#####################new

		#if DATALOC not set on commandline set here
		if DATALOC:
			self.DataDirs.set(DATALOC)
		else:
			self.DataDirs.set(os.getcwd())
		
		# if a batch file exists on the command line,
		# we just run necessary processes for modifying headers
		self.BatchFile=StringVar()
		self.BatchFile.set(BatchFile)
		
		# If batchmode then launch from here and exit
		if BATCHMODE:
			#address endian change first since unique i.e. no batchfile
			print "Running in Batch Mode"
			if RunEndianBatch: 
				print "Changing Endianess to: ", Endianess
				self.ToEndian.set(Endianess)
				self.RunChangeEndian.set(1)
				print "Finding Files beneath directory: ", self.DataDirs.get()
				self.BuildTrcList()
				self.ChangeEndian()
			else:
				if RunTimeBatch: print "Correcting Timing"
				if RunHeaderBatch: print "Correcting Headers"
	
				print "Using Template: ", self.BatchFile.get()
				self.LoadTemplate()
				if RunTimeBatch:
					if not self.UpdateTimeDict: 
						print "No Timing Corrections in Template.\nDone"
						sys.exit(1)
					print "Finding Files beneath directory: ", self.DataDirs.get()
					self.BuildTrcList()
					self.RunApplyTimeCor.set(1)
					self.ApplyTimeCor()
				if RunHeaderBatch:
					if not self.UpdateHdrDict: 
						print "No Header Corrections in Template.\nDone"
						sys.exit(1)
					print "Finding Files beneath directory: ", self.DataDirs.get()
					self.BuildTrcList()
					self.RunModHdrs.set(1)
					self.ModHdrs()
			print "Done"
			sys.exit(0)
		
		# Build GUI
		self.createMainButtons(self.root)
		self.createNoteBooks(self.root)
########################################
	def createMainButtons(self,master):
		"""
		Build buttons for root window
		"""
		#create info bar at bottom of root window
		self.InfoString_l = Label(master,
				bg = "yellow",
				relief = "ridge")
		self.InfoString_l.pack(side='bottom', fill='x')

		#persistent buttons across all tabs
		self.Button_fm = Frame(master, relief = 'groove', borderwidth = 2)
		self.Button_fm.pack(side = 'bottom', pady=5, fill = 'x')

		self.exit_b = Button(self.Button_fm,
			text = "Exit",
			relief = "ridge",
			cursor = 'pirate',
			command = Command(self.Exit),
			activebackground= 'red',
			activeforeground='black')
		self.exit_b.pack(side='right', anchor='e')
		self.balloon.bind(self.exit_b, "Exit Program")

		self.SaveScan_b = Button(self.Button_fm,
			text='Save Scan',
			relief = "ridge",
			activebackground='green',
			command=Command(self.saveWidget, master)
			)
		self.SaveScan_b.pack(side='right', anchor='e')
		self.balloon.bind(self.SaveScan_b, "Allows scan results to \nbe saved to a file")

		self.PopUpHelp_cb = Checkbutton(self.Button_fm,
			text="PopUp Help",
			command=self.ToggleBalloons,
			variable=self.PopUpHelp
			)
		self.PopUpHelp_cb.pack(side='left')
		self.balloon.bind(self.PopUpHelp_cb, "Toggles 'PopUp Help' on and off")
		
########################################
	def ToggleBalloons(self):
		"""
		turns balloon help on and off
		"""
		if self.PopUpHelp.get():
			self.balloon.configure(state = 'balloon')
		else:
			self.balloon.configure(state = 'none')
########################################
	def createNoteBooks(self,master):
		"""
		Set up notebooks in root window
		"""
		self.nb = Pmw.NoteBook(master)
		self.buildScan(self.nb)
		self.nb.pack(padx=5, pady=5, fill='both', expand=1)

########################################
	def buildRemainingNoteBooks(self):
		self.buildBigEndian(self.nb)
		self.buildLittleEndian(self.nb)
		self.buildError(self.nb)
		self.nb.pack(padx=5, pady=5, fill='both', expand=1)

##################################################################
	def buildScan(self,master):
		"""
		Populate HdrList NoteBook
		tab for selecting traces, building trace database, and correcting headers one key at a time
		"""
		self.Scan_nb = master.add('Scan')

		#buttons
		self.Button_fm = Frame(self.Scan_nb, borderwidth = 2)
		self.Button_fm.pack(side = 'bottom', padx= 5, pady=5, fill = 'x')
		self.Scan_fm = Frame(self.Scan_nb, relief = 'groove', borderwidth = 2)

		#data directory find and clear buttons, and entry field
		#button to build trace db
		self.DataDirs_fm = Frame(self.Scan_nb, relief = 'groove', borderwidth = 2)
		self.DataDirs_fm.pack(side = 'top', pady=5, fill = 'x')
		self.DataDirs_l = Label(self.DataDirs_fm, text='Data Directories: ')
		self.DataDirs_l.pack(side='left')
		self.balloon.bind(self.DataDirs_l, \
		   "Search path(s) for finding mseed files. \nColon separate multiple entries")

		self.DataDirs_e = Entry(self.DataDirs_fm,
			selectbackground = 'yellow',
			textvariable = self.DataDirs)
		self.DataDirs_e.pack(side='left', anchor='w',expand=1, fill='x')

		self.ClearDataDir_b = Button(self.DataDirs_fm,
			activebackground = 'orange',
			relief = "ridge",
			text = "Clear",
			command = Command(self.setValue, self.DataDirs)
			)
		self.ClearDataDir_b.pack(side='right')
		self.balloon.bind(self.ClearDataDir_b, \
		   "Clears 'Data Directories' entry")
		
		self.FindDataDir_b = Button(self.DataDirs_fm,
			activebackground = 'green',
			relief = "ridge",
			text = "Find",
			command = Command(self.getPath, self.DataDirs, None)
			)
		self.FindDataDir_b.pack(side='right')
		self.balloon.bind(self.FindDataDir_b, \
		   "Dialog window to \nselect Data Directories")

		if not DATALOC: self.DataDirs.set(os.getcwd())

		self.Scan_b = Button(self.DataDirs_fm,
			activebackground = 'green',
			relief = "ridge",
			background='lightblue',
			text = "Scan Traces",
			command = Command(self.BuildTrcList)
			)
		self.Scan_b.pack(side='right')
		self.balloon.bind(self.Scan_b, \
		   "Scan traces using \n'Data Directories' \nas top level directories")

		# station selection frame and entry box
		self.StatSel_fm = Frame(self.Scan_nb, relief = 'groove', borderwidth = 2)
		self.StatSel_fm.pack(side = 'top', pady=5, fill = 'x')
		self.StatSel_l = Label(self.StatSel_fm, text='Scan only stations (colon separated list): ')
		self.StatSel_l.pack(side='left')
		self.StatSel_e = Entry(self.StatSel_fm,
			selectbackground = 'yellow',
			textvariable = self.StatSel)
		self.StatSel_e.pack(side='left', anchor='w',expand=1, fill='x')
		self.balloon.bind(self.StatSel_e, "Filter trace search \nfor these stations")

		self.ClearStatSel_b = Button(self.StatSel_fm,
			activebackground = 'orange',
			relief = "ridge",
			text = "Clear",
			command = Command(self.setValue, self.StatSel)
			)
		self.ClearStatSel_b.pack(side='right')
		self.balloon.bind(self.ClearStatSel_b, "Clear station filter")
		
		#filters
		self.RadButtons_fm = Frame(self.Scan_nb, relief = 'groove', borderwidth = 2)
		self.RadButtons_fm.pack(side = 'top', pady=5, fill = 'x')
		self.Scan_l = Label(self.RadButtons_fm, text='Scan Type: ')
		self.Scan_l.pack(side='left')
		self.balloon.bind(self.Scan_l, "Simple - ID traces\nVerbose - Include Start/End Times\n"\
			"Very Verbose - Scan all blocks")

		for text, value in self.ScanTypeList:
			Radiobutton(self.RadButtons_fm,
				text=text,
				value=value,
				variable=self.ScanType).pack(side='left', anchor='e')
				
		#setup frame for station substitutions. to be filled later
		Label(self.Scan_fm, text="Stat:Chan:Loc:Net:Sps Found").pack(side='top', fill='x')

		self.ScanText = Pmw.ScrolledText(self.Scan_fm, borderframe=1)
		self.ScanText.pack(side='top', fill='x')
		self.Scan_fm.pack(side = 'top', pady = 5, fill = 'x')


		self.ScanText.tag_config("odd", background="lightblue")
		self.ScanText.tag_config("head", background="yellow")

##################################################################
	def buildBigEndian(self,master):
		"""
		Populate Log NoteBook for keeping track of changes
		"""
		lstr=str
		try:
			self.nb.delete(self.BigEndianPageName)
		except StandardError, e:
			pass
		self.BigEndianPageName='Big Endian (' + lstr(self.NumBigFiles.get()) + ')'
		self.BE_nb = master.add(self.BigEndianPageName)

		self.BEDisplay_fm = Frame(self.BE_nb, relief='groove', borderwidth=2)
		self.BEDisplay_fm.grid()
		self.BEDisplay_fm.columnconfigure(0,weight=1)
		self.BEDisplay_fm.columnconfigure(1,weight=1)

		keylist=self.BigEndianDict.keys()
		keylist.sort()
		if keylist:
			keylist.insert(0,"All")

		Label(self.BEDisplay_fm, text="Display Traces Matching:").grid(row=0, column=0, sticky=E)
		Pmw.ComboBox(self.BEDisplay_fm,
			history=0,
			entry_width=self.e_width-5,
			entry_textvariable=self.BigEndianKey,
			scrolledlist_items=(keylist),
			selectioncommand=Command(self.LoadBigEndianStat)
			).grid(row=0, column=1, sticky=W)
		self.BEDisplayText = Pmw.ScrolledText(self.BEDisplay_fm,borderframe=1)
		self.BEDisplayText.grid(row=1, column=0, columnspan=2)
		self.BEDisplayText.columnconfigure(0,weight=1)
		self.BEDisplayText.columnconfigure(1,weight=1)

		#tags used for highlighting log entries
		self.BEDisplayText.tag_config('blue', foreground='blue')
		self.BEDisplayText.tag_config('dkgreen', foreground='darkgreen')
		self.BEDisplayText.tag_config('red', foreground='red')
		self.BEDisplayText.tag_config('black', foreground='black')
		self.BEDisplayText.tag_config("head", background="yellow")
		self.BEDisplayText.tag_config("odd", background="lightblue")

##################################################################
	def buildLittleEndian(self,master):
		"""
		Populate Log NoteBook for keeping track of changes
		"""
		lstr=str
		try:
			self.nb.delete(self.LittleEndianPageName)
		except:
			pass
		self.LittleEndianPageName='Little Endian (' + lstr(self.NumLittleFiles.get()) + ')'
		self.LE_nb = master.add(self.LittleEndianPageName)

		self.LEDisplay_fm = Frame(self.LE_nb, relief='groove', borderwidth=2)
		self.LEDisplay_fm.grid()
		self.LEDisplay_fm.columnconfigure(0,weight=1)
		self.LEDisplay_fm.columnconfigure(1,weight=1)

		keylist=self.LittleEndianDict.keys()
		keylist.sort()
		if keylist:
			keylist.insert(0,"All")

		Label(self.LEDisplay_fm, text="Display Traces Matching:").grid(row=0, column=0, sticky=E)
		Pmw.ComboBox(self.LEDisplay_fm,
			history=0,
			entry_width=self.e_width-5,
			entry_textvariable=self.LittleEndianKey,
			scrolledlist_items=(keylist),
			selectioncommand=Command(self.LoadLittleEndianStat)
			).grid(row=0, column=1, sticky=W)
		self.LEDisplayText = Pmw.ScrolledText(self.LEDisplay_fm,borderframe=1)
		self.LEDisplayText.grid(row=1, column=0, columnspan=2)
		self.LEDisplayText.columnconfigure(0,weight=1)
		self.LEDisplayText.columnconfigure(1,weight=1)


		#tags used for highlighting log entries
		self.LEDisplayText.tag_config('blue', foreground='blue')
		self.LEDisplayText.tag_config('dkgreen', foreground='darkgreen')
		self.LEDisplayText.tag_config('red', foreground='red')
		self.LEDisplayText.tag_config('black', foreground='black')
		self.LEDisplayText.tag_config("head", background="yellow")
		self.LEDisplayText.tag_config("odd", background="lightblue")

##################################################################
	def buildError(self,master):
		"""
		Populate Log NoteBook for keeping track of changes
		"""
		lstr=str
		try:
			self.nb.delete(self.ScanErrorsPageName)
		except:
			pass
		self.ScanErrorsPageName='Errors (' + lstr(self.ScanErrors.get()) + ')'
		self.Error_nb = master.add(self.ScanErrorsPageName)
		self.ErrorDisplay_fm = Frame(self.Error_nb, relief='groove', borderwidth=2)
		self.ErrorDisplay_fm.pack(side='top', pady=5, fill='x')
		
		self.ErrorText = Pmw.ScrolledText(self.Error_nb, borderframe=1)

		#log_filters
		self.RadButtons_fm = Frame(self.Error_nb, relief = 'groove', borderwidth = 2)
		self.RadButtons_fm.pack(side = 'top', pady=5, fill = 'x')
		self.ErrorDisplay_l = Label(self.RadButtons_fm, text='Display: ')
		self.ErrorDisplay_l.pack(side='left')
		self.balloon.bind(self.ErrorDisplay_l, "Filter Error messages")

		for text, value in self.ErrorTypeList:
			Radiobutton(self.RadButtons_fm,
				text=text,
				value=value,
				command=Command(self.DisplayError),
				variable=self.ErrorType).pack(side='left', anchor='e')

		self.ErrorText.pack(side='bottom', fill='both', expand=1)

		#tags used for highlighting log entries
		self.ErrorText.tag_config('blue', foreground='blue')
		self.ErrorText.tag_config('dkgreen', foreground='darkgreen')
		self.ErrorText.tag_config('red', foreground='red')
		self.ErrorText.tag_config('black', foreground='black')

#######################################
	def BuildTrcList(self):
		"""
		build a trace list using DataDirList as base directories
		"""
		# clear infostring
		self.addTextInfoBar()
		self.ButtonState("disabled")

		#kill warn window if it exist (i.e. user got here from self.Ignore)
		#this may not longer be necessary
		try:
			self.killWindow(self.WarnWidget_tl)
		except:
			pass

		#clear text windows
		try:
			self.ScanText.clear()
			self.BEDisplayText.clear()
			self.LEDisplayText.clear()
			self.ErrorText.clear()
		except:
			pass
		#initialize lists
		self.DataDirList = []
		self.StatSelList = []
		self.BigEndianDict={}
		self.LittleEndianDict={}
		n=0
		
		# split directory string & test they exist before launching into self.FindTrace
		# populate DataDirList
		for idir in string.split(self.DataDirs.get(), ":") :
			dirlist = glob(idir)
			for newdir in dirlist:
				if not os.path.isdir(newdir):
					err="***WARNING*** Directory " + newdir + " not found."
					self.addTextInfoBar(err, "red")
					self.ScanErrors.set(self.ScanErrors.get() + 1)
					self.ButtonState()
					return
				self.DataDirList.append(newdir)

		# split station select list if it exists
		if self.StatSel.get() == "*" or self.StatSel.get() == "":
			pass
		else:
			for statsel in string.split(self.StatSel.get(), ":") :
				statsel=string.strip(statsel)
				self.StatSelList.append(statsel)
			
		# find & ID traces in DataDirList, setup various list for nb's
		# first I set self.RunScan so we know that this is running and I have
		# a variable to watch status of process
		# next I spawn a thread to FindTrace
		self.RunScan.set(1)
#		tRun=threading.Thread(target=self.LaunchFindTrace)
#		tRun.start()
		self.LaunchFindTrace()
		# stay here until thread dies
#		tRun.join()

		numfiles=self.NumBigFiles.get() + self.NumLittleFiles.get()
		numerrors=self.ScanErrors.get()
		text= "\n" + str(numfiles) + " unique mseed files found. *** " \
		      + str(numerrors) + " scan errors."
		self.addTextInfoBar(text, "green")
		self.root.bell()

		self.buildRemainingNoteBooks()
		self.UpdateScan()
		self.LittleEndianKey.set("All")
		self.BigEndianKey.set("All")
		self.LoadLittleEndianStat("All")
		self.LoadBigEndianStat("All")
		self.DisplayError()
		self.ButtonState()
		return
#######################################
	def LaunchFindTrace(self) :
		"""
		separated out so FindTrace could be run as a thread
		
		"""
		if not BATCHMODE:
			self.CancelTL(self.RunScan, "Scan Traces")

		self.FindTrace(self.DataDirList)
		
		if self.RunScan.get() and not BATCHMODE:
			self.KillCancelTL(self.RunScan)

#######################################
	def FindTrace(self, DataDir) :
		"""
		based on traverse routine in "python standard library", Lundh pg 34
		"""
		#local variables
		lstrip=string.strip
		ljoin=string.join
		lstrftime=time.strftime
		lgmtime=time.gmtime
		setScanErr=self.ScanErrors.set
		getScanErr=self.ScanErrors.get
		setBigFiles=self.NumBigFiles.set
		setLittleFiles=self.NumLittleFiles.set
		getBigFiles=self.NumBigFiles.get
		getLittleFiles=self.NumLittleFiles.get
		# build stack of input directories
		stack = []
		for k in range(len(DataDir)) :
			if not DataDir[k] in stack:
				stack.append(DataDir[k])
		# init several counters and dictionaries
		self.BigEndianDict={}
		self.LittleEndianDict={}
		self.ErrorDict={}
		self.StatChanLocDict={}
		self.NumLittleFiles.set(0)
		self.NumBigFiles.set(0)
		self.ScanErrors.set(0)
		self.ErrorAll=[]
		self.ErrorRW=[]
		self.ErrorSize=[]
		self.ErrorEndian=[]
		self.ErrorUnique=[]
		scantype=self.ScanType.get()

		cnt=1
		#loop while directories still exist in stack
		while stack :
			directory = stack.pop()
			if not os.access(directory, 5):
				text = "Skipped: %s" % directory
				text1 = "\t\tAccess Error"
				self.WriteError(text,"Read/Write","red")
				self.WriteError(text1,"Read/Write","black")
				setScanErr(getScanErr() + 1)
				continue

			try:
				listfiles=(dir for dir in os.listdir(directory))

			except StandardError, e:
				print "Directory Read Error: %s" % e
				setScanErr(getScanErr() + 1)
				continue

			while 1:
				try:
					file=listfiles.next()
				except StopIteration:
					break

				#respond to a cancel request
				if not self.RunScan.get():
					break
				# keep user posted of progress
				if mod(cnt, 10):
					pass
				else:
					self.wait("Examining File: ", cnt)
				#build up list of mseed files w/ full pathnames
				fullname = os.path.join(directory, file)
				if os.path.isfile(fullname) :
					if not os.access(fullname, 6):
						err= "ERROR: Read/Write permission denied."
						err1="\t File:" + fullname
						self.WriteError(err,"Read/Write","red")
						self.WriteError(err1,"Read/Write")
						self.AddToDict(self.ErrorDict, "Permission Error", directory,file)
						setScanErr(getScanErr() + 1)
						continue
					
					try:
						msfile = Mseed(fullname)
						if msfile.isMseed() :

							try:
								#simple test to determine if correct size file
								filesize=msfile.filesize
								blksize=msfile.blksize
								numblocks=msfile.numblocks
							except:
								err= "ERROR: Cannot determine file and block sizes."
								err1="\t File:" + fullname
								self.WriteError(err,"Size","red")
								self.WriteError(err1,"Size")
								self.AddToDict(self.ErrorDict, "Size", directory,file)
								setScanErr(getScanErr() + 1)
								continue
							#assign header info
							type=msfile.type
							rate=msfile.rate
							tracetime=msfile.time
							stat=lstrip(msfile.FH.Stat)
							chan=lstrip(msfile.FH.Chan)
							loc=lstrip(msfile.FH.Loc)
							net=lstrip(msfile.FH.Net)
							fileid=ljoin(map(str,(stat,chan,loc,net,rate)), ":")
							
							
							#window on specific stations if exist
							if self.StatSelList:
								if not stat in self.StatSelList:
									continue
							if not scantype:
								filelist=[file]
							else:
								(startepoch, endepoch) = msfile.FirstLastTime()
								endepoch+=1
								start = lstrftime('%Y:%j:%H:%M:%S', lgmtime(startepoch))
								end = lstrftime('%Y:%j:%H:%M:%S', lgmtime(endepoch))
								if scantype == 1:
									filelist=[file,start,end]
								else:
									blklist=self.ReadAll(msfile, numblocks,directory,file,fileid)
									filelist=[file,start,end] + blklist
							#build file list for fixing headers

							if not scantype:
#								if not self.StatChanLocDict.has_key(fileid):
								self.StatChanLocDict[fileid]=[]
							else:
								try:
									if startepoch < self.StatChanLocDict[fileid][0][0]:
										self.StatChanLocDict[fileid][0][0] = startepoch
									if endepoch > self.StatChanLocDict[fileid][0][1]:
										self.StatChanLocDict[fileid][0][1] = endepoch
								except KeyError:
									self.StatChanLocDict[fileid]=[]
									self.StatChanLocDict[fileid].append([startepoch,endepoch])


									
							# build endian lists
							if msfile.byteorder == "big":
								setBigFiles(getBigFiles() + 1)
								self.AddToDict(self.BigEndianDict,fileid,directory,filelist)
							elif msfile.byteorder == "little":
								setLittleFiles(getLittleFiles() + 1)
								self.AddToDict(self.LittleEndianDict,fileid,directory,filelist)

						msfile.close()
					except StandardError, e:
						err="ERROR: %s" % e
						self.WriteError(err,"Read/Write","red")
						err1= "\t File:" + fullname
						self.WriteError(err1,"Read/Write")
						self.AddToDict(self.ErrorDict, "Read/Write", directory,file)
						setScanErr(getScanErr() + 1)
				cnt+=1

				# add fullname to stack if it is a directory or link
				if os.path.isdir(fullname) or (os.path.islink(fullname) and not os.path.isfile(fullname)):
					if not fullname in stack:
						stack.append(fullname)
		return

#########################################################
	def UpdateScan(self):
		if not self.StatChanLocDict: return

		self.ScanText.clear()

		keylist=[]
		keylist=self.StatChanLocDict.keys()
		keylist.sort()

		header="Stat:Chan:Loc:Net:Sps    Big  Little   Begin Time          End Time"
		self.ScanText.insert("end", """%s\n""" % header, "head")

		if keylist:
			c=0
			for key in keylist:
				numBig=0
				numLittle=0
				numError=0
				numspace=22-len(key)
				
				if self.BigEndianDict.has_key(key):
					for dir in self.BigEndianDict[key].keys():
						numBig=numBig+len(self.BigEndianDict[key][dir])
				if self.LittleEndianDict.has_key(key):
					for dir in self.LittleEndianDict[key].keys():
						numLittle=numLittle+len(self.LittleEndianDict[key][dir])
				#if self.ErrorDict.has_key(key):
					#for dir in self.ErrorDict[key].keys():
						#numError=numError+len(self.ErrorDict[key][dir])

				text=key + numspace*SPACE
				numspace=6-len(str(numBig))
				text=text + numspace*SPACE + str(numBig)
				numspace=8-len(str(numLittle))
				text=text + numspace*SPACE + str(numLittle)
				#numspace=8-len(str(numError))
				#text=text + numspace*SPACE + str(numError)

				if not self.ScanType.get():
					pass
				else:
					start = time.strftime('%Y:%j:%H:%M:%S', time.gmtime(self.StatChanLocDict[key][0][0]))
					end = time.strftime('%Y:%j:%H:%M:%S', time.gmtime(self.StatChanLocDict[key][0][1]))
					text=text + 3*SPACE + string.join(map(str,(start,end)), "   ")
#					text=key + numspace*SPACE +string.join(map(str,(start,end)), "   ")

				if c :
					self.ScanText.insert("end", """%s\n""" % text, "odd")
					c=0
				else :
					self.ScanText.insert("end", """%s\n""" % text)
					c+=1
		return
#########################################################
	def LoadBigEndianStat(self,key):
		self.BEDisplayText.clear()
		header="    Trace Name"
		header2="      Start Time          End Time            Blockettes"
		self.BEDisplayText.insert("end", """%s\n""" % header, "head")
		self.BEDisplayText.insert("end", """%s\n""" % header2, "head")
		if not self.BigEndianDict: return
		c=0
		if key == "All":
			for indexkey in self.BigEndianDict.keys():
				text = "<" + indexkey + ">\n"
				self.BEDisplayText.insert('end', text, "blue")
				for directory in self.BigEndianDict[indexkey].keys():
					text2= "  <" + directory + ">\n"
					self.BEDisplayText.insert('end', text2, "dkgreen")
					for trace in self.BigEndianDict[indexkey][directory]:
						text= 4*SPACE + str(trace[0]) + "\n"
						text=text + 6*SPACE + string.join(map(str,(trace[1:])), "   ")
						if c:
							self.BEDisplayText.insert('end', text + "\n", "odd")
							c=0
						else:
							self.BEDisplayText.insert('end', text + "\n")
							c=1

		else:
			numtrace=0
			text = "<" + key + ">\n"
			self.BEDisplayText.insert('end', text, "blue")
			for directory in self.BigEndianDict[key].keys():
				text2= "  <" + directory + ">\n"
				self.BEDisplayText.insert('end', text2, "dkgreen")
				for trace in self.BigEndianDict[key][directory]:
					text= 4*SPACE + str(trace[0]) + "\n"
					text=text + 6*SPACE + string.join(map(str,(trace[1:])), "   ")
					if c:
						self.BEDisplayText.insert('end', text + "\n", "odd")
						c=0
					else:
						self.BEDisplayText.insert('end', text + "\n")
						c=1
					numtrace+=1
			text="Displaying " + str(numtrace) + " traces"
			self.addTextInfoBar(text, "green")
		return
#########################################################
	def LoadLittleEndianStat(self,key):
		self.LEDisplayText.clear()
		header="    Trace Name"
		header2="      Start Time          End Time            Blockettes"
		self.LEDisplayText.insert("end", """%s\n""" % header, "head")
		self.LEDisplayText.insert("end", """%s\n""" % header2, "head")

		if not self.LittleEndianDict: return
		c=0
		if key == "All":
			for indexkey in self.LittleEndianDict.keys():
				text = "<" + indexkey + ">\n"
				self.LEDisplayText.insert('end', text, "blue")
				for directory in self.LittleEndianDict[indexkey].keys():
					text2= "  <" + directory + ">\n"
					self.LEDisplayText.insert('end', text2, "dkgreen")
					for trace in self.LittleEndianDict[indexkey][directory]:
						text= 4*SPACE + str(trace[0]) + "\n"
						text=text + 6*SPACE + string.join(map(str,(trace[1:])), "   ")
						if c:
							self.LEDisplayText.insert('end', text + "\n", "odd")
							c=0
						else:
							self.LEDisplayText.insert('end', text + "\n")
							c=1
		else:
			numtrace=0
			text = "<" + key + ">\n"
			self.LEDisplayText.insert('end', text, "blue")
			for directory in self.LittleEndianDict[key].keys():
				text2= "  <" + directory + ">\n"
				self.LEDisplayText.insert('end', text2, "dkgreen")
				for trace in self.LittleEndianDict[key][directory]:
					text= 4*SPACE + str(trace[0]) + "\n"
					text=text + 6*SPACE + string.join(map(str,(trace[1:])), "   ")
					if c:
						self.LEDisplayText.insert('end', text + "\n", "odd")
						c=0
					else:
						self.LEDisplayText.insert('end', text + "\n")
						c=1
					numtrace+=1
			text="Displaying " + str(numtrace) + " traces"
			self.addTextInfoBar(text, "green")
		return
#########################################################
	def WriteError(self, info, type="", color="black"):
		"""
		writes errors to appropriate list
		"""
		if BATCHMODE:
			if info:
				print info
		else:
			info=info + "\n"
			self.ErrorAll.append((info, color))
			
			if type == "Read/Write":
				self.ErrorRW.append((info, color))
			elif type == "Size":
				self.ErrorSize.append((info, color))
			elif type == "Endian":
				self.ErrorEndian.append((info, color))
			elif type == "Unique":
				self.ErrorUnique.append((info, color))
			else:
				pass
		return
##################################################################
	def DisplayError(self):
		"""
		filters Error entries
		"""
		self.ErrorText.clear()
		if self.ErrorType.get() == 0: textlist=self.ErrorAll
		if self.ErrorType.get() == 1: textlist=self.ErrorRW
		if self.ErrorType.get() == 2: textlist=self.ErrorSize
		if self.ErrorType.get() == 3: textlist=self.ErrorEndian
		if self.ErrorType.get() == 4: textlist=self.ErrorUnique
		for (textcmd, color) in textlist:
			self.ErrorText.insert('end', textcmd, color)
		return

##################################################################
	def AddToDict(self, inDict, id, inDir, inList):
		try:
			try:
				inDict[id][inDir].append(inList)
			except KeyError:
				inDict[id][inDir] = []
				inDict[id][inDir].append(inList)
		except KeyError:
			inDict[id] = {}
			inDict[id][inDir] = []
			inDict[id][inDir].append(inList)
		return

##################################################################
	def ReadAll(self, msfile, numblocks, inDir, inFile, old_fileid):
		"""
		attempts to read all blockettes and check for consistancy
		"""
		#local variables
		lstrip=string.strip
		ljoin=string.join
		lfixedhdr=msfile.fixedhdr
		ltypenxt=msfile.typenxt
		lGetBlk=msfile.GetBlk
		lrate=msfile.rate
		lstat=lstrip(msfile.FH.Stat)
		lchan=lstrip(msfile.FH.Chan)
		lloc=lstrip(msfile.FH.Loc)
		lnet=lstrip(msfile.FH.Net)
		fullname = os.path.join(inDir, inFile)
		warn=""
		blk_err=0
		blocks=[]
		n=0
		blksize=msfile.blksize
		while n < numblocks:
			#read & rewrite fixed header
			hdrs=lfixedhdr(n*blksize)
			rate=lrate
			stat=lstat
			chan=lchan
			loc=lloc
			net=lnet
			numblk=hdrs[3][3]
			addseek=hdrs[3][6]
			fileid=ljoin(map(str,(stat,chan,loc,net,rate)), ":")
			if fileid != old_fileid:
				warn="WARNING: Multiplexed miniseed file"
				warn1="\tFile: " + fullname
			b=0
			#loop over number of blockettes following fixed header at block n
			while b < numblk:
				seekval=(n*blksize)+addseek
				(blktype, next)=ltypenxt(seekval)
				blklist=lGetBlk(blktype, seekval)
				if not blklist:
					#if blockette error encountered bail
					err= "Corrupt mseed: " + fullname
					self.WriteError(err, "Endian", "red")
					err1= "\tRecord: " + str(n)
					self.WriteError(err1, "Endian")
					err2= "\tUnrecognized Blockette: " + str(blktype)
					self.AddToDict(self.ErrorDict, "Unrecognized Blockette", inDir,inFile)
					self.WriteError(err2, "Endian")
					return None
				else:
					if not blktype in blocks:
						blocks.append(blktype)
				addseek=next
				b+=1
			old_fileid=fileid
			n+=1
		if warn:
			self.WriteError(warn, "Unique", "red")
			self.WriteError(warn1, "Unique")
			self.AddToDict(self.ErrorDict, "Multiplexed", inDir,inFile)
			self.ScanErrors.set(self.ScanErrors.get() + 1)

		return blocks

#########################################################
	def Exit(self):
		"""
		a no questions asked exit
		"""
		sys.exit(0)
#########################################
	def killWindow(self, widget):
		"""
		Destroy Widget and Set InfoBar to Default
		"""
		widget.destroy()
		self.addTextInfoBar()

#######################################
	def CancelTL(self, runvar, title):
		"""
		creates a window for canceling trace modifications
		
		"""
		#disable all buttons that write to traces
		self.ButtonState("disabled")
		
		self.Cancel_tl = Toplevel(self.root)
		self.Cancel_tl.title(title)
		self.Cancel_b = Button(self.Cancel_tl,
			text="Cancel",
			cursor='pirate',
			relief = "ridge",
			activebackground='red',
			command= Command(self.KillCancelTL, runvar)
			)
		self.Cancel_b.pack(side='bottom', fill='x')

		self.Text_fm = Frame(self.Cancel_tl,
			relief = 'groove',
			borderwidth=2
			)
		self.Text_fm.pack(side='top', 
			fill='x', 
			pady=5
			)

		infotext = "   " + title + " Active. Please Wait   "
		Label(self.Text_fm,
			text=infotext,
			background='yellow'
			).pack(side='left', anchor='w')
#######################################
	def KillCancelTL(self, runvar):
		"""
		kills cancel window and unsets runvar
		"""
		self.killWindow(self.Cancel_tl)
		self.setValue(runvar, 0)
		self.ButtonState()

#######################################
	def setValue(self, var, value=''):
		"""
		Sets Value of var
		"""
		var.set(value)

#######################################
	def addTextInfoBar(self, str='', bg='yellow'):
		"""
		Adds Text To InfoBar
		"""
		#only bell if error, e.g. color red
		# don't ring bell if clearing text or progress info (e.g. color == yellow/lightblue)
		if BATCHMODE:
			if str:
				if string.count(str,'Examining') or string.count(str, 'Modifying') \
				   or string.count(str,'Correcting') or string.count(str,'Remaining'):
					print "\r" + str,
#					print ".",
					sys.stdout.flush()
				else:
					print str
		else:
			if bg != "yellow" and bg != "lightblue":
				self.root.bell()
			self.InfoString_l.configure(background=bg, text=str)

#######################################
	def wait(self, words, cnt):
		"""
		puts words plus cnt to info bar
		"""
		txt = words + str(cnt)
		if not BATCHMODE:
			self.root.update()
		self.addTextInfoBar(txt, 'lightblue')

#######################################
	def ButtonState(self, newstate="normal"):
		"""
		changes state of activity buttons
		"""
		#buttons that should be deactivated during activity
		ButtonList = (
			self.Scan_b,
			self.SaveScan_b,
			self.FindDataDir_b
			)
		for item in ButtonList:
			item.configure(state=newstate)
##########################################
	def getPath (self, var, clear=1) :
		"""
		Concatonate paths
		"""
		self.var=var
		if clear:
			self.var.set('')
		newpath_dd = DirectoryDialog (self.root)
		self.path = newpath_dd.go (dir_or_file = os.getcwd())
		if self.path != None :
			if self.var.get():
				self.var.set(self.var.get() + ':')
			if len(self.path) == 1 and self.path[0] == "/":
				self.var.set(self.var.get() + self.path)
			elif self.path[-1] == "/":
				self.var.set(self.var.get() + self.path[:-1])
			else:
				self.var.set(self.var.get() + self.path)

#######################################
	def saveWidget(self, master):
		"""
		Toplevel to save update dictionary or log text to file
		"""
		try:
			self.tl_State = self.saveWidget_tl.winfo_exists()
		except:
			self.tl_State = 0
		
		if self.tl_State == 1:
			self.saveWidget_tl.tkraise()
		else:
			# setup output file name
			(year, month, day, hour, minute, second, weekday, yearday, daylight) = time.localtime(time.time())
			now = string.join(map(str, (year, yearday, hour, minute)), ".")

			self.Savefile.set("ckMseed." + now)
			title = "Save Scan File As:"
				
			box_length = len(self.Savefile.get()) + 15
			self.saveWidget_tl = Toplevel(master)
			self.saveWidget_tl.title(title)

			self.saveWidgetCancel_b = Button(self.saveWidget_tl,
				text="Cancel",
				cursor='pirate',
				relief = "ridge",
				activebackground='red',
				command= Command(self.killWindow, self.saveWidget_tl)
				)
			self.saveWidgetCancel_b.pack(side='bottom', fill='x')
	
			self.saveWidgetSave_b = Button(self.saveWidget_tl,
				text="Save",
				background='lightblue',
				relief = "ridge",
				activebackground='green',
				command = Command(self.writeFile, self.saveWidget_tl, self.Savefile)
				)
			self.saveWidgetSave_b.pack(side='bottom', fill='x')
			
			self.SelectButton_fm = Frame(self.saveWidget_tl,
				relief = 'groove',
				borderwidth=2
				)
			self.SelectButton_fm.pack(side='bottom', 
				fill='x', 
				pady=5
				)
				
			self.SaveAll_cb=Checkbutton(self.SelectButton_fm,
				text="All",
				command=Command(self.ToggleSaveSelect),
				padx=5,
				pady=5,
				variable=self.SaveAll).pack(side='left', fill='x')
#			self.SaveAll.set(1)
#			self.balloon.bind(self.SaveAll_cb, "All text")
			
			self.SaveInfo_cb=Checkbutton(self.SelectButton_fm,
				text="Info",
				padx=5,
				pady=5,
				variable=self.SaveInfo).pack(side='left', fill='x')
#			self.balloon.bind(self.SaveInfo_cb, "Station ID only")
			
			self.SaveErrors_cb=Checkbutton(self.SelectButton_fm,
				text="Errors",
				padx=5,
				pady=5,
				variable=self.SaveErrors).pack(side='left', fill='x')
#			self.balloon.bind(self.SaveErrors_cb, "All Error messages")
			
			self.SaveErrorTraces_cb=Checkbutton(self.SelectButton_fm,
				text="Error Traces",
				padx=5,
				pady=5,
				variable=self.SaveErrorTraces).pack(side='left', fill='x')
#			self.balloon.bind(self.SaveErrorTraces_cb, "List of Error traces")
				
			self.saveWidgetEntry_fm = Frame(self.saveWidget_tl,
				relief = 'groove',
				borderwidth=2
				)
			self.saveWidgetEntry_fm.pack(side='bottom', 
				fill='x', 
				pady=5
				)
			
			self.saveWidgetEntry_e = Entry(self.saveWidgetEntry_fm,
				textvariable = self.Savefile,
				width = box_length
				)
			self.saveWidgetEntry_e.pack(side='left', anchor='w', fill='x', expand=1)

##########################################
	def ToggleSaveSelect(self):
		if self.SaveAll.get():
			self.SaveInfo.set(1)
			self.SaveErrors.set(1)
			self.SaveErrorTraces.set(1)
		else:
			self.SaveInfo.set(0)
			self.SaveErrors.set(0)
			self.SaveErrorTraces.set(0)
		return
			
##########################################
	def writeFile(self, master, file):
		"""
		Write File to disk
		"""
		divider="///////////////////"
		if os.path.isfile(file.get()):
			self.Continue_dl = Pmw.MessageDialog(master,
				title = "WARNING",
				defaultbutton = 1,
				buttons = ('Overwrite', 'Cancel'),
				message_text = 'The File exists!'
				)
			self.Result = self.Continue_dl.activate()
		else:
			self.Result = "Overwrite"
			
		if ( self.Result == "Cancel"):
			self.addTextInfoBar()
		elif ( self.Result == "Overwrite"):
			master.destroy()
			if not self.SaveAll.get() and not self.SaveInfo.get() and not self.SaveErrors.get() and\
			   not self.SaveErrorTraces.get():
				oops="Nothing to save"
				self.addTextInfoBar(oops, 'orange')
				return

			try:
				outfile=open(file.get(), "w")
				
				if self.SaveAll.get() or self.SaveInfo.get():

					if self.StatChanLocDict:
						outfile.write("%s\n" % divider)
						outfile.write("%s\n" % "Trace Information")
						outfile.write("%s\n" % divider)
						keylist=[]
						keylist=self.StatChanLocDict.keys()
						keylist.sort()
				
						if keylist:
							for key in keylist:
								numspace=24-len(key)
								if not self.ScanType.get():
									text=key
								else:
									start = time.strftime('%Y:%j:%H:%M:%S', time.gmtime(self.StatChanLocDict[key][0][0]))
									end = time.strftime('%Y:%j:%H:%M:%S', time.gmtime(self.StatChanLocDict[key][0][1]))
									text=key + numspace*SPACE +string.join(map(str,(start,end)), "   ")
								outfile.write("%s\n" % text)
					else:
						outfile.close()
						os.unlink(file.get())
						oops="Nothing to save"
						self.addTextInfoBar(oops, 'orange')
						return
		
				if self.SaveErrors.get():
					if not self.SaveInfo.get():
						outfile.write("%s\n" % divider)
					else:
						outfile.write("\n\n%s\n" % divider)
					outfile.write("%s\n" % "All Errors")
					outfile.write("%s\n" % divider)
					if self.ErrorAll:
						for (text, color) in self.ErrorAll:
							outfile.write("%s" % text)
					else:
						outfile.write("%s\n" % "NONE")
						
				if self.SaveErrorTraces.get():
					if not self.SaveInfo.get() or not self.SaveErrors.get():
						outfile.write("%s\n" % divider)
					else:
						outfile.write("\n\n%s\n" % divider)
					outfile.write("%s\n" % "Traces with Errors")
					outfile.write("%s\n" % divider)
					if self.ErrorDict:
						for indexkey in self.ErrorDict.keys():
							text = "<" + indexkey + ">\n"
							outfile.write("%s" % text)
							for directory in self.ErrorDict[indexkey].keys():
								text2= "   <" + directory + ">\n"
								outfile.write("%s" % text2)
								for trace in self.ErrorDict[indexkey][directory]:
									text3="\t" + trace + "\n"
									outfile.write("%s" % text3)
					else:
						outfile.write("%s\n" % "NONE")
	
				outfile.close()
	
			except IOError, e:
				err = "Can't Create %s" % file.get(), e
				self.addTextInfoBar(err, 'red')
			return

##########################################

	def killWindow(self, widget):
		"""
		Destroy Widget and Set InfoBar to Default
		"""
		widget.destroy()
#		self.addTextInfoBar()
		

##################################################################

mw = MainWindow("ckMseed %s" % VERSION)
mw.root.geometry("650x500")
mw.root.mainloop()
#import profile
#profile.run('mw.root.mainloop()')
