#!/usr/bin/env python

import sys, time, os

if __name__ == "__main__" :
    if len (sys.argv) != 2 :
        print "USAGE: e2h epoch"
        sys.exit ()
    os.environ['TZ'] = 'UTC'
    time.tzset ()
    epoch = int (sys.argv[1])
    tt = time.gmtime (epoch)
    
    print "%4d:%03d:%02d:%02d:%02d" % (tt[0], tt[7], tt[3], tt[4], tt[5])
