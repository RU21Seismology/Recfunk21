#!/usr/bin/env python

import math
import wigglepoly


a = []
d = 0
for y in range (10000) :
    x = math.sin (d) * 1000
    d += piInc
    #print "%d\t%d" % (int(x), y)
    x = int (x) + 1000
    a.append ([x, y])

wigglepoly.init ()
wigglepoly.build (a, 1000, 1)
while 1 :
    p = wigglepoly.next ()
    if len (p) == 0 :
        break
    for i in p :
        print i[0], i[1] 


    
