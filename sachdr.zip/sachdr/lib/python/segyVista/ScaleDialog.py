#!/usr/bin/env python

#
#   A widget to select pixels per trace, and gain
#
#   Steve Azevedo, Feburary 2001
#

from Tkinter import *
import Pmw
import sys

class ScaleDialog :
    def __init__ (self, root, pixelsTrace = [0, 10, 3],
                              gainRange = [1.0, 10.0, 2.0]) :
        #   root = root window
        #   pixelsTrace = number of pixels to use to display each trace (x)
        #    a tuple in the format (min, max, current)
        #   gainRange = min, max, and current gain
        try :
            minTrace = pixelsTrace[0]
            maxTrace = pixelsTrace[1]
            self.pixelsTrace = pixelsTrace[2]
            minGain = gainRange[0]
            maxGain = gainRange[1]
            self.gain = gainRange[2]
        except:
            sys.stderr.write ("pixelsTrace not a tuple!\n")
            return None

        self.dialog = Pmw.Dialog (root,
                                  buttons = ('Okay', 'Cancel'),
                                  title = 'segyView')
        self.dialog.resizable (0,0)
        self.rootFrame = self.dialog.interior ()

        self.scaleFrame = Frame (self.rootFrame,
                                 relief = FLAT)

        self.scaleTrace = Scale (self.scaleFrame,
                                  label = 'Pixels/Trace',
                                  orient = HORIZONTAL,
                                  relief = GROOVE,
                                  borderwidth = 2,
                                  length = 200,
                                  width = 8,
                                  from_ = minTrace,
                                  to = maxTrace)
        self.scaleTrace.set (self.pixelsTrace)
        
        self.scaleGain = Scale (self.scaleFrame,
                                label = 'Trace amplitude gain',
                                orient = HORIZONTAL,
                                relief = GROOVE,
                                borderwidth = 2,
                                length = 200,
                                width = 8,
                                resolution = 0.01,
                                from_ = minGain,
                                to = maxGain)
        self.scaleGain.set (self.gain)

        self.scaleFrame.pack (side = TOP, fill = X)
        self.scaleTrace.pack (side = TOP)
        self.scaleGain.pack (side = BOTTOM)
        self.dialog.withdraw ()

    def init (self, pixelsTrace, gainRange) :
        try :
            minTrace = pixelsTrace[0]
            maxTrace = pixelsTrace[1]
            self.pixelsTrace = pixelsTrace[2]
            minGain = gainRange[0]
            maxGain = gainRange[1]
            self.gain = gainRange[2]
        except:
            sys.stderr.write ("pixelsTrace not a tuple!\n")
            return None
        
        self.scaleTrace.configure (from_ = minTrace, to = maxTrace)
        self.scaleTrace.set (pixelsTrace[2])
        self.scaleGain.configure (from_ = minGain, to = maxGain)
        self.scaleGain.set (gainRange[2])

    def activate (self) :
        ret = self.dialog.activate ()
        trace = self.scaleTrace.get ()
        gain = self.scaleGain.get ()
        self.dialog.deactivate ()
        if ret == 'Okay' :
            return (trace, gain)
        else :
            return (self.pixelsTrace,
                    self.gain)

if __name__ == '__main__' :
    import sys
    import time
    r = Tk ()
    r.withdraw ()
    Pmw.initialise (r)
    sd = ScaleDialog (r, (5, 50, 10), (1, 150, 1))
    print "Sleeping..."
    time.sleep (3)
    print "Activate..."
    print sd.activate ()
    print "Sleeping..."
    time.sleep (3)
    print "Activate..."
    sd.init ((10, 55, 12), (5, 155, 10))
    print sd.activate ()
    sys.exit ()
    r.mainloop ()














