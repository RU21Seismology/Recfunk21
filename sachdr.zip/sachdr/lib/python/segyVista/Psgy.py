#!/usr/bin/env python

#
#   A simple class to read PASSCAL SEGY trace files.
#
#   Steve Azevedo, Jan. 2001
#

import array
import struct
import sys

TRUE = (1 == 1)
FALSE = (1 == 0)

class Psgy :
    #
    #   filename is the name of the RSY file to read
    #   endian is the endian'ness of the file being read, 'big' or 'little'
    #   march is the type of machine it is running on 'Linux' or 'Solaris'
    #   Warning:  This assumes that Linux is little endian and Solaris
    #   is big endian!  (This assumption is made in the PASSCAL software
    #   release.)
    #
    def __init__ (self, filename, endian = 'big', march = 'Solaris') :
        
        self.fh = open (filename, 'rb')
        if self.fh == None :
            sys.stderr.write ("Error: failed to read: %s\n" % filename)
            return None

        #print endian, march
        #   We assume Solaris is big endian and Linux is little endian
        self.byteSwap = FALSE
        if endian == 'big' and march == 'Linux' :
            self.byteSwap = TRUE
        elif endian == 'little' and march == 'Solaris' :
            self.byteSwap = TRUE
        else :
            sys.stderr.write ("Error: Unknown arch: %s\n" % march)


        #   Is input in big or little endian?
        #   This format describes the 104 fields in PASSCAL SEGY
        if endian == 'big' :
            self.fmt = '>lllllllhhhhllllllllhhllllhhhhhhhhhhhhhhhhhhhhhhhhhhh'
        else :
            self.fmt = '<lllllllhhhhllllllllhhllllhhhhhhhhhhhhhhhhhhhhhhhhhhh'
        self.fmt = \
            self.fmt + 'hhhhhhhhhhhhhhhhhhhcccccccccccccccccchlhhhhhhhhfhhlll'

        #print struct.calcsize (self.fmt)

    
    def readHeader (self) :
        #   Read the 240 byte SEGY header, byte swap as described in fmt
        bHeader = self.fh.read (240)
        self.header = struct.unpack (self.fmt, bHeader)
        #print self.header
        self.numSamps = int (self.header[38])
        if self.numSamps == 32767 :
            self.numSamps = int (self.header[102])
        self.sr = int ((1.0 / self.header[39]) * 1000000)
        #print "SR ", self.sr
        self.inst_no = self.header[100]
        self.max = self.header[103]
        self.min = self.header[104]
        #print "Inst ", self.inst_no
        #print self.header

    def readData (self) :
        #   Read time series and byte swap if needed
        self.data = array.array ('l')
        self.data.fromfile (self.fh, self.numSamps)
        #  
        if self.byteSwap == TRUE :
            self.data.byteswap ()

    def readRaw (self) :
        #   Read raw time series
        self.fh.seek (240, 0)
        self.raw = self.fh.read ()

    def read (self) :
        #   Read a PASSCAL SEGY trace file and return the dau number
        self.readHeader ()
        self.readData ()
        #self.readRaw ()
        self.fh.close ()
        return (self.inst_no)

    def _removeMean (self, l) :
        return l - self.mean - self.min

    def _getSum (self, l) :
        l = l - self.min
        #print l, self.sum
        self.sum = self.sum + l

    def demean (self) :
        #   Remove mean from time series (expensive)
        #   Sets self.data, self.mean, self.sum, self.min, self.max
        print "Demean"
        self.mean = 0
        self.sum = 0L
        map (self._getSum, self.data)
        self.mean = round (float (self.sum / self.numSamps))
        self.data= map (self._removeMean, self.data)
        self.max = self.max - self.mean
        self.min = self.min - self.mean

if __name__ == '__main__' :
    #print 'Main'
    gather = {}
    #
    for i in xrange (100) :
        segy = Psgy ('2000_168_02_44_45_10679_1.RSY', 'big', 'Solaris')
        inst = segy.read ()
        segy.demean ()
        inst = int (inst) + i
        if not gather.has_key (inst) :
            gather[inst] = ()
        gather[inst] = segy
        #print gather[inst]
        '''
        for j in segy.data :
            print j
'''
    


        







