#!/usr/bin/env python

#
#   An AGC class to apply agc to a NumPy array.  Uses the extension agc.
#
#   Steve Azevedo, October 2001
#

import agc_py;
import numpy;
import sys

class Agc :
    def __init__ (self, **kw) :
        """ interval is in microseconds,
            kw is a keyword dictionary of the following:
            window = agc window in milliseconds
            dwind = detection window in milliseconds
            detect = event detection boolean (always false)
            threshold = event detection threshold (amplitude)"""
        #   Initialize extension
        agc_py.init ()
        #   Initialize the self.vars dictionary
        self.initVars ()
        #   Set self.vars dictionary with kw
        if kw :
            self.setVars (**kw)

    def __del__ (self) :
        """ Free memory held by filtered trace """
        #sys.stderr.write ("Free memory in Agc\n")
        agc_py.free ()

    def freeTrace (self) :
        #sys.stderr.write ("Free memory in Agc\n")
        agc_py.free ()

    def setInterval (self, interval) :
        """ interval passed in as microseconds and converted to milliseconds"""
        self.interval = interval / 1000.0

    def initVars (self) :
        self.vars = {}
        self.vars['interval'] = 10.0
        self.vars['window'] = 16
        self.vars['dwind'] = 16
        self.vars['detect'] = 0
        self.vars['threshold'] = 25.0

    def setVars (self, **kw) :
        for k in kw.keys () :
            self.vars[k] = kw[k]

        try :
            #   Convert window in milliseconds to points
            window = int (round ((float (self.vars['window']) /
                      (self.vars['interval'] / 1000.0))))
            dwind = int (round ((float (self.vars['dwind']) /
                     (self.vars['interval'] / 1000.0))))
            #   The agc extension expects window and dwind in samples!
            #print self.vars['window'], window, self.vars['interval']
            agc_py.set (window,
                        dwind,
                        self.vars['detect'],
                        self.vars['threshold'])
        except ZeroDivisionError :
            sys.stderr.write  (
                'Division by zero in Agc.py: interval = %f' % self.vars['interval'])

    def getVars (self) :
        return self.vars

    def apply (self, trace) :
        filteredTrace = agc_py.agc (trace)
        return filteredTrace













