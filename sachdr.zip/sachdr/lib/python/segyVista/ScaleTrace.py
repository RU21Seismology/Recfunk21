#!/usr/bin/env python

#
#   A simple class to scale trace amplitudes to pixel positions.
#   Uses the extension scaletrace.
#
#   Steve Azevedo, September 2001
#

import scaletrace_py
import numpy
import gc

class ScaleTrace :
    def __init__ (self) :
        self.windowMax = 0.0
        #   Initialise pixel memory tracking structure
        scaletrace_py.initPixelMem ()
        #   Initialise scale info structure
        scaletrace_py.initScaleInfo ()
        #   Init our python vars
        self.initVars ()

    def __del__ (self) :
        #   Free memory in scaletrace 
        try :
            scaletrace_py.freePixelMem ()
        except AttributeError :
            pass

    def freePixelMem (self) :
        #   Force garbage collection
        scaletrace_py.freePixelMem ()
        gc.collect ()

    def initVars (self) :
        self.vars = {}
        #   Samples per second in trace
        self.vars['sps'] = 0
        #   Pixels per second on the plot
        self.vars['pps'] = 0
        #   Pixels per trace
        self.vars['ppt'] = 0
        #   Starting X pixel position
        self.vars['startX'] = 0
        #   Starting Y pixel position
        self.vars['startY'] = 0
        #   Gain applied to plot
        self.vars['gain'] = 1.0
        #   Start of plot in seconds
        self.vars['start'] = 0.0
        #   Stop of plot from start of trace in seconds
        self.vars['stop'] = 0.0

    def setVars (self, **kwargs) :
        #   Set vars using key words

        for k in kwargs.keys () :
            self.vars[k] = kwargs[k]
        scaletrace_py.setVerticalInfo (self.vars['sps'],
                                    self.vars['pps'],
                                    self.vars['start'],
                                    self.vars['stop'])
        
        scaletrace_py.setHorizontalInfo (self.vars['ppt'],
                                      self.vars['gain'])
        
        scaletrace_py.setStartXY (self.vars['startX'],
                               self.vars['startY'])

    def setScaleByTrace (self
                         ) :
        #   Set to scale by trace
        self.windowMax = 0.0

    def setScaleByWindow (self, seis) :
        #   Set to scale by window
        max = 0.0
        dasList = seis.getDasList ()
        epochList = seis.getEpochList ()

        n = len (dasList)

        for i in range (n) :
            trace = seis.getData (epochList[i], dasList[i])
            offset = scaletrace_py.getOffset (trace.data)
            if offset > max :
                max = offset

        self.freePixelMem ()
        self.windowMax = max
            
    def scale (self, trace) :
        #print max (trace), min (trace), sum (trace) / len (trace) 
        #   Do the trace scale
        o = scaletrace_py.tracescaler (trace, self.windowMax)
        return o


if __name__ == '__main__' :
    #   Build a sine wave for testing
    import math
    pii = math.pi / 10000
    a = []
    p = 0
    #   This is the longest trace we will ever encounter
    for i in range (32768) :
        a.append (math.sin (p))
        p += pii

    na = numpy.array (a, numpy.Float)

    for i in range (1000) :
        st = ScaleTrace ()
        
        #   Vertical, sps = Samples per Second, pps = Pixels per Trace,
        #   start = start time in seconds, stop in seconds from start
        #   of trace.
        st.setVars (sps = 100, pps = 100, start = 0.0, stop = 327.68)
        
        #   Horizontal, ppt = Pixels per Trace, gain = gain applied to
        #   plot
        st.setVars (ppt = 50, gain = 1.0)
        
        #   startXY, startX = Starting X position in Pixels, startY =
        #   Starting Y position in pixels
        st.setVars (startX = 100, startY = 20)

        #   Scale the trace
        scaled = st.scale (na)

        #   Garbage collect
        del (st)


