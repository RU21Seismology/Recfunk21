#!/usr/bin/env python
#
#   A file dialog class
#   Steve Azevedo, 991028
#
import tkFileDialog

class TkFileDialog :
    def __init__ (self, filetypes = [("all", "*")], basedir = '.') :
        self.filetypes = filetypes
        self.basedir = basedir

    def setFileTypes (self, filetypes) :
        self.filetypes = filetypes

    def askopenfile (self) :
        ret = tkFileDialog.askopenfile (filetypes = self.filetypes)
        return (ret)

    def askopenfilename (self) :
        ret = tkFileDialog.askopenfilename (filetypes = self.filetypes)
        return (ret)

    def asksaveasfilename (self) :
        ret = tkFileDialog.asksaveasfilename ()
        return (ret)


if __name__ == "__main__" :
    ask = TkFileDialog ([("Gzip", "*.gz"), ("Tar", "*.tar")])
    file = ask.askopenfilename ()
    print "File name returned: %s\n" % file
    file = ask.asksaveasfilename ()
    print "File name to save: %s\n" % file
    """del (ask)
    ask = TkFileDialog ([("Directory", "dir")])
    file = ask.askopenfile ()"""
