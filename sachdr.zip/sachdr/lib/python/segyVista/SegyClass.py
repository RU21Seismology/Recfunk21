#!/usr/bin/env python

#
#   A class to describe segy gathers ordered by either shot or receiver.
#   Uses the python extension segy written in C to very quickly read standard
#   SEGY files.  Trace data are returned in IEEE float format in a NumPy
#   array.  Traces, Trace (), are keyed into a dictionary by epoch and das
#   number.   Supports both little endian and big endian byte ordering, but
#   assumes the SEGY file is in big endian format.
#
#   Steve Azevedo, July 2001
#

import segy
import numpy
import gc

#
#   Define a very basic seismic trace class
#
class Trace :
    def __init__ (self) :
        #   NumPy array of IEEE floats
        self.data = None
        #   Seconds since 1970/01/01 00:00:00.0
        self.epoch = 0
        #   Das number or serial or unique assigned number
        self.inst_no = 0
        #   Trace max and min
        self.max = 0
        self.min = 0
        #   The source to receiver distance
        self.sourceToRecDist = 0;

#
#   Segy gather class
#
class Segy :
    def __init__ (self, filename) :
        self.openNew (filename)

    def __del__ (self) :
        segy.clearTraces ()
        gc.collect ()
    #
    #   Open a new SEGY file and initialize the gather level variables
    #
    def openNew (self, filename) :
        self.filename = filename
    
        #   Number of traces in this file
        self.traces = segy.openSegy (filename)
        
        if self.traces != None :
            #   Number of samples in each trace
            self.samples = segy.samples ()
            #   Sample interval in micro-seconds
            self.interval = segy.sampleRate ()
            #   Sample rate in samples per second
            self.rate = int (1.0 / (self.interval / 1000000.0))
            #   The maximum offset in gather (t.max - t.min)
            self.deltaMax = 0
            #self.traces = segy.traces ()
            #   List of dases as they appear in the gather
            self.dases = []
            #   List of epochs in the order they appear
            self.epochs = []
            #   The traces keyed by epoch and das
            #   self.data[epoch][das] = Trace ()
            self.data = {}
            #   Maximum and minimum source to receiver distances
            self.maxOffset = 0xFFFFFFFF
            self.minOffset = 0x7FFFFFFF


    #
    #   Read all of the traces in the SEGY file
    #   The dictionary data contains the traces as a NumPy array of floats
    #   keyed on epoch and das number or sensor serial number
    #   Trace () defines trace level variables
    #
    def readTraces (self) :
        self.deltaMax = 0
        for x in range (self.traces) :
            #   New trace
            t = Trace ()
            #
            t.data = segy.getNextTrace ()
            #   Try to read tracehdr->inst_no, if this is 0
            #   read tracehdr->sensor_serial
            #   else if not trace das = minus offset in file
            if t.data :
                t.inst_no = segy.currentDas ()
                if t.inst_no <= 0 :
                    t.inst_no = segy.currentSerial ()
            else :
                #   No das found so make one up that is less than zero
                t.inst_no = (x + 1) * -1;

            #   Get trace epoch
            t.epoch = segy.currentEpoch ()
            #   Get trace max / min
            t.max, t.min = segy.traceMaxMin ()
            #   Find maximum offset in traces
            delta = t.max - t.min
            if delta > self.deltaMax :
                self.deltaMax = delta
            #   Get source to receiver offset for trace and the
            #   max and min offset
            t.sourceToRecDist = segy.sourceToRec ()
            if t.sourceToRecDist > self.maxOffset :
                self.maxOffset = t.sourceToRecDist
            if t.sourceToRecDist < self.minOffset :
                self.minOffset = t.sourceToRecDist
            #   Keep ordered list of dases
            self.dases.append (t.inst_no)
            #   Keep ordered list of epochs
            self.epochs.append (t.epoch)
            #
            #   Data is a dictionary of Trace () objects keyed by
            #   epoch then das
            #
            if not self.data.has_key (t.epoch) :
                self.data[t.epoch] = {}
            self.data[t.epoch][t.inst_no] = t
            #print self.data[t.epoch][t.inst_no].epoch
            #print self.data[t.epoch][t.inst_no].inst_no
            
        segy.rewindSegy ()

    def getDasList (self) :
        return self.dases

    def getEpochList (self) :
        return self.epochs

    #
    #   Return trace data, 0 is entire matrix
    #   Null traces have das number < 0
    #
    def getData (self, epoch = 0, das = 0) :
        #print "Epoch: %d Das: %d\n" % (epoch, das)
        if das == 0 or epoch == 0:
            dat = self.data
        else :
            if self.data.has_key (epoch) :
                if self.data[epoch].has_key (das) :
                    dat = self.data[epoch][das]
                else :
                    #print "None 1"
                    dat = None
            else :
                #print "None 2"
                dat = None

        return dat

if __name__ == '__main__' :
    import time
    import gc
    for i in range (1000000) :
        s = Segy ('SegyReader/shot5_2.SGY')
        s.readTraces ()
        dasList = s.getDasList ()
        epochList = s.getEpochList ()
        l = len (dasList)
        for j in range (l) :
            d = s.getData (epochList[j], dasList[j])
            for point in d.data :
                print point
        del (s)
        gc.collect ()
        time.sleep (1)
    
    #n = len (dasList)

    #for i in range (n) :
        #print "Das List %d\n" % i
        #d = dasList[i]
        #print "Das List"
        #e = epochList[i]
        #print "Das List"
        #t = s.getData (e, d)
        #print "Das List"
        #print t.sourceToRecDist
        #if t and i == 2 :
        #    for x in t.data :
        #        print x
        #    break
    print "Max: %d Min: %d\n" % (s.maxOffset, s.minOffset)



