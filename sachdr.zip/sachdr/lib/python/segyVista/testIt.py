#!/usr/bin/env python

import scaletrace
import math
import Numeric

scaletrace.initPixelMem ()

scaletrace.initScaleInfo ()

pii = math.pi / 10000
a = []
p = 0

for i in range (32768) :
    a.append (math.sin (p))
    p += pii

na = Numeric.array (a, Numeric.Float)
#   sps, pps, start, stop
scaletrace.setVerticalInfo (100, 100, 0.0, 327.68)
#   ppt, gain
scaletrace.setHorizontalInfo (50, 1.0)
#   startX, startY
scaletrace.setStartXY (100, 20)

ar = scaletrace.tracescaler (na)

for xy in ar :
    print "%d\t%d\n" % (xy[0], xy[1])
