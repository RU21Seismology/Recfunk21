#!/usr/bin/env python

#
#   A class to describe segy gathers ordered by either shot or receiver.
#   Uses the python extension segy written in C to very quickly read standard
#   SEGY files.  Trace data are returned in IEEE float format in a NumPy
#   array.  Traces, Trace (), are keyed into a dictionary by epoch and das
#   number.   Supports both little endian and big endian byte ordering, but
#   assumes the SEGY file is in big endian format.
#
#   Steve Azevedo, July 2001
#

import segy_py
import math
import numpy
import gc

TRUE = 0 == 0
FALSE = 0 == 1
#
#   Define a very basic seismic trace class
#
class Trace :
    def __init__ (self) :
        #   NumPy array of IEEE floats
        self.data = None
        #   Gather Number in file
        self.gatherNum = 1
        #   Energy Source Point
        self.energySourcePt = -1
        #   Phone First Trace
        self.phoneFirstPt = -1
        #   Seconds since 1970/01/01 00:00:00.0
        self.epoch = 0
        #   Das number or serial or unique assigned number
        self.inst_no = 0
        #   Das number or serial number->string
        self.inst_no_str = ''
        #   Trace max and min
        self.max = 0
        self.min = 0
        #   Channel
        self.channel = 0
        #   The source to receiver distance
        self.sourceToRecDist = 0;
        #   Offset from end of line
        self.offset = float(0)
#
#   Segy gather class
#
class Segy :
    def __init__ (self, filename) :
        self.openNew (filename)

    def __del__ (self) :
        segy_py.clearTraces ()
        #gc.collect ()
    #
    #   Open a new SEGY file and initialize the gather level variables
    #
    def openNew (self, filename) :
        self.filename = filename
    
        #   Number of traces in this file
        self.traces = segy_py.openSegy (filename)
        if self.traces != None :
            #   Gather type, 0 = shot, 1 = receiver
            self.gatherType = -1
            #   Gathers in file
            self.gathersInFile = 1
            #   Number of samples in each trace
            self.samples = segy_py.samples ()
            #   Sample interval in micro-seconds
            self.interval = segy_py.sampleRate ()
            #   Sample rate in samples per second
            self.rate = int (1.0 / (self.interval / 1000000.0))
            #   The maximum amplitude in gather (t.max - t.min)
            self.deltaMax = 0
            #
            #self.traces = segy.traces ()
            #   List of dases as they appear in the gather
            self.dases = []
            self.dasesStr = []
            self.instKey = []
            #   List of epochs in the order they appear
            self.epochs = []
            #   The traces keyed by epoch and das
            #   self.data[epoch][das] = Trace ()
            self.data = {}
            #   Maximum offset along line (sum of offsets between stations)
            self.maxOffset = 0
            #   Minimun offset along line (closest stations)
            self.minOffset = 0x7FFFFFFF
            #   reset traces since the binary header holds traces/gather!
            self.traces = 0
        else :
            print 'open failed'
        

    #
    #   Read all of the traces in the SEGY file
    #   The dictionary data contains the traces as a NumPy array of floats
    #   keyed on epoch and das number or sensor serial number
    #   Trace () defines trace level variables
    #
    def readTraces (self, root = None) :
        SHOT = 0
        RECEIVER = 1
        #   Maximum amplitude offset
        self.deltaMax = 0
        ddif = []
        d = []
        #
        lastSourceToReceiver = None
        prevEnergySourcePt = None
        prevPhoneFirstPt = None
        traceQ = 1
        gatherNum = 1 
    #   Sum of offsets between sites
        self.maxOffset = 0
        #for x in range (self.traces) :
        while traceQ != -1 :

            if root != None :
                root.update ()
            
            #   New trace
            t = Trace ()
            #
            t.data = segy_py.getNextTrace ()
            if t.data == None :
                traceQ = -1
                break
            self.traces += 1 
            #   Try to read tracehdr->inst_no, if this is 0
            #   read tracehdr->sensor_serial
            #   else if not trace das = minus offset in file
            if t.data.all () :
                t.inst_no = segy_py.currentDas ()
                if t.inst_no <= 0 :
                    t.inst_no = segy_py.currentSerial ()
            else :
                #   No das found so make one up that is less than zero
                t.inst_no = (self.traces + 1) * -1;
            
            try :
                t.inst_no_str = "%d" % (t.inst_no)
            except :
                t.inst_no = (self.traces + 1) * -1;
                t.inst_no_str = "%d" % (t.inst_no)
                
            if t.inst_no > 35225 :
                ttr = hex(t.inst_no)
                t.inst_no_str = ttr[2:6]
            #   Get trace epoch
            t.epoch = segy_py.currentEpoch ()
            #   Get trace channel
            t.channel = segy_py.channelNumber ()
            #   Energy Source Point
            t.energySourcePt = segy_py.energySourcePt ()
            #   Phone First Trace
            t.phoneFirstPt = segy_py.phoneFirstPt ()
            #
            #   Determine type of gather
            #
            if self.traces == 2 :
                if t.energySourcePt == prevEnergySourcePt :
                    self.gatherType = SHOT
                elif t.phoneFirstPt == prevPhoneFirstPt :
                    self.gatherType = RECEIVER
            if self.gatherType == SHOT :
                if t.energySourcePt != prevEnergySourcePt :
                    gatherNum += 1
            if self.gatherType == RECEIVER :
                if t.phoneFirstPt != prevPhoneFirstPt :
                    gatherNum += 1
            prevEnergySourcePt = t.energySourcePt
            prevPhoneFirstPt = t.phoneFirstPt
            t.gatherNum = gatherNum
            #   Get trace max / min
            t.max, t.min = segy_py.traceMaxMin ()
            #
            #   Find maximum offset in traces
            #
            delta = t.max - t.min
            if delta > self.deltaMax :
                self.deltaMax = delta
            #
            #   Get source to receiver offset for trace and the
            #   max and min offset and distance between sites
            #
            t.sourceToRecDist = segy_py.sourceToRec ()
            d.append (t.sourceToRecDist)
            delta = 0

            lastSourceToReceiver = t.sourceToRecDist

            #   Keep ordered list of dases
            self.dases.append (t.inst_no)
            self.dasesStr.append (t.inst_no_str)
            #   Keep ordered list of epochs
            self.epochs.append (t.epoch)
            #
            #   Data is a dictionary of Trace () objects keyed by
            #   epoch then das
            #
            if not self.data.has_key (t.epoch) :
                self.data[t.epoch] = {}
               
            inst_key = "%d:%d" % (t.inst_no, t.channel)
            self.data[t.epoch][inst_key] = t
            self.instKey.append (inst_key)
            
        self.gathersInFile = gatherNum
        segy_py.rewindSegy ()
    # new code to work with scaleBySourceToRecDist  04/2004
        
        nT=int(self.traces)
        self.minStoRdist = min(d)
        self.arrSpan=max(d)-self.minStoRdist
        for i in range (0,(nT - 1)) :
            dta = abs(d[i+1]-d[i])
            ddif.append(dta)
        self.minOffset=min(ddif)
        for i in self.epochs:
          for k in self.dases:
             if self.data[i].has_key(k) :
                t = Trace()
                t = self.getData(i,k)
                t.offset=float(t.sourceToRecDist -
                              self.minStoRdist) 
                self.data[i][k] = t
              
    #    Calculate max, min, mean and standard deviation of data x[]:
    def meanstdv(self, x):
        maxint = 0x7FFFFFFF
        n, mean, std = len(x), 0, 0
        max, min = float (maxint) * -1, float (maxint)
        for a in x:
            if a > max :
                max = a
            if a < min :
                min = a
            mean = mean + a
        mean = mean / float(n)
        for a in x:
            std = std + (a - mean)**2
        std = math.sqrt(std / float(n-1))
        return max, min, mean, std

    #
    #   Return minumum value still inside the standard deviation
    #
    def calcMinOffset (self, x) :
        max, min, mean, std = self.meanstdv (x)
        cmpval = mean - std
        x.sort ()
        for val in x :
            if val > cmpval :
                break
        #print "Value %d Min: %d Max: %d\n" % (val, min, max)
        return val

    def getDasList (self) :
        return self.dases
    
    def getKeyList (self) :
        return self.instKey

    def getDasListStr (self) :
        return self.dasesStr

    def getEpochList (self) :
        return self.epochs

    def getGatherType (self) :
        return self.gatherType

    #
    #   Return trace data, 0 is entire matrix
    #   Null traces have das number < 0
    #
    def getData (self, epoch = 0, das = 0) :
        #print "Epoch: ", epoch, "Das: ", das
        if das == 0 or epoch == 0:
            dat = self.data
        else :
            if self.data.has_key (epoch) :
                if self.data[epoch].has_key (das) :
                    dat = self.data[epoch][das]
                else :
                    #print "None 1"
                    dat = None
            else :
                #print "None 2"
                dat = None

        return dat

if __name__ == '__main__' :
    import time
    import gc
    s = Segy ('2000_176_02_59_45.SGY')
    s.readTraces ()
    dasList = s.getDasList ()
    epochList = s.getEpochList ()
    print s.minOffset, s.maxOffset










