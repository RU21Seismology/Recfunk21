
from distutils.core import setup, Extension

setup (name = "scaletrace_py", version = "2001.250",
       ext_modules = [
    Extension (
    "scaletrace_py", ["scaletrace_py.c", "scaletracewrapper_py.c"],
#    extra_link_args = ["-m32"]
    extra_compile_args = ["-errchk=longptr64"]
)])
