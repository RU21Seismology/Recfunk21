#!/usr/bin/env python

#
#   A widget to select trace plot style (+, wiggle, -),
#   trace amplitude scaling method (by trace or by window),
#   trace spacing (by offset or fixed)
#
#   Steve Azevedo, August 2001
#

from Tkinter import *
import Pmw
#import sys

class OptionsDialog :
    def __init__ (self, root, fill = 0,
                              scale = 0,
                              spacing = 0) :
        #   root = root window
        #   fill = -1 -> fill minus, 0 -> wiggle, 1 -> fill plus
        #   scale = 0 -> by trace, 1 -> by window
        #   spacing = 0 -> fixed, 1 -> by shot to receiver distance
        self.dialog = Pmw.Dialog (root,
                                  buttons = ('Okay', 'Cancel'),
                                  title = 'segyView')
        self.dialog.resizable (0, 0)
        self.rootFrame = self.dialog.interior ()

        fillFrame = Frame (self.rootFrame,
                           relief = GROOVE,
                           borderwidth = 2)
        fillText = Frame (fillFrame,
                          relief = GROOVE,
                          borderwidth = 2)
        Label (fillText,
               text = "Trace Style").pack ()
        fillText.pack (side = TOP, fill = X)
        
        scaleFrame = Frame (self.rootFrame,
                            relief = GROOVE,
                            borderwidth = 2)
        scaleText = Frame (scaleFrame,
                           relief = GROOVE,
                           borderwidth = 2)
        Label (scaleText,
               text = "Amplitude Scaling").pack ()
        scaleText.pack (side = TOP, fill = X)
        
        spacingFrame = Frame (self.rootFrame,
                              relief = GROOVE,
                              borderwidth = 2)
        spacingText = Frame (spacingFrame,
                             relief = GROOVE,
                             borderwidth = 2)
        Label (spacingText,
               text = "Trace Offset").pack ()
        spacingText.pack (side = TOP, fill = X)
        
        #   Fill style radio buttons
        self.fillVar = IntVar ()
        self.minusFill = Radiobutton (fillFrame,
                                      text = 'Fill -',
                                      #command = self.setFill,
                                      variable = self.fillVar,
                                      state = NORMAL,
                                      value = -1)
        self.minusFill.pack (side = LEFT)
        self.wiggleFill = Radiobutton (fillFrame,
                                       text = 'Wiggle',
                                       #command = self.setFill,
                                       variable = self.fillVar,
                                       value = 0)
        self.wiggleFill.pack (side = LEFT)
        self.plusFill = Radiobutton (fillFrame,
                                     text = 'Fill +',
                                     #command = self.setFill,
                                     variable = self.fillVar,
                                     state = NORMAL,
                                     value = 1)
        self.plusFill.pack (side = RIGHT)
        self.fillVar.set (fill)
        self.fill = fill
        #   Scale
        self.scaleVar = IntVar ()
        self.scaleTrace = Radiobutton (scaleFrame,
                                       text = 'Trace',
                                       variable = self.scaleVar,
                                       #command = self.setScale,
                                       value = 0)
        self.scaleTrace.pack (side = LEFT)
        self.scaleWindow = Radiobutton (scaleFrame,
                                        text = 'Window',
                                        variable = self.scaleVar,
                                        #command = self.setScale,
                                        value = 1)
        self.scaleWindow.pack (side = RIGHT)
        self.scaleVar.set (scale)
        self.scale = scale
        #   Spacing
        self.spacingVar = IntVar ()
        self.spacingFixed = Radiobutton (spacingFrame,
                                         text = 'Fixed',
                                         variable = self.spacingVar,
                                         #command = self.setSpacing,
                                         value = 0)
        self.spacingFixed.pack (side = LEFT)
        self.spacingOffset = Radiobutton (spacingFrame,
                                          text = 'Shot to Receiver',
                                          variable = self.spacingVar,
                                          #command = self.setOffset,
                                          #state = DISABLED,
                                          value = 1)
        self.spacingOffset.pack (side = RIGHT)
        self.spacingVar.set (spacing)
        self.spacing = spacing

        fillFrame.pack (side = TOP, fill = X)
        scaleFrame.pack (side = TOP, fill = X)
        spacingFrame.pack (side = TOP, fill = X)
        self.dialog.withdraw ()

    def init (self, fill, scale, spacing) :
        self.fillVar.set (fill)
        self.scaleVar.set (scale)
        self.spacingVar.set (spacing)

    def activate (self) :
        ret = self.dialog.activate ()
        fill = self.fillVar.get ()
        scale = self.scaleVar.get ()
        spacing = self.spacingVar.get ()
        
        if ret == 'Okay' :
            return (fill, scale, spacing)
        else :
            return (self.fill, self.scale, self.spacing)

if __name__ == '__main__' :
    import sys
    import time
    r = Tk ()
    r.withdraw ()
    Pmw.initialise (r)
    sd = OptionsDialog (r, 0, 0, 0)
    print "Sleeping..."
    time.sleep (3)
    print "Activate..."
    print sd.activate ()
    print "Sleeping..."
    time.sleep (3)
    sd.init (1, 1, 1)
    print "Activate..."
    print sd.activate ()
    sys.exit ()
    r.mainloop ()














