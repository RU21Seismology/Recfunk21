#!/usr/bin/env python

#
#   A simple (and quick) class to plot seismograms
#
#   Steve Azevedo, Jan 2001
#
            
from Tkinter import *
import Pmw
import Image, ImageDraw, ImageTk, ImageFont
import Segy
#import Naat
import numpy
import time
from ScaleTrace import *
import copy
import WigglePoly

#   Plot styles
WIGGLE = 0
COLORED = 1

TRUE = 1 == 1
FALSE = 1 == 0

#   Color choices
RED = 0
GREEN = 1
BLACK = 2
NOCOLOR = -1

#   Fill styles
FILLPOSITIVE = 1
NOFILL = 0
FILLNEGATIVE = -1

#
#    A simple message  bar class
#
class MessageBar (Frame) :
    def __init__ (self, root, width = 40) :
        self.root = root
        self.width = width
        apply (Frame.__init__, (self, root))
        
        self.message = Label (self,
                             height = 1,
                             width = self.width,
                             font = (('MS', 'Sans', 'Serif'), '10'),
                             relief = FLAT)
        self.message.pack ()

    def set (self, mes) :
        self.message.configure (text = mes)
        self.root.update_idletasks ()


class Gather (Frame) :
    def __init__ (self, mess, root, width, height) :
        #   width and height are the width and height of the window
        apply (Frame.__init__, (self, root))
        root.minsize(480,325)
        self.configure (width = width, height = height)
        canvasFrame = Frame (self)
        hscrollFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        messageFrame = Frame (self)
        innermessageFrame = Frame(messageFrame)
        
        self.canvas = Canvas (canvasFrame,
                              relief = GROOVE,
                              borderwidth = 2,
                              #lloyd changed
                              scrollregion = ('0', '0', '0','0'))

        Widget.bind (self.canvas, "<Button-2>", self.middleMouseDown)
        Widget.bind (self.canvas, "<Button-1>", self.leftMouseDown)
        Widget.bind (self.canvas, "<Button1-Motion>", self.leftMouseMotion)
        Widget.bind (self.canvas, "<Button1-ButtonRelease>", self.leftMouseUp)
        self.canvas.configure (cursor = "crosshair")
        
        self.activity = Canvas (hscrollFrame,
                                height = 8,
                                width = 8,
                                relief = FLAT)
        
        self.light = self.activity.create_oval (1, 1, 7, 7, fill = 'red')
        self.isRed = TRUE
        
        self.hscroll = Scrollbar (hscrollFrame, orient = HORIZONTAL,
                                  width = 8, relief = GROOVE,
                                  command = self.canvas.xview)
        
        self.vscroll = Scrollbar (canvasFrame, orient = VERTICAL,
                                  width = 8, relief = GROOVE,
                                  command = self.canvas.yview)
        
        self.canvas.configure (xscrollcommand = self.hscroll.set,
                               yscrollcommand = self.vscroll.set,
                               background = 'white')

        self.dasMessage = MessageBar (messageFrame, 7)
        self.timeMessage = MessageBar (messageFrame, 26)
        self.offsetMessage = MessageBar (messageFrame, 7)
        self.channelMessage = MessageBar (innermessageFrame, 3)
        self.gatherMessage = MessageBar (innermessageFrame, 3)
        self.shotMessage = MessageBar (innermessageFrame, 12)
        self.siteMessage = MessageBar (innermessageFrame, 12)
        
        
        canvasFrame.pack (side = TOP, expand=YES, fill=BOTH)
        self.canvas.pack (side = LEFT,expand=YES, fill=BOTH)
        self.vscroll.pack (side = RIGHT, fill=Y)
        hscrollFrame.pack (side = TOP, fill=X)
        self.hscroll.pack (side = LEFT, fill=X,expand=YES)
        self.activity.pack (side = RIGHT)
        messageFrame.pack (side = BOTTOM, fill=X)
        innermessageFrame.pack(side=BOTTOM,fill=X, expand=YES)
        Label (messageFrame, text = 'DAS:').pack (side = LEFT)
        self.dasMessage.pack (side = LEFT)
        Label (messageFrame, text = 'Time:').pack (side = LEFT)
        self.timeMessage.pack (side = LEFT)
        Label (messageFrame, text = 'Shot to receiver:').pack (side = LEFT)
        self.offsetMessage.pack (side = LEFT)
        Label (innermessageFrame, text = 'Channel:').pack (side = LEFT)
        self.channelMessage.pack (side = LEFT)
        Label (innermessageFrame, text = 'Gather in file:').pack (side = LEFT)
        self.gatherMessage.pack (side = LEFT)
        Label (innermessageFrame, text = 'Shot:').pack (side = LEFT)
        self.shotMessage.pack (side = LEFT)
        Label (innermessageFrame, text = 'Site:').pack (side = LEFT)
        self.siteMessage.pack (side = LEFT)

        self.message = mess
        #   Seis object
        self.seis = None
        #   PIL draw object
        self.draw = None
        #   PIL image object
        self.im = None
        #   Which gathers in file to plot
        self.gathersToPlot = []
        self.gathersToPlot.append (1)
        #   Which channel to plot
        self.channelToPlot = 1
        #   Tkinter canvas image object
        self.image = None
        #   The Filtering object
        self.filters = None
        self.initVars ()

    def initVars (self) :
        if self.seis != None :
            del self.seis
            self.seis = None

        if self.image != None :
            del self.image
            self.image = None
            
        if self.draw != None :
            del self.draw
            self.draw = None

        if self.im != None :
            del self.im
            self.im = None


        
        self.pixelsSecond = 150.0
        self.pixelsTrace = 10.0
        self.startXY = [30, 36]
        self.startStartXY = [30, 36]
        self.startSecs = 0
        self.style = WIGGLE
        self.threshold = 0
        self.gain = 1.0
        self.scaleByTrace = TRUE
        self.scaleByOffset = FALSE

    #lloyds code for selecting traces/time frames
    def leftMouseDown(self, event):
        self.selected = None
        self.selectStartx = self.selectLastx = self.canvas.canvasx(event.x)
        self.selectStarty = self.selectLasty = self.canvas.canvasy(event.y)

    def leftMouseMotion(self, event):
        None
##         if self.selected: self.canvas.delete(self.selected)
##         self.selectLastx = self.canvas.canvasx(event.x)
##         self.selectLasty = self.canvas.canvasy(event.y)
##         self.selected = self.canvas.create_rectangle(self.selectStartx,
##                                                      self.selectStarty,
##                                                      self.selectLastx,
##                                                      self.selectLasty,)



    def leftMouseUp(self, event):
        None
        
        

    #
    #   Call back on mouse down to get trace and time that was clicked
    #   
    def middleMouseDown (self, e) :
        x = int (self.canvas.canvasx (e.x))
        y = int (self.canvas.canvasy (e.y))
        slop = self.pixelsTrace / 2
        big = x + slop
        small = x - slop
        try :
            starti = 0
            trace, xval = self.indexedTrace[starti]
            secs = float (y - self.startStartXY[1]) / float (self.pixelsSecond)
        except (LookupError, AttributeError) :
            return

        found = FALSE
        while 1 :
            traceLast = trace
            starti += 1
            #   We have passed end of indexedTrace list
            if starti > len (self.indexedTrace) :
                break
            #   Are we in the space occupied by the trace?
            if xval <= big and xval >= small :
                found = TRUE
                break
            #   Get next trace
            try :
                trace, xval = self.indexedTrace[starti]
            except IndexError :
                sys.stderr.write ("Error: IndexError exception in mouseDown\n")
            
        if found :    
            totalSecs = secs + traceLast.epoch + self.startSecs
            fracSeconds = totalSecs - float (int (totalSecs))
            ttuple = time.gmtime (int (totalSecs))
            
            timeString = "%4d/%02d/%02d %02d:%02d:%07.4f" % (ttuple[0],
                                                             ttuple[1],
                                                             ttuple[2],
                                                             ttuple[3],
                                                             ttuple[4],
                                                             ttuple[5] +
                                                             fracSeconds)


            if (traceLast.inst_no_str >=9000 and traceLast.inst_no_str < 10000):
                das = "0x" + str(i)
            else:
                das = str (traceLast.inst_no_str)
                
            offset = str (traceLast.sourceToRecDist)
            ga = str (traceLast.gatherNum)
            chan = str (traceLast.channel)
            shot = str (traceLast.energySourcePt)
            site = str (traceLast.phoneFirstPt)
            
            self.dasMessage.set (das)
            self.timeMessage.set (timeString)
            self.offsetMessage.set (offset)
            self.gatherMessage.set (ga)
            self.channelMessage.set (chan)
            self.shotMessage.set (shot)
            self.siteMessage.set (site)
        else :
            sys.stderr.write ("No trace found!\n")
            self.bell ()
        
    def setSeis (self, seis) :
        self.seis = seis

    #   Set gather within file/reel to plot
    def setGathersToPlot (self, g) :
        self.gathersToPlot = g

    #   Use shot to receiver distance?
    def setScaleByOffset (self) :
        self.scaleByOffset = TRUE

    def setScaleByFixed (self) :
        self.scaleByOffset = FALSE

    #   Trace normalization
    def setScaleByTrace (self) :
        self.scaleByTrace = TRUE

    def setScaleByWindow (self) :
        self.scaleByTrace = FALSE
        
    #   Toggle activity light
    def toggleLight (self) :
        if self.isRed :
            self.activity.itemconfigure (self.light, fill = 'LightCoral')
            self.isRed = FALSE
        else :
            self.activity.itemconfigure (self.light, fill = 'red')
            self.isRed = TRUE
        self.update_idletasks ()

    def lightRed (self) :
        self.activity.itemconfigure (self.light, fill = 'red')
        self.isRed = TRUE
        self.update_idletasks ()

    def lightGreen (self) :
        self.activity.itemconfigure (self.light, fill = 'green')
        self.isRed = FALSE
        self.update_idletasks ()

    #   Save file as eps file to filename
    def doSave (self, filename = 'Untitled.eps') :
        self.im.save (filename, 'eps')

    #   Set gain multiplier
    def setGain (self, gain) :
        self.gain = gain

    def setPixelsSecond (self, pps) :
        self.pixelsSecond = pps

    def setPixelsTrace (self, ppt) :
        self.pixelsTrace = ppt

    #   Start X Y position in pixels to start drawing trace
    def setStartXY (self, x, y) :
        self.startXY = [x, y]

    #   Set plot style, wiggle or fill
    def setStyle (self, threshold) :
        self.threshold = threshold
        if self.threshold == 0 :
            self.style = WIGGLE
        else :
            self.style = COLORED
            self.threshold = threshold

    def setFilters (self, f) :
        #print f
        self.filters = f

    def drawWiggle (self, scaled) :
        #s = [36, 36, 36, 37, 36, 38, 36, 39, 36, 40, 36, 41, 36, 42, 36, 43, 36, 44, 36, 45, 36, 46, 36, 47, 36, 48, 36, 49, 36, 50, 36, 51, 36, 52, 36, 53, 36, 54, 36, 55, 36, 56, 36, 57, 36, 58, 36, 59, 36, 60, 36, 61, 36, 62, 36, 63, 36, 64, 36, 65, 36, 66, 36, 67, 36, 68, 36, 69, 36, 70, 36, 71, 36, 72, 36, 73, 36, 74, 36, 75, 36, 76, 36, 77, 36, 78, 36, 79, 36, 80, 36, 81, 36, 82, 36, 83, 36, 84, 36, 85]
        s = scaled.tolist ()
        #print s
        self.draw.line (s, fill=(0, 0, 0))

    #   Get points of polygon(s) to fill
    def mapPoly (self, xy) :
        mean = self.startXY[0]
        x = xy[0]
        y = xy[1]
        x0 = self.lastXY[0]
        y0 = self.lastXY[1]
        dx = abs (float (x) - float (x0))
        dy = abs (float (y) - float (y0))
        if dx != 0 :
            ryx = dy / dx
        else :
            yrx = 0
            
        if (x > mean or x0 > mean) and self.threshold > 0 :
            #   Fill the plus side
            #   Reset x and y so they fall on the mean line if required
            if x < mean :
                a = mean - x
                y = y - int (round (a * ryx))
                x = mean
            if x0 < mean :
                a = mean - x0
                y0 = y0 + int (round (a * ryx))
                x0 = mean
            if x > mean or x0 > mean :
                #self.poly.append ((mean, y0))
                self.poly.append ((x0, y0))
                self.poly.append ((x, y))
                #self.poly.append ((mean, y))
            
        elif (x < mean or x0 < mean) and self.threshold < 0 :
            #   Fill the minus side
            if x > mean :
                a = x - mean
                y = y - int (round (a * ryx))
                x = mean
                
            if x0 > mean :
                a = x0 - mean
                y0 = y0 + int (round (a * ryx))
                x0 = mean
            if x < mean or x0 < mean :
                #self.poly.append ((mean, y0))
                self.poly.append ((x0, y0))
                self.poly.append ((x, y))
                #self.poly.append ((mean, y))
    
        self.lastXY = xy

    #
    #   Draw filled wiggle
    #
    def drawColored (self, scaled) :
        #   scaled - trace scaled to pixels
        s = numpy.reshape (scaled, (-1, 2))
        #print s
        wp = WigglePoly.WigglePoly ()
        #print "Building...",
        wp.build (s, self.startXY[0], int (self.threshold))
        #print "Done"
        r = g = b = 128
        #print "Polygon...",
        while 1 :
            a = []
            #print "get"
            poly = wp.next ()
            #print "plot"
            if len (poly) == 0 :
                break
            self.draw.polygon (poly.tolist (), fill=(r, g, b))

        #print "Done"

    def _drawAxis (self, box, nTraces, nSecs, start) :
        self.draw.rectangle (box, outline = (0, 0, 0))
        x0 = self.startXY[0] / 2
        x = box[2]
        self.draw.setfont (ImageFont.load_path ('helvB08.pil'))
        #print nSecs
        for i in range (int (nSecs)) :
            #print i
            y0 = y = i * self.pixelsSecond + box[1]
            #print i + 1
            if self.pixelsSecond >= 60 :
                for j in range (10) :
                    j = j + 1
                    y1 = y2 = y + (j * self.pixelsSecond / 10)
                    #  Draw 1/10 second line
                    self.draw.line (((x0, y1), (x, y2)), (200, 200, 200))
            #  Draw blue line at 1 second
            self.draw.line (((x0, y0), (x, y)), (0, 0, 255))
            #print i + 2
            if self.pixelsSecond >= 12 :
                self.draw.text ((x0 + 2, y0), str (i+start), fill=(0,0,255))
                self.draw.text ((x - 12, y), str (i+start), fill=(0,0,255))
                
                #print "Done"

    def _warnMess (self, mess) :
        d = Pmw.MessageDialog (self, title = 'Warning',
                               buttons = ('Continue', 'Cancel'),
                               message_text = mess)
        r = d.activate ()
        if r == 'Continue' :
            return TRUE
        else :
            return FALSE
        
    def _isLargeOk (self, x, y) :
        if x > 32767 or y > 32767 :
            mess = ("WARNING\nX: %d pixels Y: %d pixels " % (x, y))
            mess = mess + "Any dimension > 32768 will crash X windows!"
            return self._warnMess (mess)
        if (x * y) > 2097152 :
            mess = ("WARNING\nThe size of the plot is %d X %d pixels\n" %
                    (x, y))
            mess = mess +\
                   "this may take a long time to plot or crash X windows!"
            return self._warnMess (mess)
        if x > 6000 :
            mess = ("WARNING\nThe plot X dimension is: %d pixels " % x)
            mess = mess + "this may take a long time to plot!"
            return self._warnMess (mess)
        if y > 6000 :
            mess = ("WARNING\nThe plot Y dimension is: %d pixels " % y)
            mess = mess + "this may take a long time to plot!"
            return self._warnMess (mess)

        
    def _sizeCanvas (self, nTraces, nSecs,start) :
        #   Re-size canvas to hold trace
        #   startXY is starting point of first trace
        #   x, y is maximum size of canvas
        x = int ((nTraces * self.pixelsTrace) + (self.startXY[0] * 2))
        y = int ((nSecs * self.pixelsSecond) + (self.startXY[1] * 2))
        print "X: %d Y: %d\n" % (x, y)
        #   Hard X11 limits?
        if self._isLargeOk (x, y) == FALSE :
            return FALSE

        #   padX, padY is space between box and trace in x, y directions
        padX = self.startXY[0] / 2
        padY = self.startXY[1] / 2
        #
        box = (padX, self.startXY[1], x - padX, y - (padY * 2)) 
        
        self.canvas.configure (scrollregion = ('0', '0', x, y))
        #   Create the image
        
        self.im = Image.new ('RGB', (x, y), (255,255,255))
        #   Create so we can draw directly to the image
        
        self.draw = ImageDraw.Draw (self.im)
        
        self._drawAxis (box, nTraces, nSecs,start)

        return TRUE
        
    def _labelTrace (self, i) :
        self.textAbove = TRUE 
        if (i >= 0x9000 and i < 0x10000):
            string = "0x" + str(hex(i))
            #print hex(i)
        else:
            string = str(i)
        if self.textAbove :
            self.draw.text ((self.startXY[0] - 11, self.startXY[1] - 24),
                            string,
                            (0, 0, 255))
            #self.textAbove = FALSE
        else :
            self.draw.text ((self.startXY[0] - 11, self.startXY[1] - 12),
                            string,
                            (0, 0, 255))
            #self.textAbove = TRUE

    #
    #   Call filters on trace here
    #
    def filter (self, trace) :
        #   Should we plot this gather?
        g = trace.gatherNum
        found = FALSE
        for gtp in self.gathersToPlot :
            #print g, gtp
            if gtp == g :
                found = TRUE
                break
            
        if found == FALSE :
            return None

        if self.filters != None and self.filters.numActive () > 0 :
            #print 'Filtering...%d' % self.filters.numActive ()
            t = self.filters.apply (trace)
            t = copy.copy (t)
            self.filters.free ()
        else :
            t = copy.copy (trace.data)
        
        return t

    def drawGather (self, seis, start, stop) :
        #   seis - dictionary of traces keyed by das and epoch
        #   start - start time in seconds from start of trace
        #   stop - stop time also in seconds
        self.lightRed ()
        dasList = seis.getDasList ()
        keyList = seis.getKeyList ()
        dasListStr = seis.getDasListStr ()
        epochList = seis.getEpochList ()
        nTraces = len (dasList)
        tSecs = seis.samples / seis.rate
        if stop <= 0 :
            stop = tSecs
            
        if start >= tSecs or start > stop :
            start = 0
            
        self.startSecs = start
        nSecs = stop - start
        #   Number of traces to fit if plotting by offset
        nTracesPlot = 0
        
        #for i in range (nTraces) :
            #traceData = seis.getData (epochList[i], keyList[i])
            #trace = self.filter (traceData)
            #if not trace :
                #print "Failed to find trace (epoch, key): ", epochList[i], keyList[i]
                
            #nTracesPlot += 1
            
        #nOffset = nTracesPlot
        #nOffset = nTraces
        nOffset = 0
        
        XwindowPix = 1024
        #lloyd removed this line to reenable horozon. scaling
        #don't know if it broke other things
        #self.setPixelsTrace ( int (round (1024 / float (nTracesPlot))) )
        #
        st = ScaleTrace ()
        #   Vertical scale

        st.setVars (sps = seis.rate,
                    pps = self.pixelsSecond,
                    start = start,
                    stop = stop)
        
        #   Horizontal scale
        st.setVars (ppt = self.pixelsTrace, gain = self.gain)
        
        #   Starting pixel pos
        self.startXY[0] = self.startXY[0] + (self.pixelsTrace / 2)
        tmpX = self.startXY[0]
        st.setVars (startY = self.startXY[1])
        
        self.indexedTrace = []

        if self.scaleByTrace == FALSE :
            st.setScaleByWindow (seis)
        else :
            st.setScaleByTrace ()
        
        #   Uggg, count traces we need to size canvas
        for i in range (nTraces) :
            t = seis.getData (epochList[i], keyList[i])
            g = t.gatherNum
            for gtp in self.gathersToPlot :
                if gtp == g :
                    nOffset += 1
                    break
                
        if self._sizeCanvas (nOffset, nSecs, start) == FALSE :
            return FALSE
        
        for i in range (nTraces) :
            traceData = seis.getData (epochList[i], keyList[i])
            try :
                if self.scaleByOffset :
                    n = float (traceData.offset) / float (seis.arrSpan)
                    self.startXY[0]=int( round(tmpX + n* XwindowPix) )
                else :
                    n = 1.0
            except :
                n = 1.0
                print "Scale by offset failed!"
                
            st.setVars (startX = self.startXY[0])
            self.message.set ("Scale trace: %d" % i)
            self.toggleLight ()
            #
            if not traceData :
                continue
            
            trace = self.filter (traceData)
            if trace == None : continue
            
            if not trace.all () :
                continue
            
            
            self.indexedTrace.append ((traceData, self.startXY[0]))
            #mtr = max (trace) - min (trace)
            scaledTrace = st.scale (trace) 
            #msc = max (scaledTrace) - min (scaledTrace)
            #print "Max trace: %f Max scaled: %d" % (mtr, msc)

            #del (trace)

            if self.style == WIGGLE :
                self.drawWiggle (scaledTrace)
            else :
                #self.drawWiggle (scaledTrace)
                self.drawColored (scaledTrace)

            if ( self.pixelsTrace > 35):

                if (seis.getGatherType() == 0) :
                    # shot gather 
                    self._labelTrace(dasListStr[i])
                else :
                    # receiver gather
                    self._labelTrace(traceData.energySourcePt)
 
            self.startXY[0] = (int (round (self.pixelsTrace * n))
                               + self.startXY[0])

        del (st)
        
        self.image = ImageTk.PhotoImage (self.im)
        xy = self.im.size

        x = int (xy[0] / 2)
        y = int (xy[1] / 2)
        self.message.set ("Displaying Image")
        self.canvas.create_image (x, y, image = self.image)
        self.message.set ("Idle")
        self.lightGreen ()

if __name__ == '__main__' :
    #print "Reading"
    seis = Segy.Segy ("gather.SGY")
    seis.readTraces ()
    
    startSeconds = 0.9
    endSeconds = 3.0
    
    mw = Tk ()
    #print "Drawing"
    ga = Gather (None, mw, 900, 600)
    ga.setStyle (WIGGLE)
    ga.setScaleByTrace ()
    ga.setGain(1.5)
    ga.setPixelsSecond (500)
    ga.setPixelsTrace (60)
    ga.pack ()

    ga.drawGather (seis, startSeconds, endSeconds)

    #print "Save"
    #stdout.flush ()
    ga.doSave ()
        
    mw.mainloop ()
