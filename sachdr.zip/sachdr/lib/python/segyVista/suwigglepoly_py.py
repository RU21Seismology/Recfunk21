
from distutils.core import setup, Extension

setup (name = "wigglepoly_py", version = "2001.277",
       ext_modules = [
    Extension (
    "wigglepoly_py",
    ["wigglepolywrapper_py.c", "wigglepoly_py.c"],
#    extra_link_args = ["-m32"]
     extra_compile_args = ["-errchk=longptr64"]
    )
    ]
       )
