#!/usr/bin/env python

import wigglepoly_py
import gc

class WigglePoly :
    TRUE = (1 == 1)
    FALSE = (0 == 1)
    def __init__ (self) :
        wigglepoly_py.init ()
        self.active = self.FALSE

    def __del__ (self) :
        wigglepoly_py.free ()
        gc.collect ()

    def build (self, scaled, mean, side = 1) :
        if wigglepoly_py.build (scaled, mean, side) :
            self.active = self.TRUE
        else :
            self.active = self.FALSE

    def next (self) :
        if self.active == self.FALSE :
            return None
        
        poly = wigglepoly_py.next ()

        if len (poly) <= 0 :
            pass
            #wigglepoly.free ()

        return poly
        
if __name__ == "__main__" :
    import math
    import sys
    piInc = math.pi / 1000.0
    a = []
    d = 0
    for y in range (10000) :
        x = math.sin (d) * 1000
        d += piInc
        #print "%d\t%d" % (int(x), y)
        x = int (x) + 1000
        a.append ([x, y])

    wp = WigglePoly ()
    j = 0
    print "Build...",
    wp.build (a, 1000, 1)
    #for i in a :
        #print i[0], i[1]
    print "Done"
    #sys.exit ()
    print "Getting polys"
    while 1 :
        poly = wp.next ()
        #print j
        #sys.stdout.flush ()
        #sys.stderr.flush ()

        for i in poly :
            print i
            
        if len (poly) <= 0 :
            print "Break ", j
            break
        
        j += 1
    #del (wp)







