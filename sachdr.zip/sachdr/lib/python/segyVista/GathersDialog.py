#!/usr/bin/env python

#
#   A widget to select which gather in a file/reel to plot.
#   On creation gets passed the number of gathers in the file,
#   on selection returns a list containing the selected gather numbers
#
#   Steve Azevedo, September 2001
#

from Tkinter import *
import Pmw

class GathersDialog :
    """
    gd = GathersDialog (root, numGathers)
    selectedList = gd.activate ()
    """
    def __init__ (self, root, num = 1) :
        self.n = num
        self.vars = []
        self.dialog = Pmw.Dialog (root,
                                  buttons = ('Okay', 'Cancel'),
                                  title = 'segyView')
        self.dialog.resizable (0, 0)
        self.rootFrame = self.dialog.interior ()

        textFrame = Frame (self.rootFrame,
                           relief = GROOVE,
                           borderwidth = 2)
        checkFrame = Frame (self.rootFrame,
                            relief = GROOVE,
                            borderwidth = 2)
        Label (textFrame,
               text = 'Gathers to plot:').pack ()
        textFrame.pack (side = TOP, fill = X)

        for n in range (num) :
            var = IntVar ()
            var.set (0)
            self.vars.append (var)
            cb = Checkbutton (checkFrame,
                              text = ("%02d" % (n + 1)),
                              variable = var)
            cb.pack (side = TOP, fill = X, anchor = W)

        checkFrame.pack (side = TOP, fill = X)
        self.vars[0].set (1)

    def activate (self) :
        ret = self.dialog.activate ()
        gathers = []
        for i in range (self.n) :
            val = self.vars[i].get ()
            if val == 1 :
                gathers.append (i + 1)

        if ret == 'Okay' :
            return gathers
        else :
            return None
        
            
if __name__ == '__main__' :
    import sys
    r = Tk ()
    r.withdraw ()
    Pmw.initialise (r)
    gd = GathersDialog (r, 10)
    print gd.activate ()
    sys.exit ()
    r.mainloop ()



