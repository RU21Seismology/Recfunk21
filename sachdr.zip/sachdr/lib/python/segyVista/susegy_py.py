
from distutils.core import setup, Extension
import os

setup (name = "segy_py", version = "2001.205",
       ext_modules = [
    Extension (
    "segy_py", ["segy_py.c",
                "ibm2ieee_py.c",
                "segywrapper_py.c",
                "segytime_py.c"],
    include_dirs = ["../include"],
    define_macros = [(os.environ['OSTYPE'], 1)],
#    extra_link_args = ["-m32"]
    extra_compile_args = ["-errchk=longptr64"]
)])
