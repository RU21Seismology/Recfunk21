
from distutils.core import setup, Extension

setup (name = "agc_py", version = "2001.273",
       ext_modules = [
    Extension (
    "agc_py", ["agc_py.c", "agcwrapper_py.c"],
#    extra_link_args = ["-m32"]
    extra_compile_args = ["-errchk=longptr64"]
)])
