#!/usr/bin/env python

#
#   A widget to select a time range, (part of Natt)
#
#   Steve Azevedo, Feburary 2001
#

from Tkinter import *
import Pmw

class TimeDialog :
    def __init__ (self, root,
                  currentStart = 0.0,
                  currentStop = 10.0,
                  maxSeconds = 10.0,
                  minPixSecond = 1,
                  maxPixSecond = 1024,
                  pixelsTrace = 1) :
        #
        #    root = root window
        #    currentStart = start time in seconds offset
        #    currentStop = end of plotted trace time in seconds offset
        #    maxSeconds = total length of trace in seconds
        #    minPixSecond = minimum pixels / second
        #    maxPixSecond = maximum pixels / second
        #    pixelsTrace = current pixels / second
        #    returns selected start, stop, pixels as a tuple
        #    (or original start, stop, pixels) if the Cancel button is pressed
        #
        self.currentStart = currentStart
        self.currentStop = currentStop
        self.maxSeconds = maxSeconds

        self.minPixSecond = minPixSecond
        self.maxPixSecond = maxPixSecond
        self.pixelsTrace = pixelsTrace

        self.dialog = Pmw.Dialog (root,
                                  buttons = ('Okay', 'Cancel'),
                                  title = 'segyView')
        self.dialog.resizable (0,0)
        self.rootFrame = self.dialog.interior ()

        self.labelFrame = Frame (self.rootFrame,
                                 relief = GROOVE,
                                 borderwidth = 2)
        Label (self.labelFrame,
               text = 'Portion of trace to display from start').pack ()
        
        self.scaleFrame = Frame (self.rootFrame,
                                 relief = FLAT,
                                 borderwidth = 2)

        self.scaleStart = Scale (self.scaleFrame,
                                 label = 'Start Seconds',
                                 orient = VERTICAL,
                                 relief = GROOVE,
                                 borderwidth = 2,
                                 length = 200,
                                 width = 8,
                                 resolution = 0.01,
                                 from_ = 0.0,
                                 to = self.maxSeconds)
        self.scaleStart.set (self.currentStart)
        self.scaleStart.bind ('<ButtonRelease-1>', self.checkStop)
        
        self.scaleStop = Scale (self.scaleFrame,
                                label = 'Stop Seconds',
                                orient = VERTICAL,
                                relief = GROOVE,
                                borderwidth = 2,
                                length = 200,
                                width = 8,
                                resolution = 0.01,
                                from_ = 0.0,
                                to = self.maxSeconds)
        self.scaleStop.set (self.currentStop)
        self.scaleStop.bind ('<ButtonRelease-1>', self.checkStart)

        self.labelStretchFrame = Frame (self.rootFrame,
                                        relief = GROOVE,
                                        borderwidth = 2)

        self.stretchLabel = Label (self.labelStretchFrame,
                                   text = "Stretch trace")
        
        self.stretchFrame = Frame (self.rootFrame,
                                   relief = FLAT,
                                   borderwidth = 2)
        
        self.scaleTrace = Scale (self.stretchFrame,
                                  label = 'Pixels/Second',
                                  orient = HORIZONTAL,
                                  relief = GROOVE,
                                  borderwidth = 2,
                                  length = 260,
                                  width = 8,
                                  from_ = minPixSecond,
                                  to = maxPixSecond)
        
        self.scaleTrace.set (self.pixelsTrace)

        self.labelFrame.pack (side = TOP, fill = X)
        self.scaleFrame.pack (side = TOP, fill = X)
        self.scaleStart.pack (side = LEFT)
        self.scaleStop.pack (side = RIGHT)
        self.labelStretchFrame.pack (fill = X)
        self.stretchLabel.pack ()
        self.stretchFrame.pack (side = TOP, fill = X)
        self.scaleTrace.pack (side = BOTTOM, fill = X)
        self.dialog.withdraw ()

    def init (self,
              currentStart,
              currentStop,
              maxSeconds,
              minPixSecond,
              maxPixSecond,
              pixelsTrace) :
        
        self.currentStart = currentStart
        self.currentStop = currentStop
        self.maxSeconds = maxSeconds

        self.minPixSecond = minPixSecond
        self.maxPixSecond = maxPixSecond
        self.pixelsTrace = pixelsTrace

        self.scaleStart.configure (to = maxSeconds)
        self.scaleStop.configure (to = maxSeconds)
        self.scaleTrace.configure (from_ = minPixSecond, to = maxPixSecond)

        #print "Set Start: %f, Stop: %f" % (self.currentStart,
        #                                   self.currentStop)
        
        self.scaleStart.set (self.currentStart)
        self.scaleStop.set (self.currentStop)
        self.scaleTrace.set (self.pixelsTrace)

    def activate (self) :
        #   
        ret = self.dialog.activate ()
        start = self.scaleStart.get ()
        stop = self.scaleStop.get ()
        stretch = self.scaleTrace.get ()
        self.dialog.deactivate ()
        if ret == 'Okay' :
            return (start, stop, stretch)
        else :
            return (self.currentStart, self.currentStop, self.pixelsTrace)

    def checkStart (self, e) :
        #    Make sure start is not after stop
        start = self.scaleStart.get ()
        stop = self.scaleStop.get ()
        if stop < start :
            self.scaleStart.set (stop)

    def checkStop (self, e) :
        #    Make sure stop is not before start
        start = self.scaleStart.get ()
        stop = self.scaleStop.get ()
        if start > stop :
            self.scaleStop.set (start)


if __name__ == '__main__' :
    import sys
    import time
    r = Tk ()
    r.withdraw ()
    Pmw.initialise (r)
    td = TimeDialog (r, 0, 12, 15, 5, 50, 10)
    print "Sleeping..."
    time.sleep (3)
    print "Activate..."
    print td.activate ()
    print "Sleeping..."
    time.sleep (3)
    print "Activate..."
    td.init (1, 13, 16, 6, 51, 11)
    print td.activate ()
    sys.exit ()
    r.mainloop ()











