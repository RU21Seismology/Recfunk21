#!/usr/bin/env python

#
#   A class to manage filtering if NumPy seismic traces.
#   All filters (for NaAT) run in two modes, configuration of the filter 
#   parameters, and application of the filter to the trace.  This class
#   operates it the same way.  Each filter is added, then configured.
#   Filters are then applied to the trace in the order that they are added
#   to the Filtering object.  Filters can also be removed from the filtering
#   chain.  The method apply, applies each filter in order and returns the
#   result as an N X 1 NumPy array.
#
#   Steve Azevedo, October 2001
#

import copy
import sys

class Filtering :

    TRUE = (1 == 1)
    FALSE = (0 == 1)
    
    def __init__ (self) :
        """
        names = a list of the names of the filters to apply
        initialized = a boolean to tell if a specific filter has been
                      initialised.
        objects = a dictionary of filter objects
        """
        self.names = []
        self.initialized = {}
        self.objects = {}
        self.active = {}

    def numActive (self) :
        """ Return the number of active filters """
        i = 0
        for n in self.names :
            if self.active[n] == self.TRUE :
                i += 1
        return i
    
    def add (self, name, object) :
        """ Build list and dictionary of filters """
        self.names.append (name)
        self.objects[name] = object
        self.initialized[name] = self.FALSE
        self.active[name] = self.FALSE

    def remove (self, name) :
        """ Remove a filter from the list """
        i = 0
        for n in self.names :
            if n == name :
                try :
                    del self.names[i]
                    del self.objects[name]
                    del self.initialized[name]
                except AttributeError :
                    sys.stderr.write ("Failed to remove " + name)
                break
            i += 1

    def activate (self, name) :
        if self.active.has_key (name) :
            self.active[name] = self.TRUE

    def deActivate (self, name) :
        if self.active.has_key (name) :
            self.active[name] = self.FALSE

    def isActive (self, name) :
        if self.active.has_key (name) :
            return self.active[name]
        else :
            return None

    def initialize (self, name, **kw) :
        """ Initialize a filter """
        self.objects[name].setVars (**kw)
        self.initialized[name] = self.TRUE

    def getVars (self, name) :
        """ Return configuration for this filter """
        if self.objects.has_key (name) :
            return self.objects[name].getVars ()
        else :
            return None

    def free (self) :
        for name in self.names :
            self.objects[name].freeTrace ()

    def apply (self, trace) :
        """ Apply all filters in sequence to NumPy trace file """
        newTrace = copy.copy (trace.data)
        for name in self.names :
            if self.active[name] == self.TRUE :
                newTrace = self.objects[name].apply (newTrace)

        return newTrace







