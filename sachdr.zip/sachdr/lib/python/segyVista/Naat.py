#!/usr/bin/env python

PROG_VERSION = "2010.330"

FILLPOSITIVE = 1
NOFILL = 0
FILLNEGATIVE = -1

from Tkinter import *
import Pmw
from time import gmtime, sleep
from FileDialog import *
from TkFileDialog import *
import Gather
import TimeDialog
import ScaleDialog
import OptionsDialog
import GathersDialog
import AgcDialog
import string
import tkMessageBox
import os.path
import re
import Segy
import threading
#   Filters
import Filtering
import Agc

#
#    A simple message  bar class
#
class MessageBar (Frame) :
    def __init__ (self, root, width = 40) :
        self.root = root
        self.width = width
        apply (Frame.__init__, (self, root))
        self.message = Label (self,
                             height = 1,
                             width = self.width,
                             font = (('MS', 'Sans', 'Serif'), '10'),
                             relief = FLAT)
        self.message.pack ()

    def set (self, mes) :
        self.message.configure (text = mes)
        self.root.update_idletasks ()

#
#
#
class Naat (Frame) :
    TRUE = (1 == 1)
    FALSE = (1 == 0)
    def __init__ (self, root, **kw) :
        apply (Frame.__init__, (self, root), kw)
        t = Toplevel (root)
        t.title ('segyView Display Window')

        self.root = root
        self.path = ''
        self.seis = None
        self.gathersList = []
        self.gathersList.append (1)
        self.epochs = self.dases = []
        self.fd = TkFileDialog ()

        self.initPlotVars ()
        self.setUpFilters ()
        self.initDialogs ()
        
        menuFrame = Frame (self)
        listFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        radioFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        pathFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        activityFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        buttonFrame = Frame (self, relief = GROOVE, borderwidth = 2)

        #   Set up menu
        self.menuBar = Pmw.MenuBar (menuFrame,
                                    hull_relief = GROOVE,
                                    hull_borderwidth = 2)
        self.menuBar.pack (fill = X)

        #   File menu
        self.menuBar.addmenu ('File', 'FileCommands', tearoff = 1)
        self.menuBar.addmenuitem ('File', 'command',
                                  label = 'Input file...',
                                  command = self.getPath)
        self.menuBar.addmenuitem ('File', 'separator')
        self.menuBar.addmenuitem ('File', 'command',
                                  label = 'Save eps...',
                                  command = self.saveEps)
        self.menuBar.addmenuitem ('File', 'separator')
        self.menuBar.addmenuitem ('File', 'command',
                                  label = 'Quit',
                                  command = self.goByeBye)

        #   Options menu
        self.menuBar.addmenu ('Options', 'OptionsCommands', tearoff = 1)
        self.menuBar.addmenuitem ('Options', 'command',
                                  label = 'Gathers to plot...',
                                  command = self.getGatherNums)
        self.menuBar.addmenuitem ('Options', 'separator')
        self.menuBar.addmenuitem ('Options', 'command',
                                  label = 'Vertical scale...',
                                  command = self.getVerticalScale)
        self.menuBar.addmenuitem ('Options', 'command',
                                  label = 'Horizontal scale...',
                                  command = self.getHorizontalScale)
        self.menuBar.addmenuitem ('Options', 'separator')
        self.menuBar.addmenuitem ('Options', 'command',
                                  label = 'Plot options...',
                                  command = self.getPlotOptions)
        self.menuBar.addmenuitem ('Options', 'separator')
        self.menuBar.addmenuitem ('Options', 'command',
                                  label = 'Plot/Re-plot',
                                  command = self.rePlot)
        #   Filter menu
        self.menuBar.addmenu ('Filters', 'OptionsCommands', tearoff = 1)
        self.menuBar.addmenuitem ('Filters', 'command',
                                  label = 'AGC...',
                                  command = self.getAgcOptions)

        #   List box
        self.listBox = Text (listFrame,
                             width = 40,
                             height = 10,
                             background = 'gray')
        self.listBox.tag_config ("new", foreground = 'white')
        self.listBox.tag_config ("scale", foreground = 'ForestGreen')
        self.listBox.tag_config ("plot", foreground = 'SaddleBrown')
        self.listBox.pack (side = LEFT)
        self.scrollBar = Scrollbar (listFrame,
                                    relief = GROOVE,
                                    borderwidth = 2,
                                    width = 8,
                                    command = self.listBox.yview)
        self.scrollBar.pack (side = RIGHT, fill = Y)
        self.listBox.configure (yscrollcommand = self.scrollBar.set)

        #   Path entry box
        self.entryVar = StringVar ()
        self.entryPath = Entry (pathFrame,
                                textvariable = self.entryVar,
                                width = 42)
        self.entryPath.bind ('<Return>', self.setEntry)
        self.entryPath.pack ()

        #   Activity box
        self.message = MessageBar (activityFrame, 20)
        self.message.pack ()
        self.message.set ('Idle')

        #   Buttons
        self.buttonPlot = Button (buttonFrame,
                                  text = 'Plot/Re-plot',
                                  command = self.rePlot,
                                  relief = RAISED,
                                  borderwidth = 2)
        self.buttonPlot.pack (fill = X)

        #   Pack all the frames
        menuFrame.pack (side = TOP, fill = X)
        listFrame.pack (side = TOP, fill = X)
        radioFrame.pack (side = TOP, fill = X)
        pathFrame.pack (side = TOP, fill = X)
        activityFrame.pack (side = TOP, fill = X)
        buttonFrame.pack (side = TOP, fill = X)
        #   Pack Display window
        self.gather = Gather.Gather (self.message, t, 0,0)
        self.gather.pack (fill=BOTH, expan =YES)

    def displayPlotVars (self) :
        #   Display plot variables in text box
        style = {-1: 'Fill -', 0: 'Wiggle', 1: 'Fill +'}
        scale = {0: 'By Trace', 1: 'By Window'}
        offset = {0: 'Fixed', 1: 'Shot to receiver'}
        pv = self.plotVars
        self.listBox.insert (END, "--- New Plot ---\n", "new")
        self.listBox.insert (END, "SEGY File: %s\n" % pv['file'])
        self.listBox.insert (END, "Pixels / Second: %d\n" % pv['pps'], "scale")
        self.listBox.insert (END, "Pixels / Trace: %d\n" % pv['ppt'], "scale")
        self.listBox.insert (END, "Start Seconds: %f\n" % pv['start'])
        self.listBox.insert (END, "Stop Seconds: %f\n" % pv['stop'])
        self.listBox.insert (END, "Plot Style: %s\n" %
                             style[pv['style']], "plot")
        self.listBox.insert (END, "Amplitude scaling: %s\n" %
                             scale[pv['scaling']], "plot")
        self.listBox.insert (END, "Gain: %d\n" % pv['gain'], "plot")
        self.listBox.insert (END, "Trace Offset: %s\n" %
                             offset[pv['offset']], "plot")
        

    def setPlotVars (self, **kwargs) :
        #
        #   Plot args (self.plotVars):
        #   file = SEGY file name
        #   pps = pixels per second
        #   ppt = pixels per trace
        #   start = start seconds
        #   stop = stop seconds
        #   gain = amplitude gain to trace
        #   style = fill negative side = -1,
        #           wiggle = 0
        #           fill positive side = 1
        #   scaling = trace = 0
        #             window = 1
        #   offset = fixed = 0
        #            shot to receiver = 1
        for k in kwargs.keys () :
            self.plotVars[k] = kwargs[k]

    def initPlotVars (self) :
        self.plotVars = {}
        self.plotVars['file'] = None    #
        self.plotVars['pps'] = None     #   Set when file is read
        self.plotVars['ppt'] = None     #   Set when file is read
        self.plotVars['start'] = 0.0    #   Start of trace
        self.plotVars['stop'] = 0.0     #   End of trace
        self.plotVars['gain'] = 1.0     #   No gain
        self.plotVars['style'] = 0      #   Wiggle
        self.plotVars['scaling'] = 0    #   Scale to trace
        self.plotVars['offset'] = 0     #   Plot fixed spacing
        
    def newPlotWindow (self, seis, pps = 0, ppt = 0) :
        try :
            if self.gather :
                self.gather.destroy ()
                
            self.gather = Gather.Gather (seis, self.root, 0,0)
            if seis == None :
                self.gather.setStyle (NOFILL)
                self.gather.setScaleByTrace ()
                self.gather.setGain (1)
            self.gather.setPixelsSecond (pps)
            self.gather.setPixelsTrace (ppt)
            self.gather.pack ()
        except :
            print "Can't create plot window"

    def openPlot (self) :
        #   Open a segy file and read reel headers
        self.root.configure (cursor = 'gumby')
        self.message.set ("Reading file...")
        self.root.update_idletasks ()
        
        try :
            #   Open the SEGY file
            self.seis = Segy.Segy (self.path)
            self.seis.readTraces (self.root)
            #   Reset list of gathers in file to plot to 1
            self.gathersList = []
            self.gathersList.append (1)
            samples = self.seis.samples
            rate = self.seis.rate
            seconds = float (samples) / rate
            #print "Seconds: %f Rate: %f Samples: %d" % (seconds,
            #                                            rate,
            #                                            samples)
            numTraces = len (self.seis.dases)
            pixelsX = 1024.0
            pixelsY = 700.0
            gain = 1
            pixelsPerSecond = int (round (pixelsY / seconds))
            if pixelsPerSecond < 3 :
                pixelsPerSecond = 3
            pixelsPerTrace = int (round (pixelsX / float (numTraces)))
            if pixelsPerTrace < 2 :
                pixelsPerTrace = 2
            if pixelsPerTrace < 3 :
                gain = 2.0
                
            self.setPlotVars (pps = pixelsPerSecond,
                              ppt = pixelsPerTrace,
                              gain = gain,
                              file = self.path,
                              stop = seconds,
                              start = 0)
        except :
            tkMessageBox.showwarning (message = "Can't read %s\n" % self.path)
            
        #return
        self.root.configure (cursor = 'left_ptr')
        self.message.set ('Idle')

    def initDialogs (self) :
        self.ad = AgcDialog.AgcDialog (self.root)
        #self.ad.withdraw ()
        self.pd = OptionsDialog.OptionsDialog (self.root)
        #self.pd.withdraw ()
        self.sd = ScaleDialog.ScaleDialog (self.root)
        #self.sd.withdraw ()
        self.td = TimeDialog.TimeDialog (self.root)
        #self.td.withdraw ()

    def getPath (self) :
        #   Get path to segy file from filename widget
        self.fd.setFileTypes ([("SEGY", "*\[Ss\]\[Gg\]\[Yy\]"), ("all", "*")])
        self.path = self.fd.askopenfilename ()
        if self.path == None :
            self.path = ''
        if self.path != '' :
            #   Open Segy file here
            self.entryVar.set (self.path)
            self.openPlot ()

    def saveEps (self) :
        #   Save plot as postscript
        file = self.fd.asksaveasfilename ()
        if self.gather != None and file != None :
            self.gather.doSave (file)

    def goByeBye (self) :
        #   Kill root window
        self.root.destroy ()

    def getPlotOptions (self) :
        #   Throw up a dialog to get plot options
        style = self.plotVars['style']
        scaling = self.plotVars['scaling']
        offset = self.plotVars['offset']
        self.pd.init (style, scaling, offset)
        style, scaling, offset = self.pd.activate ()
        self.setPlotVars (style = style,
                          scaling = scaling,
                          offset = offset)

    def getHorizontalScale (self) :
        #   Launch Scale dialog widget
        #   ALERT: This should get set based on
        p = self.plotVars['ppt']
        if p == None :
            p = 5
        y = 6 * p
        ppt = (1, y, p)
        g = self.plotVars['gain']
        y = 20 * g
        gain = (1, y, g)
        self.sd.init (ppt, gain)
        p, g = self.sd.activate ()
        self.setPlotVars (ppt = p,
                          gain = g)

    def getGatherNums (self) :
        if self.seis == None :
            num = 1
        else :
            num = self.seis.gathersInFile

        gd = GathersDialog.GathersDialog (self.root, num)

        g = gd.activate ()
        if g != None :
            self.gathersList = g

    def getVerticalScale (self) :
        #   Launch Time dialog widget
        #   ALERT
        start = self.plotVars['start']
        stop = self.plotVars['stop']
        try :
            max = float (self.seis.samples) / self.seis.rate
        except :
            max = 300.0
        curpps = self.plotVars['pps']
        if curpps == None :
            curpps = 10
        minpps = 1
        maxpps = curpps * 20
        #print "Start: %f Stop: %f Max: %f" % (start, stop, max)
        self.td.init (start, stop, max, minpps, maxpps, curpps)
        start, stop, pps = self.td.activate ()
        self.setPlotVars (pps = pps,
                          start = start,
                          stop = stop)

    #   Set up Filtering object to know about filters
    def setUpFilters (self) :
        #   Get a filtering object
        self.filters = Filtering.Filtering ()
        #
        #   Now add filters
        #
        #   AGC
        agc = Agc.Agc ()
        self.filters.add ('agc', agc)

    def setAgc (self) :
        if self.seis != None :
            interval = self.seis.interval
            if self.filters.isActive ('agc') :
                self.filters.initialize ('agc',
                                         interval = interval)
            
    #   Get and set options for AGC
    def getAgcOptions (self) :
        #   Get current arguments
        options = self.filters.getVars ('agc')
        #   Is this filter active?
        a = self.filters.isActive ('agc')
        #   Throw up a dialog for agc options
        self.ad.init (options['window'],
                      options['dwind'],
                      options['threshold'],
                      a)
        ret = self.ad.activate ()
        #   Configure agc filter through the Filtering object
        self.filters.initialize ('agc',
                                 window = ret[1],
                                 dwind = ret[2],
                                 threshold = ret[3])

        #   Turn this filter on or off based on what we got from the
        #   agc dialog
        if ret[0] == self.TRUE :
            self.filters.activate ('agc')
        else :
            self.filters.deActivate ('agc')
    
    def setEntry (self, e) :
        #   Set path from entry box
        n = self.entryPath.get ()
        self.path = self.prev = ''
        flds = string.split (n, ':')
        allDir = TRUE
        for i in flds :
            if not os.path.isdir (i) :
                allDir = FALSE
        self.entryPath.delete (0, END)
        if allDir :
            self.path = self.prev = n
            self.entryVar.set (n)

    def rePlot (self) :
        if self.seis == None :
            tkMessageBox.showwarning (message = "No input file selected")
            return
        #   Plot or replot gather
        self.root.configure (cursor = 'gumby')
        self.setAgc ()
        self.gather.setFilters (self.filters)
        #   Plot commands go here
        self.gather.initVars ()
        self.displayPlotVars ()
        self.gather.setStyle (self.plotVars['style'])
        #   Change this in Gather.py
        if self.plotVars['scaling'] == 0 :
            self.gather.setScaleByTrace ()
        else :
            self.gather.setScaleByWindow ()
        if self.plotVars['offset'] == 0 :
            self.gather.setScaleByFixed ()
        else :
            self.gather.setScaleByOffset ()
        self.gather.setGathersToPlot (self.gathersList)
        self.gather.setGain (self.plotVars['gain'])
        self.gather.setPixelsSecond (self.plotVars['pps'])
        self.gather.setPixelsTrace (self.plotVars['ppt'])
        #   Set up filters
        #   Now draw graph
        self.gather.drawGather (self.seis,
                                self.plotVars['start'],
                                self.plotVars['stop'])
        #except :
        #    tkMessageBox.showwarning (message = "Can't plot input file")
            
        self.root.configure (cursor = 'left_ptr')


if __name__ == "__main__" :
    import os
    print "Version: %s" % PROG_VERSION
    os.environ['TZ'] = 'UTM'
    r = Tk ()
    r.title ('segyView Control Panel')
    n = Naat (r)
    n.pack ()
    n.mainloop ()














