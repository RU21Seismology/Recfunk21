#!/usr/bin/env python

#
#   A widget to set up for an agc filter
#
#   Steve Azevedo, October 2001
#

from Tkinter import *
import Pmw
import sys

class AgcDialog :
    def __init__ (self, root, windowMs = 32,
                              dwindMs = 32,
                              threshold = 0.0,
                              yesNo = 0) :
        #   root = root window
        #   windowMs = Agc window in milliseconds
        #   dwindMs = Detection window in milliseconds
        #   threshold = detection threshold
        #   yesNo = Is agc on or off
        
        self.windowMs = windowMs
        self.dwindMs = dwindMs
        self.threshold = threshold
        self.yesNo = yesNo
        
        self.dialog = Pmw.Dialog (root,
                                  buttons = ('Okay', 'Cancel'),
                                  title = 'segyView')
        self.dialog.resizable (0,0)
        self.rootFrame = self.dialog.interior ()

        self.windowFrame = Frame (self.rootFrame,
                                  relief = FLAT)

        self.scaleWindow = Scale (self.windowFrame,
                                  label = 'AGC Window (milliseconds)',
                                  orient = HORIZONTAL,
                                  relief = GROOVE,
                                  borderwidth = 2,
                                  length = 200,
                                  width = 8,
                                  from_ = 16,
                                  to = 2048)
        self.scaleWindow.set (self.windowMs)
        
        self.scaleDwind = Scale (self.windowFrame,
                                 label = 'Detection Window (milliseconds)',
                                 orient = HORIZONTAL,
                                 relief = GROOVE,
                                 borderwidth = 2,
                                 length = 200,
                                 width = 8,
                                 from_ = 16,
                                 to = 2048)
        self.scaleDwind.set (self.dwindMs)
        
        self.scaleThreshold = Scale (self.windowFrame,
                                     label = 'Threshold Amplitude',
                                     orient = HORIZONTAL,
                                     relief = GROOVE,
                                     borderwidth = 2,
                                     length = 200,
                                     width = 8,
                                     resolution = 0.1,
                                     from_ = 0.0,
                                     to = 204.8)
        self.scaleThreshold.set (self.threshold)

        self.windowFrame.pack (side = TOP, fill = X)
        self.scaleWindow.pack (side = TOP)
        self.scaleDwind.pack (side = TOP)
        self.scaleThreshold.pack (side = TOP)

        self.do = IntVar ()
        self.toggleFrame = Frame (self.rootFrame, relief = FLAT)
        Checkbutton (self.toggleFrame,
                     text = 'Automatic Gain Control',
                     variable = self.do).pack ()
        self.do.set (self.yesNo)
        self.toggleFrame.pack (side = TOP, fill = X)
        self.dialog.withdraw ()

    def init (self, windowMs, dwindMs, threshold, yesNo) :
        
        self.windowMs = windowMs
        self.dwindMs = dwindMs
        self.threshold = threshold
        self.yesNo = yesNo
        
        self.scaleWindow.set (self.windowMs)
        self.scaleDwind.set (self.dwindMs)
        self.scaleThreshold.set (self.threshold)
        self.do.set (self.yesNo)

    def activate (self) :
        ret = self.dialog.activate ()
        wind = self.scaleWindow.get ()
        dwind = self.scaleDwind.get ()
        thresh = self.scaleThreshold.get ()
        yesNo = self.do.get ()
        self.dialog.deactivate ()
        if ret == 'Okay' :
            return (yesNo, wind, dwind, thresh)
        else :
            return (self.yesNo,
                    self.windowMs,
                    self.dwindMs,
                    self.threshold)

if __name__ == '__main__' :
    import sys
    import time
    r = Tk ()
    r.withdraw ()
    Pmw.initialise (r)
    ad = AgcDialog (r, 256, 15, 25.0, 0)
    print "Sleeping..."
    time.sleep (3)
    print "Activate..."
    ad.init (256, 15, 25.0, 0)
    ret = ad.activate ()
    print ret
    print "Sleeping..."
    time.sleep (3)
    print "Activate..."
    ret = ad.activate ()
    sys.exit ()
    r.mainloop ()














