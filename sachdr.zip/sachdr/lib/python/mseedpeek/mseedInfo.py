# VERSION 2005.026
# definitions of variables for the various seed blockettes. The
# 0th entry is the title of the blockette
BlkVars = {}
BlkVars[100] = [
	"Sample Rate Blockette 100 (12 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"Actual Sample Rate:",
	"Flags:",
	"Reserved:"
]

BlkVars[200]= [
	"Generic Event Detection Blockette 200 (52 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"Signal Amplitude:",
	"Signal Period:",
	"Background Estimate:",
	"Event Detection Flags:",
	"Reserved:",
	"Signal Onset Time:",
	"Detector Name:",
]

BlkVars[201] = [
	"Murdock Event Detection Blockette 201 (60 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"Signal Amplitude:",
	"Signal Period:",
	"Background Estimate:",
	"Event Detection Flags:",
	"Reserved:",
	"Signal Onset Time:",
	"Signal-to-Noise Ratio Values:",
	"Lookback Value:",
	"Pick Algorithym:",
	"Detector Name:",
]

BlkVars[300] = [
	"Step Calibration Blockette 300 (60 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"Beginning of Calibration Time:",
	"Number of Step Calibrations:",
	"Calibrations Flags:",
	"Step Duration:",
	"Interval Durations:",
	"Calibration Signal Amplitude:",
	"Channel with Calibration Input:",
	"Reserved:",
	"Reference Amplitude:",
	"Coupling:",
	"Rolloff:"
]

BlkVars[310] = [
	"Sine Calibration Blockette 310 (60 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"Beginning of Calibration time:",
	"Reserved:",
	"Calibrations Flags:",
	"Calibration Duration:",
	"Period of Signal:",
	"Amplitude of Signal:",
	"Channel with Calibration input:",
	"Reserved:",
	"Reference Amplitued:",
	"Coupling:",
	"Rolloff:"
]

BlkVars[320] = [
	"Pseudo-random Calibraton Blockette 320 (64 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"Beginning of calibration time:",
	"Reserved:",
	"Calibrations flags:",
	"Calibration duration:",
	"Peak-to-peak amplitude of steps:",
	"Channel with calibration input:",
	"Reserved:",
	"Reference amplitued:",
	"Coupling:",
	"Rolloff:",
	"Noise type:"
]

BlkVars[390] = [
	"Generic Calibraton Blockette 390 (28 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"Beginning of Calibration Time:",
	"Reserved:",
	"Calibrations Flags:",
	"Calibration Duration:",
	"Calibration Signal Amplitude:",
	"Channel with Calibration Input:",
	"Reserved:"
]

BlkVars[395] = [
	"Calibraton Abort Blockette 395 (16 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"End of calibration time:",
	"Reserved:"
]

BlkVars[400] = [
	"Beam Blockette 400 (16 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"Beam Azimuth (degrees):",
	"Beam Slowness (sec/degree):",
	"Beam Configuration:",
	"Reserved:"
]

BlkVars[405] = [
	"Beam Delay Blockette 405 (6 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"Array of Delay Values:"
]

BlkVars[500] = [
	"Timing Blockette 500 (200 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"VCO Correction:",
	"Time of Exception:",
	"microsec:",
	"Reception Quality:",
	"Exception Count:",
	"Exception Type:",
	"Clock Model:",
	"Clock Status:"
]

BlkVars[1000] = [
	"Data Only SEED Blockette 1000 (8 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"Encoding Format:",
	"Word Order:",
	"Data Record Length:",
	"Reserved:"
]

BlkVars[1001] = [
	"Data Extension Blockette 1001 (8 bytes)",
	"Blockette Type:",
	"Next Blk Offset:",
	"Timing Quality:",
	"microsec:",
	"Reserved:",
	"Frame Count:",
]

BlkVars[2000] = [
	"Variable Length Opaque Data Blockette",
	"Blockette Type:",
	"Next Blk Offset:",
	"Total Blockette Length in Bytes:",
	"Offset to Opaque Data:",
	"Record Number:",
	"Data Word Order:",
	"Opaque Data Flags:",
	"Number of Opaque Header Fields:",
	"Opaque Data Header Fields:"
]

# definitions of variables for the various seed blockettes. The
# 0th entry is the title of the blockette
BlkInfoDict = {}

BlkInfoDict["Data Fields"] = """

Field type   Number of bits   Field description
UBYTE         8               Unsigned quantity
BYTE          8               Twos complement signed quantity
UWORD        16               Unsigned quantity
WORD         16               Twos complement signed quantity
ULONG        32               Unsigned quantity
LONG         32               Twos complement signed quantity
CHAR*n       n*8              n characters, each 8 bits and each with a
                              7-bit ASCII character (high bit always 0)
FLOAT        32               IEEE Floating point number
"""

BlkInfoDict["BTime"] = """

Field type   Number of bits   Field description
UWORD        16               Year (e.g., 1987)
UWORD        16               Day of Year (Jan 1 is 1)
UBYTE         8               Hours of day (023)
UBYTE         8               Minutes of day (059)
UBYTE         8               Seconds of day (059, 60 for leap seconds)
UBYTE         8               Unused for data (required for alignment)
UWORD        16               .0001 seconds (09999)
"""

BlkInfoDict["Fixed Header"] = """

Fixed Section of Data Header (48 bytes)

The data record header starts at the first byte. The next eight bytes follow
the same structure as the control headers. Byte seven contains an ASCII D,
indicating it is a data record. (The eighth byte, or third field, is always
an ASCII space  shown here as a "delta"). The next ten bytes contain the station,
location, and channel identity of the record. The rest of the header section
is binary.

Note   Field Name                    Type   Length   Mask or Flags
1      Sequence number               A       6       "######"
2      Data header/quality indicator
       (D|R|Q)                       A       1
3      Reserved byte ("delta")       A       1
4      Station identifier code       A       5       [UN]
5      Location identifier           A       2       [UN]
6      Channel identifier            A       3       [UN]
7      Network Code                  A       2
8      Record start time             B      10
9      Number of samples             B       2
10      Sample rate factor           B       2
11      Sample rate multiplier       B       2
12      Activity flags               B       1
13      I/O and clock flags          B       1
14      Data quality flags           B       1
15      Number of blockettes that 
        follow                       B       1
16      Time correction              B       4
17      Beginning of data            B       2
18      First blockette              B       2

Notes for fields: * indicates mandatory information
1 * Data record sequence number (Format "######").
2 * "D" or "R" or "Q"  Data header/quality indicator. Previously, this
    field was only allowed to be "D" and was only used to indicate that
    this is a data header. As of SEED version 2.4 the meaning of this
    field has been extended to also indicate the level of quality control
    that has been applied to the record.
      D  The state of quality control of the data is indeterminate.
      R  Raw Waveform Data with no Quality Control
      Q  Quality Controlled Data, some processes have been applied to the data.
3   Space (ASCII 32)  Reserved; do not use this byte.
4 * Station identifier designation (see Appendix G). Left justify and pad with
    spaces.
5 * Location identifier designation. Left justify and pad with spaces.
6 * Channel identifier designation (see Appendix A). Left justify and pad
    with spaces.
7 * A two character alphanumeric identifier that uniquely identifies the
    network operator responsible for the data logger. This identifier is
    assigned by the IRIS Data Management Center in consultation with the
    FDSN working group on the SEED format.
8 * BTIME: Start time of record.
9 * UWORD: Number of samples in record.
10 * WORD: Sample rate factor:
           > 0  Samples/second
           < 0  Seconds/sample
11 * WORD: Sample rate multiplier:
           >0  Multiplication factor
           <0  Division factor
12 UBYTE: Activity flags:
          [Bit 0]  Calibration signals present
   *      [Bit 1]  Time correction applied. Set this bit to 1 if the time
                    correction in field 16 has been applied to field 8. Set
                    this bit to 0 if the time correction in field 16 has not
                    been applied to field 8.
          [Bit 2]  Beginning of an event, station trigger
          [Bit 3]  End of the event, station detriggers
          [Bit 4]  A positive leap second happened during this record (A 61
                    second minute).
          [Bit 5]  A negative leap second happened during this record (A 59
                    second minute). A negative leap second clock correction has
                    not yet been used, but the U.S. National Bureau of Standards
                    has said that it might be necessary someday.
          [Bit 6]  Event in progress
13 UBYTE: I/O flags and clock flags:
          [Bit 0]  Station volume parity error possibly present
          [Bit 1]  Long record read (possibly no problem)
          [Bit 2]  Short record read (record padded)
          [Bit 3]  Start of time series
          [Bit 4]  End of time series
          [Bit 5]  Clock locked
14 UBYTE: Data quality flags
          [Bit 0]  Amplifier saturation detected (station dependent)
          [Bit 1]  Digitizer clipping detected
          [Bit 2]  Spikes detected
          [Bit 3]  Glitches detected
          [Bit 4]  Missing/padded data present
          [Bit 5]  Telemetry synchronization error
          [Bit 6]  A digital filter may be charging
          [Bit 7]  Time tag is questionable
15 * UBYTE: Total number of blockettes that follow.
16 * LONG: Time correction. This field contains a value that may modify the
           field 8 record start time. Depending on the setting of bit 1 in
           field 12, the record start time may have already been adjusted.
           The units are in 0.0001 seconds.
17 * UWORD: Offset in bytes to the beginning of data. The first byte of the
            data records is byte 0.
18 * UWORD: Offset in bytes to the first data blockette in this data record.
            Enter 0 if there are no data blockettes. The first byte in the
            data record is byte offset 0.

NOTE: All unused bits in the flag bytes are reserved and must be set to zero.
The last word defines the length of the fixed header. The next-to-last word
fixes the length reserved for the entire header.

If glitches (missing samples) are detected, set bit 3 of the data quality flags,
and code missing data values as the largest possible value. Do this for any data
format, even if you are using theSteim Compression algorithm.

Here is an algorithm and some sample rate combinations that describe how the
sample rate factors and multipliers work:

If Sample rate factor > 0 and Sample rate Multiplier > 0,
   Then nominal Sample rate = Sample rate factor X Sample rate multiplier
If Sample rate factor > 0 and Sample rate Multiplier < 0,
   Then nominal Sample rate = -1 X Sample rate factor / Sample rate multiplier
If Sample rate factor < 0 and Sample rate Multiplier > 0,
   Then nominal Sample rate = -1 X Sample rate multiplier / Sample rate factor
If Sample rate factor < 0 and Sample rate Multiplier < 0,
   Then nominal Sample rate = 1/ (Sample rate factor X Sample rate multiplier)

Sample rate   Sample rate factor   Sample rate multiplier
330 SPS         33                  10
330              1
330.6 SPS     3306                 -10
1 SP Min       -60                   1
0.1 SPS          1                 -10
-10              1
-1             -10
"""

BlkInfoDict[100] = """

Sample Rate Blockette 100 (12 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 100            B      2
2      Next blockettes byte number   B      2
3      Actual Sample Rate            B      4
4      Flags (to be defined)         B      1
5      Reserved byte                 B      3

Notes for fields:
1 UWORD: Blockette type [100]: sample rate.
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 FLOAT: Actual sample rate of this data block.
4 BYTE:  Flags (to be defined)
5 UBYTE: Reserved; do not use.
"""
BlkInfoDict[200]= """
Generic Event Detection Blockette 200 (52 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 200            B       2
2      Next blockettes byte number   B       2
3      Signal amplitude              B       4
4      Signal period                 B       4
5      Background estimate           B       4
6      Event detection flags         B       1
7      Reserved byte                 B       1
8      Signal onset time             B      10
9      Detector Name                 A      24

Notes for fields:
1 UWORD: Blockette type [200]: event detection information.
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 FLOAT: Amplitude of signal (for units, see event detection flags, below;
         0 if unknown).
4 FLOAT: Period of signal, in seconds (0 if unknown).
5 FLOAT: Background estimate (for units, see event detection flags, below;
         0 if unknown).
6 UBYTE: Event detection flags:
         [Bit 0]  If set: dilatation wave; if unset: compression
         [Bit 1]  If set: units above are after deconvolution
                   (see Channel Identifier Blockette [52], field 8);
                   if unset: digital counts
         [Bit 2]  When set, bit 0 is undetermined
         [Other bits reserved and must be zero.]
7 UBYTE: Reserved; do not use.
8 BTIME: Time of the onset of the signal.
9 CHAR*24: The name of the event detector.
"""
BlkInfoDict[201] = """

Murdock Event Detection Blockette 201 (60 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 201            B       2
2      Next blockettes byte number   B       2
3      Signal amplitude              B       4
4      Signal period                 B       4
5      Background estimate           B       4
6      Event detection flags         B       1
7      Reserved byte                 B       1
8      Signal onset time             B      10
9      Signal-to-noise ratio values  B       6
10      Lookback value               B       1
11      Pick algorithm               B       1
12      Detector name                A      24

Notes for fields:
1 UWORD: Blockette type [201]: event detection information.
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 FLOAT: Amplitude of signal (in counts).
4 FLOAT: Period of signal (in seconds).
5 FLOAT: Background estimate (in counts).
6 UBYTE: Event detection flags:
         [Bit 0]  If set: dilatation wave; if unset: compression
         [Other bits reserved and must be zero.]
7 UBYTE: Reserved; do not use.
8 BTIME: Onset time of the signal.
9 UBYTE*6: Signal-to-noise ratio values.
10 UBYTE: Lookback value (0,1,2).
11 UBYTE: Pick algorithm (0,1).
12 CHAR*24: The name of the event detector.

NOTE: See Murdock (1983) and Murdock (1987) for more information on this
type of eventdetector, and on what the fields listed above should contain.
"""

BlkInfoDict[300] = """

Step Calibration Blockette 300 (60 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 300            B       2
2      Next blockettes byte number   B       2
3      Beginning of calibration time B      10
4      Number of step calibrations   B       1
5      Calibration flags             B       1
6      Step duration                 B       4
7      Interval duration             B       4
8      Calibration signal amplitude  B       4
9      Channel w/ calibration input  A       3
10     Reserved byte                 B       1
11     Reference amplitude           B       4
12     Coupling                      A      12
13     Rolloff                       A      12

Notes for fields:
1 UWORD: Blockette type[300]: step calibration.
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 BTIME: Beginning time of calibration.
4 UBYTE: Number of step calibrations in sequence.
5 UBYTE: Calibration flags:
         [Bit 0]  If set: first pulse is positive
         [Bit 1]  If set: calibrations alternate sign
         [Bit 2]  If set: calibration was automatic; if unset: manual
         [Bit 3]  If set: calibration continued from previous record(s)
         [Other bits reserved and must be zero.]
6 ULONG: Number of .0001 second ticks for the duration of the step.
7 ULONG: Number of .0001 second ticks for the interval between times the
         calibration step is on.
8 FLOAT: Amplitude of calibration signal in units (see Channel Identifier
         Blockette [52), field 9).
9 CHAR*3: Channel containing calibration input (blank means none).
          SEED assumes that the calibration output is on the current
          channel, identified in the fixed header.
10 UBYTE: Reserved; do not use.
11 ULONG: Reference amplitude. This is a user defined value that indicates
          either the voltage or amperage of the calibration signal when the
          calibrator is set to 0dB. If this value is zero, then no units are
          specified, and the amplitude (Note 4) will be reported in "binary
          decibels" from to -96.
12 CHAR*12: Coupling of calibration signal, such as "Resistive " or "Capacitive".
13 CHAR*12: Rolloff characteristics for any filters used on the calibrator,
            such as "3dB@10Hz".
"""

BlkInfoDict[310] = """

Sine Calibration Blockette 310 (60 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 310            B       2
2      Next blockettes byte number   B       2
3      Beginning of calibration time B      10
4      Reserved byte                 B       1
5      Calibration flags             B       1
6      Calibration duration          B       4
7      Period of signal (seconds)    B       4
8      Amplitude of signal           B       4
9      Channel w/ calibration input  A       3
10      Reserved byte                B       1
11      Reference amplitude          B       4
12      Coupling                     A      12
13      Rolloff                      A      12

Notes for fields:
1 UWORD: Blockette type [310]: sine calibration.
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 BTIME: Beginning time of calibration.
4 UBYTE: Reserved; do not use.
5 UBYTE : Calibration flags:
[Bit 2]  If set: calibration was automatic; otherwise: manual
[Bit 3]  If set: calibration continued from previous record(s)
[Bit 4]  If set: peak-to-peak amplitude
[Bit 5]  If set: zero-to-peak amplitude
[Bit 6]  If set: RMS amplitude
[Other bits reserved and must be zero.]
6 ULONG: Number of .0001 second ticks for the duration of calibration.
7 FLOAT: Period of signal in seconds.
8 FLOAT: Amplitude of signal in units (see Channel Identifier Blockette [52),
         field 9).
9 CHAR*3: Channel containing calibration input (blank means none).
10 UBYTE: Reserved; do not use.
11 ULONG: Reference amplitude. This is a user defined value that indicates
          either the voltage or amperage of the calibration signal when the
          calibrator is set to 0dB. If this value is zero, then no units are
          specified, and the amplitude (Note 4) will be reported in "binary
          decibels" from 0 to -96.
12 CHAR*12: Coupling of calibration signal such as "Resistive or "Capacitive".
13 CHAR*12: Rolloff characteristics for any filters used on the calibration,
            such as "3dB@10Hz".
            
NOTE: Only one of flag bits 4, 5, and 6 can be set at one time, but one of
them must be set.
"""

BlkInfoDict[320] = """

Pseudo-random Calibraton Blockette 320 (64 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 320            B       2
2      Next blockettes byte number   B       2
3      Beginning of calibration time B      10
4      Reserved byte                 B       1
5      Calibration flags             B       1
6      Calibration duration          B       4
7      Peak-to-peak amplitude of 
       steps                         B       4
8      Channel w/ calibration input  A       3
9      Reserved byte                 B       1
10      Reference amplitude          B       4
11      Coupling                     A      12
12      Rolloff                      A      12
13      Noise type                   A       8

Notes for fields:
1 UWORD: Blockette type [320]: pseudo-random binary sequence.
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 BTIME: Beginning time of calibration.
4 UBYTE: Reserved; do not use.
5 UBYTE: Calibration flags:
         [Bit 2]  If set: calibration was automatic; otherwise: manual
         [Bit 3]  If set: calibration continued from previous record(s)
         [Bit 4]  If set: random amplitudes
         (must have a calibration in channel)
         [Other bits reserved and must be zero.]
6 ULONG: Number of .0001 second ticks for the duration of calibration.
7 FLOAT: Peak-to-peak amplitude of steps in units (see Channel Identifier
         Blockette [52], field 9).
8 CHAR*3: Channel containing calibration input (blank if none).
9 UBYTE: Reserved; do not use.
10 ULONG: Reference amplitude. This is a user defined value that indicates
          either the voltage or amperage of the calibration signal when the
          calibrator is set to 0dB. If this value is zero, then no units are
          specified, and the amplitude (Note 4) will be reported in "binary
          decibels" from 0 to -96.
11 CHAR*12: Coupling of calibration signal such as "Resistive or "Capacitive".
12 CHAR*12: Rolloff characteristics for any filters used on the calibration,
            such as "3dB@10Hz".
13 CHAR*8: Noise characteristics, such as "White" or "Red".

NOTE: When you set calibration flag bit 4, the amplitude value contains the
maximum peakto-peak amplitude.
"""

BlkInfoDict[390] = """

Generic Calibraton Blockette 390 (28 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 390            B       2
2      Next blockettes byte number   B       2
3      Beginning of calibration time B      10
4      Reserved byte                 B       1
5      Calibration flags             B       1
6      Calibration duration          B       4
7      Calibration signal amplitude  B       4
8      Channel w/ calibration input  A       3
9      Reserved byte                 B       1

Notes for fields:
1 UWORD: Blockette type [390]: generic calibration.
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 BTIME: Beginning time of calibration.
4 UBYTE: Reserved; do not use.
5 UBYTE: Calibration flags:
         [Bit 2]  If set: calibration was automatic; otherwise: manual
         [Bit 3]  If set: calibration continued from previous record(s)
         [Other bits reserved and must be zero.]
6 ULONG: Number of .0001 second ticks for the duration of calibration.
7 FLOAT: Amplitude of calibration in units, if known (see Channel Identifier
         Blockette [52], field 9).
8 CHAR*3: Channel containing calibration input (must be specified).
9 UBYTE: Reserved; do not use.
"""

BlkInfoDict[395] = """

Calibraton Abort Blockette 395 (16 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 395            B       2
2      Next blockettes byte number   B       2
3      End of calibration time       B      10
4      Reserved bytes                B       2

Notes for fields:
1 UWORD: Blockette type [395]: calibration abort.
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 BTIME: Time calibration ends.
4 UWORD: Reserved; do not use.
"""

BlkInfoDict[400] = """

Beam Blockette 400 (16 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 400            B       2
2      Next blockettes byte number   B       2
3      Beam azimuth (degrees)        B       4
4      Beam slowness (sec/degree)    B       4
5      Beam configuration            B       2
6      Reserved bytes                B       2

This blockette is used to specify how the beam indicated by the corresponding
Beam Configuration Blockette [35] was formed for this data record. For beams
formed by non-plane waves, the Beam Delay Blockette [405] should be used to
determine the beam delay for each component referred to in the Beam Configuration
Blockette [35].

Notes for fields:
1 UWORD: Blockette type [400]: beam forming.
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 FLOAT: Azimuth of beam (degrees clockwise from north).
4 FLOAT: Beam slowness (sec/degree).
5 UWORD: Beam configuration (see field 3 of the Beam Configuration Blockette [35]
         abbreviation dictionary).
         NOTE: This field is a binary equivalent of the ASCII formatted dictionary
         key entry number in the Beam Configuration Blockette [35]. This is the
         only place in SEED Version 2.1 where this ASCII-to-binary conversion
         needs to be made.
6 UWORD: Reserved; do not use.
"""

BlkInfoDict[405] = """

Beam Delay Blockette 405 (6 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 405            B       2
2      Next blockettes byte number   B       2
3      Array of delay values         B       2

Use this blockette to define beams that do not travel as plane waves at
constant velocities across arrays. This blockette, if used, will always
follow a Beam Blockette [400]. The Beam Delay Blockette [405] describes
the delay for each input component in the samples. SEED reading programs
must find a corresponding entry in the Beam Delay Blockette [405] for each
component in the Beam Configuration Blockette [35] of the abbreviation
dictionary control headers, indexed by the Beam Blockette [400].

Notes for fields:
1 UWORD: Blockette type [405]: beam delay.
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 UWORD: Array of delay values (one for each entry of the Beam Configuration
         Blockette [35]. The array values are in .0001 second ticks.
"""

BlkInfoDict[500] = """

Timing Blockette 500 (200 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 500            B        2
2      Next blockettes byte number   B        2
3      VCO correction                B        4
4      Time of exception             B       10
5      microsec                      B        1
6      Reception Quality             B        1
7      Exception count               B        4
8      Exception type                A       16
9      Clock model                   A       32
10      Clock status                 A      128

Notes for fields:
1 UWORD: Blockette type [500]: Timing blockette.
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 FLOAT: VCO correction is a floating point percentage from 0.0 to 100.0% of VCO
         control value, where 0.0 is slowest , and 100.0% is fastest.
4 BTIME: Time of exception, same format as record start time.
5 UBYTE: microsec has the clock time down to the microsecond. The SEED format
         handles down to 100microsecs. This field is an offset from that value.
         The recommended value is from -50 to +49microsecs. At the users option,
         this value may be from 0 to +99microsecs.
6 UBYTE: Reception quality is a number from 0 to 100% of maximum clock accuracy
         based only on information from the clock.
7 ULONG: Exception count is an integer count, with its meaning based on the type
         of exception, such as 15 missing timemarks.
8 CHAR*16: Exception type describes the type of clock exception, such as "Missing"
           or "Unexpected".
9 CHAR*32: Clock model is an optional description of the clock, such as "Quanterra
           GPS1/QTS".
10 CHAR*128: Clock status is an optional description of clock specific parameters,
             such as the station for an Omega clock, or satellite signal to noise
             ratios for GPS clocks.
"""

BlkInfoDict[1000] = """

Data Only SEED Blockette 1000 (8 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 1000           B       2
2      Next blockettes byte number   B       2
3      Encoding Format               B       1
4      Word order                    B       1
5      Data Record Length            B       1
6      Reserved                      B       1

Notes for fields:
1 UWORD: Blockette type [1000]: Data Only SEED
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3. BYTE : A code indicating the encoding format. This number is assigned by
          the FDSN Data Exchange Working Group. To request that a new format
          be included contact the FDSN through the FDSN Archive at the IRIS
          Data Management Center. To be supported in Data Only SEED, the dat
          format must be expressible in SEED DDL. A list of valid codes at the
          time of publication follows.

               CODES 0-9 GENERAL
               0        ASCII text, byte order as specified in field 4
               1        16 bit integers
               2        24 bit integers
               3        32 bit integers
               4        IEEE floating point
               5        IEEE double precision floating point

               CODES 10 - 29 FDSN Networks
               10        STEIM (1) Compression
               11        STEIM (2) Compression
               12        GEOSCOPE Multiplexed Format 24 bit integer
               13        GEOSCOPE Multiplexed Format 16 bit gain ranged,
                         3 bit exponent
               14        GEOSCOPE Multiplexed Format 16 bit gain ranged,
                         4 bit exponent
               15        US National Network compression
               16        CDSN 16 bit gain ranged
               17        Graefenberg 16 bit gain ranged
               18        IPG - Strasbourg 16 bit gain ranged
               19        STEIM (3) Compression

               CODES 30 - 39 OLDER NETWORKS
               30        SRO Format
               31        HGLP Format
               32        DWWSSN Gain Ranged Format
               33        RSTN 16 bit gain ranged
               
4. The byte swapping order for 16 bit and 32 bit words. A 0 indicates VAX or
   8086 order and a 1 indicates 68000 or SPARC word order. See fields 11 and
   12 of blockette 50.
5. The exponent (as a power of two) of the record length for these data. The data
   record can be as small as 256 bytes and, in Data Only SEED format as large as
   2 raised to the 256 power.
"""

BlkInfoDict[1001] = """

Data Extension Blockette 1001 (8 bytes)

Note   Field Name                    Type   Length   Mask or Flags
1      Blockette type 1001           B       2
2      Next blockettes byte number   B       2
3      Timing quality                B       1
4      microsec                      B       1
5      Reserved                      B       1
6      Frame count                   B       1

Notes for fields:
1 UWORD: Blockette type [1001]: Data extension blockette
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3. UBYTE: Timing quality is a vendor specific value from 0 to 100% of maxium
          accuracy, taking into account both clock quality and data flags.
4. UBYTE: microsec has the data start time down to the microsecond. The SEED
          format handles down to 100microsecs. This field is an offset from that
          value. The recommended value is from -50 to +49microsecs. At the users
          option, this value may be from 0 to +99microsecs.
5. Reserved byte.
6. UBYTE: Frame count is the number of 64 byte compressed data frames in the
          4K record (maximum of 63). Note that the user may specify fewer than
          the maxium allowable frames in a 4K record to reduce latency
"""

BlkInfoDict[2000] = """

Variable Length Opaque Data Blockette

Note   Field Name                    Type   Length   Offset
1      Blockette type 2000           B       2        0
2      Next blockettes byte number   B       2        2
3      Total blockette length in
       bytes                         B       2        4
4      Offset to Opaque Data         B       2        6
5      Record number                 B       4        8
6      Data Word order               B       1       12
7      Opaque Data flags             B       1       13
8      Number Opaque Header fields   B       1       14
9      Opaque Data Header fields     V       V       15
          a Record type
          b Vendor type
          c Model type
          d Software
          e Firmware
10      Opaque Data                  Opaque

More than one blockette 2000 may be stored in a SEED data record if the
SEED data record timetag is not required for precise timing of the data
in the opaque blockette.

Under normal usage, there would be no data in the data portion of the SEED
data record. However, it is possible that the blockette 2000 could be used
to provide additional information
for a normal timeseries data channel.

Notes for fields:
1 UWORD: Blockette type [2000]: Opaque Data blockette
2 UWORD: Byte number of next blockette. (Calculate this as the byte offset
         from the beginning of the logical record  including the fixed
         section of the data header; use 0 if no more blockettes will follow.)
3 UWORD: Blockette length. The total number of bytes in this blockette, including
         the 6 bytes of header. The only restriction is that the blockette must
         fit within a single SEED data record for the channel. Otherwise, the
         blockette must be partitioned into multiple blockettes.
4 UWORD: Offset to Opaque Data. Byte offset from beginning of blockette to
         Opaque Data.
5 ULONG: Record Number. The record number may be used for sequence identification
         of stream, record, or file oriented data. If a record is partitioned
         into multiple opaque blockettes, each blockette containing a portion of
         the record should contain the identical record number. It is strongly
         recommended that the record number be used to aid in the detection of
         missing data and in merging data from different telemetry streams. Use
         0 if data is not record oriented, or if record number is not required.
6 UBYTE: Word order of binary opaque data. See field 4 of blockette 1000, and
         fields 11 and 12 of blockette 50.
              0 = little endian (VAX or 80x86 byte order).
              1 = big endian (68000 or SPARC byte order).
7 UBYTE: Opaque Data flags.
         [bit 0] Opaque blockette orientation.
              0 = record oriented.
              1 = stream oriented.
         [bit 1] Packaging bit.
              0 = Blockette 2000s from multiple SEED data records with different
                  timetags may be packaged into a single SEED data record. The exact
                  original timetag in each SEED Fixed Data Header is not required
                  for each blockette 2000.
              1 = Blockette 2000s from multiple SEED data records with differing
                  timetags may NOT be repackaged into a single SEED data record.
                  Set this bit if the timetag in the SEED Fixed Data Header is
                  required to properly interpret the opaque data.
         [bits 2-3] Opaque blockette fragmentation flags.
              00 = opaque record identified by record number is completely contained
                   in this opaque blockette.
              01 = first opaque blockette for record spanning multiple blockettes.
              11 = continuation blockette 2...N-1 of record spanning N blockettes.
              10 = final blockette for record spanning N blockettes.
         [bits 4-5] File blockette information.
              00 = not file oriented.
              01 = first blockette of file.
              10 = continuation of file.
              11 = last blockette of file.
8 UBYTE: Number of Opaque Header fields. Each opaque header field is a variable
         length ascii string, terminated by the character ~.
9 VAR: Opaque Data Header string, which contains the ascii variable length fields.
       Each field is terminated by a "~". The definition of the fields may be
       defined by the originator and receiver, but the following are recommended.
       Any of the fields may be empty.
         a    Record Type - name of the type of record (eg "GPS", "GPS MBEN").
         b    Vendor Type - name of equipment vendor (eg "ASHTECH").
         c    Model type - model type of equipment (eg "Z12").
         d   Software Version - software version number (eg "").
         e   Firmware Version - firmware version number (eg "1G0C").
10 OPAQUE: Opaque Data - bytes of opaque data. Total length of opaque data in
           bytes is blockette_length - 15 - length (opaque_data_header_string)
"""