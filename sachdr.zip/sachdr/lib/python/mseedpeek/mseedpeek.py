#!/usr/bin/env python


# gui for viewing mseed headers
# author: bcb
#
##########################
# 2004.141
# Modification
# Author: bcb
# beautified help page
#
# NOTE: next change to have drop down for blockette notebook
# and actually describe each field for given blockette

##########################
# 2004.301
# Modification
# Author: bcb
#
# utilize LibTrace calcrate function rather than local

##########################
# 2005.027
# Modification
# Author: bcb
#
# added try/except for directory & file open in self.FindTrace to 
#     reflect changes in LibTrace.py
# incorporated mseedInfo.py - file containing mseed header information
# added dropdown menus for blockettes and labeled display
# added Blockette Information window
# re-disorganized routines and added a few additional code comments
# optimized FindTrace

##########################
# 2005.040
# Modification
# Author: bcb
#
# added infobox indicating endianess
# correctly handles mseed files that are corrupt

##########################
# 2005.132
# Modification
# Author: bcb
#
# removed routine GetBlockette and replaced with 2 lines of code

##########################
# 2005.143
# Modification
# Author: bcb
#
# added main window button "Flush Dictionaries". Allows user view changes to mseed
# files without rebuilding db

##########################
# 2005.281
# Modification
# Author: bcb
#
# added a station selection box to window on station name
# added a -f option to allow user to give filenames on commandline
# using getopt for cmdline parsing
##########################
# 2005.307
# Modification
# Author: bcb
#
# added feature if only one trace on commandline input then fill fields on startup
##########################
# 2005.335
# bug fix
# Author: bcb
#
# blockettes 100, 201 and 400 were not being handled correctly in ReadHdrs
##########################
# 2007.040
# modification
# Author: bcb
#
# added capability to select viewed sta:chan:loc:net:samp in Unique view
#
# new methods: buildUniqueSelectBox, SelectKeys
################################################################
#
# modification
# version: 2008.180
# author: Bruce Beaudoin
#
# modified to take advantage of LibTrace optimization

VERSION = "2008.180"

import Pmw
from Tkinter import *
from FileDialog import *

from os import *
from glob import glob
from operator import mod
from getopt import getopt
import sys, string
from LibTrace import *
from mseedInfo import *

SPACE = " "

# return version number if -# command line option
ListInFiles = []
try:
	opts, pargs = getopt(sys.argv[1:], 'f#')
	for flag, arg in opts:
		if flag == "-f": 
			InFiles=pargs
			for fl in InFiles:
				for f in glob(fl):
					ListInFiles.append(f)
		if flag == "-#":
			print VERSION
			os._exit(0)
except:
	print "\nInvalid command line usage\n"
	print "Usage:\nmseedpeek\nmseedpeek -#\nmseedpeek -f file(s)\n"
	sys.exit(1)

print "\n", os.path.basename(sys.argv[0]), VERSION


#From "Python and Tkinter Programming", J.E. Grayson, pg.103
class Command:
	def __init__(self,func, *args, **kw):
		self.func = func
		self.args = args
		self.kw = kw
	def __call__(self, *args, **kw):
		args = self.args + args
		kw.update(self.kw)
		apply(self.func, args, kw)
		
#
#	Over ride some methods in FileDialog so we only select directories
#	From TraceBuilder.py, auth Steve Azevedo & Lloyd Carothers
#
class DirectoryDialog (FileDialog) :

	title="Directory Select"
	def __init__ (self, root) :
		FileDialog.__init__ (self, root)

    #   Only allow selection of directories (single click)
	def files_select_event (self, e):
		pass
    #   Double click
	def files_double_event (self, e):
		pass

    #   Make sure it's a directory and accessable
	def ok_command (self) :
		ifile = self.get_selection ()
		if not path.isdir (ifile) :
			if not access (ifile, R_OK) :
				self.root.bell ()
				ifile = None
		self.quit (ifile)


class MainWindow:
	def __init__(self, title='',InFiles=''):
		
		self.root = Tk()
		Pmw.initialise(self.root)
		self.root.title(title)

		self.e_width = 8
		self.InfoString = StringVar()

		#if files entered on commandline set self.ListInFiles
		self.ListInFiles = {}
		if InFiles:
			self.ListInFiles=ListInFiles
		#some standard vars
		self.DataDirs = StringVar()
		self.StatSel = StringVar()
		self.StatSelList = []
		self.Trace=StringVar()
		self.SelDir = StringVar()
		self.SelDir.set("")
		self.Station = StringVar()
		self.NetCode = StringVar()
		self.SampleRate = IntVar()
		self.Channel = StringVar()
		self.LocCode = StringVar()
		self.ByteOrder = StringVar()
		
		#positional vars
		self.ByteOffset = IntVar()
		self.BlkSize = IntVar()

		#dictionaries, lists and misc vars
		self.BlockNum = IntVar()
		self.JumpNum = IntVar()
		self.NumBlocks = IntVar()
		self.FixedHdrDict={}
		self.RateDict={}
		self.Blockettes={}
		self.BlockettesList=[]
		self.UniqueList=[]
		self.UniqueSelectList=[]
		self.UniqueSelect = StringVar()
		self.TraceList=[]
		self.TraceListDict={}

		#file and verbosity vars
		self.MseedFile = StringVar()
		self.Blockette = StringVar()
		self.BlocketteType = StringVar()
		self.OldMseedFile = StringVar()
		self.VerbVar = IntVar()
		self.OldVerbVar = IntVar()
		self.VerbList = [
			["Standard", 0],
			["Verbose", 1],
			["Very Verbose", 2],
			["Unique", 3]
		]
		self.VerbVar.set(0)
		self.OldVerbVar.set(0)

		#verbosity lists - each builds on the previous
		self.StandardVars = [
			["Station Name:", self.Station],
			["Location Code:", self.LocCode],
			["Channel:", self.Channel],
			["Net Code:", self.NetCode],
			["Sps (nominal):", self.SampleRate]
		]
		
		self.Year = StringVar()
		self.Jday = StringVar()
		self.Hour = StringVar()
		self.Min = StringVar()
		self.Sec = StringVar()
		self.Micro = StringVar()
		self.VerboseVars = [
			["Year:", self.Year],
			["Day:", self.Jday],
			["Hour:", self.Hour],
			["Min:", self.Min],
			["Sec:", self.Sec],
			["0.0001s:", self.Micro]
		]
		self.VerboseVars = self.StandardVars + self.VerboseVars 
		
		self.SeqNum = StringVar()
		self.DQual = StringVar()
		self.Resv = StringVar()
		self.AddVVVars = [
			["Sequence Number:", self.SeqNum],
			["Data Hdr/Qaul:", self.DQual],
			["Reserved:", self.Resv]
		]
		
		self.NumSamp = IntVar()
		self.SampFact = IntVar()
		self.SampMult = IntVar()
		self.ActFlag = StringVar()
		self.IOFlag = StringVar()
		self.DQFlag = StringVar()
		self.NumBlockettes = IntVar()
		self.TimeCorr = IntVar()
		self.BeginData = IntVar()
		self.FstBlkett = IntVar()
		self.VeryVerboseVars = [
			["Number Samples:", self.NumSamp],
			["Sample Factor:", self.SampFact],
			["Sample Multiplier:", self.SampMult],
			["Activity Flags:", self.ActFlag],
			["I/O & Clk Flags:", self.IOFlag],
			["Data Qaul Flags:", self.DQFlag],
			["Number Blockettes:", self.NumBlockettes],
			["Time Corr:", self.TimeCorr],
			["Offet Data:", self.BeginData],
			["Offset Blockette:", self.FstBlkett]
		]
		self.VeryVerboseVars = self.AddVVVars +self.VerboseVars + self.VeryVerboseVars
		
		#set up notebooks
		self.createMainButtons(self.root)
		self.createNoteBooks(self.root)
		
########################################
	def createMainButtons(self,master):
		"""
		Build info bar and buttons for root window
		"""
		self.InfoString_l = Label(master,
				bg = "yellow",
				relief = "ridge")
		self.InfoString_l.pack(side='bottom', fill='x')
		

		self.Button_fm = Frame(master, relief = 'groove', borderwidth = 2)
		self.Button_fm.pack(side = 'bottom', pady=5, fill = 'x')

		self.exit_b = Button(self.Button_fm,
					text = "Exit",
					relief = "ridge",
					cursor = 'pirate',
					command = Command(self.Exit),
					activebackground= 'red',
					activeforeground='black')
		self.exit_b.pack(side='right', anchor='e')

		self.flush_b = Button(self.Button_fm,
					text = "Flush Dictionaries",
					relief = "ridge",
					command = Command(self.FlushDict),
					activebackground= 'orange',
					activeforeground='black')
		self.flush_b.pack(side='left', anchor='w')

########################################
	def createNoteBooks(self,master):
		"""
		Set up notebooks in root window
		"""
		nb = Pmw.NoteBook(master)
		self.buildHdrDisplay(nb)
		self.buildBlockette(nb)
		self.buildHelp(nb)
		nb.pack(padx=5, pady=5, fill='both', expand=1)
		# If commandline trace input
		if self.ListInFiles:
			(self.TraceListDict, NumFiles) = self.IndexFiles(self.ListInFiles)
			self.UpdateDirList(self.HdrSelect_fm)
			if NumFiles == 1:
				vdir=self.TraceListDict.keys()[0]
				self.SelDir.set(vdir)
				self.UpdateTrcList()
				trace=self.TraceListDict[vdir][0]
				self.MseedFile.set(trace)
				self.ReadHdrs()
				
	
			#clear any lingering updates
# 			self.MseedFile.set("")
# 			self.ClearAll(self.VeryVerboseVars)
# 			self.Hdrs_fm.destroy()
# 			self.Blks_fm.destroy()
	
	
			self.root.bell()
			text= "Done. " + str(NumFiles) + " mseed files found."
			self.addTextInfoBar(self.InfoString_l, text, "green")
##################################################################
	def buildHdrDisplay(self,master):
		"""
		Populate HdrDisplay NoteBook
		"""
		self.FixedHdr_nb = master.add('Trace Headers')

		#data selection frame
		self.DataDirs_fm = Frame(self.FixedHdr_nb, relief = 'groove', borderwidth = 2)
		self.DataDirs_fm.pack(side = 'top', pady=5, fill = 'x')
		self.DataDirs_l = Label(self.DataDirs_fm, text='Data Directories: ')
		self.DataDirs_l.pack(side='left')
		self.DataDirs_e = Entry(self.DataDirs_fm,
			selectbackground = 'yellow',
			textvariable = self.DataDirs)
		self.DataDirs_e.pack(side='left', anchor='w',expand=1, fill='x')
		self.ClearDataDir_b = Button(self.DataDirs_fm,
			activebackground = 'orange',
			relief = "ridge",
			text = "Clear",
			command = Command(self.setValue, self.DataDirs)
			)
		self.ClearDataDir_b.pack(side='right')
		self.FindDataDir_b = Button(self.DataDirs_fm,
			activebackground = 'green',
			relief = "ridge",
			text = "Find",
			command = Command(self.getPath, self.DataDirs, None)
			)
		self.FindDataDir_b.pack(side='right')
		self.DataDirs.set(getcwd())

		self.BuildTrcList_b = Button(self.DataDirs_fm,
			activebackground = 'green',
			relief = "ridge",
			background='lightblue',
			text = "Build Trace db",
			command = Command(self.BuildTrcList)
			)
		self.BuildTrcList_b.pack(side='right')

		# station selection frame and entry box
		self.StatSel_fm = Frame(self.FixedHdr_nb, relief = 'groove', borderwidth = 2)
		self.StatSel_fm.pack(side = 'top', pady=5, fill = 'x')
		self.StatSel_l = Label(self.StatSel_fm, text='Find only stations (colon separated list): ')
		self.StatSel_l.pack(side='left')
		self.StatSel_e = Entry(self.StatSel_fm,
			selectbackground = 'yellow',
			textvariable = self.StatSel)
		self.StatSel_e.pack(side='left', anchor='w',expand=1, fill='x')

		self.ClearStatSel_b = Button(self.StatSel_fm,
			activebackground = 'orange',
			relief = "ridge",
			text = "Clear",
			command = Command(self.setValue, self.StatSel)
			)
		self.ClearStatSel_b.pack(side='right')
		
		#verbosity buttons
		self.RadButtons_fm = Frame(self.FixedHdr_nb, relief = 'groove', borderwidth = 2)
		self.RadButtons_fm.pack(side = 'top', pady=5, fill = 'x')
		
		for text, value in self.VerbList:
			Radiobutton(self.RadButtons_fm,
				text=text,
				value=value,
				command=Command(self.ReadHdrs, None),
				variable=self.VerbVar).pack(side='left', anchor='e')

		Entry(self.RadButtons_fm,
			width = self.e_width,
			background = 'yellow',
			relief = 'ridge',
			textvariable = self.ByteOrder).pack(side='right', anchor='e')
		Label(self.RadButtons_fm,
				text="Header Endianess").pack(side='right', anchor='e')

		#set up frames that get filled when traces are selected
		self.HdrScale_fm = Frame(self.FixedHdr_nb, borderwidth = 2)
		self.HdrScale_fm.pack(side = 'bottom', padx= 5, pady=5, fill = 'x')

		self.HdrSelect_fm = Frame(self.FixedHdr_nb, relief = 'groove', borderwidth = 2)
		self.HdrSelect_fm.pack(side = 'top', pady = 5, fill = 'x')

		self.Hdrs_fm = Frame(self.FixedHdr_nb, relief = 'groove', borderwidth = 2)
		self.Hdrs_fm.pack(side = 'top', pady = 5, fill = 'x')

##################################################################
	def buildBlockette(self,master):
		"""
		Populate Blockettes NoteBook
		"""
		self.Blockette_nb = master.add('Blockettes')

		#these get filled when traces are selected
		self.BlkScale_fm = Frame(self.Blockette_nb, borderwidth = 2)
		self.BlkScale_fm.pack(side = 'bottom', padx= 5, pady=5, fill = 'x')

		self.BlksSelect_fm = Frame(self.Blockette_nb, relief = 'groove', borderwidth = 2)
		self.BlksSelect_fm.pack(side = 'top', pady = 5, fill = 'x')

		self.BlksTitle_fm = Frame(self.Blockette_nb, relief = 'groove', borderwidth = 2)
		self.BlksTitle_fm.pack(side = 'top', pady = 5, fill = 'x')

		self.Blks_fm = Frame(self.Blockette_nb, relief = 'groove', borderwidth = 2)
		self.Blks_fm.pack(side = 'top', pady = 5, fill = 'x')

##################################################################
	def buildBlkInfo(self, blktype, master):
		"""
		Provide information window for blockettes
		"""


		try:
			self.tl_State = self.BlkInfo_tl.winfo_exists()
		except:
			self.tl_State = 0

		if self.tl_State == 1:
			self.BlkInfo_tl.tkraise()
			#display info on selected block
			self.BlocketteType.set(blktype)
			self.displayBlkInfo(blktype)
			

		else:
			self.BlkInfo_tl = Toplevel(master)
			self.BlkInfo_tl.title("Blockette Information")
			
			self.BlkInfoSelect_fm = Frame(self.BlkInfo_tl, relief = 'groove', borderwidth = 2)
			self.BlkInfoSelect_fm.pack(side = 'top', pady = 5, fill = 'x')

			List = ["Fixed Header","Data Fields","BTime",100,200,201,300,310,320,390,395,400,405,500,1000,1001,2000]
			Label(self.BlkInfoSelect_fm, text="Blockette:").grid(row=1, sticky=W)
			Pmw.ComboBox(self.BlkInfoSelect_fm,
				history=0,
				entry_width=self.e_width + 15,
				entry_textvariable=self.BlocketteType,
				selectioncommand=Command(self.displayBlkInfo),
				scrolledlist_items=(List)
				).grid(row=1, column=1, sticky=W)
				

	
			self.ExitBlkInfo_b = Button(self.BlkInfo_tl, 
				activebackground = 'red',
				cursor = 'pirate',
				background = 'lightblue',
				text="Done",
				command = Command(self.killWindow, self.BlkInfo_tl)
				)
			self.ExitBlkInfo_b.pack(side='bottom', fill='x', expand=1)

			self.BlkInfoText = Pmw.ScrolledText(self.BlkInfo_tl,
				borderframe=1)
			self.BlkInfoText.pack(side='bottom', fill='both', expand=1)

			#display info on selected block
			self.BlocketteType.set(blktype)
			self.displayBlkInfo(blktype)
			
##################################################################

	def buildUniqueSelectBox(self, master):
		"""
		In unique view allows user to select block to jump to
		"""
		if "*" not in self.UniqueSelectList:
			self.UniqueSelectList.append("*")
			self.UniqueSelectList.sort()
		Label(master, text="Select Keys:").pack(side='top', anchor='w')

		Pmw.ComboBox(master,
			history=1,
			entry_width=self.e_width+15,
			entry_textvariable=self.UniqueSelect,
			selectioncommand=Command(self.SelectKeys),
			scrolledlist_items=self.UniqueSelectList
			).pack(side='top', anchor='w')
		self.UniqueSelect.set("*")

##################################################################

	def buildJumpBox(self, master, numblocks=0):
		"""
		In unique view allows user to select block to jump to
		"""
		if self.VerbVar.get() == 3:
			Label(master, text="Jump To Block #:").pack(side='top', anchor='w')
		else:
			Label(master, text="Jump To Block #:").pack(side='top', anchor='n')
		
		jumpbox_cb=Pmw.ComboBox(master,
			history=1,
			entry_width=self.e_width,
			entry_textvariable=self.JumpNum,
			selectioncommand=Command(self.Jump),
			scrolledlist_items=(range(numblocks))
			)
		if self.VerbVar.get() == 3:
			jumpbox_cb.pack(side='top', anchor='w')
		else:
			jumpbox_cb.pack(side='top', anchor='n')

##################################################################
	def Jump(self, value):
		"""
		Fills hdr values based on block selected in JumpBox
		"""
		if int(value) < 0: value=0
		if int(value) > (self.NumBlocks.get() - 1): value= self.NumBlocks.get() - 1
		self.BlockNum.set(value)
		if self.VerbVar.get() == 3:
			self.VerbVar.set(2)
		self.ReadHdrs()
		self.FillHdr(value)

##################################################################
	def SelectKeys(self, value):
		"""
		Fills hdr values based on block selected in JumpBox
		"""
		self.UniqueText.clear()
		self.UniqueText.tag_config("list", foreground="blue")
		self.UniqueText.tag_config("odd", backgroun="lightblue")

		self.UniqueText.insert("end", "Block\tStat\tChan\tLoc\tNet\tRate\n", "list")

		selectkey=self.UniqueSelect.get()
		c=0
		for key in self.UniqueList:
			testkey=string.join(string.split(key, ":")[1:],":")
			if not selectkey == "*":
				if selectkey != testkey: continue
			for var in string.split(key, ":"):
				if c :
					self.UniqueText.insert("end", """%s\t""" % var, "odd")
				else :
					self.UniqueText.insert("end", """%s\t""" % var)
			self.UniqueText.insert("end", """\n""")
			if c :
				c=0
			else :
				c+=1
##########################################
	def UpdateDirList(self,fm):
		"""
		build dropdown for selecting data filled directories 
		"""
		self.DirList=self.TraceListDict.keys()

		self.DirList.sort()
		self.SelDir.set("")
		if not self.DirList:
			self.root.bell()
			self.addTextInfoBar(self.InfoString_l, "No Data Found", 'orange')

		else:
			Label(fm, text="Directory:").grid(row=0, sticky=W)
			Pmw.ComboBox(fm,
				history=0,
				entry_width=self.e_width + 40,
				entry_textvariable=self.SelDir,
				selectioncommand=Command(self.UpdateTrcList),
				scrolledlist_items=(self.DirList)
				).grid(row=0, column=1, sticky=W)

##################################################################

	def UpdateTrcList(self, name=""):
		"""
		create dropdown file list based on selected directory
		"""
		self.MseedFile.set("")
		self.TraceList=self.TraceListDict[self.SelDir.get()]
		self.TraceList.sort()
		self.ClearAll(self.VeryVerboseVars)
		if not self.TraceList:
			self.root.bell()
			self.addTextInfoBar(self.InfoString_l, "No Data Found", 'orange')

		Label(self.HdrSelect_fm, text="Trace:").grid(row=1, sticky=W)
		Pmw.ComboBox(self.HdrSelect_fm,
			history=0,
			entry_width=self.e_width + 40,
			entry_textvariable=self.MseedFile,
			selectioncommand=Command(self.ReadHdrs),
			scrolledlist_items=(self.TraceList)
			).grid(row=1, column=1, sticky=W)


#######################################
	def BuildTrcList(self):
		"""
		build a trace list using DataDirList as base directories
		"""
		self.addTextInfoBar(self.InfoString_l)

		self.ByteOrder.set("")
		DataDirList = []
		self.StatSelList = []
		n=0
		for idir in string.split(self.DataDirs.get(), ":") :
			dirlist=glob(idir)
			for newdir in dirlist:
				if not path.isdir(newdir):
					err="***WARNING*** Directory " + newdir + " not found."
					self.root.bell()
					self.addTextInfoBar(self.InfoString_l, err, "red")
					return
				DataDirList.append(newdir)

		# split station select list if it exists
		if self.StatSel.get() == "*" or self.StatSel.get() == "":
			pass
		else:
			for statsel in string.split(self.StatSel.get(), ":") :
				statsel=string.strip(statsel)
				self.StatSelList.append(statsel)

		(self.TraceListDict, NumFiles, errfiles) = self.FindTrace(DataDirList)
		self.UpdateDirList(self.HdrSelect_fm)

		#clear any lingering updates
		self.MseedFile.set("")
		self.ClearAll(self.VeryVerboseVars)
		self.Hdrs_fm.destroy()
		self.Blks_fm.destroy()


		self.root.bell()
		text= "Done. " + str(NumFiles) + " mseed files found. ***" \
		    + str(errfiles) + " files with errors."
		self.addTextInfoBar(self.InfoString_l, text, "green")

#######################################

	def FindTrace(self, DataDir) :
		"""
		based on traverse routine in "python standard library", Lundh pg 34
		"""
		stack = []
		for k in range(len(DataDir)) :
			stack.append(DataDir[k])
		file_list = {}
		NumMseedFiles=0
		rwError=0
		cnt=1
		while stack :
			directory = stack.pop()
			if not path.isdir(directory):
				print "\n***WARNING*** Directory \"%s\" not found.\n" % directory
				continue

			try:
				listfiles = listdir(directory)
			except StandardError, e:
				print "Directory Read Error: %s" % e

			for ifile in listfiles:
				if mod(cnt, 25):
					pass
				else:
					self.wait("Examining File: ", cnt)
				fullname = path.join(directory, ifile)
				if path.isfile(fullname) :
					if not os.access(fullname, 6):
						err= "ERROR: Read/Write permission denied."
						err1="\t File: " + fullname
						print err
						print err1
						rwError+=1
						continue					
					try:
						msfile = Mseed(fullname)
						if msfile.isMseed() :
							try:
								#simple test to determine if correct size file
								filesize=msfile.filesize
								blksize=msfile.blksize
								(numblocks, odd_size)=divmod(filesize, blksize)
								if odd_size:
									warn="ERROR: File size is not an integer number of block size ("\
									   + str(blksize) +"). \n\t File: " + fullname
									print warn
									rwError+=1
									continue
							except:
								err= "ERROR: Cannot determine file and block sizes. \n\t File:" + fullname
								print err
								rwError+=1
								continue
							NumMseedFiles+=1
							stat=string.strip(msfile.FH.Stat)

							if self.StatSelList:
								if not stat in self.StatSelList:
									continue

							if file_list.has_key(directory) :
								file_list[directory].append(ifile)
							else :
								file_list[directory] = []
								file_list[directory].append(ifile)
						msfile.close()
					except StandardError, e:
						rwError+=1
						print "File Open Error: %s" % fullname, e
				cnt+=1

				if path.isdir(fullname) or (path.islink(fullname) and not path.isfile(fullname)):
					stack.append(fullname)

		return file_list, NumMseedFiles, rwError
	
#######################################

	def IndexFiles(self, ListInFiles) :
		"""
		based on traverse routine in "python standard library", Lundh pg 34
		"""
		file_list = {}
		cnt=1
		NumMseedFiles=0
		directory=getcwd()
		self.DataDirs.set(getcwd())
		for ifile in ListInFiles:
			if mod(cnt, 25):
				pass
			else:
				self.wait("Examining File: ", cnt)
			fullname = path.join(directory, ifile)
			if path.isfile(fullname) :
				try:
					newfile = Mseed(fullname)
					if newfile.isMseed() :
						stat=string.strip(newfile.FH.Stat)
						if self.StatSelList:
							if not stat in self.StatSelList:
								continue

						NumMseedFiles+=1
						if file_list.has_key(directory) :
							file_list[directory].append(ifile)
						else :
							file_list[directory] = []
							file_list[directory].append(ifile)
					newfile.close()
				except StandardError, e:
					print "File Open Error: %s" % e
			cnt+=1

		return file_list, NumMseedFiles
#######################################
	def ReadHdrs(self, ifile=""):
		"""
		read headers of a given file build dictionary for quick access
		"""

		#this is a bit of a hack, but I am unable to pass self.MseedFile.get()
		#from buildHdrDisplay:Radiobutton:command
		if not ifile:
			ifile=self.MseedFile.get()
			#if someone changes VerbVar before selecting file do nothing
			if not ifile:
				return

		FileAbsolutePath = path.join(self.SelDir.get(), ifile)

		#create object (we've already tested all files for mseed)
		#and get some base info
		rdfile=Mseed(FileAbsolutePath)
		if rdfile.isMseed():
			try:
				filesize=rdfile.filesize
				blksize=rdfile.blksize
			except:
				self.ClearAll(self.VeryVerboseVars)
				self.Hdrs_fm.destroy()
				self.HdrScale_fm.destroy()
				self.BlkScale_fm.destroy()
				self.BlksSelect_fm.destroy()
				self.BlksTitle_fm.destroy()
				self.Blks_fm.destroy()
				err= "Cannot determine file and block sizes. File: " + ifile
				self.addTextInfoBar(self.InfoString_l, err, 'red')
				rdfile.close()
				return
		else:
			return

		#initialize variables, lists, and dicts for later
		self.BlkSize.set(blksize)
		(numblocks, self.odd_size)=divmod(filesize, blksize)
		self.NumBlocks.set(numblocks)
		verbose=self.VerbVar.get()
		if not self.OldMseedFile.get() or self.OldMseedFile.get() != FileAbsolutePath:
			self.FixedHdrDict={}
			self.RateDict={}
			self.Blockettes={}
			self.keyList=[]
			self.UniqueList=[]
			self.UniqueSelectList=[]
			n=0
	
			#now build a dictionary of all fixed header info keyed to block number
			#looping over total number of blocks in files
			lastkey = -1
			while n < numblocks:
			
				hdrs=rdfile.fixedhdr(n*blksize)
				position = rdfile.where() - 48
				self.FixedHdrDict[n]=hdrs
# 				fact=hdrs[2][1]
# 				mult=hdrs[2][2]
#				self.RateDict[n]=rdfile.calcrate(mult,fact)
				self.RateDict[n]=rdfile.rate
	
				#if unique selected build unique list
#				if verbose == 3:
				(SeqNum, DHQual, res, Stat, Loc, Chan, Net)=hdrs[0]
				Rate=str(self.RateDict[n])
				Stat=string.strip(Stat)
				Chan=string.strip(Chan)
				Loc=string.strip(Loc)
				Net=string.strip(Net)
				key=Stat + ":" + Chan + ":" + Loc + ":" + Net + ":" + Rate
#				if key in self.keyList:
				if key == lastkey:
					pass
				else:
#					self.keyList.append(key)
					lastkey = key
					if key not in self.UniqueSelectList:
						self.UniqueSelectList.append(key)
					key= str(n) + ":" + key
					self.UniqueList.append(key)
	
				#build Blockette dictionary keyed to block number
				numblk=hdrs[3][3]
				addseek=hdrs[3][6]
				b=0
			#loop over number of blockettes following fixed header at block n
				while b < numblk:
					seekval=(n*blksize)+addseek
					(blktype, next)=rdfile.typenxt(seekval)
					#builds command to read specific blockette
					getBlkCmd="blklist=rdfile.blk" + str(blktype) + "(" + str(seekval) + ")"
					exec getBlkCmd
					if blklist :
						#handle awkward lists w/ muli-byte reserve, array, or calib fields
						if blklist[0] == 100:
							tmplist=blklist[:4]
							tup=blklist[4:]
							tmplist.append(tup)
							blklist=tmplist
						if blklist[0] == 201:
							tmplist=blklist[:8]
							tup=blklist[8:13]
							for new in tup, blklist[14], blklist[15], blklist[16]:
								tmplist.append(new)
							blklist=tmplist
						if blklist[0] == 400:
							tmplist=blklist[:5]
							tup=blklist[5:]
							tmplist.append(tup)
							blklist=tmplist
						#build Blockettes
						if self.Blockettes.has_key(n):
							self.Blockettes[n].append(blklist)
						else:
							self.Blockettes[n] = []
							self.Blockettes[n].append(blklist)
						
					addseek=next
					b+=1
				n+=1
		#get endianess before closing
		self.ByteOrder.set(rdfile.byteorder)
		rdfile.close()


		#if unique proceed, else set up scales and entry fields.
		if verbose == 3:
			self.Unique(numblocks)
		else:
			try:
				self.HdrScale_fm.destroy()
				self.HdrScale_fm = Frame(self.FixedHdr_nb, borderwidth = 2)
				self.HdrScale_fm.pack(side = 'bottom', padx= 5, pady=5, fill = 'x')
				self.BlkScale_fm.destroy()
				self.BlkScale_fm = Frame(self.Blockette_nb, borderwidth = 2)
				self.BlkScale_fm.pack(side = 'bottom', padx= 5, pady=5, fill = 'x')
			except:
				pass
			self.buildJumpBox(self.HdrScale_fm, numblocks)

			tick=numblocks/6
			if FileAbsolutePath != self.OldMseedFile.get():
				self.BlockNum.set(0)
				self.JumpNum.set(0)

			Label(self.HdrScale_fm, text='Block Number').pack(side='left', anchor='w')
			
			Scale(self.HdrScale_fm,
				variable=self.BlockNum,
				length=625,
				orient='horizontal',
				from_ = 0,
				to = numblocks-1,
				tickinterval=numblocks/6,
				command=Command(self.FillHdr)
				).pack(side='left', anchor='w')

			Label(self.BlkScale_fm, text='Block Number').pack(side='left', anchor='w')
			Scale(self.BlkScale_fm,
				variable=self.BlockNum,
				length=625,
				orient='horizontal',
				from_ = 0,
				to = numblocks-1,
				tickinterval=numblocks/6,
				command=Command(self.FillHdr)
				).pack(side='left', anchor='w')

			self.SetBlockettes(0)
			if not verbose:
				self.Standard(0, 1)
			elif verbose == 1:
				self.Verbose(0, 1)
			elif verbose == 2:
				self.VeryVerbose(0, 1)

		self.OldMseedFile.set(FileAbsolutePath)

#######################################
	def SetBlockettes(self, key):
		"""
		setup blockette frames for new key entry
		"""
		self.BlockettesList=[]
		for blk in self.Blockettes[key]:
			self.BlockettesList.append(blk[0])
		self.BlockettesList.sort()
		self.Blockette.set(self.BlockettesList[0])

		self.BlksSelect_fm.destroy()
		self.BlksSelect_fm = Frame(self.Blockette_nb, relief = 'groove', borderwidth = 2)
		self.BlksSelect_fm.pack(side = 'top', pady = 5, fill = 'x')

		Label(self.BlksSelect_fm, text="Blockette:").grid(row=1, sticky=W)
		Pmw.ComboBox(self.BlksSelect_fm,
			history=0,
			entry_width=self.e_width,
			entry_textvariable=self.Blockette,
			selectioncommand=Command(self.FillSelectBlk, key),
			scrolledlist_items=(self.BlockettesList)
			).grid(row=1, column=1, sticky=W)

# fill blockette info for first blockette found
		self.FillSelectBlk(key, self.BlockettesList[0])
		
#######################################
	def VarInit(self, Vars):
		"""
		clears/initializes entry fields on HdrDisplay
		"""

		self.Hdrs_fm.destroy()
		self.Hdrs_fm = Frame(self.FixedHdr_nb, relief = 'groove', borderwidth = 2)
		self.Hdrs_fm.pack(side = 'top', pady = 5, fill = 'x')

		c=r=n=0
		for var in Vars:
			Label(self.Hdrs_fm, text=var[0]).grid(row=r, column=c, sticky=W)
			Entry(self.Hdrs_fm,
				width = self.e_width,
				selectbackground = 'yellow',
				textvariable = var[1]).grid(row=r, column=c+1, sticky=W)
			if n == 5:
				n=r=0
				c+=2
			else:
				n+=1
				r+=1
				
#######################################
	def Unique(self, numblocks=0):
		"""
		setup hdr frames for new unique display
		"""
		self.ClearAll(self.VeryVerboseVars)
		self.Hdrs_fm.destroy()
		self.Hdrs_fm = Frame(self.FixedHdr_nb, relief = 'groove', borderwidth = 2)
		self.Hdrs_fm.pack(side = 'top', pady = 5, fill = 'x')
		self.HdrScale_fm.destroy()
		self.HdrScale_fm = Frame(self.FixedHdr_nb, borderwidth = 2)
		self.HdrScale_fm.pack(side = 'bottom', padx= 5, pady=5, fill = 'x')
		self.buildUniqueSelectBox(self.Hdrs_fm)
		self.buildJumpBox(self.Hdrs_fm, numblocks)

		self.FillUnique()

#######################################
	def Standard(self, key, init=0):
		"""
		setup standard vars for new key entry
		"""
		if init:
			self.VarInit(self.StandardVars)

		self.FillStandard(key)
		
#######################################
	def Verbose(self, key, init=0):
		"""
		setup verbose vars for new key entry
		"""

		if init:
			self.VarInit(self.VerboseVars)

		self.FillVerbose(key)

#######################################
	def VeryVerbose(self, key, init=0):
		"""
		setup very verbose vars for new key entry
		"""

		if init:
			self.VarInit(self.VeryVerboseVars)

		self.FillVeryVerbose(key)

#######################################
	def FillHdr(self, value):
		"""
		fill header field on page based on block number
		"""
		key = int(value)
		self.JumpNum.set(value)
		self.ByteOffset.set(self.BlockNum.get()*self.BlkSize.get())
		verbose=self.VerbVar.get()
		self.SetBlockettes(key)
		if not verbose:
			self.Standard(key)
		elif verbose == 1:
			self.Verbose(key)
		elif verbose == 2:
			self.VeryVerbose(key)

		if self.odd_size:
			info="WARNING: File size is not an integer number of block size (" + str(self.BlkSize.get()) +")"
			self.addTextInfoBar(self.InfoString_l, info, "orange")
			self.odd_size=0
		else:
			info="Byte Offset: " + str(self.BlockNum.get()*self.BlkSize.get())
			self.addTextInfoBar(self.InfoString_l, info)

#######################################
	def FillSelectBlk(self, key, blktype):
		"""
		clears/initializes entry fields on Blockette Display
		"""
		self.BlksTitle_fm.destroy()
		self.BlksTitle_fm = Frame(self.Blockette_nb, relief = 'groove', borderwidth = 2)
		self.BlksTitle_fm.pack(side = 'top', pady = 5, fill = 'x')

		self.BlkInfo_b = Button(self.BlksTitle_fm , 
			activebackground = 'green',
			background = 'lightblue',
			text="Blockette Info",
			activeforeground= 'black',
			command = Command(self.buildBlkInfo, blktype, self.Blockette_nb)
			)
		self.BlkInfo_b.grid(row=0, column=1, padx=10)

		self.Blks_fm.destroy()
		self.Blks_fm = Frame(self.Blockette_nb, relief = 'groove', borderwidth = 2)
		self.Blks_fm.pack(side = 'top', pady = 5, fill = 'x')
		

		for block in self.Blockettes[key]:
			if block[0] == blktype:
				blocktuple = block

		Label(self.BlksTitle_fm, text=BlkVars[blktype][0]).grid(row=0, column=0)

		c=r=n=0
		for var in range(len(BlkVars[blktype])-1):
			Label(self.Blks_fm,
				text=BlkVars[blktype][var+1]).grid(row=r, column=c, sticky=W)
			Label(self.Blks_fm,
				text=blocktuple[var]).grid(row=r, column=c+1, sticky=W)
			if n == 5:
				n=r=0
				c+=2
			else:
				n+=1
				r+=1

#######################################
	def FillUnique(self):
		"""
		Fills unique info on HdrDisplay
		"""
		self.UniqueText = Pmw.ScrolledText(self.Hdrs_fm,
			borderframe=1)
		self.UniqueText.pack(side='bottom', fill='both', expand=1)


		self.UniqueText.tag_config("list", foreground="blue")
		self.UniqueText.tag_config("odd", backgroun="lightblue")

		self.UniqueText.insert("end", "Block\tStat\tChan\tLoc\tNet\tRate\n", "list")

		c=0
		for key in self.UniqueList:
			for var in string.split(key, ":"):
				if c :
					self.UniqueText.insert("end", """%s\t""" % var, "odd")
				else :
					self.UniqueText.insert("end", """%s\t""" % var)
			self.UniqueText.insert("end", """\n""")
			if c :
				c=0
			else :
				c+=1

#######################################
	def FillStandard(self, key):
		"""
		Fills standard info on HdrDisplay
		"""

		#cleanup existing vars and reset to new key location
		self.ClearAll(self.StandardVars)
		(SeqNum, DHQual, res, Stat, Loc, Chan, Net)=self.FixedHdrDict[key][0]
		self.SeqNum.set(SeqNum)
		self.DQual.set(DHQual)
		self.Resv.set(res)
		self.Station.set(Stat)
		self.Channel.set(Chan)
		self.LocCode.set(Loc)
		self.NetCode.set(Net)
		(numsamp, sampfact, sampmult)=self.FixedHdrDict[key][2]
		rate=self.RateDict[key]
		self.SampleRate.set(rate)

#######################################
	def FillVerbose(self, key):
		"""
		Fills verbose info on HdrDisplay
		"""

		#cleanup existing vars and reset to new key location
		self.ClearAll(self.VerboseVars)
		self.FillStandard(key)
		(Year, Day, Hour, Min, Sec, junk, Micro)=self.FixedHdrDict[key][1]
		self.Year.set(Year)
		self.Jday.set(Day)
		self.Hour.set(Hour)
		self.Min.set(Min)
		self.Sec.set(Sec)
		self.Micro.set(Micro)

#######################################
	def FillVeryVerbose(self, key):
		"""
		Fills very verbose info on HdrDisplay
		"""

		#cleanup existing vars and reset to new key location
		self.ClearAll(self.VeryVerboseVars)
		self.FillVerbose(key)
		(NumSamp, SampFact, SampMult)=self.FixedHdrDict[key][2]
		(act, io, DQual, numblk, timcorr, bdata, bblock)=self.FixedHdrDict[key][3]
		self.NumSamp.set(NumSamp)
		self.SampFact.set(SampFact)
		self.SampMult.set(SampMult)
		self.ActFlag.set(act)
		self.IOFlag.set(io)
		self.DQFlag.set(DQual)
		self.NumBlockettes.set(numblk)
		self.TimeCorr.set(timcorr)
		self.BeginData.set(bdata)
		self.FstBlkett.set(bblock)

##########################################
	def FlushDict(self) :
		"""
		clears dictionaries and OldMseedFile. Allows user to apply a reset and
		dynamically monitor changes to mseed files.
		"""

		#clear selected directory and file
		self.MseedFile.set("")
		self.SelDir.set("")
		
		#clear variables and destroy frames
		self.ClearAll(self.VeryVerboseVars)
		self.Hdrs_fm.destroy()
		self.HdrScale_fm.destroy()
		self.BlkScale_fm.destroy()
		self.BlksSelect_fm.destroy()
		self.BlksTitle_fm.destroy()
		self.Blks_fm.destroy()
				
		#now clear dictionaries and set OldMseedFile to blank
		self.OldMseedFile.set("")
		self.FixedHdrDict={}
		self.RateDict={}
		self.Blockettes={}
		self.keyList=[]
		self.UniqueList=[]

##########################################

	def getPath (self, var, clear=1) :
		"""
		Concatonate paths
		"""
		self.var=var
		if clear:
			self.var.set('')
		newpath_dd = DirectoryDialog (self.root)
		self.path = newpath_dd.go (dir_or_file = getcwd())
		if self.path != None :
			if self.var.get():
				self.var.set(self.var.get() + ':')
			if len(self.path) == 1 and self.path[0] == "/":
				self.var.set(self.var.get() + self.path)
			elif self.path[-1] == "/":
				self.var.set(self.var.get() + self.path[:-1])
			else:
				self.var.set(self.var.get() + self.path)

##################################################################

	def ClearTxt(self, var) :
		"""
		clear text
		"""
		var.clear()
	
##################################################################

	def ClearAll(self, varlist) :
		"""
		clear a variable list
		"""
		self.addTextInfoBar(self.InfoString_l)
		for var in varlist :
			self.setValue(var[1])

#######################################

	def setValue(self, var, value=''):
		"""
		Sets Value of var
		"""
		var.set(value)

#######################################

	def addTextInfoBar(self, widget, str='', bg='yellow'):
		"""
		Adds Text To InfoBar
		"""
		widget.configure(background=bg, text=str)
##################################################################

	def killWindow(self, widget):
		"""
		Destroy Widget and Set InfoBar to Default
		"""
		widget.destroy()
		self.addTextInfoBar(self.InfoString_l)
		

#######################################

	def wait(self, words, cnt):
		"""
		routine to put words on info bar, used to count traces
		being examined
		"""

		txt = words + str(cnt)
		self.root.update()
		self.addTextInfoBar(self.InfoString_l, txt, 'lightblue')

##################################################################

	def Exit(self):
		"""
		a no questions asked exit
		"""
		sys.exit(0)
		
##################################################################

	def displayBlkInfo(self, type):
		text=BlkInfoDict[type]
		self.BlkInfoText.settext(text)

##################################################################
	def buildHelp(self,master):
		"""
		Populate Help NoteBook
		"""
		self.Help_nb = master.add('Help')

		self.HelpText = Pmw.ScrolledText(self.Help_nb,
			borderframe=1)
		self.HelpText.pack(side='bottom', fill='both', expand=1)


		self.HelpText.tag_config("hdr1", foreground="blue")
		self.HelpText.tag_config("hdr2", foreground="darkgreen")
		self.HelpText.tag_config("bttn", foreground="red")

		self.HelpText.insert("end", "NAME", "hdr1")
		self.HelpText.insert("end", """
   mseedpeek - GUI for displaying mseed file headers.\n""")

		self.HelpText.insert("end", "\nVERSION", "hdr1")
		self.HelpText.insert("end", """
   %s\n""" % VERSION)

		self.HelpText.insert("end", "\nSYNOPSIS", "hdr1")
		self.HelpText.insert("end", """
   mseedpeek
   mseedpeek -#
   mseedpeek -f file_names\n""")

		self.HelpText.insert("end", "\nOPTIONS", "hdr1")
		self.HelpText.insert("end", """
   -# returns version number
   -f file_name(s) - accepts command line input for files to inspect (wildcards accepted)\n""")

		self.HelpText.insert("end", "\nDESCRIPTION", "hdr1")
		self.HelpText.insert("end", """
   mseedpeek has three notebooks: """)
		self.HelpText.insert("end", "[Trace Headers]", "hdr2")
		self.HelpText.insert("end", "[Blockettes]", "hdr2")
		self.HelpText.insert("end", """, and """)
		self.HelpText.insert("end", "[Help]", "hdr2")
		self.HelpText.insert("end", """.""")

		self.HelpText.insert("end", """
   The """)
		self.HelpText.insert("end", "[Trace Headers]", "hdr2")
		self.HelpText.insert("end", """ notebook displays various the fixed header
   in four levels of verbosity. The """)
		self.HelpText.insert("end", "[Blockettes]", "hdr2")
		self.HelpText.insert("end", """ notebook displays
   blockette information.\n""")
	
		self.HelpText.insert("end", "\n   [Trace Headers]", "hdr2")
		self.HelpText.insert("end", """
   General:
      >> specify/load directories for building trace db
      >> select trace for header display
      >> select level of verbosity for display
        
   Buttons:\n""")
		self.HelpText.insert("end", "      <Build Trace db>", "bttn")
		self.HelpText.insert("end", """: Searchs the directories listed in the "Data-
         Directories" entry box (a colon separated list) and builds a list of mseed
         files found indexing them on unique values of <dir>:<file_name>. It then
         creates a dropdown menu with entries for each data directory found.\n""")
		self.HelpText.insert("end", "      <Find>", "bttn")
		self.HelpText.insert("end", """: Launches a file browser allowing the user to
         add directories to the "Data Directories" entry box. Double clicking selects
         the new directory.\n""")
		self.HelpText.insert("end", "      <Clear>", "bttn")
		self.HelpText.insert("end", """: Clears the "Data Directories" entry box.\n""")


		self.HelpText.insert("end", """
        By selecting a data directory a dropdown menu is created for
        trace selection. Selecting a trace from this menu will create
        a header display.

   Radio Buttons:\n""")
		self.HelpText.insert("end", "      <Standard>", "bttn")
		self.HelpText.insert("end", """: This is the default. It displays Station, Channel, Location Code,
        Net Code, and the nominal Sample Rate.\n""")
		self.HelpText.insert("end", "      <Verbose>", "bttn")
		self.HelpText.insert("end", """: Standard display plus time of block.\n""")
		self.HelpText.insert("end", "      <Very Verbose>", "bttn")
		self.HelpText.insert("end", """: Verbose plus the rest of the mseed fixed header fields.\n""")
		self.HelpText.insert("end", "      <Unique>", "bttn")
		self.HelpText.insert("end", """: This displays changes in the Standard fields within a mseed file.\n""")
		self.HelpText.insert("end", """: 

   Slider Scale and """)
		self.HelpText.insert("end", "<Jump To Block #>", "bttn")
		self.HelpText.insert("end", """ Button:
        At the bottom of the page is a scale bar showing block numbers. Sliding
        the bar scans through all fixed headers for the selected mseed file.\n""")

		self.HelpText.insert("end", "\n   <Flush Dictionaries>", "bttn")
		self.HelpText.insert("end", """: Clears cached trace header data.
        As you view mseed headers, mseedpeek maintains a cache of previously
        viewed headers for quick, future access. If you wish to monitor changes
        to mseed files you need to flush the dictionaries so that the new 
        changes will be displayed.\n\n""")


		self.HelpText.insert("end", "   [Blockettes]", "hdr2")
		self.HelpText.insert("end", """: 
        The 'Blockettes' notebook displays all blockettes found for the select
        mseed file in a dropdown menu. By selecting a blockette from the dropdown
        menu, the contents of the blockette will be displayed.\n""")

		self.HelpText.insert("end", "      <Blockette Info>", "bttn")
		self.HelpText.insert("end", """: Displays a pop-up window with a definition of the SEED Blockette.
	
        At the bottom of the page is a scale bar showing block numbers and 
        Sliding the bar scans through all blockettes for the selected mseed file.\n""")

		self.HelpText.insert("end", "\nKEYWORDS", "hdr1")
		self.HelpText.insert("end", """
   mseed; header information\n""")

		self.HelpText.insert("end", "\nSEE ALSO", "hdr1")
		self.HelpText.insert("end", """
   SEED manual (pdf), fixhdr, mseedhdr\n""")

		self.HelpText.insert("end", "\nAUTHOR", "hdr1")
		self.HelpText.insert("end", """
   Bruce Beaudoin <bruce@passcal.nmt.edu>
""")

if ListInFiles:
	mw = MainWindow("mseedpeek %s" % VERSION, ListInFiles)
	mw.root.geometry("775x545")
	mw.root.mainloop()
else:
	mw = MainWindow("mseedpeek %s" % VERSION)
	mw.root.geometry("775x545")
	mw.root.mainloop()
