#!/usr/bin/env python

#
#    QuickAudit
#    Quickly search out raw, and segy texan files and present file statistics
#    of file size graphically.  To be used for quick field qc.
#    Steve Azevedo, Oct, 2000
#

PROG_VERSION = "2000.356"
                
from Tkinter import *
from FileDialog import *
from TexanTree import *
from StatGraph import *
import tkMessageBox
from TkFileDialog import *
import string
from time import gmtime
from os import environ

TRUE = (0 == 0)
FALSE = (1 == 0)

environ['TZ'] = 'GMT'

#
#    Over ride some methods in FileDialog so we only select directories
#
class DirectoryDialog (FileDialog) :
    def __init__ (self, root) :
        FileDialog.__init__ (self, root)

    #   Only allow selection of directories (single click)
    def files_select_event (self, e) :
        pass
    #   Double click
    def files_double_event (self, e) :
        pass

    #   Make sure it's a directory and accessable
    def ok_command (self) :
        file = self.get_selection ()
        if not os.path.isdir (file) :
            if not os.access (file, R_OK) :
                self.root.bell ()
                file = None
        
        self.quit (file)

#
#    Set up the main window that contains a list box of epochs to select
#
class QuickAudit (Frame) :
    def __init__ (self, root, width, height, **kw) :
        apply (Frame.__init__, (self, root), kw)
        self.root = root
        self.root.resizable (0, 0)
        #    Are we appending to starting path?
        self.path = self.prev = ''
        #    A texan tree object, reads from qft and does stats
        self.tt = TexanTree ()
        #    Control updating of idle tasks using after
        self.update = FALSE
        #    List of raw epochs
        self.epochsRaw = []
        #    List of segy epochs
        self.epochsSegy = []
        self.masterdas = []

        #    Set up File menu
        self.menuFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        self.menuFrame.pack (side = TOP, fill = X)
        self.fileMenu = Menubutton (self.menuFrame, text = 'File')
        self.fileMenu.pack (side = LEFT)
        self.fileMenu.menu = Menu (self.fileMenu)
        self.fileMenu.menu.add_command (label = 'Path...',
                                        command = self.getPath)
        self.fileMenu.menu.add_command (label = 'Read master...',
                                        command = self.readMaster)
        self.fileMenu.menu.add_separator ()
        self.fileMenu.menu.add_command (label = 'Quit',
                                        command = self.goByeBye)
        self.fileMenu['menu'] = self.fileMenu.menu
        self.menuFrame.tk_menuBar (self.fileMenu)

        #    Set up list box
        self.listFrame = Frame (self)
        self.listFrame.pack (side = TOP)
        self.listBox = Listbox (self.listFrame,
                                width = 19,
                                height = 10)
        self.listBox.bind ('<Double-ButtonRelease-1>', self.getList)
        self.listBox.pack (side = LEFT)
        self.scrollBar = Scrollbar (self.listFrame,
                                    relief = GROOVE,
                                    borderwidth = 2,
                                    command = self.listBox.yview)
        self.scrollBar.pack (side = RIGHT, fill = Y)
        self.listBox.configure (yscrollcommand = self.scrollBar.set)

        #    Set up Raw and Segy radio buttons
        self.radioVar = IntVar ()
        self.radioFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        self.radioFrame.pack (side = TOP, fill = X)
        self.radioRaw = Radiobutton (self.radioFrame,
                                     text = "Raw",
                                     command = self.setRaw,
                                     value = 0,
                                     variable = self.radioVar)
        self.radioRaw.pack (side = LEFT)
        self.radioSegy = Radiobutton (self.radioFrame,
                                      command = self.setSegy,
                                      text = "SEGY",
                                      value = 1,
                                      variable = self.radioVar)
        self.radioSegy.pack (side = RIGHT)
        self.radioVar.set (1)

        #    Starting path entry widget
        self.entryVar = StringVar ()
        self.entryFrame = Frame (self)
        self.entryFrame.pack (side = TOP)
        self.entryPath = Entry (self.entryFrame,
                                textvariable = self.entryVar,
                                width = 21)
        self.entryPath.bind ('<Return>', self.setEntry)
        self.entryPath.pack ()
        self.entryLabel = Label (self.entryFrame, text = "Search Path")
        self.entryLabel.pack (side = BOTTOM)

        #    Set up Quit and Read buttons
        self.buttonFrame = Frame (self, relief = GROOVE, borderwidth = 2)
        self.buttonFrame.pack (side = TOP,
                               fill = X)
        self.buttonRead = Button (self.buttonFrame,
                                  relief = GROOVE,
                                  borderwidth = 2,
                                  text = "Read",
                                  command = self.walkTree)
        
        self.buttonQuit = Button (self.buttonFrame,
                                  relief = GROOVE,
                                  borderwidth = 2,
                                  text = "Quit",
                                  command = self.goByeBye)
        self.buttonQuit.pack (side = LEFT)
        self.buttonRead.pack (side = RIGHT)

    def dascmp (self, x, y) :
        return (int (x[1]) - int (y[1]))

    def readMaster (self) :
        self.masterdas = []
        fd = TkFileDialog ()
        file = fd.askopenfilename ()
        if file == '' :
            return

        isDas = FALSE
        flds = []
        flds.append ('??????')
        flds.append ('0')
        flds.append ('?')
        flds.append ('?')
        flds.append ('????_???_??_??_??.???')
        
        try :
            fh = open (file, 'r')
            while 1 :
                line = fh.readline ()
                #print line
                if not line :
                    break
                if line[0] != 'S' or line[0] != '#' :
                    #print line
                    line = line[:-1]
                    read = string.split (line)
                    if len (read) == 3 :
                        isDas = TRUE
                    elif len (read) != 5 :
                        continue
                    flds[1] = read[1]
                    self.masterdas.append (tuple (flds))
            if isDas :
                self.masterdas.sort (self.dascmp)
                
        except :
            self.masterdas = []
            tkMessageBox.showwarning (message =
                                      "Failed to read: " + file)

        #print self.masterdas

    #    Get and display file size stats
    def getList (self, e) :
        i = self.listBox.curselection ()
        i = int (i[0])
        if int (self.radioVar.get ()) == 1 :
            ep = self.epochsSegy[i]
            all = self.tt.getTexanAll (ep)
            
            stats = self.tt.getTexanStats (ep)
            #print stats
            out = self.tt.outsideTexan (ep)
            #print out
            if stats :
                sg = StatGraph (self.root,
                                all,
                                self.masterdas,
                                out,
                                stats,
                                ep)
                sg.showGraph ()
            else :
                tkMessageBox.showinfo (message =
                 "Only a single file exists for this epoch: " +
                                       all[0][4])
        else :
            ep = self.epochsRaw[i]
            all = self.tt.getRawAll (ep)
            #print all
            stats = self.tt.getRawStats (ep)
            #print stats
            out = self.tt.outsideRaw (ep)
            #print out
            if stats :
                sg = StatGraph (self.root,
                                all,
                                self.masterdas,
                                out,
                                stats,
                                ep)
                sg.showGraph ()
            else :
                tkMessageBox.showinfo (message =
                 "Only a single file exists for this epoch: " +
                                       all[0][4])

    #    Epoch 2 human
    def humanTime (self, epoch) :
        ttuple = gmtime (int (epoch))
        htime = ("   %4d:%03d:%02d:%02d:%02d" % (int (ttuple[0]),
                                                 int (ttuple[7]),
                                                 int (ttuple[3]),
                                                 int (ttuple[4]),
                                                 int (ttuple[5])))
        return (htime)

    #    Display raw epochs
    def setRaw (self) :
        #print int (self.radioVar.get ())
        self.epochsRaw = self.tt.getRawEpochs ()
        self.listBox.delete (0, END)
        for i in self.epochsRaw :
            htime = self.humanTime (i)
            self.listBox.insert (END, htime)

    #    Display segy epochs
    def setSegy (self) :
        #print int (self.radioVar.get ())
        tepochs = self.tt.getTexanEpochs ()
        lepochs = self.tt.getLegacyEpochs ()
        self.listBox.delete (0, END)
        if len (tepochs) != 0 or len (lepochs) != 0 :
            self.epochsSegy = tepochs + lepochs
            self.epochsSegy.sort ()

            for i in self.epochsSegy :
                htime = self.humanTime (i)
                self.listBox.insert (END, htime)
        
    #    Put starting directory in entry widget
    def setEntry (self, e) :
        n = self.entryPath.get ()
        self.path = self.prev = ''
        flds = string.split (n, ':')
        allDir = TRUE
        for i in flds :
            if not os.path.isdir (i) :
                allDir = FALSE
        self.entryPath.delete (0, END)
        if allDir :
            self.path = self.prev = n
            self.entryVar.set (n)
        
    #    Get starting path using DirectoryDialog widget
    def getPath (self) :
        fd = DirectoryDialog (self.root)
        if self.prev != '' :
            self.prev = self.path + ':'
        self.path = fd.go (dir_or_file = '/')
        if self.path != None :
            self.path = self.path[:-1]
            self.path = self.prev + self.path
            self.prev = self.path
            self.entryVar.set (self.path)

    #    BROKEN!!!
    def idletasks (self) :
        #print '.'
        self.root.update_idletasks ()
        if self.update == TRUE :
            self.root.after (250, self.idletasks)

    #    Launch TexanTree read method
    def run_it (self) :
        #    Ignore legacy stuff (for now)
        self.tt.read ('-d ' + self.path + ' -l')

    def disableAll (self) :
        self.fileMenu.configure (state = DISABLED)
        self.radioRaw.configure (state = DISABLED)
        self.radioSegy.configure (state = DISABLED)
        self.buttonQuit.configure (state = DISABLED)
        self.buttonRead.configure (state = DISABLED)

    def enableAll (self) :
        self.fileMenu.configure (state = NORMAL)
        self.radioRaw.configure (state = NORMAL)
        self.radioSegy.configure (state = NORMAL)
        self.buttonQuit.configure (state = NORMAL)
        self.buttonRead.configure (state = NORMAL)
        
    #    Search for Raw and Segy files
    def walkTree (self) :
        self.tt.clear ()
        if self.path == '' :
            tkMessageBox.showwarning (message =
                "Please select a path from the File menu first!")
        else :
            from threading import *
            self.root.configure (cursor = 'gumby')
            self.update = TRUE
            self.disableAll ()
            tThread = Thread (target = self.run_it)
            tThread.start ()
            self.idletasks ()
            #    Wait here for tt thread to finish
            tThread.join ()
            self.tt.statsTexan ()
            self.tt.statsRaw ()
            self.root.configure (cursor = 'left_ptr')
            self.update = FALSE
            
            if int (self.radioVar.get ()) == 1 :
                self.setSegy ()
            else :
                self.setRaw ()
            self.enableAll ()
            
    #    Quit
    def goByeBye (self) :
        self.root.destroy ()


if __name__ == '__main__' :
    root = Tk ()
    root.title ('QuickAudit: ' + PROG_VERSION)
    qa = QuickAudit (root, 19, 25)
    qa.pack ()
    root.mainloop ()

