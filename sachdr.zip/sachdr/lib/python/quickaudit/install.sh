#!/usr/bin/env bash

PASSCAL=$1

PATH=/usr/X11/bin:/usr/X11R6/bin:${PATH}
export PATH

install_dir=${PASSCAL}/lib/python
echo $install_dir
echo -n "Attempting to make lib install directory..."
if mkdir -p "$install_dir"
then
    echo
    echo -n "Installing libraries..."
    if cp -r ../quickaudit "$install_dir"
    then
	echo
    else
	echo "FAILED"
	exit
    fi
    echo -n "Installing quickaudit..."
    if mkdir -p "${PASSCAL}/bin"
    then
    	if cp ./quickaudit "${PASSCAL}/bin"
    	then
		chmod a+x "${PASSCAL}/bin/quickaudit"
    	else
		echo "Failed..."
    	fi
    fi
    echo
else
    echo "FAILED"
fi

