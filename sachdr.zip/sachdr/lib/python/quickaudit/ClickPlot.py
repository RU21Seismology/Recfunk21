#!/usr/bin/env python

#
#    Build a "clickable" graph
#
#    Steve Azevedo, Oct, 2000
#

from Tkinter import *
from Plot import *
from FileDetail import *

#
#    Bind Button-1 callback so we can get at which point was clicked
#
class GraphClickable (GraphSymbols) :
    def __init__ (self, outside, stat, epoch) :
        #    Vector of points in x, y
        self.points = []
        #    Vector of file info corresponding to point 
        self.info = []
        #    Our info vector starts at 0 so we need to get start of
        #    point object
        self.first_symbol_id = None
        
        #   i contains: (0) filesize,
        #               (1) das number,
        #               (2) chan,
        #               (3) key,
        #               (4) filename
        try :
            for i in outside :
                #    Append das, filesize
                self.points.append ((int (i[1]), int (i[0])))
                #print "x: ", i[1], "y: ", i[0]
                #    epoch, das, chan, filesize, filename
                self.info.append ((int (epoch),
                                   int (i[1]),
                                   int (i[2]),
                                   int (i[0]),
                                   i[4]))
        except :
            pass

        GraphSymbols.__init__ (self, self.points, fillcolor='red')

    #    Override draw method in GraphSymbols
    def draw(self, canvas):
	color     = self.attributes['color']
        size      = self.attributes['size']
        fillcolor = self.attributes['fillcolor']
        marker    = self.attributes['marker']
        fillstyle = self.attributes['fillstyle']

	self.symbols = self._drawmarkers(canvas,
                                         self.scaled,
                                         marker,
                                         color,
                                         fillstyle,
                                         fillcolor,
                                         size)
        try :
            self.first_symbol_id = int (self.symbols[0])
        except :
            pass

    #    Return the offset of first point object
    def getFirstSymbolId (self) :
        return (self.first_symbol_id)

    #    Return file info for the point object
    def pointInfo (self, key) :
        #print key
        first_id = self.getFirstSymbolId ()
        try :
            point_info = self.info[key - first_id]
            return point_info
        except :
            return None

#
#    Plot GraphBase with click callback
#
class ClickBase (GraphBase) :
    def __init__ (self, gc, root, width, height) :
        #    gc is our graph clickable object
        self.gc = gc
        self.root = root
        GraphBase.__init__ (self,
                            root,
                            width,
                            height,
                            background='gray')
        #    Bind button click to getInfo
        self.canvas.bind ("<Button-1>", self.getInfo)

    #    Callback point click here
    def getInfo (self, event) :
        x = self.canvas.canvasx (event.x)
        y = self.canvas.canvasy (event.y)
        selectedObject = self.canvas.find_closest (x, y)[0]
        info = self.gc.pointInfo (int (selectedObject))
        if info != None :
            fd = FileDetail (info, self.root)
            fd.show ()


if __name__ == '__main__' :
    root = Tk ()
    root.title ("File sizes by DAS")
    outside = []
    outside.append (15000, 10100, 1, 1, "/a/bunch/of/junk0")
    outside.append (200, 10120, 1, 1, "/a/bunch/of/junk1")
    outside.append (200, 10131, 1, 1, "/a/bunch/of/junk2")
    outside.append (500, 10230, 1, 1, "/a/bunch/of/junk3")
    outside.append (25000, 10300, 1, 1, "/a/bunch/of/junk4")
    outside.append (2500, 10500, 1, 2, "/a/bunch/of/junk5")
    outside.append (2, 10900, 1, 3, "/a/bunch/of/junk6")
    stat = (30000, 2, 29999, .1)

    symbols = GraphClickable (outside, stat, 969379425)
    ave = []
    len = (10888 - 10100) + 1
    das = 10100
    for i in range (len) :
        das = das + 1
        #print das, i
        ave.append (das, 20000)

    line = GraphLine (ave, color='blue')
    graphObject = GraphObjects ([line, symbols])
    graph = ClickBase (symbols, root, 600, 200)
    graph.pack(side=TOP, fill=BOTH, expand=YES)
    graph.draw (graphObject, 'automatic', 'automatic')

    root.mainloop ()















