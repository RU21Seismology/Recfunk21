#!/usr/bin/env python

#from string import join
from sys import stderr
from Tkinter import *
from TkFileDialog import *

TRUE = (1 == 1)
FALSE = (1 == 0)

class DasList :
    #
    #   daslist = list containing (size, das, chan, n, filepath)
    #   root = root window
    def __init__ (self, root, daslist, tstring) :
        self.daslist = daslist
        self.tstring = tstring
        #   Set up frames
        self.mainFrame = Toplevel (root)
        self.mainFrame.resizable (0, 0)
        self.mainFrame.title ("All DASs for Epoch")
        self.labelFrame = Frame (self.mainFrame)
        self.labelText = Label (self.labelFrame,
                                text =
                                "Size       DAS    Chan    n    File")
        self.textFrame = Frame (self.mainFrame)
        self.scrollFrame = Frame (self.mainFrame)
        self.buttonFrame = Frame (self.mainFrame)
        #   Set up text window
        self.text = Text (self.textFrame, height = 25, width = 36, wrap = NONE)
        self.text.tag_configure ('color', foreground = 'red')
        self.xscroll = Scrollbar (self.scrollFrame,
                                  command = self.text.xview,
                                  relief = GROOVE,
                                  borderwidth = 2,
                                  orient = HORIZONTAL)
        self.yscroll = Scrollbar (self.textFrame,
                                  relief = GROOVE,
                                  borderwidth = 2,
                                  command = self.text.yview)
        self.text.configure (yscrollcommand = self.yscroll.set)
        self.text.configure (xscrollcommand = self.xscroll.set)
        #   Set up buttons
        self.buttonOkay = Button (self.buttonFrame,
                                  command = self.goByeBye,
                                  relief = GROOVE,
                                  borderwidth = 2,
                                  text = 'Okay')
        self.labelTime = Label (self.buttonFrame,
                                text = self.tstring)
        self.buttonSave = Button (self.buttonFrame,
                                  command = self.save,
                                  relief = GROOVE,
                                  borderwidth = 2,
                                  text = 'Save')
        

    def goByeBye (self) :
        self.mainFrame.destroy ()

    def save (self) :
        fd = TkFileDialog ()
        file = fd.asksaveasfilename ()
        if file == '':
            return
        try :
            fh = open (file, 'w')
            fh.write ("Size\tDAS\tChan\tn\tFile name\n")
            for tup in self.daslist :
                #print tup
                line = str (tup[0])
                for i in tup[1:] :
                    line = line + '\t' + str (i)
                line = line
                #print line
                fh.write (line + "\n")

            fh.close ()
        except :
            stderr.write ("Error: Failed to write %s\n" % file)

    def showDasList (self) :
        #    Display daslist

        #    We need to be able to compare to the previous das number
        if len (self.daslist) > 0 :
            first = TRUE
            #    Cur is the previous das number
            cur = self.daslist[0][1]
            
        for text in self.daslist :
            #    First time thru so display as normal
            if first == TRUE :
                self.text.insert (END, text)
                self.text.insert (END, "\n")
                first = FALSE
            else :
                das = text[1]
                #    This das is out of sequence so display it in red
                if int (das) - 1 != int (cur) :
                    self.text.insert (END, text, 'color')
                    self.text.insert (END, "\n")
                else :
                    self.text.insert (END, text)
                    self.text.insert (END, "\n")
            cur = text[1]
            
        self.labelFrame.pack (side = TOP, fill = X)
        self.labelText.pack (side = LEFT)
        self.textFrame.pack (side = TOP)
        self.scrollFrame.pack (side = TOP, fill = X)
        self.buttonFrame.pack (side = BOTTOM, fill = X)
        self.text.pack (side = LEFT)
        self.yscroll.pack (side = RIGHT, fill = Y)
        self.xscroll.pack (side = BOTTOM, fill = X)
        
        self.buttonOkay.pack (side = LEFT)
        self.buttonSave.pack (side = RIGHT)
        self.labelTime.pack (side = LEFT, fill = X)

if __name__ == "__main__" :
    root = Tk ()
    root.withdraw ()
    das = []
    dn = 10000
    for i in range (50) :
        das.append (10000, dn, 1, 0, "/data/2000_123_01_01_01.RSY")
        if i % 7 == 0 :
            dn = dn + 13
        else :
            dn = dn + 1
    dasList = DasList (root, das)
    dasList.showDasList ()
    root.mainloop ()
