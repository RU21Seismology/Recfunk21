#!/usr/bin/env python

#
#   Graph file size statistics
#
#   Steve Azevedo, Oct, 2000
#
from Tkinter import *
from ClickPlot import *
from time import gmtime
from os import environ
from DasList import *

environ['TZ'] = 'GMT'

class StatGraph :
    #    root = root window
    #    daslist = sorted daslist of all that are found
    #    dasmaster = sorted das master list (all that should exist for
    #                deployment
    #    outside = list of (file size, das, chan, number, filename)
    #    stat = (max, min, mean, standard deviation
    #    epoch = start epoch for rsy files, epoch rounded to nearest day
    #            for raw files
    #
    def __init__ (self, root, daslist, dasmaster, outside, stat, epoch) :
        self.symbols = GraphClickable (outside, stat, epoch)
        self.daslist = daslist
        self.dasmaster = dasmaster
        self.numberOfDas = len (daslist)
        self.mean = stat[2]
        ave = []
        self.dasmissing = []
        self.epoch = int (epoch)
        ttuple = gmtime (int (epoch))
        self.tstring = ("Time: %4d:%03d:%02d:%02d:%02d" %
                        (int (ttuple[0]),
                         int (ttuple[7]),
                         int (ttuple[3]),
                         int (ttuple[4]),
                         int (ttuple[5])))
        
        firstDas = daslist[0][1]
        lastDas = daslist[-1][1]
        num = int (lastDas) - int (firstDas)
        for i in range (num + 1) :
            n = int (firstDas) + i
            ave.append (n, float (self.mean))
        
        self.rootFrame = Toplevel (root)
        self.rootFrame.resizable (0,0)
        self.rootFrame.title ("Outliers by File Size")
        self.graphFrame = Frame (self.rootFrame,
                                 relief = GROOVE,
                                 borderwidth = 2)
        self.buttonFrame = Frame (self.rootFrame,
                                  relief = GROOVE,
                                  borderwidth = 2)
        self.epochFrame = Frame (self.buttonFrame)
        self.epochLabel = Label (self.epochFrame,
                                 text = self.tstring)
        self.numberLabel = Label (self.epochFrame,
                                  text =
                                  "Number of DAS's: " + str (self.numberOfDas))
        self.aveLine = GraphLine (ave, color = 'blue')
        self.graphObject = GraphObjects ([self.aveLine, self.symbols])
        self.graph = ClickBase (self.symbols, self.graphFrame, 600, 200)
        self.okButton = Button (self.buttonFrame,
                                text = "Okay",
                                borderwidth = 2,
                                relief = GROOVE,
                                command = self.goByeBye)
        self.missingButton = Button (self.buttonFrame,
                                     text = "Missing",
                                     borderwidth = 2,
                                     relief = GROOVE,
                                     command = self.showMissing)
        self.allButton = Button (self.buttonFrame,
                                 text = "All",
                                 borderwidth = 2,
                                 relief = GROOVE,
                                 command = self.showAll)

    def goByeBye (self) :
        self.rootFrame.destroy ()

    def showMissing (self) :
        if len (self.dasmaster) <= 0 :
            return
        
        self.dasmissing = []
        j = 0
        for i in range (len (self.dasmaster)) :
            try :
                master = self.dasmaster[i]
                masternum = int (master[1])
            except IndexError :
                masternum = 0

            try :
                das = self.daslist[j]
                dasnum = int (das[1])
            except IndexError :
                dasnum = 99999

            if masternum < dasnum :
                self.dasmissing.append (master)
            elif masternum >= dasnum :
                j = j + 1

            
        dl = DasList (self.rootFrame, self.dasmissing, self.tstring)
        dl.showDasList ()
    
    def showAll (self) :
        #####
        dl = DasList (self.rootFrame, self.daslist, self.tstring)
        dl.showDasList ()

    #
    #   Display graph of file size verses DAS #
    #
    def showGraph (self) :
        #self.rootFrame.pack ()
        self.graphFrame.pack (side = TOP)
        self.buttonFrame.pack (side = BOTTOM, fill = X)
        self.graph.pack (fill = BOTH, expand = YES)
        self.okButton.pack (side = LEFT)
        
        self.epochLabel.pack (fill = X)
        self.numberLabel.pack (fill = X)
        self.missingButton.pack (side = RIGHT)
        if len (self.dasmaster) <= 0 :
            self.missingButton.configure (state = DISABLED)
        self.allButton.pack (side = RIGHT)
        self.epochFrame.pack (side = LEFT, fill = X, expand = YES)
        self.graph.draw (self.graphObject, 'minimal', 'minimal')

if __name__ == "__main__" :
    root = Tk ()
    root.withdraw ()
    
    daslist = []
    dn = 10000
    for i in range (400) :
        daslist.append (10000, dn, 1, 0, "/data/2000_123_01_01_01.RSY")
        if i % 7 == 0 :
            dn = dn + 13
        else :
            dn = dn + 1

    outside = []
    outside.append (15000, 10100, 1, 1, "/a/bunch/of/junk0")
    outside.append (200, 10120, 1, 1, "/a/bunch/of/junk1")
    outside.append (200, 10131, 1, 1, "/a/bunch/of/junk2")
    outside.append (500, 10230, 1, 1, "/a/bunch/of/junk3")
    outside.append (25000, 10300, 1, 1, "/a/bunch/of/junk4")
    outside.append (2500, 10500, 1, 2, "/a/bunch/of/junk5")
    outside.append (2, 10900, 1, 3, "/a/bunch/of/junk6")
    stat = (30000, 2, 20000, .1)
    epoch = 969379425
    sg = StatGraph (root, daslist, outside, stat, epoch)
    sg.showGraph ()
    root.mainloop ()
