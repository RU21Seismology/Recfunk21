#!/usr/bin/env python

#
#    Class libraries to do time series statistics on the output of qft
#
#    Steve Azevedo, Oct, 2000
#

from os import popen, environ
from os.path import exists
from string import join, split
from math import sqrt
from sys import stderr, maxint
from time import sleep

environ['TZ'] = 'GMT'

class TexanTree :
    def __init__ (self, root = ".", qft = "qft") :
        self.root = root
        self.qft = qft
        #   Numbers of each file type
        self.texanNum = -1
        self.rawNum = -1
        self.legacyNum = -1
        #   Vectors of file info for each file type as returned by qft
        self.texanVector = []
        self.legacyVector = []
        self.rawVector = []
        #   Dictionaries of arrays of file sizes, see read for description
        #   of keys
        self.texanEpoch = {}
        self.legacyEpoch = {}
        self.rawEpoch = {}

        self.rawExists = {}

        self.texanStats = {}
        self.legacyStats = {}
        self.rawStats = {}

    #    Clear all
    def clear (self) :
        self.texanNum = -1
        self.rawNum = -1
        self.legacyNum = -1
        self.texanVector = []
        self.legacyVector = []
        self.rawVector = []
        self.texanEpoch = {}
        self.legacyEpoch = {}
        self.rawEpoch = {}
        self.rawExists = {}
        self.texanStats = {}
        self.legacyStats = {}
        self.rawStats = {}

    #    Calculate max, min, mean and standard deviation of data x[]:
    def meanstdv(self, x):
        
        n, mean, std = len(x), 0, 0
        max, min = float (maxint) * -1, float (maxint)
        for a in x:
            if a > max :
                max = a
            if a < min :
                min = a
            mean = mean + a
        mean = mean / float(n)
        for a in x:
            std = std + (a - mean)**2
        std = sqrt(std / float(n-1))
        return max, min, mean, std

    #    Calculate stats on file size
    def stats (self, epoch, stats) :
        epochs = epoch.keys ()
        #epochs.sort ()
        for i in epochs :
            bytes = []
            arr = epoch[i]
            
            #    Get file sizes
            for j in arr :
                bytes.append (float (j[0]))
                
            if len (bytes) > 1 :
                max, min, mean, std = self.meanstdv (bytes)
                if not stats.has_key (i) :
                    stats[i] = ()
                stats[i] = (max, min, mean, std)

    #    Return a texan epoch list
    def getTexanEpochs (self) :
        epochs = self.texanEpoch.keys ()
        epochs.sort ()
        return (epochs)
    
    #    Return a legacy epoch list
    def getLegacyEpochs (self) :
        epochs = self.legacyEpoch.keys ()
        epochs.sort ()
        return (epochs)
    
    #    Return a raw epoch list
    def getRawEpochs (self) :
        epochs = self.rawEpoch.keys ()
        epochs.sort ()
        return (epochs)

    #    Stats for given epoch
    def getTexanStats (self, epoch) :
        try :
            return (self.texanStats[epoch])
        except KeyError :
            return (None)

    def getLegacyStats (self, epoch) :
        try :
            return (self.legacyStats[epoch])
        except KeyError :
            return (None)

    def getRawStats (self, epoch) :
        try :
            return (self.rawStats[epoch])
        except KeyError :
            return (None)

    def dascmp (self, x, y) :
        return (int (x[1]) - int (y[1]))

    #
    #   Return an array of das's outside of standard deviation
    #
    def outside (self, epoch, Epoch, Stats) :
        out = []
        try :
            arr = Epoch[epoch]
            max, min, mean, std = Stats[epoch]
        except KeyError :
            return (None)
        high = float (mean) + float (std)
        low = float (mean) - float (std)
        for i in arr :
            if float (i[0]) > high or float (i[0]) < low :
                out.append ((i))
        if len (out) :
            out.sort (self.dascmp)
            return (out)
        else :
            return (None)

    #    Return info on das's outside of sd
    def outsideRaw (self, epoch) :
        return (self.outside (epoch,
                              self.rawEpoch,
                              self.rawStats))
    
    #    Return info on das's outside of sd
    def outsideTexan (self, epoch) :
        return (self.outside (epoch,
                              self.texanEpoch,
                              self.texanStats))
    
    #    Return info on das's outside of sd
    def outsideLegacy (self, epoch) :
        return (self.outside (epoch,
                              self.legacyEpoch,
                              self.legacyStats))

    #    Calculate stats for Texan SEGY
    def statsTexan (self) :
        self.stats (self.texanEpoch, self.texanStats)

    #    Calculate stats for Legacy SEGY
    def statsLegacy (self) :
        self.stats (self.legacyEpoch, self.legacyStats)

    #    Calculate stats for Raw Texan files
    def statsRaw (self) :
        self.stats (self.rawEpoch, self.rawStats)

    #    Return filename for num (key)
    def getRawFilename (self, key) :
        flds = self.rawVector[key]
        return (flds[1])
    
    #    Return filename for num (key)
    def getTexanFilename (self, key) :
        flds = self.texanVector[key]
        return (flds[1])
    
    #    Return filename for num (key)
    def getLegacyFilename (self, key) :
        flds = self.legacyVector[key]
        return (flds[1])

    #    Return sorted list of all texan
    #    size, das, chan, n, file path
    def getTexanAll (self, epoch) :
        try :
            tmp = self.texanEpoch[epoch]
        except KeyError :
            return (None)
        tmp.sort (self.dascmp)
        return (tmp)

    #    Return sorted list of all Legacy
    def getLegacyAll (self, epoch) :
        try :
            tmp = self.legacyEpoch[epoch]
        except KeyError :
            return (None)
        tmp.sort (self.dascmp)
        return (tmp)

    #    Return sorted list of all Raw
    def getRawAll (self, epoch) :
        try :
            tmp = self.rawEpoch[epoch]
        except KeyError :
            return (None)
        tmp.sort (self.dascmp)
        return (tmp)
        
    #
    #   Find all of the files using qft and create vectors of everything
    #   and dictionaries of file sizes
    #
    def read (self, *flags) :

        command = self.qft + " " + str (join (flags))
        try :
            rh = popen (command)
        except :
            stderr.write ("Failure: Can't execute %s\n" % command)
        while 1 :
            line = rh.readline ()
            #sleep (0)
            if not line :
                break
            
            line = line[0:-1]            
            flds = split (line, '\t')
            #print '.',

            #   Raw texan
            if line[0] == '1' :
                #   Key dictionary on das
                key = flds[1]
                epoch = str (int ((flds[4])))
                
                if not self.rawExists.has_key (key) :
                    self.rawExists[key]  = []

                if not self.rawEpoch.has_key (epoch) :
                    self.rawEpoch[epoch] = []
                    
                self.rawNum = self.rawNum + 1    
                #   Append to the vector of everything
                self.rawVector.append (flds[1:])
                
                #   Append tuple of size, das, chan keyed on epoch
                self.rawEpoch[epoch].append ((flds[3],
                                              flds[1],
                                              '0',
                                              self.rawNum,
                                              flds[2]))
                
                #   Append the size keyed by das
                self.rawExists[key].append (flds[3])
                

            #   Texan SEGY and legacy SEGY
            elif line[0] == '2' or line[0] == '3' :
                
                das = flds[1]
                das = "%05d" % int (das)
                epoch = flds[4]
                chan = flds[5]
                #   Key for das chan dictionary
                key = das + chan

                #   Texan
                if line[0] == '2' :
                   
                   if not self.texanEpoch.has_key (epoch) :
                       self.texanEpoch[epoch] = []

                   self.texanNum = self.texanNum + 1
                   #   Append the size keyed by epoch
                   self.texanEpoch[epoch].append ((flds[3],
                                                   flds[1],
                                                   flds[5],
                                                   self.texanNum,
                                                   flds[2]))

                   self.texanVector.append (flds[1:])
                   

                #   Legacy SEGY
                if line[0] == '3' :

                    if not self.legacyEpoch.has_key (epoch) :
                        self.legacyEpoch[key] = []
                        
                    self.legacyNum = self.legacyNum + 1
                    #   Append the file size keyed by epoch
                    self.legacyEpoch[key].append ((flds[3],
                                                   flds[1],
                                                   flds[5],
                                                   self.legacyNum,
                                                   flds[2]))
                    
                    #   Append to a vector of everything
                    self.legacyVector.append (flds[1:])
                    

            
if __name__ == "__main__" :
    tt = TexanTree ()
    from time import time
    import sys
    t1 = time ()
    print "Finding files in %s\n" % "/garnetdata/jdtest/SEGY"
    tt.read ("-d /garnetdata/Dobre")
    t2 = time ()
    print "Finding files took %d seconds\n" % int (t2 - t1)

    '''
    print "Getting texan statistics..."
    t1 = time ()
    tt.statsTexan ()
    t2 = time ()
    print "Getting stats took %d seconds\n" % int (t2 - t1)
    t1 = time ()
    print "Finding outliers..."
    epochs = tt.getTexanEpochs ()
    #print epochs
    for i in epochs :
        #    Get statistics for this epoch max, min, mean, sd
        st = tt.getTexanStats (i)
        #    Get outliers list for this epoch
        #    list of (size, das, chan, n, path)
        out = tt.outsideTexan (i)
        #    Get everything for this epoch
        #    list of (size, das, chan, n, path)
        all = tt.getTexanAll (i)
        print
        if out :
            pass
            #print out
        if all :
            n = len (all)
            cur = all[0][1]
            #print "Epoch: " + i
            for j in range (n) :
                if int (cur) != int (all[j][1]) :
                    if int (cur) + 1 != int (all[j][1]) :
                        #pass
                        print "* ",
                        print i + " " + all[j][1] + " " + all[j][4]
                    else :
                        #pass
                        print i + " " + all[j][1] + " " + all[j][4]
                        #print all
                else :
                    #pass
                    print i + " " + all[j][1] + " " + all[j][4]
                    #print all
                cur = all[j][1]
    t2 = time ()
    print "It took %d seconds to find outliers\n" % int (t2 - t1)
    
    print "Getting legacy statistics..."
    t1 = time ()
    tt.statsLegacy ()
    t2 = time ()
    print "Getting stats took %d seconds\n" % int (t2 - t1)
    t1 = time ()
    print "Finding outliers..."
    epochs = tt.getLegacyEpochs ()
    #print epochs
    for i in epochs :
        #    Get statistics for this epoch max, min, mean, sd
        st = tt.getLegacyStats (i)
        #    Get outliers list for this epoch
        #    list of (size, das, chan, n, path)
        out = tt.outsideLegacy (i)
        #    Get everything for this epoch
        #    list of (size, das, chan, n, path)
        all = tt.getLegacyAll (i)
        print
        if out :
            pass
            #print out
        if all :
            n = len (all)
            cur = all[0][1]
            #print "Epoch: " + i
            for j in range (n) :
                if int (cur) != int (all[j][1]) :
                    if int (cur) + 1 != int (all[j][1]) :
                        #pass
                        print "* ",
                        print i + " " + all[j][1] + " " + all[j][4]
                    else :
                        #pass
                        print i + " " + all[j][1] + " " + all[j][4]
                        #print all
                else :
                    #pass
                    print i + " " + all[j][1] + " " + all[j][4]
                    #print all
                cur = all[j][1]
    t2 = time ()
    print "It took %d seconds to find outliers\n" % int (t2 - t1)
    '''
    print "Getting raw statistics..."
    t1 = time ()
    tt.statsRaw ()
    t2 = time ()
    print "Getting stats took %d seconds\n" % int (t2 - t1)
    t1 = time ()
    print "Finding outliers..."
    epochs = tt.getRawEpochs ()
    #print epochs
    for i in epochs :
        #    Get statistics for this epoch max, min, mean, sd
        st = tt.getRawStats (i)
        #    Get outliers list for this epoch
        #    list of (size, das, chan, n, path)
        out = tt.outsideRaw (i)
        #    Get everything for this epoch
        #    list of (size, das, chan, n, path)
        all = tt.getRawAll (i)
        print i
        if out :
            pass
            #print out
        if all :
            n = len (all)
            cur = all[0][1]
            #print "Epoch: " + i
            for j in range (n) :
                if int (cur) != int (all[j][1]) :
                    if int (cur) + 1 != int (all[j][1]) :
                        #pass
                        print "* ",
                        print i + " " + all[j][1] + " " + all[j][4]
                    else :
                        #pass
                        print i + " " + all[j][1] + " " + all[j][4]
                        #print all
                else :
                    print all[j]
                    #pass
                    print i + " " + all[j][1] + " " + all[j][4]
                    #print all
                cur = all[j][1]
    t2 = time ()
    print "It took %d seconds to find outliers\n" % int (t2 - t1)




