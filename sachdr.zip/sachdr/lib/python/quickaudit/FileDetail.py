#!/usr/bin/env python

#
#    A toplevel widget to display file details
#    Epoch, DAS, Chan, File size, File name
#
#    Steve Azevedo, Oct, 2000
#

from Tkinter import *

#
#    Text list mix-in
#
class TextList :
    def __init__ (self, master, txt) :
        self.master = master
        self.frame = Frame (self.master, relief = GROOVE, borderwidth = 2)
        self.frame.pack (fill = X)
        
        self.tw = Label (self.frame, text = txt)
        self.tw.pack (side = LEFT)

        self.lb = Listbox (self.frame, width = 30, height = 1)
        self.lb.pack (side = RIGHT)

    def insert (self, what) :
        self.lb.delete (0, END)
        self.lb.insert (END, what)

#
#    Show file details:
#        Epoch, Das number, Channel, File size, file name
#
class FileDetail :
    def __init__ (self, details, root) :
        self.tw = Toplevel (root)
        self.tw.title ("File Details")
        #self.tw.withdraw ()
        self.details = details

    def show (self) :
        ep = TextList (self.tw, "Epoch: ")
        ep.insert (self.details[0])

        das = TextList (self.tw, "Das: ")
        das.insert (self.details[1])

        chan = TextList (self.tw, "Channel: ")
        chan.insert (self.details[2])

        size = TextList (self.tw, "File Size: ")
        size.insert (self.details[3])

        name = TextList (self.tw, "File Name: ")
        name.insert (self.details[4])

        butt = Button (self.tw,
                       text = "Okay",
                       relief = GROOVE,
                       borderwidth = 2,
                       command = self.__del__)

        butt.pack ()

    def __del__ (self) :
        self.tw.destroy ()

if __name__ == "__main__" :
    root = Tk ()
    root.withdraw ()
    f = Frame (root)
    det = (969379425, 10100, 1, 15000, '/a/bunch/of/2000_263_16_03.RSY')
    fd = FileDetail (det, f)
    fd.show ()
    root.mainloop ()
    


