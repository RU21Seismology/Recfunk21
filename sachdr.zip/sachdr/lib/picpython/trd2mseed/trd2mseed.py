#!/usr/bin/env picpython

#
#   Convert raw texan data files to mini-seed
#
#   Steve Azevedo, January 2008
#

import sys, os, os.path, re, string
import mseed, pn125, TimeDoy

PROG_VERSION = '2010.084'

#   Match lines related to timing in SOH
timetoRE = re.compile ("TIME\s+CHANGED\s+TO\s+(\d{4}:\d{3}:\d{2}:\d{2}:\d{2}:\d{3})\s+AND\s+(\d{4}/\d{4})\s+MS")
timefromRE = re.compile ("TIME\s+CHANGED\s+FROM\s+(\d{4}:\d{3}:\d{2}:\d{2}:\d{2}:\d{3})\s+AND\s+(\d{4}/\d{4})\s+MS")

RAWFILE = []

class Par (object) :
    __slots__ = ('station', 'loccode', 'netcode', 'channel')
    def __init__ (self) :
        self.station = None
        self.loccode = None
        self.netcode = None
        self.channel = None

def get_order (line) :
    order = {}
    line = line[1:]
    flds = string.split (line, ';')
    i = 0
    for f in flds :
        order[string.strip (f)] = i
        i += 1
        
    return order
    
def read_par_file (file) :
    '''
       Read parameter file containing: das;station;netcode;channel;loccode as a 
       colon separated list. The first line describes the order and the first char
       must be '#'. As example the first three lines could be:
       #das;netcode;channel;loccode
       12400; XY; EPZ; 00
       12399;XY; EPZ ; 01
    '''
    global PARAMETERS
    PARAMETERS = {}
    try :
        fh = open (file)
    except :
        return False
    
    while 1 :
        line = fh.readline ()
        if not line : break
        line = line[:-1]
        if line[0] == '#' :
            order = get_order (line)
            continue
        
        flds = string.split (line, ';')
        
        if not order.has_key ('das') :
            return False
        
        if len (flds) != len (order.keys ()) :
            sys.stderr.write ('Error in parameter file:\n%s\n' % line)
            return False
        
        par = Par ()
        id = string.strip (flds[order['das']])
        #print flds, order
        if order.has_key ('station') :
            par.station = string.strip (flds[order['station']])
        if order.has_key ('netcode') :
            par.netcode = string.strip (flds[order['netcode']])
        if order.has_key ('channel') :
            par.channel = string.strip (flds[order['channel']])
        if order.has_key ('loccode') :
            par.loccode = string.strip (flds[order['loccode']])
            
        PARAMETERS[id] = par
        
    return True
    
def read_input_files (file) :
    global RAWFILE
    try :
        fh = open (file, "r")
        while 1 :
            line = fh.readline ()
            if not line : break
            line = line[:-1]
            RAWFILE.append (line)
            
        fh.close ()
    except :
        return False
    
    return True
            
def create_outdir (dir) :
    command = "mkdir -p %s" % dir
    ret = os.system (command)
    #print ret
    if ret == 0 :
        return True
    else :
        return False
#
#   Read Command line arguments
#
def get_args () :
    '''
       RAWFILE -> TRD input file name(s)
       NETCODE -> Net code from DMC, 2 ascii characters
       STATION -> Station code, 1 to 5 ascii characters
       CHANNEL -> Channel description, see Appendix A of SEED manual
       LOCCODE -> Location Code
    '''
    global RAWFILE, NETCODE, STATION, CHANNEL, LOCCODE, OUTDIR, PARAMETERS, STEIM, VERBOSE
    
    from optparse import OptionParser
    
    oparser = OptionParser ()
    
    oparser.usage = "trd2mseed %s\ntrd2mseed --trdfile=trdfile|--filelist=trdfile_list options" % PROG_VERSION
    
    oparser.description = "Convert texan raw data to mini-seed."
    
    oparser.add_option ("-f", "--trdfile", dest = "trd_file",
                        help = "The raw texan file.",
                        metavar = "trd_file")
    
    oparser.add_option ("-F", "--filelist", dest = "file_list",
                        help = "Text file containing a list of input files, one per line.",
                        metavar = "file_list")
    
    oparser.add_option ("-p", "--parfile", dest = "par_file",
                        help = "Parameter file used to set netcode, station, channel, and loccode.\n\
                               The file contains colon separated lists. The first line describes the\n\
                               order and the first char must be '#'. As example the first three\n\
                               lines could be:\n\
                               #das;netcode;channel;loccode\n\
                               12400; XY; EPZ; 00\n\
                               12399;XY; EPZ ; 01",
                        metavar = "par_file")
    
    oparser.add_option ("-n", "--netcode", dest = "netcode",
                        help = "DMC assigned network code, two ascii characters.",
                        metavar = "netcode")
    
    oparser.add_option ("-s", "--station", dest = "station",
                        help = "Station designator, one to five ascii characters.",
                        metavar = "station")
    
    oparser.add_option ("-c", "--channel", dest = "channel",
                        help = "SEED channel name, three ascii characters.",
                        metavar = "channel")
    
    oparser.add_option ("-l", "--locationcode", dest = "loccode",
                        help = "Location code.",
                        metavar = "loccode")
    
    oparser.add_option ("-o", "--outputdir", dest = "out_dir",
                        help = "Output directory",
                        metavar = "out_dir")
    
    oparser.add_option ("-2", "--steim2", dest="steim2",
                        action = "store_true", default = False,
                        help = "Steim 2 compress data.")
    
    oparser.add_option ("-v", "--verbose", dest = "verbose",
                        action = "store_true", default = False,
                        help = "Be verbose")
    
    options, args = oparser.parse_args ()
    
    if options.trd_file != None :
        RAWFILE.append (options.trd_file)
    elif options.file_list != None :
        if not read_input_files (options.file_list) :
            sys.stderr.write ("Failed to read input files\n")
            sys.exit ()
    else :
        sys.stderr.write ("Input file required. Try --help option.\n")
        sys.exit ()
        
    if options.out_dir != None :
        OUTDIR = options.out_dir
        if not create_outdir (OUTDIR) :
            sys.stderr.write ("Failed to create %s\n" % OUTDIR)
            sys.exit ()
    else :
        OUTDIR = "."
    
    STEIM = options.steim2
    VERBOSE = options.verbose
    
    if options.netcode != None :
        NETCODE = options.netcode
    else :
        NETCODE = 'XX'
        
    if options.station != None :
        STATION = options.station
    else :
        STATION = 'XXXX'
        
    if options.channel != None :
        CHANNEL = options.channel
    else :
        CHANNEL = 'XXX'
        
    if options.loccode != None :
        LOCCODE = options.loccode
    else :
        LOCCODE = 'XX'
        
    if options.par_file != None :
        if not read_par_file (options.par_file) :
            sys.stderr.write ("Error: Failed to read: %s\n" % options.par_file)
            sys.exit ()
    else :
        PARAMETERS = {}
        
def write_mseed (timestr, fileprefix, data, samplerate) :
    '''
       Write mseed using pylibmseed
    '''
    global NETCODE, STATION, CHANNEL, LOCCODE, OUTDIR, DAS, PARAMETERS, VERBOSE, STEIM
    
    INT32 = 3
    STEIM2 = 11
    LEN = 1024
    
    if STATION == 'XXXX' :
        station = str (DAS)
    else :
        station = STATION
    
    netcode = NETCODE; channel = CHANNEL; loccode = LOCCODE
    if PARAMETERS :
        if PARAMETERS.has_key (str (DAS)) :
            p = PARAMETERS[str (DAS)]
            if p.netcode :
                netcode = p.netcode
            if p.station :
                station = p.station
            if p.channel :
                channel = p.channel
            if p.loccode :
                loccode = p.loccode
                
    verbosity = mseed.QUIET
    if VERBOSE : verbosity = mseed.VERBOSE
    encoding = INT32
    if STEIM : encoding = STEIM2
        
    #   Output file name, skipnodata, data flag, verbose?
    msr = mseed.MSRwrite (os.path.join (OUTDIR, fileprefix + ".m"), 0, 0, verbosity)
    #   
    msr.write (netcode, station, channel, loccode, timestr, samplerate, data, encoding = encoding, reclen=1024)
    del msr
        
def process_event (points, trace, page) :
    '''
       Process each event in trd file
    '''
    global DAS
    
    tdoy = TimeDoy.TimeDoy ()
    bitweight = 10.0 / trace.gain / trace.fsd   #   volts/bit
    DAS = page.unitID
    sr = trace.sampleRate
    yr = trace.year; jd = trace.doy; hr = trace.hour; mn = trace.minute; sc = trace.seconds
    mo, da = tdoy.getMonthDay (yr, jd)
    #   ASCII time string (start time of event)
    timestr = "%04d/%02d/%02d %02d:%02d:%09.6f" % (yr, mo, da, hr, mn, sc)
    fileprefix = "%04d.%03d.%02d.%02d.%02d.%d.1" % (yr, jd, hr, mn, int (sc), DAS)
    write_mseed (timestr, fileprefix, trace.trace, sr)
    
    return fileprefix

def process_et (fileprefix, event) :
    '''
       Write event table to file
    '''
    global OUTDIR
    if not event : return
    
    fh = open (os.path.join (OUTDIR, fileprefix + ".tet"), "w+")
    for line in event :
        fh.write ("%04d:%02d:%02d:%02d:%02d %d %d\n" % (line.year,
                                                        line.doy,
                                                        line.hour, 
                                                        line.minute, 
                                                        line.seconds, 
                                                        line.action,
                                                        line.parameter))
        
    fh.close ()
    
def write_pcf (tos, froms, das) :
    if len (tos) < 2 or len (froms) < 1 :
        return False
    
    pcffile = os.path.join (OUTDIR, "passcal.pcf")
    if os.path.exists (pcffile) :
        fh = open (pcffile, "a+")
    else :
        fh = open (pcffile, "w+")
        fh.write ("#!PCF trd2mseed %s\n" % PROG_VERSION)
        
    #   Time of the first TO
    start = tos[0][0] + tos[0][1]
    
    #   Texan time at FROM
    end125 = froms[0][0] + froms[0][1]
    
    #   GPS time at last (?) TO
    endgps = tos[1][0] + tos[1][1]
    
    #   If clock is fast, slope is positive
    if end125 > endgps :
        offset = end125 - endgps
    else :
        offset = (endgps - end125) * -1.0
        
    #   Slope in seconds per second
    tt = end125 - start
    slope = offset / tt
    
    tdoy = TimeDoy.TimeDoy ()
    asciistart = tdoy.epoch2PasscalTime (start, ms = True)
    asciistop = tdoy.epoch2PasscalTime (endgps, ms = True)
    
    fh.write ("%s\t%s\t%e\t%e\t#Start\n" % (das, asciistart, 0.0, slope * -1.0))
    fh.write ("%s\t%s\t%e\t%e\t#End\n" % (das, asciistop, 0.0, 0.0))
        
def ms (m) :
    '''
       Calculate milliseconds
    '''
    a, b = map (float, string.split (m, '/'))
    return a / b / 1000.0
    
def str2epoch (s) :
    '''   Convert colon separated string to epoch   '''
    yr, jd, hr, mn, sc, ms = map (int, string.split (s, ":"))
    tm = TimeDoy.TimeDoy ()
    sec = float (sc) + float (ms) / 1000.0
    
    e = tm.epoch (yr, jd, hr, mn, 0)
    
    return e + sec

def process_soh (fileprefix, soh) :
    '''
       Write SOH to file
    '''
    global OUTDIR, DAS
    froms = []
    tos = []
    if not soh : return
    
    fh = open (os.path.join (OUTDIR, fileprefix + ".soh"), "w+")
    for line in soh :
        to = timetoRE.match (line.message)
        if to :
            t, m = to.groups ()
            tos.append ([str2epoch (t), ms (m)])
            
        fr = timefromRE.match (line.message)
        if fr :
            t, m = fr.groups ()
            froms.append ([str2epoch (t), ms (m)])
            
        fh.write ("%04d:%02d:%02d:%02d:%02d %s\n" % (line.year,
                                                     line.doy,
                                                     line.hour, 
                                                     line.minute, 
                                                     line.seconds, 
                                                     line.message))
    
    write_pcf (tos, froms, DAS)
    fh.close ()
        
def process_file () :
    '''
       Process TRD file(s)
    '''
    global RAWFILE, VERBOSE
    if VERBOSE :
        print PROG_VERSION
    for infile in RAWFILE :
        if VERBOSE :
            print "Processing: %s" % infile
            
        try :
            pn = pn125.pn125 (infile)
        except Exception, e :
            sys.stderr.write ("Error: Can't open %s. %s\n" % (infile, e))
        
        fileprefix = None
        while 1 :
            points = pn.getEvent ()
            if points == 0 : break
            trace = pn.trace
            page = pn.page
            tmp = process_event (points, trace, page)
            if fileprefix == None : fileprefix = tmp
            
        process_soh (fileprefix, pn.sohbuf)
        process_et (fileprefix, pn.eventTable)
        
if __name__ == '__main__' :
    get_args ()
    process_file ()