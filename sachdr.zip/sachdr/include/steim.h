/* Public header file for steim.c	*/

#ifndef STEIM_H
#define STEIM_H

#include <sys/types.h>

typedef union steim_frame {
		char str[64];
		long word[16];
} Frame;



#ifdef ANSI_C

long uncompress32 (char *, long [], long);
long uncompress16 (char *, short [], long);
long do_frame32 (Frame *, long [], long, long *, long);
long do_frame16 (Frame *, short [], long, long *);
void unpack (register u_int, register u_int []);
long one_byte (register long, register int);
long two_byte (long, int);
#else
long do_frame32_fixed ();
long uncompress32();
long uncompress16();
long do_frame32();
long do_frame16();
void unpack();
long one_byte();
long two_byte();
#endif

#endif /* STEIM_H	*/
