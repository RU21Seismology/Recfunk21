TRACE * ReadTraceMSEED();
TRACE * ReadTraceHeadMSEED();
int ReadTraceDataMSEED();
int WriteTraceMSEED();
int WriteTraceHeadMSEED();
int WriteTraceDataMSEED();
int rewindMSEEDblock();
