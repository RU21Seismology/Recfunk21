/* BEGIN HEADER: passcal.h
 */

#ifndef TRUE
#  define TRUE (1)
#endif

#ifndef FALSE
#  define FALSE (0)
#endif

#ifndef NEITHER
#  define NEITHER (999)
#endif

#ifndef SUCCESS
#  define SUCCESS (0)
#endif

#ifndef FAILED
#  define FAILED (-1)
#endif

#ifndef ON
#  define ON (1)
#endif

#ifndef OFF
#  define OFF (0)
#endif

#ifndef OK
#  define OK (0)
#endif

#ifndef PASSED
#  define PASSED (0)
#endif

/*   This section is pretty much a copy of the file rttypes.h from RefTek's
 *   125_SEGY program.  It tries to define everything depending on the
 *   operating system.  I've just kept the generic stuff.
 *
 *   Purpose  :  REF TEK standard types to enhance portability.
 *   Host     :  CC, GCC, Microsoft Visual C++ 5.x, Borland C++ 4.x, MCC68K 3.1
 *   Target   :  Solaris (Sparc and x86), Linux, DOS, Win32, and RTOS
 *   Author   :  William D. Wagers, Robert Banfill
 *   Company  :  Refraction Technology, Inc.
 *               2626 Lombardy Lane, Suite 105
 *               Dallas, Texas  75220
 *               (214) 353-0609     Fax (214) 353-9659
 *   Copyright:   (c) 1989 - 1999 Refraction Technology, Inc.
 */

/* DOS Variables definition */
#ifdef  _DOS

   typedef void VOID;   /* Void type */
   typedef char CHAR;   /* Characters */
   typedef unsigned char UCHAR;
   typedef int INT;   /* Signed integers */
   typedef unsigned int UINT;   /* Unsigned integers */
   typedef char INT8;   /* Signed and unsigned 8 bit integers */
   typedef unsigned char UINT8;
   typedef short INT16;   /* 16 bit integer values */
   typedef unsigned short UINT16;
   typedef signed long INT32;   /* 32 bit integer values */
   typedef unsigned long UINT32;
   typedef signed long INT64;   /* 64 bit integer values */
   typedef unsigned long UINT64;
   typedef float REAL32;   /* 32 bit IEEE 754 Real */
   typedef double REAL64;   /* 64 bit IEEE 754 Real */
   typedef double REAL80;   /* 80 bit IEEE 754 Real */

#endif   /* end ifdef _DOS */


/* Sun4 variables definition */
#ifdef sun4

   typedef void VOID;   /* Void type */
   typedef char CHAR;   /* Characters */
   typedef unsigned char UCHAR;
   typedef int INT;   /* Integers values */
   typedef unsigned int UINT;
   typedef char INT8;   /* 8 bit integers */
   typedef unsigned char UINT8;            
   typedef signed short int INT16;   /* 16 bit integer values */
   typedef unsigned short int UINT16;
   typedef signed long int INT32;   /* 32 bit integer values */
   typedef unsigned long int UINT32;
   typedef long long INT64;   /* 64 bit integer values */
   typedef unsigned long long UINT64;
   typedef float REAL32;   /* 32 bit IEEE 754 Real */
   typedef double REAL64;   /* 64 bit IEEE 754 Real */
   typedef long double REAL80;   /* 80 bit IEEE 754 Real */

#endif   /* end ifdef sun4 */


/* Linux variables definition */
#ifdef linux

   typedef void VOID;   /* Void type */
   typedef char CHAR;   /* Characters */
   typedef unsigned char UCHAR;
   typedef int INT;   /* Integers values */
   typedef unsigned int UINT;
   typedef char INT8;   /* 8 bit integers */
   typedef unsigned char UINT8;            
   typedef signed short int INT16;   /* 16 bit integer values */
   typedef unsigned short int UINT16;
   typedef signed long int INT32;   /* 32 bit integer values */
   typedef unsigned long int UINT32;
   typedef long long INT64;   /* 64 bit integer values */
   typedef unsigned long long UINT64;
   typedef float REAL32;   /* 32 bit IEEE 754 Real */
   typedef double REAL64;   /* 64 bit IEEE 754 Real */
   typedef long double REAL80;   /* 80 bit IEEE 754 Real */

#endif   /* end ifdef linux */


/* MACINTOSH variable definition */
#ifdef DARWIN
   
   typedef void VOID;   /* Void type */
   typedef char CHAR;   /* Characters */
   typedef unsigned char UCHAR;
   typedef int INT;   /* Integers values */
   typedef unsigned int UINT;
   typedef char INT8;   /* 8 bit integers */
   typedef unsigned char UINT8;
   typedef signed short int INT16;   /* 16 bit integer values */
   typedef unsigned short int UINT16;
   typedef signed long int INT32;   /* 32 bit integer values */
   typedef unsigned long int UINT32;
   typedef long long INT64;   /* 64 bit integer values */
   typedef unsigned long long UINT64;
   typedef float REAL32;   /* 32 bit IEEE 754 Real */
   typedef double REAL64;   /* 64 bit IEEE 754 Real */
   typedef long double REAL80;   /* 80 bit IEEE 754 Real */

#endif	/*end ifdef DARWIN */


/* WIN32 Variables definition */
#ifdef _WIN32

#  include <windows.h>

/* VOID is defined by the Win32 API in windows.h */
   typedef char CHAR;   /* Characters */
   typedef unsigned char UCHAR;
   typedef int INT;
   typedef signed char INT8;   /* 8 bit integers */
   typedef unsigned char UINT8;
   typedef signed short INT16;   /* 16 bit integer values */
   typedef unsigned short UINT16;
   typedef signed long INT32;   /* 32 bit integer values */
   typedef unsigned long UINT32;
   typedef __int64 INT64;   /* 64 bit integer values */
   typedef unsigned __int64 UINT64;
   typedef float REAL32;   /* 32 bit IEEE 754 Real */
   typedef double REAL64;   /* 64 bit IEEE 754 Real */
   typedef long double REAL80;   /* 80 bit IEEE 754 Real */

#endif   /* end ifdef _WIN32 */


/* Character constants */
#  define CH_SOH ((UCHAR)1)   /* SOH (start of header) char */
#  define CH_STX ((UCHAR)2)   /* STX (start of text) char */
#  define CH_BACKSP (0x08)   /* BACKSPACE key  */
#  define CH_LF (0x0A)   /* linefeed/enter key */
#  define CH_CR (0x0D)   /* carriage return */
#  define CH_FF (0x0C)   /* formfeed */
#  define CH_ESC (0x1B)   /* ESCAPE key  */
#  define CH_SPACE (0x20)   /* SPACE char */
#  define CH_DP (0x2E)   /* decimal point - numeric entry */
#  define CH_ASCZERO (0x30)   /* ASCII numeric conversion,e.g., + ASCZERO */
#  define CH_DEL (0x7F)   /* delete */

/* END HEADER: passcal.h */
