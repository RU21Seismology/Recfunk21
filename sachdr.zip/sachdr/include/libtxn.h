/* BEGIN HEADER: libtxn.h
 *   Header file with the function prototypes for all of the txnlib
 *   functions.
 */
#ifndef PASSOFT_LIBTXNH
#  define PASSOFT_LIBTXNH

#  define TXNPROG_VERSION "2002.063"

   extern REAL64 txncmp(CHAR *, CHAR *, INT);
   extern VOID txnTime(CHAR *, CHAR *, INT);
   extern VOID txnTimeD(CHAR *, CHAR *, REAL64);

#endif
/* END HEADER: libtxn.h */
