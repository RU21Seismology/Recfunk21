#ifndef BLOCKETTE_034
#define BLOCKETTE_034

typedef struct block_034 {

  int     code_key;             /* key for accessing unit abbreviations */
  char    unit_name[21];        /* the unit's name */
  char    unit_description[51]; /* the unit's description */
      
} b_034_i ;


/* create a list of b_034_items */
typedef struct list_item_034 {
  b_034_i b_034;
  struct list_item_034 *next;
} li_034;

typedef li_034 *b_034_lp;




/* ****************************************************************
 * This section holds the routines for blockette 034 items
 *
 */

int init_list_034( /*      char *master_dir */);
     /* This routine checks to see if a file witht he suggested file */
     /* name exists. If it does, then it attemps to read in any and */
     /* all blockette 034's . if the file does not yet exist, or there */
     /* are no blockette 034's in the file, then the list_ptr is left */
     /* as the NULL ptr. If there are blockette 034's in the file, */
     /* then the list_ptr consists of only the blockettes read in from */
     /* the file. This function returns the number of blockettes read. */

int lookup_b_034_i(/* li_034 *list_ptr,
		   char *name,
		   char *desc */);
/* this function takes a name/desc pair and checks the currently */
/* active b_034 list to see if that description exists yet.  If it */
/* does not, that name/desc pair is added to the list.  In either case */
/* the function returns the lookup key of the name/desc pair, or */
/* FAILURE in case of error. */
/* This function is called by the user. */


int print_li_034(/* li_034 *list_ptr,
		    FILE *f_p */);
/* this function prints out the entire list of blockette 034 items. */
/* it returns the number of blockettes printed, or FAILURE. */
/* This function is actually called by the user. */


/* what follows are the dummy routines to allow the user to add */
/* comments without explicitly maintaining the internal lists.  The */
/* lists are automatically maintained within the block.c program. */



int add_blockette_034_list_item(/*key , units, string*/);


#endif
