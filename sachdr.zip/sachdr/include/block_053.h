#ifndef BLOCKETTE_053
#define BLOCKETTE_053

#include "block_057.h"
#include "block_058.h"





typedef struct block_053 {
  char     stage_type;            /* for PAZ response - 
				     A = Laplace tranform
				     B = Analog (rads/sec or Hz)
				     C = composite(used?) 
				     D = digital,*/
  int      seq_number;            /* assuming a multi-stage filter, */
				  /* which one is this? */
  int      sig_in_units;          /* signal input units */
  int      sig_out_units;         /* signal output units */
  double   a_zero;                /* A0 term/normalization factor */
  double   norm_freq;             /* frequency at which A0 is normailized */
  int      num_poles;             /* poles array size/number of poles */
  double  *p_real;                /* real part of pole */
  double  *p_imag;                /* imaginary part of pole */
  double  *p_real_er;             /* pole real part error */
  double  *p_imag_er;             /* pole imaginary part error */
  int      num_zeros;             /* zeros array size/number of zeros */
  double  *z_real;                /* real part of zero */
  double  *z_imag;                /* imaginary part of zero */
  double  *z_real_er;             /* zero real part error */
  double  *z_imag_er;             /* zero imaginary part error */
} b_053_i ;


/* a real blockette 053 needs 057's and 058's to be described */
typedef struct blk_it_053 {
  b_053_i b_053;
  b_057_i b_057;
  b_058_i b_058;
} b_053_st;
/* so each item in the list has a blockette 053 AND a list of 057's */
/* and a list of 058's */


typedef struct list_item_053 {
  b_053_st st_053;
  struct list_item_053 *next;
} li_053;

typedef li_053 *b_053_lp;



int    init_blk_053( /*     b_053_i *blk_p */ );
/* this function initializes blockette 053.  it returns SUCCESS or */
/* FAILURE */

int copy_blk_053( /*     b_053_i *dest_p     b_053_i *src_p */ );
/* this function initializes blockette 053.  it returns SUCCESS or */
/* FAILURE */



int   write_blk_053(/*     FILE *out_file,     b_053_i *blk_p */ );
     /* This function returns SUCCESS or FAILURE or EMPTY (where */
     /* EMPTY>SUCCESS) */   

int  delete_blk_053(/*     b_053_i *blk_p */ );
/* not needed */

int  free_blk_053(/*     b_053_i *blk_p */);
     /* frees the internal memory of blockette 053, returns SUCCESS of */
     /* FAILURE */

/* ************************************************************************ */

int init_li_st_053(/*     b_053_st *item */ );
/* This fucntion initializes a structure item if blockette 053. It */
/* returns SUCCESS or FAILURE */

int copy_li_053(/*     li_053 *dest_p,     li_053 *src_p */ );
/* This function copies a list of blockette 053 items. IT returns */
/* SUCCESS or FAILURE. it calls  copy_li_it_053() below. */

int copy_li_it_053(/*     b_053_st *dest_p,     b_053_st *src_p */ );
/* This function copies a list item of blockette 053. IT returns */
/* SUCCESS or FAILURE. */


int append_053_list(/*     li_053   *list_ptr,     b_053_st *new_item_ptr */ );
/* this function will add a new item to the end of the list of */
/* blockettes 053. */


int print_053_list(/*     FILE *out_file,     li_053 *list_ptr */ );
/* This fucntion prints out an entire list of blockette 053 items. It */
/* returns SUCCESS or FAILURE */

int print_053_li_it(/*     FILE *out_file,     b_053_st *item */ );
/* This function prints out one item of a list item of blockette 053. */
/* It returns SUCCESS or FAILURE */

int delete_list_053(/*     li_053 *list_ptr */ );
/* This function deletes all the elements in the list of blockette 053 */
/* items. It returns SUCCESS or FAILURE */


/* *********************************************************************** */


#endif
