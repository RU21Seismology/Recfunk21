/* if you add new codes to this list, please make sure
   they are at the end of the list!
*/
struct soh {
	char	code[5];
	char	key[80];
} soh_mapping[] = {
	{"AQON", "ACQUISITION STARTED"},
	{"AQST", "ACQUISITION STOPPED"},
	{"UNKN", "****UNKNOWN****"},
	{"CKUN", "CLOCK IS UNLOCKED"},
	{"CKLK", "CLOCK IS LOCKED"},
	{"CKJK", "INTERNAL CLOCK TIME JERK"},
	{"CKPE", "INTERNAL CLOCK PHASE ERROR"},
	{"CKDP", "DSP CLOCK SET"},
	{"CKNO", "NO EXTERNAL CLOCK"},
	{"CKDD", "DSP CLOCK DIFFERENCE"},
	{"CKDC", "DSP CLOCK HAS CHANGED"},
	{"AUTO", "AUTO DUMP"},
	{"SCSI", "SCSI OPERATION/ERROR"},
	{"OMGA", "KINEMETRICS FORMAT OMEGA EXTERNAL CLOCK"},
	{"GPS",  "POSITION"},
	{"24AD", "24-BIT"}
};
#define SOH_NUM (sizeof soh_mapping / sizeof(struct soh))

#define SOH_START (0)	/* index into soh_mapping for Acquisition start code */
#define SOH_STOP (1)	/* index for Acq. Stop */
#define SOH_UNKNOWN (2)	/* index UNKNOWN */
#define SOH_DSP1    (7)
#define SOH_DSP2    (9)
#define SOH_DSP3    (10)
#define SOH_AUTO    (11) /* some kind of auto dump message */
