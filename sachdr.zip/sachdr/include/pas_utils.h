#ifndef TRUE
#define TRUE 1
#endif TRUE

#ifndef FALSE
#define FALSE 0
#endif FALSE
char * CleanPath(/* char *directory */);
char * Basename(/* char *string */);
