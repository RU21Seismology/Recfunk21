/* BEGIN HEADER: libtrd.h
 *   All of the defines and structs for the libtrd routines.
 *
 *   Must include passcal.h in the .c file before including this file.
 */
#ifndef PASSOFT_LIBTRDH
#  define PASSOFT_LIBTRDH

#  define TRDPROG_VERSION "2005.166"

#  include <sys/types.h>
#  include <sys/stat.h>

#  define TRDPAGELEN 528
#  define TRDMAXFILES 20

#  define TRDMAXFNLEN 128
#  define TRDTIMELENGTH 23
#  define TRDMAXGMSGLENGTH 128
#  define TRDCHIPSETLEN 25
#  define TRDGAINSLEN 30

#  define TRDMAXDATA 519
#  define TRDMAXSOHDATA 516
#  define TRDMAXEVTDATA 516
#  define TRDMAXEXTDATA 507

#  define TRDMAXDATAVALUE 999999999
#  define TRDMINDATAVALUE -999999999
#  define TRDMAXVOLTAGE 9999.999
#  define TRDMINVOLTAGE -9999.999
#  define TRDMAXMSGCOUNT 64
#  define TRDMAXSAMPLECOUNT 172
#  define TRDMAXEVENTS 1024

#  define TRDBADTYPE 0
#  define TRDSOHTYPE 1
#  define TRDDTTYPE 3
#  define TRDEVTTYPE 5
#  define TRDERASEDTYPE (0xFF)

   struct _PageStruct   /* Basic page structure */
   {
      UCHAR Type;
      UCHAR Unit[2];
      UCHAR Sequence[2];
      UCHAR Flag;
      UCHAR GainInfo;
      UCHAR Data[TRDMAXDATA];
      UCHAR Crc[2];
   };

   struct _SOHStruct
   {
      UCHAR Type;
      UCHAR Unit[2];
      UCHAR Sequence[2];
      UCHAR Flag;
      UCHAR GainInfo;
      UCHAR ByteCount[2];
      UCHAR MessageCount;
      UCHAR Data[TRDMAXSOHDATA];
      UCHAR Crc[2];
   };

   struct _EventStruct
   {
      UCHAR Type;
      UCHAR Unit[2];
      UCHAR Sequence[2];
      UCHAR Flag;
      UCHAR GainInfo;
      UCHAR EventNumber[2];
      UCHAR SampleCount;
      UCHAR Data[TRDMAXEVTDATA];
      UCHAR Crc[2];
   };

   struct _ExtStruct
   {
      UCHAR Type;
      UCHAR Unit[2];
      UCHAR Sequence[2];
      UCHAR Flag;
      UCHAR GainInfo;
      UCHAR EventNumber[2];      
      UCHAR SampleCount;
      UCHAR EventTime[6];
      UCHAR SampleRate[2];
      UCHAR Voltage;
      UCHAR Data[TRDMAXEXTDATA];
      UCHAR Crc[2];
   };

   struct _TRDFilePage
   {
      INT16 Fd;
      CHAR Filename[TRDMAXFNLEN];
      INT16 Position1;
      INT16 Position2;
      struct stat Stat;
      INT32 Pages;
      INT32 PagesBad;
      INT32 PagesErased;
      INT32 PagesUnknown;
      INT32 PagesDT;
      INT32 PagesSOH;
      INT32 FilePoints;
      INT32 FileMax;
      INT32 FileMin;
      INT32 EventNumber[TRDMAXEVENTS];
      INT32 EventStartPoint[TRDMAXEVENTS];
      CHAR EventStartTime[TRDMAXEVENTS][TRDTIMELENGTH];
      INT32 EventSampleRate[TRDMAXEVENTS];
      REAL64 EventVoltage[TRDMAXEVENTS];
      INT32 EventMax[TRDMAXEVENTS];
      INT32 EventMin[TRDMAXEVENTS];
      INT32 EventPoints[TRDMAXEVENTS];
      CHAR StartTime[TRDTIMELENGTH];
      CHAR TexanEndTime[TRDTIMELENGTH];
      CHAR GPSEndTime[TRDTIMELENGTH];
      REAL64 ClockDrift;
      CHAR Chipset[TRDCHIPSETLEN];
      CHAR Gains[TRDGAINSLEN];
      REAL64 MaxVoltage;
      REAL64 MinVoltage;
      CHAR *DataBlock;
      union Data
      {
         CHAR Data[TRDPAGELEN];
         struct _PageStruct PageData;
         struct _SOHStruct SOHData;
         struct _EventStruct EventData;
         struct _ExtStruct ExtData;
      } Data;
   };
   struct _TRDFilePage *TRD[TRDMAXFILES];

   INT TRDBigEndian;
   CHAR GMsg[TRDMAXGMSGLENGTH];

   extern CHAR *trdCalcPageCrc(INT16, UINT16 *);
   extern CHAR *trdCheckFile(INT16);
   extern CHAR *trdCheckPage(INT16);
   extern CHAR *trdCleanSOH(CHAR *);
   extern CHAR *trdCloseAllFiles(VOID);
   extern CHAR *trdCloseFile(INT16);
   extern CHAR *trdDumpAllPoints(INT16);
   extern CHAR *trdDumpPage(INT16, CHAR *);
   extern CHAR *trdGetByteCount(INT16, CHAR *);
   extern CHAR *trdGetClockDrift(INT16, REAL64 *);
   extern CHAR *trdGetDataBlock(INT16, CHAR *);
   extern CHAR *trdGetEventMax(INT16, INT16, INT32 *);
   extern CHAR *trdGetEventMin(INT16, INT16, INT32 *);
   extern CHAR *trdGetEventNumber(INT16, INT32 *);
   extern CHAR *trdGetEventSampleRate(INT16, INT16, INT32 *);
   extern CHAR *trdGetEventStartPoint(INT16, INT16, INT32 *);
   extern CHAR *trdGetEventStartTime(INT16, INT16, CHAR *);
   extern CHAR *trdGetEventVoltage(INT16, INT16, REAL64 *);
   extern CHAR *trdGetFileMax(INT16, INT32 *);
   extern CHAR *trdGetFileMin(INT16, INT32 *);
   extern CHAR *trdGetFilename(INT16, CHAR *);
   extern CHAR *trdGetFilePoints(INT16, INT32 *);
   extern CHAR *trdGetFileSize(INT16, INT32 *);
   extern CHAR *trdGetMessageCount(INT16, INT32 *);
   extern CHAR *trdGetNextPoint(INT16, INT *, INT32 *);
   extern CHAR *trdGetNextSOHMessage(INT16, CHAR *, INT);
   extern CHAR *trdGetPageCrc(INT16, INT32 *);
   extern CHAR *trdGetPageFlag(INT16, CHAR *);
   extern CHAR *trdGetPageGain(INT16, CHAR *, INT16 *);
   extern CHAR *trdGetPageInfo(INT16, CHAR *);
   extern CHAR *trdGetPageLength(INT16 *);
   extern CHAR *trdGetPageType(INT16, CHAR *);
   extern CHAR *trdGetPageSampleCount(INT16, INT32 *);
   extern CHAR *trdGetPageSampleRate(INT16, INT32 *);
   extern CHAR *trdGetPageTime(INT16, CHAR *);
   extern CHAR *trdGetPageVoltage(INT16, REAL64 *);
   extern CHAR *trdGetPgsPtsHiLo(INT16, INT32 *, INT32 *, INT32 *, INT32 *);
   extern CHAR *trdGetSequenceNum(INT16, INT32 *);
   extern CHAR *trdGetUnitID(INT16, INT32 *);
   extern CHAR *trdInit(VOID);
   extern CHAR *trdMaxPagesPoints(INT16, INT32 *, INT32 *);
   extern CHAR *trdOpenFile(CHAR *, INT16 *);
   extern CHAR *trdReadAllPoints(INT16, INT32 *, INT, CHAR *, INT32);
   extern CHAR *trdReadAllSOH(INT16, CHAR *, INT32);
   extern CHAR *trdReadNextPage(INT16);
   extern CHAR *trdReadNextPageType(INT16, CHAR *);
   extern CHAR *trdRewindFile(INT16);
   extern CHAR *trdRewindPage(INT16);
   extern CHAR *trdSetDataBlock(INT16, CHAR *);
   extern CHAR *trdSummary(INT16);
   extern CHAR *trdTime2Secs(CHAR *, CHAR *, REAL64 *);
   extern CHAR *trdWritePage(INT16, INT16);
   extern CHAR *trdYDHMS2Str(CHAR *, CHAR *);

#endif
/* END HEADER: libtrd.h */
