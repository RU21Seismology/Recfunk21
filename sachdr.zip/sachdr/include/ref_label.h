#define uchar unsigned char
#define ulong unsigned long

typedef struct ReftekLabel
   {
   ulong write_sect;       /* next sector to write to */
   uchar label[16];        /* ASCII 'REFTEK ARS DISK ' */
   ulong wrap_count;       /* # times disk has wrapped */
   ulong read_sect;        /* read pointer for VSAT transmittion */
   ulong copy_sect;        /* RT44D copy pointer for disk to tape */
   ulong leod;             /* Logical EOD */
   ulong first_dir_sect;   /* First dir sector */
   ulong last_dir_sect;    /* Last directory sector */
   ulong owrit_enable;     /* Over-write enable flg */
   ulong num_dir_blks;     /* Number of dir blocks on disk */
   ulong num_dir_ents;     /* Number of dir entries on disk */
   ulong switch_sect;      /* RT44D disk switch sector */
   uchar reserved[964];    /* Reserved - 0's */
   }REFTEK_DISK_LABEL;

#define REF_TEXT_LABEL "REFTEK ARS DISK "
int OpenRefDiskLabel(), CloseRefDiskLabel();
REFTEK_DISK_LABEL * ReadRefDiskLabel();
void EchoRefDiskLabel();
