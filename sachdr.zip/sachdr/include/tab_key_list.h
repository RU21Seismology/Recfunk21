char *key_list[] = {
"TRIGGER_ID",
"CONFIG_ID",
"DATA_STREAM_ID",
"CHANNEL_ID",
"SITE_ID",
"SENSOR_ID",
"UPLOAD_NUMBER",
"DEPLOYMENT_NUM",
"RESPONSE_ID",
"TRACE_ID",
"TAPE_ARCH_ID",
"TAPE_VOL_ID",
"DIR_ID",
"RAW_VOL_ID"
};

int key_load();
int key_parse();
