
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

/* 
NB:	the presence of RefWrite is superflous for
	the current implementation. Only RefRead is used
	as a locking flag
*/
#define 	REF_ON			1
#define 	REF_OFF			0
#define 	REF_WRITE		0001
#define 	REF_READ		0002
#define		REF_COUNTS		(72)
#define		REF_SHM_FLAGS_SIZE	(5)
#define 	REF_SHM_SEG_SIZE 	(3072)
#define 	REF_SHM_TOTAL_SIZE (REF_SHM_FLAGS_SIZE+REF_COUNTS*REF_SHM_SEG_SIZE)
#define		REF_SHM_HEADER_SIZE (sizeof(long) * REF_DATA_MEMBERS)

#define 	REF_SHM_IGNORE		0001
#define 	REF_SHM_BLOCK		0002 
