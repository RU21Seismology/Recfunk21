/* BEGIN HEADER: libscp.h
 */
#ifndef PASSOFT_LIBSCPH
#  define PASSOFT_LIBSCPH

#  define SCPPROG_VERSION "2002.060"

/* SCPINLINESIZE...the max size of the command input line
 * SCPCOMMANDSIZE..the max size of command names
 * SCPOUTLINESIZE..the max size of output lines (in scpInputs())
 * SCPBELL.........ASCII BELL value (7)
 * SCPInLine.......where the "raw" entered command is placed and not altered
 * SCPCommand......where the command (first word) of scpInLine is placed and
 *                 converted to upper case.
 * SCPArgument.....where the argument portion of a command line is worked on
 * SCPTempx........temporary char space. These will be reset each time
 *                 through scpHandler.
 * SCPTempInt......temporary int variable.
 * SCPIndex........the scp struct index value of the current command being
 *                 processed.
 * SCPMenu.........the menu to be displayed on the INPUTS command
 * SCPWords........the number of words in scpInLine
 * SCPRtnValue.....general purpose return value keeper for the host program to
 *                 use (it's not used in the SCP package)
 * SCPUseSCP.......for use by the host program to set as to whether or not the
 *                 SCP is going to be used
 */
#  define SCPARGUMENTSIZE 81
#  define SCPINLINESIZE 133
#  define SCPCOMMANDSIZE 41
#  define SCPOUTLINESIZE 133
#  define SCPSMARGUMENTSIZE 25
#  define SCPBELL 7
   CHAR SCPInLine[SCPINLINESIZE];
   CHAR SCPCommand[SCPCOMMANDSIZE];
   CHAR SCPArgument[SCPARGUMENTSIZE];
   CHAR SCPTemp1[SCPINLINESIZE];
   CHAR SCPTemp2[SCPINLINESIZE];
   CHAR SCPTemp3[SCPINLINESIZE];
   INT32 SCPTempLong;
   INT SCPIndex;
   INT SCPMenu;
   INT SCPWords;
   INT SCPRtnValue;
   INT SCPUseSCP;

   CHAR SCPProgram[SCPARGUMENTSIZE];
   CHAR SCPVersion[SCPARGUMENTSIZE];
   CHAR SCPDescription[SCPARGUMENTSIZE];

/* SCP Structure declarations:
 *   Command.......the command or the menu title (upper case)
 *   Menu..........the number of the menu to which the command belongs
 *   Type..........the type designation of the item (see SCPTypes.doc)
 *   AcceptItems...the number of items in the following list
 *   CharAccept....pointer to a list of acceptable arguments
 *   LowFlLimit....the lower allowed limit for a float argument
 *   HighFlLimit...the upper allowed limit for a float argument
 *   LowIntLimit...the lower allowed limit for an integer argument
 *   HighIntLimit..the upper allowed limit for an integer argument
 *   Default.......char representation of the default argument
 *   Argument......char representation of the last entered argument
 */
   struct _SCP
   {
      CHAR *Command;
      INT Menu;
      INT Type;
      INT AcceptItems;
      CHAR *CharAccept;
      REAL64 LowFlLimit;
      REAL64 HighFlLimit;
      INT32 LowIntLimit;
      INT32 HighIntLimit;
      CHAR *Default;
      CHAR *CmdHelp;
      CHAR *HelpText;
      CHAR Argument[SCPARGUMENTSIZE];
   };
   struct _SCP *SCP;
   INT SCPCmdTotal;
   INT SCPCmdPos;

/* Date and time formats (keep up to date with the cclib functions
 * dateFormat.c and timeFormat.c)
 */
#  define SCPYYYYMMMDD 1
#  define SCPDDMMMYYYY 2
#  define SCPMMDDYYY 3
#  define SCPYYYYMMDD 4
#  define SCPYYYYDDD 5

#  define SCPHHCMMCSS 0
#  define SCPHHhMMmSSs 1
#  define SCPHHMMSS 2
#  define SCPHHCMMampm 3
#  define SCPHHCMMCSSampm 4
#  define SCPHHCMM 5

/* Function prototypes for everything in the package */
   extern CHAR *scpArgRtn(CHAR *);
   extern INT scpCAcmp(CHAR *);
   extern INT scpCharLine();
   extern INT scpCharMult();
   extern INT scpCharSing();
   extern INT scpDate();
   extern INT scpDateDate();
   extern INT scpDateTime();
   extern INT scpDec();
   extern INT scpDefaultsSet();
   extern INT scpDefSet();
   extern INT scpDeg();
   extern VOID scpDump();
   extern VOID scpErrorMessage(INT, CHAR *);
   extern INT scpFileName();
   extern INT scpFlRange();
   extern INT scpFlSing();
   extern VOID scpFree();
   extern INT scpGet(CHAR *);
   extern INT scpGetCmdTotal();
   extern CHAR *scpGetCommand(INT);
   extern INT scpGo();
   extern INT scpHandler();
   extern INT scpHelp();
   extern INT scpHelpPrint(INT);
   extern INT scpHex();
   extern INT scpHexMult();
   extern INT scpHexRange();
   extern INT scpIndexRtn(CHAR *);
   extern INT scpInputs(CHAR *);
   extern INT scpIntMult();
   extern INT scpIntRange();
   extern INT scpIntSing();
   extern INT scpMenuEntry();
   extern INT scpOctal();
   extern INT scpRa();
   extern INT scpSave(CHAR *);
   extern VOID scpSetCmd(CHAR *, INT, INT, INT, CHAR *, REAL64, REAL64, INT32, INT32, CHAR *, CHAR *, CHAR *);
   extern INT scpSetCmdTotal(INT);
   extern VOID scpSetDescription(CHAR *);
   extern VOID scpSetProgram(CHAR *);
   extern VOID scpSetVersion(CHAR *);
   extern VOID scpStartup();
   extern INT scpTime();
   extern INT scpTimeRange();
   extern INT scpTypes();
   extern INT scpUnique(CHAR *);

#endif
/* END HEADER: libscp.h */
