#ifndef BLOCKETTE_058
#define BLOCKETTE_058


typedef struct block_058 {

  int     seq_number;   /* stage sequence number */
  double  sense_gain;   /* sensitivity/gain value */
  double  freq;         /* frequency (Hz) */
  int     num_hist;     /* number of history values */
  double *sense_list;   /* sensitivity for calibration */
  double *freq_list;    /* Freqency of calibration */
  char    cal_time[23]; /* time of calibration */

} b_058_i ;


/* also need a linked list of these blocks */
typedef struct list_item_058 {
  b_058_i *blk_p;
  struct list_item_058 *next;
} li_058;

/* and a list pointer */
typedef li_058 *b_058_lp;

     
int    init_blk_058(/*     b_058_i *blk_p */ );
/* this function initializes blockette 058.  it returns SUCCESS or */
/* FAILURE */
     
  
int write_blk_058(/*     FILE *out_file,     b_058_i *blk_p */ );
     /* write the sensitivity/gain blockette */
     /* this function writes to 'out_file' the information in the sense_gain */
     /* item.  The format of the file is the exact format required by SEED */
     /* and POD.  Therefore all one needs to do to use this function to */
     /* create POD files is to correctly specify the file name (including */
     /* path) for the output file. */
     /* This function returns SUCCESS or FAILURE or EMPTY (where */
     /* EMPTY>SUCCESS) */   

int copy_blk_058(/*     b_058_i *dest_p,     b_058_i *src_p */ );
/* this function copies one blockette 058 to another one.  It returns */
/* SUCCESS or FAILURE */


int  delete_blk_058(/*     b_058_i *blk_p */ );
/* not needed */

int  free_blk_058(/*     b_058_i *blk_p */ );
/* this function frees up the internal memory of a blockette 058. it */
/* returns SUCCESS or FAILURE */






#endif
