
#define SEGY 	001

typedef struct FilesList {
	char *filename;		/* pointer to filename */
	char *head_ptr;		/* pointer to header (in this case SEGY) */
	long epoch;		/* epoch seconds as returned from htoe() */
	int  msecs;		/* milliseconds */
	long nsamples;		/* number of samples */
	long srate;		/* sample rate in microseconds per sample */
	short size_of_data; 	/* number of bytes in data, 2 or 4 usually*/
	int   msec_corr;	/* milliseconds correction */
	int   corrected;	/* true if the time-stamp has already been time corrected */
	int   file_type;		/* file-type NOT USED YET */
	char *data;		/* pointer to data */
} FILESLIST;
FILESLIST *ProcessGather(), *AllocFilesListEntry();
FILESLIST **GetCommandLineFileList(), **GetFileFileList();
