#ifndef BLOCKETTE_FILE
#define BLOCKETTE_FILE

#include <stdio.h>
#include <errno.h>

#ifndef RESPONSE_FILE
#include "response.h"
#endif

#ifndef SUCCESS
#define SUCCESS 0
#define FAILURE -1
#define EMPTY 1
#define TRUE 1
#define FALSE 0
#endif

#define MIN_SIZE_050 62
#define MIN_SIZE_051 19
#define MIN_SIZE_052 103
#define MIN_SIZE_053 46
#define MIN_SIZE_054 24
#define MIN_SIZE_057 51
#define MIN_SIZE_058 35
#define MIN_SIZE_059 20
#define MIN_SIZE_030 17
#define MIN_SIZE_031 16
#define MIN_SIZE_033 11
#define MIN_SIZE_034 12

#ifndef INT_DIFF_COMPRESSION
#define INT_DIFF_COMPRESSION 50 /* from blockette 30 */
#endif

#ifndef DEF_REC_LEN
#define DEF_REC_LEN 12          /* 4096 = 2^^12 */
#endif



typedef struct block_030 {

  char    name[51];        /* short descriptive name */
  int     code_key;        /* key for accessing dictionary entries */
  int     data_type;       /* data family type (0 = int fixed, 1 = int */
			   /* diffs) */
  int     num_decode_keys; /* number of decoder keys used by the data */
			   /* family type */
  char    *decode_keys[20];   /* decoder keys used by the data */
			   /* family type.   ~'s separate the entries*/
  
    
} b_030_i ;


typedef struct block_031 {

  int     code_key;        /* key for accessing comments */
  char    letter_code;     /* user assigned, determines to what the */
			   /* code refers. */
  char    comment[71];     /* the comments's text */
  int     units_level;     /* if a value is associated with the */
			   /* comment, lookup the units from blockette */
			   /* 34 */
      
} b_031_i ;



typedef struct block_033 {

  int     code_key;             /* key for accessing generic abbreviation */
  char    abb_description[51];  /* the abbreviation description */
      
} b_033_i ;




typedef struct block_034 {

  int     code_key;             /* key for accessing unit abbreviations */
  char    unit_name[21];        /* the unit's name */
  char    unit_description[51]; /* the unit's description */
      
} b_034_i ;



typedef struct block_050 {
  char   station_name[5];      /* Station call letters  */
  double latitude;             /* earth latitude (deg) (+=N -=S)  */
  double longitude;            /* earth longitude (deg) (+=E -=W)  */
  double elevation;            /* ground level (meters)  */
  int    num_channels;         /* optional,num of channels that follow  */
  int    num_station_comments; /* num of station comment blockette(51)  */
  char   site_name[61];        /* station site, (town, state, country etc  */
  int    network_id;           /* lookup code for blockette 33  */
  int    _32_bit_word_order;    /* i.e. 0123, 3210, for headers, for */
			       /* data, see data format dictionary  */
  int    _16_bit_word_order;    /* 01, 10, as above  */
  char   start_date[23];       /* earliest date that header info is correct*/
  char   end_date[23];         /* last date info correct, 0 = still ok  */
  char   update_flag;          /* to what the data update records refer  */
  char   network_code[3];      /* network operator responsible for the */
			       /* data logger, assigned by IRIS. */
  
} b_050_i;

typedef struct block_051 {
  char   start_time[23];       /* earliest date that header info is correct*/
  char   end_time[23];         /* last date info correct, 0 = still ok  */
  int     code_key;            /* key for accessing comments */
  int     comment_level;       /* numeric value from Blocketter 31 */
  
} b_051_i;

typedef struct block_052 {
  char   location[3];     /* site within an array */
  char   channel[4];      /* standard channel id */
  int    sub_channel;     /* for multiplexed data */
  int    instrument;      /* lookup index from blockette 33 */
  char   comment[31];     /* optional comment */
  int    resp_units;      /* unit lookup key in blockette 34 */
  int    cal_units;       /* unit lookup key in blockette 34 */
  double latitude;        /* for instrument, can differ from station (deg) */
  double longitude;       /* for instrument, can differ from station (deg) */
  double elevation;       /* for instrument (not ground) (meters) */
  double depth;           /* instrument depth below ground */
  double azimuth;         /* in degrees from north, clockwise */
  double dip;             /* in degrees, down from horizontal */
  int    data_format;     /* lookup index from blockette 30 */
  int    data_record_len; /* in bytes,256-4096, store as n where 2**n */
  double sample_rate;     /* nominal sample rate (Hz) for digitzer */
  double max_clock_drift; /* NUM of samples * tolerance (sec/sample) */
  int    num_comments;    /* num of channel comment blockettes(59) */
			  /* that follow */
  char   chan_flags[27];  /* channel type flags */
  char   start_date[23];  /* earliest known date data was correct this */
			  /* blockette */
  char   end_date[23];    /* last date info was correct, zero=time of */
			  /* this blockettes creation */
  char   update_flag;     /* what data the update records refer to. */
} b_052_i;

typedef struct block_053 {
  char     stage_type;            /* for PAZ response - 
				     A = Laplace tranform
				     B = Analog (rads/sec or Hz)
				     C = composite(used?) 
				     D = digital,*/
  int      seq_number;            /* assuming a multi-stage filter, */
				  /* which one is this? */
  int      sig_in_units;          /* signal input units */
  int      sig_out_units;         /* signal output units */
  double   a_zero;                /* A0 term/normalization factor */
  double   norm_freq;             /* frequency at which A0 is normailized */
  int      num_poles;             /* poles array size/number of poles */
  double  *p_real;                /* real part of pole */
  double  *p_imag;                /* imaginary part of pole */
  double  *p_real_er;             /* pole real part error */
  double  *p_imag_er;             /* pole imaginary part error */
  int      num_zeros;             /* zeros array size/number of zeros */
  double  *z_real;                /* real part of zero */
  double  *z_imag;                /* imaginary part of zero */
  double  *z_real_er;             /* zero real part error */
  double  *z_imag_er;             /* zero imaginary part error */
} b_053_i ;

typedef struct block_054 {
  char     stage_type;            /* For FIR response -
				     A = Analog (rad/sec)
				     B = Analog (Hz)
				     C = Composite
				     D = Digital */
  int      seq_number;            /* assuming a multi-stage filter, */
				  /* which one is this? */
  int      sig_in_units;          /* signal input units */
  int      sig_out_units;         /* signal output units */
  int      num_num;               /* number of numerators */
  double  *num;                   /* numerator coefficient */
  double  *num_er;                /* numerator coefficient error */
  int      num_denom;             /* number of denominators */
  double  *denom;                 /* denominator coeffiencient */
  double  *denom_er;              /* denominator coeffiencient error */
} b_054_i ;




typedef struct block_057 {
  int      seq_number;            /* assuming a multi-stage filter, */
    			          /* which one is this? */
  double   input_sample_rate;     /* samples per second */
  int      decimation_factor;     /* one sample out/this */
				  /* number in */
  int      decimation_offset;     /* which sample out of the */
				  /* decimation factor is used */
  double   delay;                 /* estimated pure delay for */
                                  /* the state. */
  double   correction;            /* time shift applied to the */
			       	  /* time tag due to delay at */
			       	  /* this stage of the filter */
} b_057_i ;


typedef struct block_058 {

  int     seq_number;   /* stage sequence number */
  double  sense_gain;   /* sensitivity/gain value */
  double  freq;         /* frequency (Hz) */
  int     num_hist;     /* number of history values */
  double *sense_list;   /* sensitivity for calibration */
  double *freq_list;    /* Freqency of calibration */
  char    cal_time[23]; /* time of calibration */

} b_058_i ;

typedef struct block_059 {

  char    start_time[23]; /* beginning of comment validity*/
  char    end_time[23];   /* end of comment validity*/

  int     code_key;       /* key for accessing comments */
  int     comment_level;  /* numeric value from Blocketter 31 */

} b_059_i ;



typedef struct block_060 {

  int     num_stages;     /* the number of stages */
  int    *stage_seq_num;  /* list of stage sequence numbers */ 
  int     num_responses;  /* the number of responses */
  int    *response_lookup_key; /* a list of lookup keys, one for each */
			       /* response within each stage. */

} b_060_i ;



typedef struct block_061 {

  int     seq_num;        /* stage sequence number */
  char    resp_name[26];  /* a descriptive name for the response */
  char    sym_code;       /* symmetry code, designates how factors */
			  /* will be specified. */
  int     sig_in_units;   /* signal input units */
  int     sig_out_units;  /* signal output units */
  int     num_coeff;      /* number of coeffients */
  double *fir_coeff;      /* list of FIR coefficients */

} b_061_i ;



/* also need a linked list of these blocks */
typedef struct list_item_057 {
  b_057_i *blk_p;
  struct list_item_057 *next;
} li_057;

/* and a list pointer */
typedef li_057 *b_057_lp;

/* also need a linked list of these blocks */
typedef struct list_item_058 {
  b_058_i *blk_p;
  struct list_item_058 *next;
} li_058;

/* and a list pointer */
typedef li_058 *b_058_lp;

/* a real blockette 053 needs 057's and 058's to be described */
typedef struct blk_it_053 {
  b_053_i b_053;
  b_057_i b_057;
  b_058_i b_058;
} b_053_st;
/* so each item in the list has a blockette 053 AND a list of 057's */
/* and a list of 058's */

typedef struct list_item_053 {
  b_053_st st_053;
  struct list_item_053 *next;
} li_053;

typedef li_053 *b_053_lp;


/* a real blockette 054 needs 057's and 058's to be described */
typedef struct blk_it_054 {
  b_054_i b_054;
  b_057_i b_057;
  b_058_i b_058;
} b_054_st;

typedef struct list_item_054 {
  b_054_st st_054;
  struct list_item_054 *next;
} li_054;

typedef li_054 *b_054_lp;
 
/* a real blockette 052 needs 053's and 054's to be described */
typedef struct list_item_052 {
  b_052_i  b_052;
  li_053 *l_053_p;
  li_054 *l_054_p;
  b_058_i b_058;         /* This item holds the channel sensitivity */
			 /* blockette */
  struct list_item_052 *next;
} li_052;
/*
   typedef struct list_item_052 {
   b_052_i  b_052;
   li_053 l_053;
   li_054 l_054;
   struct list_item_052 *next;
   } li_052;
   */
typedef li_052 *b_052_lp;

typedef struct list_item_051 {
  b_051_i b_051;
  struct list_item_051 *next;
} li_051;

typedef li_051 *b_051_lp;


/* a real blockette 050 needs a list of 052's to be described */
typedef struct list_item_050 {
  b_050_i b_050;
  li_052 *l_052_p;
  struct list_item_050 *next;
} li_050;

typedef li_050 *b_050_lp;

 

/* create a list of b_030_items */
typedef struct list_item_030 {
  b_030_i b_030;
  struct list_item_030 *next;
} li_030;

typedef li_030 *b_030_lp;



/* create a list of b_031_items */
typedef struct list_item_031 {
  b_031_i b_031;
  struct list_item_031 *next;
} li_031;

typedef li_031 *b_031_lp;


/* create a list of b_033_items */
typedef struct list_item_033 {
  b_033_i b_033;
  struct list_item_033 *next;
} li_033;

typedef li_033 *b_033_lp;



/* create a list of b_034_items */
typedef struct list_item_034 {
  b_034_i b_034;
  struct list_item_034 *next;
} li_034;

typedef li_034 *b_034_lp;





/* sidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsid */
int    init_blk_050( /* b_050_i *blk_p */);
/* this routine initializes a blockette item 050 with values with no
meaning. This function returns SUCCESS or FAILURE */

     
int write_blk_050(/* FILE *out_file b_050_i *blk_p */); 
/* This routine writes out the blockette 050 The function returns
FAILURE < SUCCESS < EMPTY.  EMPTY is returned when the pointer does
not point to anything. */ 



int  delete_blk_050(/* b_050_i *blk_p */);
/* this routine is not needed */


int compare_blk_050(/*     b_050_i *blk_p_1,     b_050_i *blk_p_2 */ );

/* in order to compare two items of blockette 050, we must only */
/* compare the station names. It returns the same values that strcmp
returns */



int    init_blk_052(/*b_052_i *blk_p */);
/* this routine initializes a blockette item 052 with values with no
meaning. This function returns SUCCESS or FAILURE */


int write_blk_052(/*    FILE *out_file,     b_052_i *blk_p */);
     /* write the channel id blockette */
     /* this function writes to 'out_file' the information in the response */
     /* item.  The format of the file is the exact format required by SEED */
     /* and POD.  Therefore all one needs to do to use this function to */
     /* create POD files is to correctly specify the file name (including */
     /* path) for the output file. */
     /* This function returns SUCCESS or FAILURE or EMPTY (where */
     /* EMPTY>SUCCESS) */   


int  delete_blk_052( /*      b_052_i *blk_p*/);
/* not needed */



int copy_blk_052(/*     b_052_i *dest_p;     b_052_i *src_p */ );
/* this function copys entire blockettes, it returns SUCCESS or */
/* FAILURE */

int    init_blk_053( /*     b_053_i *blk_p */ );
/* this function initializes blockette 053.  it returns SUCCESS or */
/* FAILURE */

int copy_blk_053( /*     b_053_i *dest_p     b_053_i *src_p */ );
/* this function initializes blockette 053.  it returns SUCCESS or */
/* FAILURE */



int   write_blk_053(/*     FILE *out_file,     b_053_i *blk_p */ );
     /* This function returns SUCCESS or FAILURE or EMPTY (where */
     /* EMPTY>SUCCESS) */   

int  delete_blk_053(/*     b_053_i *blk_p */ );
/* not needed */

int  free_blk_053(/*     b_053_i *blk_p */);
     /* frees the internal memory of blockette 053, returns SUCCESS of */
     /* FAILURE */

     
int    init_blk_054( /*     b_054_i *blk_p*/);
/* this function initializes blockette 054.  it returns SUCCESS or */
/* FAILURE */


int copy_blk_054(/*     b_054_i *dest_p,     b_054_i *src_p */ );
/* This function copys one blockette 054 to another one.  IT returns */
/* SUCCESS or FAILURE. */

int   write_blk_054(/*     FILE *out_file,     b_054_i *blk_p */ );
/* This function returns SUCCESS or FAILURE or EMPTY (where */
/* EMPTY>SUCCESS). This function writes out the blockette to the */
/* out_file */ 


int  delete_blk_054(/*     b_054_i *blk_p */ );
/* not needed */

int  free_blk_054(/*     b_054_i *blk_p */ );
/* this function frees up the internal memory of a blockette 054. it */
/* returns SUCCESS or FAILURE */

int    init_blk_057(/*     b_057_i *blk_p */ );
/* this function initializes blockette 057.  it returns SUCCESS or */
/* FAILURE */

int   write_blk_057(/*     FILE *out_file,     b_057_i *blk_p*/ );
/* This function returns SUCCESS or FAILURE or EMPTY (where */
/* EMPTY>SUCCESS) This function writes out the blockette to the */
/* out_file */   


int copy_blk_057(/*     b_057_i *dest_p,     b_057_i *src_p*/ );
/* This function copys one blockette 054 to another one.  IT returns */
/* SUCCESS or FAILURE. */


int  delete_blk_057(/*     b_057_i *blk_p */ );
/* not needed */


     
int    init_blk_058(/*     b_058_i *blk_p */ );
/* this function initializes blockette 058.  it returns SUCCESS or */
/* FAILURE */
     
  
int write_blk_058(/*     FILE *out_file,     b_058_i *blk_p */ );
     /* write the sensitivity/gain blockette */
     /* this function writes to 'out_file' the information in the sense_gain */
     /* item.  The format of the file is the exact format required by SEED */
     /* and POD.  Therefore all one needs to do to use this function to */
     /* create POD files is to correctly specify the file name (including */
     /* path) for the output file. */
     /* This function returns SUCCESS or FAILURE or EMPTY (where */
     /* EMPTY>SUCCESS) */   

int copy_blk_058(/*     b_058_i *dest_p,     b_058_i *src_p */ );
/* this function copies one blockette 058 to another one.  It returns */
/* SUCCESS or FAILURE */


int  delete_blk_058(/*     b_058_i *blk_p */ );
/* not needed */

int  free_blk_058(/*     b_058_i *blk_p */ );
/* this function frees up the internal memory of a blockette 058. it */
/* returns SUCCESS or FAILURE */


int    init_blk_059(/*     b_059_i *blk_p*/ );
/* this function initializes a blockette 059. It returns SUCCESS or */
/* FAILURE */
     
int   write_blk_059(/*     FILE *out_file,     b_059_i *blk_p */ );
     /* This function returns SUCCESS or FAILURE or EMPTY (where */
     /* EMPTY>SUCCESS). This function writes out the blockette 059 */   

     
int  delete_blk_059(/*     b_059_i *blk_p */ );
/* not needed */

/* ************************************************************************ */


int init_li_050( /*     li_050 *blk_p */ );
     /* This function take a pointer to a blokette 050 list item, and */
     /* initializes that item. This function returns SUCCESS or */
     /* FAILURE. */ 

/* ************************************************************************ */
/* ************************************************************************ */

int append_052_list(/*     li_052  *blk_p,     li_052  b_052_li */ );
/* this function takes a blockette 052 and appends it to the end of */
/* the blockette 052 list. It returns SUCCESS or FAILURE */



int copy_li_it_052(/*     li_052 *dest_p,     li_052 *src_p*/ );
/* this function copies a list item of blockette 052, including the */
/* internally stored blockettes. It returns SUCCESS or FAILURE. */

int init_li_052(/*     li_052 *blk_p */ );
     /* This function take a pointer to a blokette 052 list item, and */
     /* initializes that item. This function returns SUCCESS or */
     /* FAILURE. */ 

int append_052_list_053(/*     li_052 *b_052_li_p,     li_053 *l_053_p*/ );
     /* this function take s pointer to a blockette 052 list item and */
     /* pointer to a blockette list 053, and then adds the block list 053 */
     /* to the 053 list in the 052 list item. */

int append_052_list_054(/*     li_052 *b_052_li_p,     li_054 *l_054_p */ );
     /* this function take s pointer to a blockette 052 list and */
     /* pointer to a blockette list 054, and then adds the block list 054 */
     /* to the 054 list in the 052 list item. */

int append_052_item_053(/*     li_052 *b_052_li_p,     li_053 *l_053_p*/ );
     /* this function take s pointer to a blockette 052 list item and */
     /* pointer to a blockette list item 053, and then adds the block 053 */
     /* to the 053 list in the 052 list item. */

int append_052_item_054(/*     li_052 *b_052_li_p,     li_054 *l_054_p */ );
     /* this function take s pointer to a blockette 052 list item and */
     /* pointer to a blockette list item 054, and then adds the block 054 */
     /* to the 054 list in the 052 list item. */

int set_052_item_058(/*   li_052 *b_052_li_p, b_058_i *b_058 */);
/* This function takes a pointer to a 058 channel sensitivity */
/* blockette and copies the values in this blockette into the channel */
/* sensitivity variables within the block_052 list_item. */

int delete_list_052( /*     li_052 *list_ptr */ );
/* this function takes a pointer to a list of 052 items and deletes */
/* the items in the list. It returns SUCCESS or FAILURE. */

int free_052_list(/*     li_052 *b_052_li_p*/ );
     /* this function takes a pointer to a list of blockette 052 items */
     /* and frees all te internal memory associated with that list. */

int clear_052_list(/*     li_052 *b_052_li_p*/ );
     /* this function takes a pointer to a list of blockette 052 items */
     /* and frees all te internal memory associated with that list. */
     /* This routine assumes that the list itself was declared, but it */
     /* frees and re-initializes the internal pointers to the lists of */
     /* 053 and 054 items. */

int print_052_list(/*     FILE *out_file,     li_052 *list_p */ );
     /* this function takes as its argument a pointer to a list of */
     /* blocketts 052 items, and then prints out to the out_file the */
     /* blocketts in SEED format. */


/* ************************************************************************ */

/* ************************************************************************ */

int init_li_st_053(/*     b_053_st *item */ );
/* This fucntion initializes a structure item if blockette 053. It */
/* returns SUCCESS or FAILURE */

int copy_li_053(/*     li_053 *dest_p,     li_053 *src_p */ );
/* This function copies a list of blockette 053 items. IT returns */
/* SUCCESS or FAILURE. it calls  copy_li_it_053() below. */

int copy_li_it_053(/*     b_053_st *dest_p,     b_053_st *src_p */ );
/* This function copies a list item of blockette 053. IT returns */
/* SUCCESS or FAILURE. */


int append_053_list(/*     li_053   *list_ptr,     b_053_st *new_item_ptr */ );
/* this function will add a new item to the end of the list of */
/* blockettes 053. */


int print_053_list(/*     FILE *out_file,     li_053 *list_ptr */ );
/* This fucntion prints out an entire list of blockette 053 items. It */
/* returns SUCCESS or FAILURE */

int print_053_li_it(/*     FILE *out_file,     b_053_st *item */ );
/* This function prints out one item of a list item of blockette 053. */
/* It returns SUCCESS or FAILURE */

int delete_list_053(/*     li_053 *list_ptr */ );
/* This function deletes all the elements in the list of blockette 053 */
/* items. It returns SUCCESS or FAILURE */


/* *********************************************************************** */

/************************************************************************* */

int init_li_st_054(/*     b_054_st *item */ );
/* This fucntion initializes a structure item if blockette 054. It */
/* returns SUCCESS or FAILURE */


int copy_li_054(/*     li_054 *dest_p,     li_054 *src_p */ );
/* This function copies a list of blockette 054 items. IT returns */
/* SUCCESS or FAILURE. it calls  copy_li_it_054() below. */


int copy_li_it_054 ( /*     b_054_st *dest_p,     b_054_st *src_p */ );
/* This function copies a list item of blockette 054. IT returns */
/* SUCCESS or FAILURE. */

int append_054_list(/*     li_054   *list_ptr,     b_054_st *new_item_ptr */ );
/* this function will add a new item to the end of the list of */
/* blockettes 054. */


int print_054_list(/*     FILE *out_file,     li_054 *list_ptr */ );
/* This function prints out one item of a list item of blockette 054. */
/* It returns SUCCESS or FAILURE */


int print_054_li_it(/*     FILE *out_file,     b_054_st *item */ );
/* This function prints out one item of a list item of blockette 054. */
/* It returns SUCCESS or FAILURE */


int delete_list_054(/*     li_054 *list_ptr */ );
/* This function deletes all the elements in the list of blockette 054 */
/* items. It returns SUCCESS or FAILURE */





/* ****************************************************************
 * This section holds the routines for blockette 030 items
 *
 */


int init_list_030( /*      char *master_dir */);
     /* This routine checks to see if a file witht he suggested file */
     /* name exists. If it does, then it attemps to read in any and */
     /* all blockette 030's . if the file does not yet exist, or there */
     /* are no blockette 030's in the file, then the list_ptr is left */
     /* as the NULL ptr. If there are blockette 030's in the file, */
     /* then the list_ptr consists of only the blockettes read in from */
     /* the file. This function returns the number of blockettes read. */

int lookup_b_030_i(/*
     li_030 **list_ptr,
     char *name,
     int data_type,
     int num_keys,
     char *keys[] */);
     /* this function takes a name/data_type pair and checks the currently */
     /* active b_030 list to see if that description exists yet.  If it */
     /* does not, that name/data pair is added to the list.  In either case */
     /* the function returns the lookup key of the name/data pair, or */
     /* FAILURE in case of error. */
     /* This function is called by the user. */

int print_li_030(/* li_030 *list_ptr,
		    FILE *f_p */);
/* this function prints out the entire list of blockette 030 items. */
/* it returns the number of blockettes printed, or FAILURE. */
/* This function is actually called by the user. */


int add_steim_blockette_030_list_item();
/* this function adds the steim data descriptor to the data format */
/* dictionary blockette. It returns the key within the data */


/* ****************************************************************
 * This section holds the routines for blockette 031 items
 *
 */


int init_list_031(/*     char *local_dir */);
     /* This routine checks to see if a file witht he suggested file */
     /* name exists. If it does, then it attemps to read in any and */
     /* all blockette 031's . if the file does not yet exist, or there */
     /* are no blockette 031's in the file, then the list_ptr is left */
     /* as the NULL ptr. If there are blockette 031's in the file, */
     /* then the list_ptr consists of only the blockettes read in from */
     /* the file. This function returns the number of blockettes read. */

int lookup_b_031_i(/*
		      li_031 **list_ptr,
		      char letter_code,
		      char *comment,
		      int unit_code */);
/* this function takes a letter_code/comment pair and checks the
   currently active b_031 list to see if that description exists
   yet.  If it does not, that letter_code/comment pair is added
   to the list. In either casethe function returns the lookup key
   of the letter_code/comment pair, or FAILURE in case of error.
   This function is called by the user. */

     
int print_li_031(/* li_031 *list_ptr,
		    FILE *f_p */);
/* this function prints out the entire list of blockette 031 items. */
/* it returns the number of blockettes printed, or FAILURE. */
/* This function is actually called by the user. */

int lookup_031(/*   char class_code,
		    char *comment_desc,
		    int unit_comment_level */);
/* this function takes a letter_code/comment pair and checks the
   currently active b_031 list to see if that description exists
   yet.  If it does not, that letter_code/comment pair is added
   to the list. In either casethe function returns the lookup key
   of the letter_code/comment pair, or FAILURE in case of error.
   This function is called by the user. */

     
int print_031(/* char *local_dir */);
/* this function prints out the entire list of blockette 031 items. */
/* it returns the number of blockettes printed, or FAILURE. */
/* This function is actually called by the user. */


/* ****************************************************************
 * This section holds the routines for blockette 033 items
 *
 */

int init_list_033(/*     char *master_dir */ );
/* This routine checks to see if a file witht he suggested file */
/* name exists. If it does, then it attemps to read in any and */
/* all blockette 033's . if the file does not yet exist, or there */
/* are no blockette 033's in the file, then the list_ptr is left */
/* as the NULL ptr. If there are blockette 033's in the file, */
/* then the list_ptr consists of only the blockettes read in from */
/* the file. This function returns the number of blockettes read. */

     
int lookup_b_033_i( /*     li_033 **list_ptr;
			   char *desc; */ );
/* this function takes a desc pair and checks the
   currently active b_033 list to see if that description exists
   yet.  If it does not, that desc pair is added
   to the list. In either casethe function returns the lookup key
   of the desc pair, or FAILURE in case of error.
   This function is called by the user. */
  


int print_b_033_i( /*     b_033_i *b_p;
			  FILE *f_p; */ );
			  
/* this function takes a pointer to a block structure item and prints */
/* the info out in the standard blockette form the the already opened */
/* file pointer.  It returns SUCCESS or FAILURE. */


/* ****************************************************************
 * This section holds the routines for blockette 034 items
 *
 */

int init_list_034( /*      char *master_dir */);
     /* This routine checks to see if a file witht he suggested file */
     /* name exists. If it does, then it attemps to read in any and */
     /* all blockette 034's . if the file does not yet exist, or there */
     /* are no blockette 034's in the file, then the list_ptr is left */
     /* as the NULL ptr. If there are blockette 034's in the file, */
     /* then the list_ptr consists of only the blockettes read in from */
     /* the file. This function returns the number of blockettes read. */

int lookup_b_034_i(/* li_034 *list_ptr,
		   char *name,
		   char *desc */);
/* this function takes a name/desc pair and checks the currently */
/* active b_034 list to see if that description exists yet.  If it */
/* does not, that name/desc pair is added to the list.  In either case */
/* the function returns the lookup key of the name/desc pair, or */
/* FAILURE in case of error. */
/* This function is called by the user. */


int print_li_034(/* li_034 *list_ptr,
		    FILE *f_p */);
/* this function prints out the entire list of blockette 034 items. */
/* it returns the number of blockettes printed, or FAILURE. */
/* This function is actually called by the user. */


/* what follows are the dummy routines to allow the user to add */
/* comments without explicitly maintaining the internal lists.  The */
/* lists are automatically maintained within the block.c program. */

int add_blockette_030_list_item(/* string, key, type*/);

int add_blockette_031_list_item(/* */);

int add_blockette_033_list_item(/*model, key */);

int add_blockette_034_list_item(/*key , units, string*/);


/* ****************************************************************
 * This section holds the routines for blockette 051 items
 *
 */

int add_b_051( /*     char *local_dir,
		      char *start_time,
		      char *end_time,
		      int code_key,
		      int comment_level; */ );
/* This routine allows the user to all at once. with this */
/* routine, the input file is opened, the list initialized, the */
/* current selection is read in and looked up, and if not present */
/* added to the list, and then the disk file (B052) is updated. */
/* It returns SUCCESS or FAILURE. */


#endif /* BLOCKETTE_FILE */
