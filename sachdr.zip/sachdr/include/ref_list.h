#include "epoch.h"

#ifdef SUDS
#ifndef SUDS_H
#include <suds.h>
#endif
#endif

typedef struct event_list_strct
{
  struct event_list_strct *prev;	/* Pointer to next event	*/
  Time	start_time;		/* Time of first sample		*/
  Time	trigger_time;		/* Trigger time			*/
  Epoch	start_epoch;		/* Epoch of event start time	*/
  Epoch	trigger_epoch;		/* Epoch of event trigger time	*/
  Epoch	last_epoch[6];		/* Epoch of previous DT block	*/
  char	filename[6][128];	/* Event file name		*/
  FILE	*fpout_d[6];		/* File Pointer			*/
  int	evt_cnt;		/* Event count			*/
  int	trig_type;		/* Trigger Type, needed for TML detection */
  int	inst_num;		/* Instrument number		*/
  short	evt_num;		/* Event number for this event	*/
  short   strm_num;		/* Stream number for this event	*/
  long    sam_cnt[6];		/* Sample count for this trace	*/
  long	last_samples[6];	/* Samples in last DT block	*/
  long	sequence_num;		/* Last Sequence number read 0=start */
  long	max[6];			/* Maximum sample for trace	*/
  long	min[6];			/* Minimum sample for trace	*/
  float	scale[6];		/* A/D volts/count		*/
  /*	long    wrt_smp[6];		   sample length		*/
  long	xn[6];			/* last Xn (Steim compression)	*/
  char	start_source;	/* Source of start time, D=DT, T=ET, H=EH */
  int 	eh_data_format;	/* the dataformat of the EH packet (TRUTH) */
  struct event_list_strct *next;	/* Pointer to next event	*/
#ifdef SUDS
  SUDS_STREAM        *suds_output[6]; /* SUDS file pointer */
#endif
} EventListItem;

typedef EventListItem *EventListPtr;
  
typedef struct strm_list_strct
{
  /*	Time	time;		*/	/* Time tag for parms		*/
  int	inst_num;		/* Instrument number		*/
  short	strm_num;		/* Stream number for this event	*/
  int	srate;			/* Sample rate for this stream	*/
  int	data_format;		/* 0xC0, 0x32, 0x16		*/
  int	channels[6];		/* Channel in stream (Boolean)	*/
  int	gain[6];		/* Gain for these channels	*/
#ifdef SUDS
  LABEL	sig_path_id[6];		/* id for signal.signal_path_id	*/
#endif
  /*	char	trigger_type[4];*/	/* Trigger type	(ASCII)		*/
  /*	long	file_length;	*/	/*  Used for file splitting	*/
	struct	strm_list_strct	*next;	/* Pointer to next event	*/
} StreamListItem;

typedef StreamListItem *StreamListPtr;

EventListPtr lookup_event();
void delete_event();
EventListPtr get_event_list();
StreamListPtr lookup_strm();
StreamListPtr get_strm_list();

