#include "sql_defines.h"
#include "sql_field_positions.h"

#define MAX_TABLE_NAME_SIZE	(20)
#define MAX_FIELDS	(50)
#define NUM_DATA_INIT	(20)
#define BUF_SIZE	(256)
#define LINE_BUF_SIZE	(1024)
#define RECORD_SEPARATOR	'\n'
#define FIELD_SEPARATOR		'\t'


#define PDBSTAT_NEW	(001)
#define PDBSTAT_INSERT	(002)
#define PDBSTAT_DELETE	(004)
#define PDBSTAT_ID_SYNC	(010)

#define PDB_NOTUSED (-1)

/* the following two typedefs are for the sql include file sql_tables.h */
typedef struct sql_field {
char *name;
char *type;
short utype;
} SQL_Field;

typedef struct sql_tab {
char    name[MAX_TABLE_NAME_SIZE];
SQL_Field fields[MAX_FIELDS];
int	num_fields;
}SQL_tab;


typedef union sql_field_data {
        int     ival;
        double  fval;
        char    *cval;
} SQL_Field_Data;

typedef union sql_field_data **SQL_Field_Data_Array;

typedef struct tab_info {
	int	num_alloc_ptrs;				/* number of allocated records */
	int	next_free_record;			/* next unused record */
	short	used;					/* is this table used? */
	short	used_field[MAX_FIELDS];			/* is this field used? */
	short	**record_status;			/* how is this record to be used? see PDBSTAT */
	int	**table_set;				/* Which table set is this record from? */
	SQL_Field_Data_Array	field[MAX_FIELDS];	/* Data from field[Fieldname][Record]->union */
} Table;

int alloc_status();
int alloc_table_set();
int alloc_union();
