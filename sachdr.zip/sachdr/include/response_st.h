#ifndef RESPONSE_ST
#define RESPONSE_ST

#include "response.h"


int free_response_internals( /* instrument_resp_item *resp */);
/* this function is passed a pointer to a response structure and it */
/* frees all memory that has been allocated to the internal pointers */
/* of the response structure.  This does not free the memory that may */
/* have been directly allocated to the structure itself; that */
/* ***MUST*** be done elsewhere.  */
/* This returns SUCCESS on success, FAILURE otherwise. */
/* FAILURE may merely mean that the programmer tried to free already */
/* free'ed memory */

int free_response_struct_ptr( /* instrument_resp_item *resp */);
/* This function has the ability to free all associate memory held by */
/* a response structure.  This function is passed a pointer to the */
/* structure, and then this function calls free_response_internals(); */
/* to free up all the memory pointed to by the structure's internal */
/* pointers.  Then this function frees up the memory pointed to by the */
/* structure pointer (resp) itself.  This function should **NOT** be */
/* used if the programmer has merely declared the structure, and not a */
/* pointer to the structure, rather s/he whould call */
/* free_response_internals() directly. */
/* This returns SUCCESS on success, FAILURE otherwise. */
/* FAILURE may merely mean that the programmer tried to free already */
/* free'ed memory */





/* int init_inst_resp( instrument_resp_item *resp */
/* this function takes the address of a instrument response item and */
/* initializes it fields.  It returns SUCCESS or FAILURE */

/* int init_block_resp( blockette_resp_item *resp */
/* this function takes the address of a blockette response item and */
/* initializes it fields.  It returns SUCCESS or FAILURE */


int copy_resp_item( /* instrument_resp_item *dest_resp, */
		    /* instrument_resp_item *src_resp */);
/* this function will copy the contents of one instrument_resp_itme to */
/* another.  If any memory is already allocated for the dest_resp, it */
/* will be free'd, and any needed new memeory will be allocated. */
/* this function assumes that the dest_resp was declared as an */
/* instrument_resp_item, not as a pointer to a instrument_resp_item. */
/* This function returns SUCCESS or FAILURE */


int write_ascii_response(/* instrument_resp_item resp, FILE out */);
/* this routine is used to write the response structure out in the */
/* form desired by CSS.  It returns SUCCESS of FAILURE */

int read_ascii_response(/* char** text_ar, instrument_resp_item *resp */);
/* this routine is used to parse the response information out of an */
/* array of strings.  This routine assumes that the array of strings */
/* (each line's length is 80 chars, maximum), is in the form used by */
/* CSS.  If you are starting with a file in this form, you should use */
/* "read_text_file();"  to read the file into an array of this form. */
/* This function returns SUCCESS of FAILURE */


int read_text_file(/*char ***  text_ar,  char *file_name */ );
/* this routine opens an ascii file and reads the entire file into an */
/* array of strings of length 80.  It returns SUCCESS or FAILURE */



int read_hex_fir( /*
		     FILE *file,
		     instrument_resp_item *resp */ );
/* This function reads in a FIR filter in Jim Fowler's HEX format */
/* (REFTEK) and converts that input into passcals internal data base */
/* format.  It returns SUCCESS or FAILURE. */


void get_short_file_name( /*
			 char *filter_name,
			 char *file_name */ );
/* this function take the entire path name to a file, and returns the */
/* filename without the full path. */



#endif
