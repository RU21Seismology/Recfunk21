#ifndef BLOCKETTE_054
#define BLOCKETTE_054

#include "block_057.h"
#include "block_058.h"



typedef struct block_054 {
  char     stage_type;            /* For FIR response -
				     A = Analog (rad/sec)
				     B = Analog (Hz)
				     C = Composite
				     D = Digital */
  int      seq_number;            /* assuming a multi-stage filter, */
				  /* which one is this? */
  int      sig_in_units;          /* signal input units */
  int      sig_out_units;         /* signal output units */
  int      num_num;               /* number of numerators */
  double  *num;                   /* numerator coefficient */
  double  *num_er;                /* numerator coefficient error */
  int      num_denom;             /* number of denominators */
  double  *denom;                 /* denominator coeffiencient */
  double  *denom_er;              /* denominator coeffiencient error */
} b_054_i ;





/* a real blockette 054 needs 057's and 058's to be described */
typedef struct blk_it_054 {
  b_054_i b_054;
  b_057_i b_057;
  b_058_i b_058;
} b_054_st;

typedef struct list_item_054 {
  b_054_st st_054;
  struct list_item_054 *next;
} li_054;

typedef li_054 *b_054_lp;



int    init_blk_054( /*     b_054_i *blk_p*/);
/* this function initializes blockette 054.  it returns SUCCESS or */
/* FAILURE */


int copy_blk_054(/*     b_054_i *dest_p,     b_054_i *src_p */ );
/* This function copys one blockette 054 to another one.  IT returns */
/* SUCCESS or FAILURE. */

int   write_blk_054(/*     FILE *out_file,     b_054_i *blk_p */ );
/* This function returns SUCCESS or FAILURE or EMPTY (where */
/* EMPTY>SUCCESS). This function writes out the blockette to the */
/* out_file */ 


int  delete_blk_054(/*     b_054_i *blk_p */ );
/* not needed */

int  free_blk_054(/*     b_054_i *blk_p */ );
/* this function frees up the internal memory of a blockette 054. it */
/* returns SUCCESS or FAILURE */


/************************************************************************* */

int init_li_st_054(/*     b_054_st *item */ );
/* This fucntion initializes a structure item if blockette 054. It */
/* returns SUCCESS or FAILURE */


int copy_li_054(/*     li_054 *dest_p,     li_054 *src_p */ );
/* This function copies a list of blockette 054 items. IT returns */
/* SUCCESS or FAILURE. it calls  copy_li_it_054() below. */


int copy_li_it_054 ( /*     b_054_st *dest_p,     b_054_st *src_p */ );
/* This function copies a list item of blockette 054. IT returns */
/* SUCCESS or FAILURE. */

int append_054_list(/*     li_054   *list_ptr,     b_054_st *new_item_ptr */ );
/* this function will add a new item to the end of the list of */
/* blockettes 054. */


int print_054_list(/*     FILE *out_file,     li_054 *list_ptr */ );
/* This function prints out one item of a list item of blockette 054. */
/* It returns SUCCESS or FAILURE */


int print_054_li_it(/*     FILE *out_file,     b_054_st *item */ );
/* This function prints out one item of a list item of blockette 054. */
/* It returns SUCCESS or FAILURE */


int delete_list_054(/*     li_054 *list_ptr */ );
/* This function deletes all the elements in the list of blockette 054 */
/* items. It returns SUCCESS or FAILURE */




#endif
