#ifndef __WRITE_TAR__H__
#define __WRITE_TAR__H__

/*
   These functions allow one to write tar files from within a c program,
   sithout having to write all files at once, and without having to
   constantly rewind and rewrite a tar volume.
   
   There is one fucntion to open a tar file, another function to take a
   file from disk and write it onto the tar volume, and a 3rd function to
   close the tar file when you are finished.
   
   In reality there are two ways to write a file to tape.  The first will
   provide for the extracted file to have the same path/name as the
   original file, and the second fucntion allows the programmer to rename
   the file within the tar file.  This is useful when the disk files are
   on a scratch disk, but the user really desires a file system within
   the tar volume.
   */

/* the block size used is 512, and the group size used is 16. */

#define SIDGROUPSIZE 16
#define SIDTBLOCK 512

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef SUCCESS
#define SUCCESS 0
#endif

#ifndef FAILURE
#define FAILURE -1
#endif


int open_tar_file(/*     char *file_name */ );
/* This function opens a file for writing.  The specified tar file may */
/* be a simple file, or it may be tape device.  This function returns */
/* 0 on success, and -1 on failure. */

int close_tar_file();
/* this function writes the neccessary EOF blocks at the end of the */
/* tar volume, and then it closes the file. This function returns 0 on */
/* success, of EOF on failure. It is very important that this fucntion */
/* be used, otherwise the tar EOF blocks will never be written to the */
/* tar volume. */

int write_file_to_tar(/* char *ifile_name */ );
/* This function writes a file into the tar volume that has already */
/* been opened with open_tar_file().  This function will open the file */
/* "ifile_name, and write the info from that file into the tar file. */
/* This function returns 0 on success, -1 on failure. */

int write_file_path_to_tar(/* char *ifile_name,
			      char *intar_file_name */ );
/* This function writes a file into the tar volume that has already */
/* been opened with open_tar_file().  This function will open the file */
/* "ifile_name, and write the info from that file into the tar file, */
/* using the name "intar_file_name".  In other words, the extracted */
/* file with have the new name. This function returns 0 on success, -1 */
/* on failure. */



#endif
