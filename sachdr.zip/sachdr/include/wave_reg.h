char *	regular_open();
int 	regular_rewind();
int	regular_free();
int     regular_pass();
int 	regular_close();
