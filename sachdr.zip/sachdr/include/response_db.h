#ifndef RESPONSE_DB
#define RESPONSE_DB


#include "response.h"

int diff_response(/*instrument_resp_item *resp1, 
		    instrument_resp_item *resp2*/);
     /* returns 0 if they are the same, returns 1 otherwise */

int add_response2db();
/* this function takes the current database, and adds one attribute to */
/* the sensor class (response_id = int4) and adds one entire class to */
/* the database, (response). */
/* *** This need only be used ONCE, to update an OLD database *** */
/* This returns SUCCESS on success, FAILURE otherwise. */

int create_response(/* int new_response_id,
		       instrument_resp_item resp */ );
/* This function takes as its arguments an unused response_id and a */
/* response structure.  The response structure actually holds the */
/* response id.  whenthis routine is called if resp.response_id == */
/* new_response_id, then only the structure is written to the new */
/* class item.  IF the two integers are different, then after the */
/* structure is written, then the response_id attribute is rewritten */
/* to the database. */
/* This returns SUCCESS on success, FAILURE otherwise. */

int read_response_by_name_no_all( /* char *response_name,
		      instrument_resp_item *resp */ );
/* this function read a response record out of the database and fills */
/* a repsonse structure.  This funtions queries the database for the */
/* FIRST record with the correct response_name.  Then this function */
/* fills the structure of instrument_resp_item *resp.  This routine */
/* assumes that the user has declared only a pointer to a structure. */
/* This routine will allocate all memory needed.  The user should/must */
/* use the routine free_response_record() to free the entire */
/* strcutures memory, in order to ensure that the structures internal */
/* pointers to allocated memory are free'ed.  This helps to minimize */
/* memory leaks. */
/* this is similar to read_response_by_name_all(), but it does not
   allocate space. */
/* This returns => SUCCESS on success, FAILURE otherwise. */

int read_response_by_name_all( /* char *response_name,
		      instrument_resp_item **resp */ );
/* this function read a response record out of the database and fills */
/* a repsonse structure.  This funtions queries the database for the */
/* FIRST record with the correct response_name.  Then it allocates */
/* spec to store the response int. Then this function */
/* fills the structure of instrument_resp_item *resp.  This routine */
/* assumes that the user has declared only a pointer to a structure. */
/* This routine will allocate all memory needed.  The user should/must */
/* use the routine free_response_record() to free the entire */
/* strcutures memory, in order to ensure that the structures internal */
/* pointers to allocated memory are free'ed.  This helps to minimize */
/* memory leaks. */
/* this is similar to read_response_by_name_no_all(), but it does
   allocate space. */
/* This returns => SUCCESS on success, FAILURE otherwise. */

int read_response_by_id( /* int response_id,
		      instrument_resp_item **resp */ );
/* this function read a response record out of the database and fills */
/* a repsonse structure.  This funtions queries the database for the */
/* FIRST record with the correct response_id.  Then this function */
/* fills the structure of instrument_resp_item *resp.  This routine */
/* assumes that the user has declared only a pointer to a structure. */
/* This routine will allocate all memory needed.  The user should/must */
/* use the routine free_response_record() to free the entire */
/* strcutures memory, in order to ensure that the structures internal */
/* pointers to allocated memory are free'ed.  This helps to minimize */
/* memory leaks. */
/* This returns => SUCCESS on success, FAILURE otherwise. */

int read_response_by_id_no_all( /* int response_id,
		      instrument_resp_item *resp */ );
/* this function read a response record out of the database and fills */
/* a repsonse structure.  This funtions queries the database for the */
/* FIRST record with the correct response_id.  Then this function */
/* fills the structure of instrument_resp_item *resp.  This routine */
/* assumes that the user has already declared a structure. */
/* This routine will allocate NO memory.  
/* This returns => SUCCESS on success, FAILURE otherwise. */


int get_response_id();
/* This function checks the key file, and returns the next available */
/* response_id.  It returns SUCCESS */ 




int read_experiment( /*
     int d_site_id,
     experiment_item *exp */); 
/* this function takes as an arg the site_id and a pointer to */
/* allocated space for an experiemtn structure, and returns the */
/* experiement info for that site_id.  This function returns the */
/* number of experiment_items found, or 0 on FAILURE.*/
/* it only returns one experiment item, even if more are found.  This */
/* should be changed. */


int read_site( /*
     int d_site_id,
     site_item *site */);
/* this function takes as an arg the site_id and a pointer to */
/* allocated space for a site structure, and returns the */
/* site info for that site_id.  This function returns the */
/* number of site_items found, or 0 on FAILURE.*/
/* it only returns one site item, even if more are found.  This */
/* should be changed. */


int site_time_limits( /*
     int d_site_id,
     char *min_time,
     chat *max_time */ );
/* This function takes a site_id, and finds the maximum and minimum */
/* times that this id was valid. it returns the total number of */
/* configurations with this site id.*/



int read_config( /*
     int d_site_id,
     int d_start_epoch,
     int d_end_epoch,
     int d_data_stream_id,
     config_item *d_config */ );
/* this function returns a certain configuration item, based upon a */
/* given site_id, time range (start and stop epochs) and a */
/* data_stream_id.  This function returns the number of configurations */
/* that fit this description.  This function assumes that the d_config */
/* pointer points to allocated memory large enough to hold ALL the */
/* configuration found. (i.e. an array of config_items. */


int read_num_of_config( /* 
     int d_site_id,
     int d_start_epoch,
     int d_end_epoch,
     int d_data_stream_id */);
/* this function take the same args as the above function, except that */
/* it does not return the config info, just the number of items found. */
/* The user may use this info for allocating space before calling read */
/* config.  This function returns the number of items found, with zero */
/* being none found. */



int read_data_stream(  /*
     int d_data_stream_id,
     ds_item *d_ds */ );
/* this function takes as its arguments a data_stream_id and a pointer */
/* to a data stream item (or an array of such items)  IT fills the */
/* item (or items) , ans returns the number of items found (zero is a */
/* valid number) */


int read_num_of_ds( /* 
     int d_data_stream_id */ );
/* This function takes a data_stream_id and returns the number of */
/* items that have this id.  The user may use this info for allocating */
/* space before calling read_data_stream. This function returns the */
/* number of items found, with zero being valid. */



int read_channel_id( /*
     int  *chan_id,
     int   d_config_id */ );
/* This function takes a config_id , and returns the channel_id for */
/* that configuration in chan_id (or the channel_id's if more than one */
/* is found.  In this case the function assumes the the chan_id */
/* pointer points to an array of ints .  The return value is the */
/* number of channel_id's found/returned. */

 


int read_channel(/*
     ch_item  *d_ch_item,
     int       d_channel_id */ );
/* This function takes a channel id and returns a channel item in */
/* d_ch_item (may be an array). The return value is the number of */
/* items found in the data base. */
    

int read_sensor_id( /* 
     int      *d_sensor_id,
     int       d_channel_id,
     int       ar_size */ );
/* this function takes a channel_id and returns a sensor_id int he */
/* d_sensor_id.  The ar_size holds the number of sensor_id elements */
/* that have been allocated, ensureing that this fucntion will not */
/* write into unallocated space. The fuction returns the number of */
/* items found. */



int read_sensor( /* 
     sensor_item      *d_sensor_p,
     int               d_sensor_id,
     int               ar_size */ );
/* this function take sensor_id and a pointer to an array of sensor */
/* items where the array size is ar_size.  The function will fill the */
/* array until no more items are found, or until the array is full. */
/* The function returns the number of sensor items found. (not */
/* the number of items returned in d_sensor_p, if ar_size was too */
/* small. */




int read_response_id_from_str( /*
     int      *d_response_id;
     char     *d_response_str */ );
     /* This function returns the LAST found response_id that has the */
     /* supplied name.  The return value is the total number of */
     /* id_found with this name. */


int read_response_id_by_sensor( /*
     int      *d_response_id,
     int       d_sensor_id,
     int       ar_size*/ );
/* This function takes a sensor_id and returns a response_id(s) in */
/* d_response_id (may be an array).  This function will assume the */
/* d_response_id is an array of size ar_size.  The function will write */
/* response_id's into the d_response_id array until no more items are */
/* found, or the array if full.  The function returns the number of */
/* items foudn, not the number returned. */



int read_response_id_by_instr_and_chan( /*
     int      *d_response_id;
     int       d_das_num;
     int       chan_num;
     int       ar_size; */ );
/* This function takes a das_number and a channel_number and returns a */
/* list of the reponse id's that apply to this das and channel.  This */
/* may be only one response (which is normal for the 16 bit ADCs, or */
/* a larger number (such as 6 for the 24 bit ADCs).  The variable */
/* d_response_id is a pointer to an array of size ar_size integers in */
/* which the response_id list is returned.  The list will hold a */
/* maximum of ar_size elements.  the return value is the total number */
/* of response-id's found that match the input parameters. If more
   than ar_size response_ids were found, the total number returns is
   ar_size, which may be compared to the return value to see if a
   discrepancy exists. The funtion return -1 on a real error, and 0 if
   none were found. */


int read_response_id_by_ds_and_upl( /*
     int      *d_response_id;
     int       d_data_stream;
     int       upload_num;
     int       ar_size; */ );
/* This function takes a das_number and a channel_number and returns a */
/* list of the reponse id's that apply to this das and channel.  This */
/* may be only one response (which is normal for the 16 bit ADCs, or */
/* a larger number (such as 6 for the 24 bit ADCs).  The variable */
/* d_response_id is a pointer to an array of size ar_size integers in */
/* which the response_id list is returned.  The list will hold a */
/* maximum of ar_size elements.  the return value is the total number */
/* of response-id's found that match the input parameters. If more
   than ar_size response_ids were found, the total number returns is
   ar_size, which may be compared to the return value to see if a
   discrepancy exists. The funtion return -1 on a real error, and 0 if
   none were found. */


int read_response_id_by_instrument( /*
     int      *d_response_id,
     int       d_das_num,
     int       ar_size*/ );
/* This function takes a das number and returns a response_id(s) in */
/* d_response_id (may be an array).  This function will assume the */
/* d_response_id is an array of size ar_size.  The function will write */
/* response_id's into the d_response_id array until no more items are */
/* found, or the array if full.  The function returns the number of */
/* items foudn, not the number returned. This is how the anit-aliasing */
/* filter is read in.*/



int get_raw_data_size( /*int site_id, start_time */);
/* This function takes a stie id and a starttime, and then looks up
   the upload command line and if it is segy2mseed, returns 1024, else
   it reutrns 4096 */



#endif
