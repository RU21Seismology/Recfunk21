/* Public header file for epoch.c	*/

#ifndef EPOCH_H
#define EPOCH_H

typedef struct time_type {
	int year;	/* year         */
        int day;	/* day          */
        int hour;	/* hour         */
        int min;	/* minute       */
        int sec;	/* second       */
        int msec;	/* millisecond - NOTE, not always used (see clockview) */
        int usec;	/* microsecond  */
} Time;

typedef struct epoch_type {
	int	sec;
	int	usec;
} Epoch;

#if __STDC__ || defined(__cplusplus)
#define P_(s) s
#else
#define P_(s) ()
#endif

/* epoch.c */
void epoch2gmt P_((Time *time, Epoch *epoch, int leap_sec));
void gmt2epoch P_((Epoch *epoch, Time *time, int leap_sec));
Epoch add_epoch P_((Epoch *epoch1, Epoch *epoch2));
Epoch subtract_epoch P_((Epoch *epoch1, Epoch *epoch2));
int compare_epoch P_((Epoch *epoch1, Epoch *epoch2));
int epoch2msec P_((int *msec, Epoch *epoch));
double epoch2double P_((Epoch *epoch));
Epoch double2epoch P_((double depoch));
char *gmt2str P_((Epoch *epoch));

#undef P_

#endif /* EPOCH_H */
