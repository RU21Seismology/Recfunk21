
        /* write out preamble info */
        /*      START-OF-DATA FLAG#define (LONG)
                CHANNEL (LONG),
                EPOCH (LONG),
                MSEC  (LONG),
                SRATE (LONG),
                DATAFORM (LONG 0x16 or 0x32),
                SAMPLES (LONG),
                Data..... integers 
        */

typedef struct ref_data {
		long 	magic;
		long	channel;
		long	epoch;
		long 	msec;
		long	srate;
		long	data_format;
		long	samples;
		char * data;
} REFDATA;

/* number of non-data members */
#define REF_DATA_MEMBERS 7
#define REF_DATA_HEADER_SIZE (REF_DATA_MEMBERS*sizeof(long))
