#ifndef _REF_DT__H_
#define _REF_DT__H_

typedef struct dt_packet_info {
  
  unsigned int chn_num;		/* channel number - 1 */
  unsigned int evt_num;		/* event number */
  unsigned int strm_num;	/* strm_number  - 1 */
  unsigned int num_samples;	/* num samps this packet */
  unsigned int do_data;		/* flag to actually write out data file */
  unsigned int  data_format;	/* data format in hex 32 , 16, c0 */
  int year;                       /* Year in 2 digit BCD */
  int time_day;                   /* 12 digit BCD DDDHHMMSSTHS */
  int time_hr;
  int time_min;
  int time_sec;
  int time_frac;
  int unit_id;                    /* instrument Number in 4 digit BCD */
  int seq_num;                    /* Packet Sequence Number in 4 digit BCD */
  int oldinstr;			/* previous instrument */
  int correct_instrument;

} DT_PK_INFO;


#endif
