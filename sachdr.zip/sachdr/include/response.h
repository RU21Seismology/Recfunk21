#ifndef RESPONSE_FILE
#define RESPONSE_FILE

#include <stdio.h>
#include <errno.h>

/*
   #ifndef BLOCKETTE_FILE
   #include "block.h"
   #endif
   */

#ifndef DEF_REC_LEN
#define DEF_REC_LEN 12          /* 4096 = 2^^12 */
#endif
 

#ifndef SUCCESS
#define EMPTY 1
#define SUCCESS 0
#define FAILURE -1
#define TRUE 1
#define FALSE 0
#endif


/* the length of blocks represented as 2**n, 
   10 is 2**10 = 1024, 12 is 2**12 = 4096 */
#define RAW_SEGY_BLOCK_LEN 12
#define RAW_MSEED_BLOCK_LEN 10

#define MAX_COMMENT_SIZE 1200 /* 15 lines by 80 chars */

#define PAZ_NORM_FREQ 5.0


/* These next line are VERY IMPORTANT if you want hte units of the
   various responses to work out correctly. To completely handle the
   addition of new responses, see various defines in response.h and
   get_units(); in response_con.c and the structure unit_mapping in
   init_response.c */

#define COUNTS 1 /*            used for input and output units */
#define VOLTS  2 /*            used for input and output units */
#define MPS    3 /* meters/sec used for input and output units */
#define VMS  4 /* volts/meters/sec used for input and output units */
#define MSS  5 /* meter/sec**2 for acceleration */
#define DIS  6 /* meters for displacement */

struct units {
  char    name[80];
};

/* extern struct unit_mapping; */

#define UNIT_NUM (sizeof unit_mapping / sizeof(struct units))
/*#define UNIT_NUM 7*/
#define UNIT_COUNTS (1)   /* index into unit_mapping for counts code */
#define UNIT_VOLTS (2)   /* index into unit_mapping for volts code */
#define UNIT_MPS (3)   /* index into unit_mapping for mps code */
#define UNIT_VMS (4)   /* index into unit_mapping for v/m/s code */
#define UNIT_MSS (5) /* meter/sec**2 for acceleration */
#define UNIT_DIS (6) /* meters for displacement */



#define FACTORY 1
#define CALIBRATED 2

#define UNKNOWN 0
#define PAZ 1
#define FIR 2

/*
   extern int C_equals_stuff;
   extern int C_num_size;
   extern int C_string_size;
   extern int C_num_arrays;
   
   extern int C_num_ints_and_doubles;
   extern int C_num_char80_ars;
   
   */
#include "block_030.h"
#include "block_031.h"
#include "block_033.h"
#include "block_034.h"
#include "block_051.h"

extern li_030  *list_030;
extern li_031  *list_031;
extern li_033  *list_033;
extern li_034  *list_034;
extern li_051  *list_051;


typedef struct station {
  char   station_name[5];      /* Station call letters  */
  double latitude;             /* earth latitude (deg) (+=N -=S)  */
  double longitude;            /* earth longitude (deg) (+=E -=W)  */
  double elevation;            /* ground level (meters)  */
  int    num_channels;         /* optional,num of channels that follow  */
  int    num_station_comments; /* num of station comment blockette(51)  */
  char   site_name[61];        /* station site, (town, state, country etc  */
  int    network_id;           /* lookup code for blockette 33  */
  int    _32_bit_word_order;    /* i.e. 0123, 3210, for headers, for */
			       /* data, see data format dictionary  */
  int    _16_bit_word_order;    /* 01, 10, as above  */
  char   start_date[23];       /* earliest date that header info is correct*/
  char   end_date[23];         /* last date info correct, 0 = still ok  */
  char   update_flag;          /* to what the data update records refer  */
  char   network_code[3];      /* network operator responsible for the */
			       /* data logger, assigned by IRIS. */
  
} station_item;

typedef struct channel {
  char   location[3];     /* site within an array */
  char   channel[4];      /* standard channel id */
  int    sub_channel;     /* for multiplexed data */
  int    instrument;      /* lookup index from blockette 33 */
  char   comment[31];     /* optional comment */
  int    resp_units;      /* unit lookup key in blockette 34 */
  int    cal_units;       /* unit lookup key in blockette 34 */
  double latitude;        /* for instrument, can differ from station (deg) */
  double longitude;       /* for instrument, can differ from station (deg) */
  double elevation;       /* for instrument (not ground) (meters) */
  double depth;           /* instrument depth below ground */
  double azimuth;         /* in degrees from north, clockwise */
  double dip;             /* in degrees, down from horizontal */
  int    data_format;     /* lookup index from blockette 30 */
  int    data_record_len; /* in bytes,256-4096, store as n where 2**n */
  double sample_rate;     /* nominal sample rate (Hz) for digitzer */
  double max_clock_drift; /* NUM of samples * tolerance (sec/sample) */
  int    num_comments;    /* num of channel comment blockettes(59) */
			  /* that follow */
  char   chan_flags[27];  /* channel type flags */
  char   start_date[23];  /* earliest known date data was correct this */
			  /* blockette */
  char   end_date[23];    /* last date info was correct, zero=time of */
			  /* this blockettes creation */
  char   update_flag;     /* what data the update records refer to. */
} channel_item;

typedef struct response {
  int      response_id;           /* key for cross reference with sensor */
                                  /* char inst_resp[80];  */
  char    *response_info_string;  /* first line of ascii file*/
  char     header_line[80];       /* first non-comment line */
  /*  char     com[15][80]; */
  char    *com; 
  int      resp_type;             /* PAZ, FIR, IIR, etc. see #defines */
  int      seq_number;            /* assuming a multi-stage filter, */
				  /* which one is this? */
  char     stage_type;            /* for PAZ response - 
				     A = Laplace tranform
				     B = Analog (rads/sec or Hz)
				     C = composite(used?) 
				     D = digital,*/
                                  /* For FIR response -
				     A = Analog (rad/sec)
				     B = Analog (Hz)
				     C = Composite
				     D = Digital */
  int      source_type;           /* perhaps obsolete due to */
				  /* stage_type? */
				  /* (0)Laplace tranform, (1)analog (rads/sec */
				  /* or Hz), (2)composite(used?), (3)digital,*/
  int      sig_in_units;          /* signal input units */
  int      sig_out_units;         /* signal output units */
  int      cal_source;            /* calibration information source */
                                  /* i.e. FACTORY or CALIBRATED */
  int      time;                  /* epoch time of calibration */
  double   gain;                  /* instrument gain */
  double   a_zero;                /* A0 term/normalization factor */
  double   norm_freq;             /* frequency at which A0 is normailized */
  int      num_poles;             /* poles array size/number of poles */
  double  *p_real;                /* real part of pole */
  double  *p_imag;                /* imaginary part of pole */
  double  *p_real_er;             /* pole real part error */
  double  *p_imag_er;             /* pole imaginary part error */
  int      num_zeros;             /* zeros array size/number of zeros */
  double  *z_real;                /* real part of zero */
  double  *z_imag;                /* imaginary part of zero */
  double  *z_real_er;             /* zero real part error */
  double  *z_imag_er;             /* zero imaginary part error */
  char     response_name[20];     /* that actual name of the filter */
  int      decimation_factor;     /* one sample out/this */
                                  /* number in */
  int      decimation_offset;     /* which sample out of the */
				  /* decimation factor is used */
  double   corner_period;         /* corner period for sensor */
  char     seed_inst_type;        /* seed instrument type character */
  char     model_type[20];            /* seed instrument type character */
} instrument_resp_item ;    
/* if this strcutre is used to store a FIR filter response, then the */
/* poles will correspond to the numerators (with the imaginary and */
/* imaginary error parts empty), likewise, the zeros array will */
/* correspond to the denominators, with the imaginary part empty. */

/* the following structure contains all the information needed in */
/* order to write one of the SEED blockettes (#'s 53,54,or 57).  There */
/* may be some ancillary information needed that is not in the */
/* standard 'instrument_resp_item', so this new structure includes the */
/* 'instrument_resp_item', in addition to being able to contain other */
/* information. */


typedef struct sense_gain {
  
  /*  int     seq_number;   stage sequence number */
  double  sense_gain;   /* sensitivity/gain value */
  double  freq;         /* frequency (Hz) */
  int     num_hist;     /* number of history values */
  double *sense_list;   /* sensitivity for calibration */
  double *freq_list;    /* Freqency of calibration */
  char    cal_time[23]; /* time of calibration */
  
} sense_gain_item;




typedef struct blockette_response {
  instrument_resp_item inst_resp;         /* the basic stuff from DB */
  sense_gain_item      sense_gain;        /* the sensitivy and gain */
					  /* info */
  double               input_sample_rate; /* samples per second */
  double               delay;             /* estimated pure delay for */
					  /* the state. */
  double               correction;        /* time shift applied to the */
					  /* time tag due to delay at */
					  /* this stage of the filter */
} blockette_resp_item;

/* The following code defines a list of blockette response items. */
/* This list will be filled based upon queries to the database.  When */
/* the list is complete it will be turned into the seed blockette */
/* form. */
typedef struct response_list {
  blockette_resp_item item;
  struct response_list *next;
} resp_item_list;


typedef struct experiment_store_item {
  int ex_num;
  char network_id[3];
  char name[80];
  char description[80];
  char pi[80];
  char institution[80];
  int start_year;
  int start_jday;
  int start_hrmn;
  double X_coord;
  double Y_coord;
  double elevation;
  char coor_unit[4];
  char projection[8];
} experiment_item;

typedef struct site_store_item {
  int site_id;
  int site_number;
  char site_name[6];
  char long_name[80];
  double X_coord;
  double Y_coord;
  double elevation;
  char coor_unit[4];
  char projection[8];
  int deployment_num;
} site_item;

typedef struct config_store_item {
  int config_id;
  int channel_id;
  int das_number;
  int data_stream_id;
  int site_id;
  int channel_number;
  int upload_number;
  int data_stream_number;
  int start_year;
  int start_jday;
  int start_hrmn;
  int start_sec;
  int start_epoch;
  int end_year;
  int end_jday;
  int end_hrmn;
  int end_sec;
  int end_epoch;
} config_item;

typedef struct ds_store_item {
  int  data_stream_id;
  char name[25];
  int  data_stream_num;
  char channels_list[7];
  char trigger_type[5];
  int  data_format;
  int  sample_rate;
  int  trigger_id;
} ds_item;

typedef struct channel_store_item {
  int    channel_id;
  int    number;
  char   name[5];
  int    preamp_gain;
  char   gain_unit;
  double counts_to_volts;
  double azimuth;
  double dip;
  char   polarity;
  int    das_number;
  int    sensor_id;
} ch_item;


typedef struct sensor_store_item {
  int    sensor_id;
  char   serial_number[17];
  char   model_type[17];
  char   output_channel[4];
  double sensitivity;
  char   sens_unit[17];
  char   response_file[256];
  char   comment[80];
} sensor_item;


typedef struct filt_args_list {
  int ds;                       /* data stream number */
  int ds_id;                    /* data stream id */
  int samp_rate;                /* sample rate */
  char channels_list[8];        /* active channel list, i.e. 456 */
  int num_filts;                /* the number of filters for this ds */
  char filt_names[80][12];      /* the names of the filters, in order */
  int dec_list[100];            /* the decimation factors of the */
				/* filters, in order */
				   
} filt_args;


#endif /* RESPONSE_FILE */
