/************************ segy_io.h *******************************/
/* segy_io.h:	Include file for segy_io.c, a suite of functions to */
/* help reading and writing those annoying, redundant SEGY header */
/* variables and for reading/writing to/from SEGY files.          */
/******************************************************************/

#ifndef SEGY_IO_H
#define SEGY_IO_H

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#include "segy.h"
#ifndef MAIN
#define EXTERN extern
#else
#define EXTERN 
#endif
EXTERN int swap_to_native;

#ifndef ANSI_C	/* NON-ANSI prototyping  */

/*********************** delta_rd() *******************************/
/*     Returns Sample Interval in (int) Milliseconds or FALSE    */

int delta_rd( /* SEGYHEAD *hdr  */ );

/*********************** delta_wr() *******************************/
/* Properly writes Sample Interval (delta) into SegyHead (hdr)    */
/*          Returns TRUE on success, FALSE otherwise              */

int delta_wr( /*SEGYHEAD *hdr, int delta  */ );

/************************ samp_rd() *******************************/
/*   Returns Number of Sample in SegyHead (hdr), FALSE otherwise  */

int samp_rd( /* SEGYHEAD *hdr  */ );

/************************ samp_wr() *******************************/
/*       Properly writes Number of Sample in SegyHead (hdr)       */
/*              Returns TRUE on success, FALSE otherwise          */

int  samp_wr( /* SEGYHEAD *hdr, int samp  */ );

/************************ s_passcal_etoh() *******************************/
/*    Converts epoch and writes START time stamp to SegyHead (hdr)     */
/*              Returns TRUE on success, FALSE otherwise         */

int s_passcal_etoh( /* SEGYHEAD *hdr, double epoch  */ );

/************************ t_etoh() *******************************/
/*    Converts epoch and writes TRIGGER time stamp to SegyHead (hdr)     */
/*              Returns TRUE on success, FALSE otherwise         */

int t_passcal_etoh( /* SEGYHEAD *hdr, double epoch  */ );

/************************ s_passcal_htoe() *******************************/
/*         Returns START epoch time in (int) seconds or FALSE         */

int s_passcal_htoe( /* SEGYHEAD *hdr  */ );

/************************ s_passcal_htoe() *******************************/
/*         Returns TRIGGER epoch time in (int) seconds or FALSE         */
int t_passcal_htoe( /* SEGYHEAD *hdr  */ );

/************************ get_segy_record() **************************/
/* Returns TRUE on success, FALSE otherwise                          */

int get_segy_record(/* (char *) filename, head_ptr, data_ptr */);

/************************ get_segy_header() **************************/
/* Returns a SEGY header structure given a file pointer              */
/* NULL ptr upon Failure                                             */

SEGYHEAD *get_segy_header(/* (FILE *) file_ptr */);

/************************ get_segy_data()   **************************/
/* Returns a pointer to char or NULL ptr upon Failure                */

char *get_segy_data(/* (FILE *) file_ptr, (SEGYHEAD *) head_ptr */);

/************************ write_segy_record() **************************/
int
write_segy_record(/* (char *) filename, (SEGYHEAD *) head_ptr, data_ptr */);

/************************ write_segy_header() **************************/
int
write_segy_header(/* (FILE *) file_ptr, (SEGYHEAD *) head_ptr */);

/************************ write_segy_data()  ***************************/
int
write_segy_data(/* (FILE *) file_ptr, (SEGYHEAD *) head_ptr, data_ptr */);

/************************ get_tstatic()  *******************************/
int
get_tstatic(/* (SEGYHEAD *) head_ptr */);

/************************ put_tstatic()  *******************************/
int
put_tstatic(/* double totStatic, (SEGYHEAD *) head_ptr */);


#else		/* ANSI prototyping  */

int delta_rd( SEGYHEAD *hdr );
int delta_wr( SEGYHEAD *hdr, int delta );
int samp_rd( SEGYHEAD *hdr );
int  samp_wr( SEGYHEAD *hdr, int samp );
int s_passcal_etoh( SEGYHEAD *hdr, double epoch );
int s_passcal_htoe( SEGYHEAD *hdr );

SEGYHEAD *get_segy_header( SEGYHEAD file_ptr);
char *get_segy_data( (FILE *) file_ptr, (SEGYHEAD *) head_ptr );
int write_segy_record( (char *) filename, (SEGYHEAD *) head_ptr, data_ptr );
int write_segy_header( (FILE *) file_ptr, (SEGYHEAD *) head_ptr );
int write_segy_data( (FILE *) file_ptr, (SEGYHEAD *) head_ptr, data_ptr );
int get_tstatic( (SEGYHEAD *) head_ptr );
int put_tstatic( double totStatic, (SEGYHEAD *) head_ptr );

#endif	/* ifndef ANSI_C */

#endif /* SEGY_IO_H */
