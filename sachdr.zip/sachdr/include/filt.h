#ifndef __FILT_H__
#define __FILT_H__

/* FILT.H
 This file contains all of the REF TEK fir filters for the 72A-02
 and the 72A-08 units.
*/

/* this is the routine that allows the calculation of the reftek FIR */
/* filters. */
filtcalc();

#endif /* __FILT_H__ */
