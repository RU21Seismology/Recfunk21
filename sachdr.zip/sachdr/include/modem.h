#ifndef __MODEM__H__
#define __MODEM__H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/termios.h>
#include <fcntl.h>
#include <errno.h>
#include <ctype.h>

#define MODEM_PORT   "/dev/ttya"
#define STATION_LIST "station.phone.list"

#define SOH 0x01
#define STX 0x02
#define EOT 0x04
#define ACK 0x06
#define NAK 0x15
#define CAN 0x18

#ifndef TRUE
#define TRUE 0
#endif
#ifndef FALSE
#define FALSE -1
#endif

extern int _mfd;				/* file handle for modem tty port */
extern int cmd_fifo;			/* file handle for command in named fifo */
extern int rst_fifo;			/* file handle for status out named fifo */
extern int DEBUG;				/* debugging level, read from environment */
extern int NOMODEM;		/* if not 0 direct serial line */
extern int PARMODEM;		/* N81 - 0; O82 - 1; O81 - 2; E81 - 3; E82 - 4; N82 - 5 */
extern char tmp_buf[65536];	/* temp storage buffers */
extern char data_buf[65536];
extern char fname[50];			/* file name buffer */
extern int connected;			/* Global flag to signal connection */

extern char modem_port[40];
extern char current_station[16];	/* station number */
extern char current_id[8];			/* station id number */
int num_streams;			/* number of DAS streams */
extern char stream_names[16][16];	/* DAS stream names */
extern int das_power_mode;			/* power mode of DAS */
extern int das_record_mode;		/* DAS recording mode*/
extern int das_acq_state;			/* acquisition state of DAS */
extern int das_events;				/* events recorded by DAS */
extern int das_mem_used;			/* memory blocks used by DAS */
extern int das_mem_avail;			/* memory blocks blocks available in DAS */
extern char das_unit_number[10];	/* DAS unit number */
extern char das_ver_num[30];		/* DAS software version number */


int dial_number(/*char *phone*/);

int admin(/*char *selection, *buffer*/);

int clear_buffer(/* char *buffer; int len; */ );

int hangup ();
int dial_number(/*char *phone */);

int change_param(/*char *selection, *buffer*/);

int send_result(/*char *string*/);

int query(/*char *selection, *buffer*/);

int download(/*char *selection, *buffer*/);

int get_environment();

int close_serial_direct ();
int open_serial_direct (/*
			  char *modem_port;
			  int baud;
			  char *parity;*/ );

#endif
