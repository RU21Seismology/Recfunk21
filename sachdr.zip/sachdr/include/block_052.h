#ifndef BLOCKETTE_052
#define BLOCKETTE_052

#include "block_053.h"
#include "block_054.h"
#include "block_058.h"


typedef struct block_052 {
  char   location[3];     /* site within an array */
  char   channel[4];      /* standard channel id */
  int    sub_channel;     /* for multiplexed data */
  int    instrument;      /* lookup index from blockette 33 */
  char   comment[31];     /* optional comment */
  int    resp_units;      /* unit lookup key in blockette 34 */
  int    cal_units;       /* unit lookup key in blockette 34 */
  double latitude;        /* for instrument, can differ from station (deg) */
  double longitude;       /* for instrument, can differ from station (deg) */
  double elevation;       /* for instrument (not ground) (meters) */
  double depth;           /* instrument depth below ground */
  double azimuth;         /* in degrees from north, clockwise */
  double dip;             /* in degrees, down from horizontal */
  int    data_format;     /* lookup index from blockette 30 */
  int    data_record_len; /* in bytes,256-4096, store as n where 2**n */
  double sample_rate;     /* nominal sample rate (Hz) for digitzer */
  double max_clock_drift; /* NUM of samples * tolerance (sec/sample) */
  int    num_comments;    /* num of channel comment blockettes(59) */
			  /* that follow */
  char   chan_flags[27];  /* channel type flags */
  char   start_date[23];  /* earliest known date data was correct this */
			  /* blockette */
  char   end_date[23];    /* last date info was correct, zero=time of */
			  /* this blockettes creation */
  char   update_flag;     /* what data the update records refer to. */
} b_052_i;


/* a real blockette 052 needs 053's and 054's to be described */
typedef struct list_item_052 {
  b_052_i  b_052;
  li_053 *l_053_p;
  li_054 *l_054_p;
  b_058_i b_058;         /* This item holds the channel sensitivity */
			 /* blockette */
  struct list_item_052 *next;
} li_052;
/*
   typedef struct list_item_052 {
   b_052_i  b_052;
   li_053 l_053;
   li_054 l_054;
   struct list_item_052 *next;
   } li_052;
   */
typedef li_052 *b_052_lp;




int    init_blk_052(/*b_052_i *blk_p */);
/* this routine initializes a blockette item 052 with values with no
meaning. This function returns SUCCESS or FAILURE */


int write_blk_052(/*    FILE *out_file,     b_052_i *blk_p */);
     /* write the channel id blockette */
     /* this function writes to 'out_file' the information in the response */
     /* item.  The format of the file is the exact format required by SEED */
     /* and POD.  Therefore all one needs to do to use this function to */
     /* create POD files is to correctly specify the file name (including */
     /* path) for the output file. */
     /* This function returns SUCCESS or FAILURE or EMPTY (where */
     /* EMPTY>SUCCESS) */   


int  delete_blk_052( /*      b_052_i *blk_p*/);
/* not needed */



int copy_blk_052(/*     b_052_i *dest_p;     b_052_i *src_p */ );
/* this function copys entire blockettes, it returns SUCCESS or */
/* FAILURE */



/* ************************************************************************ */

int append_052_list(/*     li_052  *blk_p,     li_052  b_052_li */ );
/* this function takes a blockette 052 and appends it to the end of */
/* the blockette 052 list. It returns SUCCESS or FAILURE */



int copy_li_it_052(/*     li_052 *dest_p,     li_052 *src_p*/ );
/* this function copies a list item of blockette 052, including the */
/* internally stored blockettes. It returns SUCCESS or FAILURE. */

int init_li_052(/*     li_052 *blk_p */ );
     /* This function take a pointer to a blokette 052 list item, and */
     /* initializes that item. This function returns SUCCESS or */
     /* FAILURE. */ 

int append_052_list_053(/*     li_052 *b_052_li_p,     li_053 *l_053_p*/ );
     /* this function take s pointer to a blockette 052 list item and */
     /* pointer to a blockette list 053, and then adds the block list 053 */
     /* to the 053 list in the 052 list item. */

int append_052_list_054(/*     li_052 *b_052_li_p,     li_054 *l_054_p */ );
     /* this function take s pointer to a blockette 052 list and */
     /* pointer to a blockette list 054, and then adds the block list 054 */
     /* to the 054 list in the 052 list item. */

int append_052_item_053(/*     li_052 *b_052_li_p,     li_053 *l_053_p*/ );
     /* this function take s pointer to a blockette 052 list item and */
     /* pointer to a blockette list item 053, and then adds the block 053 */
     /* to the 053 list in the 052 list item. */

int append_052_item_054(/*     li_052 *b_052_li_p,     li_054 *l_054_p */ );
     /* this function take s pointer to a blockette 052 list item and */
     /* pointer to a blockette list item 054, and then adds the block 054 */
     /* to the 054 list in the 052 list item. */

int set_052_item_058(/*   li_052 *b_052_li_p, b_058_i *b_058 */);
/* This function takes a pointer to a 058 channel sensitivity */
/* blockette and copies the values in this blockette into the channel */
/* sensitivity variables within the block_052 list_item. */

int delete_list_052( /*     li_052 *list_ptr */ );
/* this function takes a pointer to a list of 052 items and deletes */
/* the items in the list. It returns SUCCESS or FAILURE. */

int free_052_list(/*     li_052 *b_052_li_p*/ );
     /* this function takes a pointer to a list of blockette 052 items */
     /* and frees all te internal memory associated with that list. */

int clear_052_list(/*     li_052 *b_052_li_p*/ );
     /* this function takes a pointer to a list of blockette 052 items */
     /* and frees all te internal memory associated with that list. */
     /* This routine assumes that the list itself was declared, but it */
     /* frees and re-initializes the internal pointers to the lists of */
     /* 053 and 054 items. */

int print_052_list(/*     FILE *out_file,     li_052 *list_p */ );
     /* this function takes as its argument a pointer to a list of */
     /* blocketts 052 items, and then prints out to the out_file the */
     /* blocketts in SEED format. */


/* ************************************************************************ */



#endif
