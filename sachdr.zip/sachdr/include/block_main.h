#ifndef BLOCKETTE_MAIN
#define BLOCKETTE_MAIN

#ifndef SUCCESS
#define SUCCESS 0
#define FAILURE -1
#define EMPTY 1
#define TRUE 1
#define FALSE 0
#endif


#define MIN_SIZE_050 62
#define MIN_SIZE_051 19
#define MIN_SIZE_052 103
#define MIN_SIZE_053 46
#define MIN_SIZE_054 24
#define MIN_SIZE_057 51
#define MIN_SIZE_058 35
#define MIN_SIZE_059 20
#define MIN_SIZE_030 17
#define MIN_SIZE_031 16
#define MIN_SIZE_033 11
#define MIN_SIZE_034 12

#ifndef INT_DIFF_COMPRESSION
#define INT_DIFF_COMPRESSION 50 /* from blockette 30 */
#endif

extern char real_update_flag;
extern int write_config_end;
extern double doub_null;
extern int int_null;
extern double pod_version;

int check_int();
double check_doub();

#endif
