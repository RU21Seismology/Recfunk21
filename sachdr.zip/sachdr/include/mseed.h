#ifndef          MSEED_FILE
#define          MSEED_FILE

#include <stdio.h>		/* Standard I/O header file      */
/*	99.201 removed this because it caused LINUX makes to bomb #include <rpc/rpc.h> */
#include <math.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#ifdef DARWIN
#include <malloc/malloc.h>
#else
#include <malloc.h>
#endif
#include <stdlib.h>
#include "segy.h"

/******************************* write_fxd() **********************************/
/*  Uses pertinant information from SEGYHEADER and copies it into DATA_HEADER */

void write_fxd(/* fxd_hdr, segy_hdr */);
/* DATA_HEADER    *fxd_hdr;                                                   */
/* struct SegyHead segy_hdr;                                                  */

/******************************* print_fxd() **********************************/
/*  Formats information from the fixed header to the standard output          */

void print_fxd(/* i, hdr */);
/* int             i;                                                         */
/* DATA_HEADER    *hdr;                                                       */

/****************************** do_all_hdrs() *********************************/
/* Loops through NUM steim blocks of DATA and calls print_fxd to printout     */
void do_all_hdrs(/* data, num */);
/* char           *data;                                                      */
/* long            num;                                                       */


/******************************** update_fxd() ********************************/
/*                                                                            */

void update_fxd(/* data, num_rec */);
/* char           *data;                                                      */
/* int             num_rec;                                                   */

#endif            /* MSEED_FILE */
