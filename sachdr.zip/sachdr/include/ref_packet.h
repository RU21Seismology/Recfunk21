#ifndef	REFPACKET_H
#define REFPACKET_H

#include <stdio.h>

#ifndef TRUE
#define		TRUE   	1
#endif
#ifndef FALSE
#define		FALSE	0
#endif

#define		AD	0x4144
#define		CD	0x4344
#define		DR	0x4452
#define		DS	0x4453
#define		DT	0x4454
#define		EH	0x4548
#define		ET	0x4554
#define		OM	0x4F4D
#define		SC	0x5343
#define		SH	0x5348

#define		max_trig	8
#define		trig_length	3
#define		EVT		1
#define		CON		2
#define		TIM		3
#define		LEV		4
#define		RAD		5
#define		CRS		6
#define		EXT		7
#define		TML		8

int             blockcnt, srate[8], gain[6], leod, maxblocks;
int             dskflg;


#define		fl_cnt		1024



FILE           *fpin;		/* Pointer to the input file  */
FILE           *fpout;		/* Pointer to output file */
int             fdpin;		/* file descriptor for exabyte */

#endif	/* REFPACKET_H	*/
