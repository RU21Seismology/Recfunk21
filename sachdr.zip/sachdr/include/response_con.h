#ifndef RESPONSE_CON
#define RESPONSE_CON


  /*
     The units that Tim has requested.
     V - Volts
     COUNTS - Digital Counts
   */

#define COUNT_NAME "Digital Counts"
#define COUNT_UNIT "COUNTS"

#define VOLT_NAME "Volts"
#define VOLT_UNIT "V"

extern int force_channel_num;
 
int resp_item_list_to_seed_blockette_052( /* resp_item_list *resp_p,
					 li_052         *blk_052_p */ );
     /* this function takes a pointer to a list of response_items and */
     /* a pointer to a blockette 052 list structure, and then it */
     /* converts the entire resp_item_list into the correct blockette */
     /* form. It returns SUCCESS or FAILURE */

int resp_item_db_to_seed( /*     blockette_resp_item *blk_resp_p,
				 li_052              *blk_052_p */ );
     /* this function takes a blockette_resp_item (from the database, */
     /* or ascii file) and appends the info into an existing blockette */
     /* 052 structure, complete with filling in the blockette 053, */
     /* 054, 057 and 058 as needed. */

int resp_item_to_blockette_053_4_7_8( /* blockette_resp_item *blk_resp_p,
					 li_053 *it_053,
					 li_054 *it_054 */ );
     /* this function takes a blockette_resp_item (from the database, */
     /* or ascii file) and appends the info into an existing blockette */
     /* 052 structure, complete with filling in the blockette 053, */
     /* 054, 057 and 058 as needed. This function returns PAZ or FIR */




#endif
