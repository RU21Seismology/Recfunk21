#ifndef RESPONSE_LIST
#define RESPONSE_LIST

double sens_read_response_list_file(/*response_list_file_name,
				      site->sensor, double *sensitiviy*/);
double noexitonerror_sens_read_response_list_file(/*response_list_file_name,
				      site->sensor, double *sensitiviy*/);

char *read_response_list_file(/*file_name, sensor, rate, chan, az, dip */);

char *noexitonerror_read_response_list_file(/*file_name, sensor, rate, chan, az, dip */);

int calc_chan_name(/*char* name, int rate, char* model, int chan, double az, double dip*/);

double check_dip_range(/*dip, orientation_tolerance*/);
double check_az_range(/*az, orientation_tolerance*/);

#endif /*RESPONSE_LIST*/

