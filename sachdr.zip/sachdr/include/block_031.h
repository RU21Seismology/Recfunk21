#ifndef BLOCKETTE_031
#define BLOCKETTE_031




typedef struct block_031 {

  int     code_key;        /* key for accessing comments */
  char    letter_code;     /* user assigned, determines to what the */
			   /* code refers. */
  char    comment[71];     /* the comments's text */
  int     units_level;     /* if a value is associated with the */
			   /* comment, lookup the units from blockette */
			   /* 34 */
      
} b_031_i ;



/* create a list of b_031_items */
typedef struct list_item_031 {
  b_031_i b_031;
  struct list_item_031 *next;
} li_031;

typedef li_031 *b_031_lp;



/* ****************************************************************
 * This section holds the routines for blockette 031 items
 *
 */


int init_list_031(/*     char *local_dir */);
     /* This routine checks to see if a file witht he suggested file */
     /* name exists. If it does, then it attemps to read in any and */
     /* all blockette 031's . if the file does not yet exist, or there */
     /* are no blockette 031's in the file, then the list_ptr is left */
     /* as the NULL ptr. If there are blockette 031's in the file, */
     /* then the list_ptr consists of only the blockettes read in from */
     /* the file. This function returns the number of blockettes read. */

int lookup_b_031_i(/*
		      li_031 **list_ptr,
		      char letter_code,
		      char *comment,
		      int unit_code */);
/* this function takes a letter_code/comment pair and checks the
   currently active b_031 list to see if that description exists
   yet.  If it does not, that letter_code/comment pair is added
   to the list. In either casethe function returns the lookup key
   of the letter_code/comment pair, or FAILURE in case of error.
   This function is called by the user. */

     
int print_li_031(/* li_031 *list_ptr,
		    FILE *f_p */);
/* this function prints out the entire list of blockette 031 items. */
/* it returns the number of blockettes printed, or FAILURE. */
/* This function is actually called by the user. */

int lookup_031(/*   char class_code,
		    char *comment_desc,
		    int unit_comment_level */);
/* this function takes a letter_code/comment pair and checks the
   currently active b_031 list to see if that description exists
   yet.  If it does not, that letter_code/comment pair is added
   to the list. In either casethe function returns the lookup key
   of the letter_code/comment pair, or FAILURE in case of error.
   This function is called by the user. */

     
int print_031(/* char *local_dir */);
/* this function prints out the entire list of blockette 031 items. */
/* it returns the number of blockettes printed, or FAILURE. */
/* This function is actually called by the user. */


int add_blockette_031_list_item(/* */);

#endif
