#include <stdio.h>
#include <sys/types.h>

/* define modes */
#define W_READ_ONLY  001 /* just what it says, no output */
#define W_FILTER     002 /* modify header and data; output to new file */
#define W_HEADER_MOD 003 /* modify header and not data; same file in */
			 /* as out */

#define F_PSEGY	001
#define F_SUDS 	002
#define F_AH 	003
#define F_SAC 	004
#define F_MSEED	005
#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

/* to support ANSI C later on */
#ifndef __P 
#define __P(protos) ()
#endif 

typedef struct Trace {
  char * site_name;		/* name of site */
  char * channel_name;		/* name of channel */
  int channel_num;		/* number of channel */
  char * recorder_name;		/* name of recorder */
  int recorder_num;		/* number of recorder (i.e., DAS)*/
  int pos_in_file;		/* trace num in file */
  long epoch;			/* epoch seconds as returned from htoe() */
  int  msecs;			/* milliseconds */
  long trig_epoch;              /* trigger epoch */
  int trig_msecs;               /* trigger milliseconds */
  long nsamples;		/* number of samples */
  long srate;			/* sample rate in milliseconds per sample */
  short size_of_data;		/* number of bytes in data, 2 or 4 usually*/
  int   msec_corr;		/* milliseconds correction */
  int   corrected;		/* true if the time-stamp has already
				   been time corrected */
  long 	time_since_rate;	/* 99.043 addition */
  int	time_quality;		/* 99.043 blockette 1001 addition */
  struct WFiles *parent;	/* which file did this trace originate from */
  void *head_ptr;		/* pointer to header */
  char *data;			/* pointer to data */
} TRACE;

typedef struct WFiles {
  char * filename;
  int __current_trace;		/* currently active trace */
  char *in_fptr;		/* null if currently active trace is not open */
  char *out_fptr;
  struct Wave *parent;
  int num_traces;
  struct Trace **traces;
} WFILE;

typedef struct Wave {
  struct WFiles **Files;
  int num_files;
  int total_traces;
  int wave_type;
  int multi_trace_file;		/* true if format supports more
				   than one trace per file */	
  int __current_file;		/* currently active file */
  int __mode;			/* IO mode for this wave struct */
  char  * (*OpenFile) __P((char * filename, char * io_flags)); /*  */
  TRACE * (*ReadTrace) __P((WFILE * wf));
  TRACE * (*ReadTraceHead) __P((WFILE *wf));
  int     (*ReadTraceData) __P((TRACE *t));
  int 	(*RewindTrace) __P((TRACE *t)); /* used for header mods only */
  int 	(*WriteTrace) __P((TRACE *t));
  int	(*WriteTraceHead) __P((TRACE *t, char *fptr));
  int 	(*WriteTraceData) __P((TRACE *t, char *fptr));
  int	(*FreeTrace) __P((TRACE *t));
  int 	(*PassNonTraceData) __P((WFILE *w)); /* used for suds */
  int   (*CloseFile) __P((char * fptr));
} WAVE;



/* these are the functions we'll use to operate on a file list */
WFILE **GetCommandLineListWFILE(), **GetFileListWFILE();
WAVE  * AllocWave();
WAVE  * OpenWave(/* WFILE ** WFilesList, int fmt_type, int io_mode */);
TRACE * GetNextTrace(/* WAVE *Wave */);
TRACE * GetNextTraceHead(/* WAVE *Wave */);
TRACE * GetNextTraceData(/* WAVE *Wave */);
TRACE * AllocTrace();  /* allocate a trace */
int OpenWF(); /* accepts WFILE and opens for reading based on mode*/

/* now it gets scary, outputing the stuff */
int     OpenOutputTrace(/* char *filename,  int permissions */);
int     CloseTrace(); /* close it if we no longer need it */
int 	PutTrace(/*TRACE *trace */);/* puts the last trace to the out_fptr */
int 	PutTraceHead(/*TRACE *trace */);
int 	PutTraceData(/*TRACE *trace */);
int 	CloseWave(/* WAVE *wave */);
int 	FreeTrace(/* TRACE *trace */);
