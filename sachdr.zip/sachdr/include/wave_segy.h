TRACE * ReadTracePSEGY();
TRACE * ReadTraceHeadPSEGY();
int ReadTraceDataPSEGY();
int WriteTracePSEGY();
int WriteTraceHeadPSEGY();
int WriteTraceDataPSEGY();
