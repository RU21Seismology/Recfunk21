/* BEGIN HEADER: libcc.h
 *   Header file with the function prototypes for all of the libcc functions.
 *
 *   Must include passcal.h in any .c file that includes libcc.h before
 *   including this file.
 */
#ifndef PASSOFT_LIBCCH
#  define PASSOFT_LIBCCH

#  include <stdio.h>
#  include <time.h>
#  include "passcal.h"

#  define CCPROG_VERSION "2003.307"

/* Date and time formats (keep these up to date with changes in the functions
 * dateFormat.c and timeFormat.c)
 */
#  define CCNODATE -1
#  define CCYYYYMMMDD 1
#  define CCDDMMMYYYY 2
#  define CCMMDDYYY 3
#  define CCYYYYMMDD 4
#  define CCYYYYDDD 5

#  define CCNOTIME -1
#  define CCHHCMMCSS 0
#  define CCHHhMMmSSs 1
#  define CCHHMMSS 2
#  define CCHHCMMampm 3
#  define CCHHCMMCSSampm 4
#  define CCHHCMM 5

   extern VOID bell(VOID);
   extern INT checkDate(INT, INT, INT);
   extern INT checkHex(CHAR *);
   extern INT checkOctal(CHAR *);
   extern INT checkTime(INT *, INT *, INT *, INT);
   extern VOID cleanLine(CHAR *);
   extern VOID cls(VOID);
   extern VOID compress(CHAR *);
   extern INT32 crcc16(CHAR *);
/* extern UINT16 crcc16b(CHAR *, INT16); */
   extern INT ctParts(CHAR *, CHAR);
   extern INT dateFormat(INT, INT, INT, INT, CHAR *);
   extern VOID dateMath(INT *, INT *, INT *, INT);
   extern REAL64 dateNumber(CHAR *);
   extern INT dateYMD(CHAR *, INT *, INT *, INT *);
   extern VOID decomma(CHAR *);
   extern VOID epoch2Str(REAL64, CHAR *);
   extern INT findLine(FILE *, CHAR *, CHAR *, INT);
   extern INT32 fsize(FILE *);
   extern CHAR *getItem(CHAR *, CHAR *, INT);
   extern CHAR *getPart(CHAR *, CHAR *, CHAR, INT);
   extern INT getTabbed(CHAR *, CHAR *, INT);
   extern VOID getUT(INT *, INT *, INT *, INT *, INT *, INT *, INT *);
   extern VOID getUTStr(INT, CHAR *, INT, CHAR *);
   extern CHAR *getWord(CHAR *, CHAR *, INT);
   extern INT inList(CHAR *, INT, CHAR);
   extern INT isCorrect(INT);
   extern time_t mkgmtime(struct tm *);
   extern INT month2Num(CHAR *);
   extern CHAR *num2Month(INT);
   extern VOID oneBlank(CHAR *);
   extern INT overWrite(CHAR *, CHAR *);
   extern VOID patternRtn(CHAR *);
   extern VOID printAt(INT, INT, CHAR *, CHAR *);
   extern CHAR *promptNInput(CHAR *, CHAR *, INT, INT);
   extern INT readLine(FILE *, CHAR *, INT);
   extern VOID replicate(CHAR *, INT, INT);
   extern REAL64 str2Dddd(CHAR *);
   extern REAL64 str2Epoch(INT, CHAR *);
   extern INT strcmps(CHAR *, CHAR *);
   extern VOID stripWhite(CHAR *);
   extern VOID stripQuotes(CHAR *);
   extern CHAR *strnncpy(CHAR *, CHAR *, INT);
   extern VOID timeFormat(INT, INT, INT, INT, CHAR *);
   extern INT timeHMS(CHAR *, INT *, INT *, INT *);
   extern REAL64 timeNumber(CHAR *);
   extern VOID toBlanks(CHAR *);
   extern VOID toContinue(VOID);
   extern INT toQContinue(VOID);
   extern INT toLeap(INT);
   extern VOID toLow(CHAR *);
   extern VOID toUp(CHAR *);
   extern VOID trimRight(CHAR *, INT);
   extern INT two2Four(INT);
   extern VOID unbcd(CHAR *, CHAR *, INT);
   extern INT wordCount(CHAR *);
   extern REAL64 ydhms2Epoch(INT, INT, INT, INT, INT);
   extern REAL64 ydhms2Epochd(INT, INT, INT, INT, REAL64);
   extern VOID ydMath(INT *, INT *, INT);
   extern INT ydoy2md(INT, INT, INT *, INT *);
   extern INT ymd2doy(INT, INT, INT);
   extern REAL64 ymd2jd(INT, INT, INT);

#endif
/* END HEADER: libcc.h */
