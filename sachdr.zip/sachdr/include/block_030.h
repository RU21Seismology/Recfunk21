#ifndef BLOCKETTE_030
#define BLOCKETTE_030





typedef struct block_030 {

  char    name[51];        /* short descriptive name */
  int     code_key;        /* key for accessing dictionary entries */
  int     data_type;       /* data family type (0 = int fixed, 1 = int */
			   /* diffs) */
  int     num_decode_keys; /* number of decoder keys used by the data */
			   /* family type */
  char    *decode_keys[20];   /* decoder keys used by the data */
			   /* family type.   ~'s separate the entries*/
  
    
} b_030_i ;

/* create a list of b_030_items */
typedef struct list_item_030 {
  b_030_i b_030;
  struct list_item_030 *next;
} li_030;

typedef li_030 *b_030_lp;



/* ****************************************************************
 * This section holds the routines for blockette 030 items
 *
 */


int init_list_030( /*      char *master_dir */);
     /* This routine checks to see if a file witht he suggested file */
     /* name exists. If it does, then it attemps to read in any and */
     /* all blockette 030's . if the file does not yet exist, or there */
     /* are no blockette 030's in the file, then the list_ptr is left */
     /* as the NULL ptr. If there are blockette 030's in the file, */
     /* then the list_ptr consists of only the blockettes read in from */
     /* the file. This function returns the number of blockettes read. */

int lookup_b_030_i(/*
     li_030 **list_ptr,
     char *name,
     int data_type,
     int num_keys,
     char *keys[] */);
     /* this function takes a name/data_type pair and checks the currently */
     /* active b_030 list to see if that description exists yet.  If it */
     /* does not, that name/data pair is added to the list.  In either case */
     /* the function returns the lookup key of the name/data pair, or */
     /* FAILURE in case of error. */
     /* This function is called by the user. */

int print_li_030(/* li_030 *list_ptr,
		    FILE *f_p */);
/* this function prints out the entire list of blockette 030 items. */
/* it returns the number of blockettes printed, or FAILURE. */
/* This function is actually called by the user. */


int add_steim_blockette_030_list_item();
/* this function adds the steim data descriptor to the data format */
/* dictionary blockette. It returns the key within the data */



int add_blockette_030_list_item(/* string, key, type*/);


#endif
