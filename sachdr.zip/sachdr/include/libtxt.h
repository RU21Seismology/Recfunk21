/* BEGIN HEADER: libtxt.h
 *   All of the defines and structs for the text file reading/writing routines.
 */
#ifndef PASSOFT_LIBTXTH
#  define PASSOFT_LIBTXTH

#  define TXTPROG_VERSION "2002.063"

#  include <stdio.h>
#  include <sys/types.h>
#  include <sys/stat.h>

#  define TXTMAXFILES 20

#  define TXTMAXFNLEN 128
#  define TXTMAXGMSGLENGTH 128
#  define TXTMAXINLINELEN 512

   struct _TXT
   {
      FILE *Fp;
      CHAR Filename[TXTMAXFNLEN];
      struct stat Stat;
      CHAR InLine[TXTMAXINLINELEN];
      UINT32 CurrByte;
      INT32 CurrLine;
      CHAR **SearchStrings;
      INT32 SearchItems;
      INT SearchIndex;
      CHAR *DataBlock;
   };
   struct _TXT *TXT[TXTMAXFILES];

   INT TXTBigEndian;
   CHAR TxtGMsg[TXTMAXGMSGLENGTH];

   extern CHAR *txtCloseAllFiles(VOID);
   extern CHAR *txtCloseFile(INT16);
   extern CHAR *txtGetCurrByte(INT16, UINT32 *);
   extern CHAR *txtGetCurrLine(INT16, INT32 *);
   extern CHAR *txtGetInLineAddr(INT16, CHAR **);
   extern CHAR *txtGetNextAllSearch(INT16, INT16);
   extern CHAR *txtGetNextSearch(INT16, INT16);
   extern CHAR *txtGetSearchIndex(INT16, INT *);
   extern CHAR *txtGetSearchIndexAddr(INT16, INT **);
   extern CHAR *txtInit(VOID);
   extern CHAR *txtOpenFile(CHAR *, INT16 *);
   extern CHAR *txtReadLine(INT16, INT16);
   extern CHAR *txtRewindFile(INT16);
   extern CHAR *txtSetSearchStrings(INT16, CHAR **);

#endif
/* END HEADER: libtxt.h */
