#define BIG_END 1
#define LITTLE_END 0

int endian(void);
