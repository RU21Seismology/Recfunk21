
#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

/* This is the header for the PASSCAL SEGY trace data.  
 * broken out into offsets for each value and whether it is short
 * int, or float.
 *
 * Other structures in this file are used for defining a table of 
 * fields and data values for the fields in memory.
 */

#define SEGY_INT 0
#define SEGY_SHORT 1
#define SEGY_FLOAT 2

/* the following structure describes the static external variable
   which holds the offsets and field names of the SEGY header */

typedef struct SEGYHeadIndex_ {
	char field[30];
	int offset;
	int type;
} SEGYHEADINDEX;

/* the following structure describes the field headers for the
 data: (1) the name of the field via the SEGYHeadIndex struct
 and (2) its position in the tuple (or row). */

typedef struct _SEGYField {
	int field;		/* index into SEGYHeadIndex for the field */
	int index;		/* index to row in header table that contains this data */
} SEGYFIELD;

/* the following structure describes the data themselves */
typedef union _SEGYFieldItem {
	float	fval;
	short	sval;
	int	lval;
	char 	*cval;
} SEGYFIELDITEM;

/* the following structure completely describes the ASCII data SEGY Header data table passed in
aint with the key fields used to associate a row of data with a specific trace header */

typedef struct _SEGYHeadTable {
	int num_fields;		/* the number of fields in the data table */
	int num_keys;		/* the number of keys in the data table */
	int num_data;		/* the number of rows of data in the data table */
	SEGYFIELD **field;	/* an array of fields (Segy Header members) */
	SEGYFIELD  **key;	/* an array of keys (Segy Header members used to associate data) */
	SEGYFIELDITEM ***data;	/* an array of rows of data */
} SEGYHEADTABLE;
	
