	complex	r_unity = { 1.0, 0.0};
	complex	i_unity = { 0.0, 1.0};

	double	c_abs ();
	complex *c_cos(),*c_div(),*c_mult(),*c_add();
	complex *c_sub(),*c_exp(),*c_log(),*c_sin();
	complex *c_sqrt();
	double	cabs();
