#ifndef BLOCKETTE_051
#define BLOCKETTE_051


typedef struct block_051 {
  char   start_time[23];       /* earliest date that header info is correct*/
  char   end_time[23];         /* last date info correct, 0 = still ok  */
  int     code_key;            /* key for accessing comments */
  int     comment_level;       /* numeric value from Blocketter 31 */
  
} b_051_i;



typedef struct list_item_051 {
  b_051_i b_051;
  struct list_item_051 *next;
} li_051;

typedef li_051 *b_051_lp;



/* ****************************************************************
 * This section holds the routines for blockette 051 items
 *
 */

int add_b_051( /*     char *local_dir,
		      char *start_time,
		      char *end_time,
		      int code_key,
		      int comment_level; */ );
/* This routine allows the user to all at once. with this */
/* routine, the input file is opened, the list initialized, the */
/* current selection is read in and looked up, and if not present */
/* added to the list, and then the disk file (B052) is updated. */
/* It returns SUCCESS or FAILURE. */





#endif
