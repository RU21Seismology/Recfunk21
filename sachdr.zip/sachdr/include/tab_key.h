#define BUF_SIZE (256)

#define PDB_KEY_LIST_SIZE (14)

/* key index */
#define PDB_TP_ID 0
#define PDB_CONFIG_ID 1
#define PDB_DS_ID 2
#define PDB_CHAN_ID 3
#define PDB_SITE_ID 4
#define PDB_SENS_ID 5
#define PDB_UP_NUM 6
#define PDB_DEP_NUM 7
#define PDB_RESP_ID 8
#define PDB_TRACE_ID 9
#define PDB_TAPE_ARCH_ID 10
#define PDB_TAPE_VOL_ID 11
#define PDB_DIR_ID 12
#define PDB_RAW_VOL_ID 13
