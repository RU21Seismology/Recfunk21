
/*
 * Error codes
 */

#ifndef _pas_errno_h
#define _pas_errno_h

#define	 EYEAR       1    /* check_ptime: Year out of range */
#define  EJULD       2    /* check_ptime: Julday out of range */
#define  EHOUR       3    /* check_ptime: Hour out of range */
#define  EMIN        4    /* check_ptime: Minutes out of range */
#define  ESECS       5    /* check_ptime: Seconds out of range */

static char    *pas_errlist[] = {"No error",
        "Year out of range",
        "Julday out of range",
        "Hour out of range",
        "Minutes out of range",
        "Seconds out of range"};
 
static int   pas_nerr = 5;
static int   pas_errno = 0;


#endif /*!_pas_errno_h*/
