#define SERIAL_READ 128

FILE *OpenRefDisk(/* char *dsk_device, int *maxblocks, int *leod */);
FILE *OpenRefTape(/* char *  tape_device,  int * maxblocks */);
