#ifndef BLOCKETTE_057
#define BLOCKETTE_057




typedef struct block_057 {
  int      seq_number;            /* assuming a multi-stage filter, */
    			          /* which one is this? */
  double   input_sample_rate;     /* samples per second */
  int      decimation_factor;     /* one sample out/this */
				  /* number in */
  int      decimation_offset;     /* which sample out of the */
				  /* decimation factor is used */
  double   delay;                 /* estimated pure delay for */
                                  /* the state. */
  double   correction;            /* time shift applied to the */
			       	  /* time tag due to delay at */
			       	  /* this stage of the filter */
} b_057_i ;




/* also need a linked list of these blocks */
typedef struct list_item_057 {
  b_057_i *blk_p;
  struct list_item_057 *next;
} li_057;

/* and a list pointer */
typedef li_057 *b_057_lp;


int    init_blk_057(/*     b_057_i *blk_p */ );
/* this function initializes blockette 057.  it returns SUCCESS or */
/* FAILURE */

int   write_blk_057(/*     FILE *out_file,     b_057_i *blk_p*/ );
/* This function returns SUCCESS or FAILURE or EMPTY (where */
/* EMPTY>SUCCESS) This function writes out the blockette to the */
/* out_file */   


int copy_blk_057(/*     b_057_i *dest_p,     b_057_i *src_p*/ );
/* This function copys one blockette 054 to another one.  IT returns */
/* SUCCESS or FAILURE. */


int  delete_blk_057(/*     b_057_i *blk_p */ );
/* not needed */


     



#endif
