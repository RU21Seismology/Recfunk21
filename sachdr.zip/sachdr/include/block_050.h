#ifndef BLOCKETTE_050
#define BLOCKETTE_050


#include "block_052.h"

typedef struct block_050 {
  char   station_name[5];      /* Station call letters  */
  double latitude;             /* earth latitude (deg) (+=N -=S)  */
  double longitude;            /* earth longitude (deg) (+=E -=W)  */
  double elevation;            /* ground level (meters)  */
  int    num_channels;         /* optional,num of channels that follow  */
  int    num_station_comments; /* num of station comment blockette(51)  */
  char   site_name[61];        /* station site, (town, state, country etc  */
  int    network_id;           /* lookup code for blockette 33  */
  int    _32_bit_word_order;    /* i.e. 0123, 3210, for headers, for */
			       /* data, see data format dictionary  */
  int    _16_bit_word_order;    /* 01, 10, as above  */
  char   start_date[23];       /* earliest date that header info is correct*/
  char   end_date[23];         /* last date info correct, 0 = still ok  */
  char   update_flag;          /* to what the data update records refer  */
  char   network_code[3];      /* network operator responsible for the */
			       /* data logger, assigned by IRIS. */
  
} b_050_i;


/* a real blockette 050 needs a list of 052's to be described */
typedef struct list_item_050 {
  b_050_i b_050;
  li_052 *l_052_p;
  struct list_item_050 *next;
} li_050;

typedef li_050 *b_050_lp;



/* sidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsidsid */
int    init_blk_050( /* b_050_i *blk_p */);
/* this routine initializes a blockette item 050 with values with no
meaning. This function returns SUCCESS or FAILURE */

     
int write_blk_050(/* FILE *out_file b_050_i *blk_p */); 
/* This routine writes out the blockette 050 The function returns
FAILURE < SUCCESS < EMPTY.  EMPTY is returned when the pointer does
not point to anything. */ 



int  delete_blk_050(/* b_050_i *blk_p */);
/* this routine is not needed */


int compare_blk_050(/*     b_050_i *blk_p_1,     b_050_i *blk_p_2 */ );

/* in order to compare two items of blockette 050, we must only */
/* compare the station names. It returns the same values that strcmp
returns */



int init_li_050( /*     li_050 *blk_p */ );
     /* This function take a pointer to a blokette 050 list item, and */
     /* initializes that item. This function returns SUCCESS or */
     /* FAILURE. */ 

/* ************************************************************************ */
/* ************************************************************************ */


#endif
