#include "sac.h"


extern float          sac_float[70];
extern int            sac_int[40];
extern long           sac_long[5];
extern char           sac_string[23][10];

void
read_sac_values (sp)

struct sac     *sp;
{
	/* get the float type values  */
		sac_float[0] = sp->delta;
		sac_float[1] = sp->depmin;
		sac_float[2] = sp->depmax;
		sac_float[3] = sp->scale;
		sac_float[4] = sp->odelta;
		sac_float[5] = sp->b;
		sac_float[6] = sp->e;
		sac_float[7] = sp->o;
		sac_float[8] = sp->a;
		sac_float[9] = sp->internal1;
		sac_float[10] = sp->t0;
		sac_float[11] = sp->t1;
		sac_float[12] = sp->t2;
		sac_float[13] = sp->t3;
		sac_float[14] = sp->t4;
		sac_float[15] = sp->t5;
		sac_float[16] = sp->t6;
		sac_float[17] = sp->t7;
		sac_float[18] = sp->t8;
		sac_float[19] = sp->t9;
		sac_float[20] = sp->f;
		sac_float[21] = sp->resp0;
		sac_float[22] = sp->resp1;
		sac_float[23] = sp->resp2;
		sac_float[24] = sp->resp3;
		sac_float[25] = sp->resp4;
		sac_float[26] = sp->resp5;
		sac_float[27] = sp->resp6;
		sac_float[28] = sp->resp7;
		sac_float[29] = sp->resp8;
		sac_float[30] = sp->resp9;
		sac_float[31] = sp->stla;
		sac_float[32] = sp->stlo;
		sac_float[33] = sp->stel;
		sac_float[34] = sp->stdp;
		sac_float[35] = sp->evla;
		sac_float[36] = sp->evlo;
		sac_float[37] = sp->evel;
		sac_float[38] = sp->evdp;
		sac_float[39] = sp->unused1;
		sac_float[40] = sp->user0;
		sac_float[41] = sp->user1;
		sac_float[42] = sp->user2;
		sac_float[43] = sp->user3;
		sac_float[44] = sp->user4;
		sac_float[45] = sp->user5;
		sac_float[46] = sp->user6;
		sac_float[47] = sp->user7;
		sac_float[48] = sp->user8;
		sac_float[49] = sp->user9;
		sac_float[50] = sp->dist;
		sac_float[51] = sp->az;
		sac_float[52] = sp->baz;
		sac_float[53] = sp->gcarc;
		sac_float[54] = sp->internal2;
		sac_float[55] = sp->internal3;
		sac_float[56] = sp->depmen;
		sac_float[57] = sp->cmpaz;
		sac_float[58] = sp->cmpinc;
		sac_float[59] = sp->unused2;
		sac_float[60] = sp->unused3;
		sac_float[61] = sp->unused4;
		sac_float[62] = sp->unused5;
		sac_float[63] = sp->unused6;
		sac_float[64] = sp->unused7;
		sac_float[65] = sp->unused8;
		sac_float[66] = sp->unused9;
		sac_float[67] = sp->unused10;
		sac_float[68] = sp->unused11;
		sac_float[69] = sp->unused12;
		
	/*  get the integer type values  */
		sac_int[0] = sp->nzyear;
		sac_int[1] = sp->nzjday;
		sac_int[2] = sp->nzhour;
		sac_int[3] = sp->nzmin;
		sac_int[4] = sp->nzsec;
		sac_int[5] = sp->nzmsec;
		sac_int[6] = sp->internal4;
		sac_int[7] = sp->internal5;
		sac_int[8] = sp->internal6;
		sac_int[9] = sp->npts;
		sac_int[10] = sp->internal7;
		sac_int[11] = sp->internal8;
		sac_int[12] = sp->unused13;
		sac_int[13] = sp->unused14;
		sac_int[14] = sp->unused15;
		sac_int[15] = sp->iftype;
		sac_int[16] = sp->idep;
		sac_int[17] = sp->iztype;
		sac_int[18] = sp->unused16;
		sac_int[19] = sp->iinst;
		sac_int[20] = sp->istreg;
		sac_int[21] = sp->ievreg;
		sac_int[22] = sp->ievtyp;
		sac_int[23] = sp->iqual;
		sac_int[24] = sp->isynth;
		sac_int[25] = sp->unused17;
		sac_int[26] = sp->unused18;
		sac_int[27] = sp->unused19;
		sac_int[28] = sp->unused20;
		sac_int[29] = sp->unused21;
		sac_int[30] = sp->unused22;
		sac_int[31] = sp->unused23;
		sac_int[32] = sp->unused24;
		sac_int[33] = sp->unused25;
		sac_int[34] = sp->unused26;
		
	/*  get the long int type values  */
		sac_long[0] = sp->leven;
		sac_long[1] = sp->lpspol;
		sac_long[2] = sp->lovrok;
		sac_long[3] = sp->lcalda;
		sac_long[4] = sp->unused27;
		
	/*  get the ascii string type values  */
		memcpy(sac_string[0], sp->kstnm, 8);
		memcpy(sac_string[1], sp->kevnm, 16);
		memcpy(sac_string[2], sp->khole, 8);
		memcpy(sac_string[3], sp->ko, 8);
		memcpy(sac_string[4], sp->ka, 8);
		memcpy(sac_string[5], sp->kt0, 8);
		memcpy(sac_string[6], sp->kt1, 8);
		memcpy(sac_string[7], sp->kt2, 8);
		memcpy(sac_string[8], sp->kt3, 8);
		memcpy(sac_string[9], sp->kt4, 8);
		memcpy(sac_string[10], sp->kt5, 8);
		memcpy(sac_string[11], sp->kt6, 8);
		memcpy(sac_string[12], sp->kt7, 8);
		memcpy(sac_string[13], sp->kt8, 8);
		memcpy(sac_string[14], sp->kt9, 8);
		memcpy(sac_string[15], sp->kf, 8);
		memcpy(sac_string[16], sp->kuser0, 8);
		memcpy(sac_string[17], sp->kuser1, 8);
		memcpy(sac_string[18], sp->kuser2, 8);
		memcpy(sac_string[19], sp->kcmpnm, 8);
		memcpy(sac_string[20], sp->knetwk, 8);
		memcpy(sac_string[21], sp->kdatrd, 8);
		memcpy(sac_string[22], sp->kinst, 8);
}
